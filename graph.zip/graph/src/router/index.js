import Vue from 'vue'
import Router from 'vue-router'
import CanvasDemo from '@/components/CanvasDemo'
import axios from 'axios'
Vue.prototype.$http = axios;

Vue.use(Router)

export const constantRouterMap = [
    {
        path: '/',
        name: 'CanvasDemo',
        component: () =>
            import ("@/components/CanvasDemo")
    },
    {
        path: '/demo2',
        name: 'demo2',
        component: () =>
            import ("@/components/demo2")
    }]

export default new Router({
    // mode: 'history', // require service support
    scrollBehavior: () => ({ y: 0 }),
    routes: constantRouterMap
});