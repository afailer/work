import request from '@/utils/request.js'

export function removeUsersFromOrg(orgCode, userCodelist) {
    return request({
        url: '/uaa/organization/removeUsersFromOrg?orgCode=' + orgCode,
        method: 'post',
        data: userCodelist
    })
}