import request from "@/utils/request";
export function getStartNodes() {
    const data = {
        ids: ["8"]
    };
    return request({
        url: "/model/v1/model/nodes/0/access",
        method: "post",
        data
    });
}

export function getNodesAndRel(uri) {
    return request({
        url: "/mdt/gremlin/query",
        method: "post",
        data: "return g.V().has('uri','" +
            uri +
            "').bothE().otherV().path().by(__.valueMap(true))"
    });
}