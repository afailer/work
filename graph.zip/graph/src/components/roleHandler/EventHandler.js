import { ElementStore } from "./ElementStore";
import { RoleController } from "./RoleController";
import Setting from "./setting";
export function EventHandler() {}
EventHandler.prototype = {
    activeEle: "", //当前点击被激活元素
    startDragEvent: {
        onDrag: false
    }, //拖拽canvas的起始事件
    startTime: 0, //激活元素被点击的起始时间，用于后期判断是否是双击，单击事件能不能被触发
    clientList: {}, //canvas系统的发布订阅
    listen: function(key, fn) {
        if (!EventHandler.prototype.clientList[key]) {
            EventHandler.prototype.clientList[key] = [];
        }
        EventHandler.prototype.clientList[key].push(fn);
    },
    trigger: function() {
        let key = Array.prototype.shift.call(arguments);
        let fns = EventHandler.prototype.clientList[key];
        if (!fns || fns.length === 0) {
            return false;
        }
        for (let l = 0; l < fns.length; l++) {
            fns[l].apply(this, arguments);
        }
    },
    handleClick: function(event) {
        for (let l = ElementStore.prototype.elements.length - 1; l >= 0; l--) {
            if (ElementStore.prototype.elements[l].caculate(event)) {
                alert("ok");
            }
        }
    },
    handleMouseDown: function(event) {
        for (let l = ElementStore.prototype.elements.length - 1; l >= 0; l--) {
            if (ElementStore.prototype.elements[l].caculate(event)) {
                if (new Date().getTime() - EventHandler.prototype.startTime < 300) {
                    ElementStore.prototype.elements[l].onDoubleClick();
                }
                EventHandler.prototype.startTime = new Date().getTime();
                EventHandler.prototype.activeEle = ElementStore.prototype.elements[l];
                EventHandler.prototype.activeEle.data.isActive = true;
                return;
            }
        }
        if (EventHandler.prototype.activeEle == "") {
            //拖拽画布
            EventHandler.prototype.trigger("drag", 0, 0, "down");
            EventHandler.prototype.startDragEvent.onDrag = true;
            EventHandler.prototype.startDragEvent.offsetX = event.offsetX;
            EventHandler.prototype.startDragEvent.offsetY = event.offsetY;
        }
    },
    handleMouseUp: function() {
        if (
            EventHandler.prototype.activeEle != "" &&
            new Date().getTime() - this.startTime < 300
        ) {
            EventHandler.prototype.trigger(
                "showInfo",
                EventHandler.prototype.activeEle.data
            );
            EventHandler.prototype.activeEle.onClick();
        }
        if (EventHandler.prototype.activeEle != "") {
            EventHandler.prototype.activeEle.data.isActive = false;
        }
        EventHandler.prototype.startDragEvent.onDrag = false;
        this.activeEle = "";
    },
    handleMouseMove: function(event) {
        if (this.activeEle != "") {
            this.activeEle.update(event);
        }

        if (EventHandler.prototype.startDragEvent.onDrag) {
            EventHandler.prototype.onDrag(event);
        }
        let showDetails = false;
        for (let l = ElementStore.prototype.elements.length - 1; l >= 0; l--) {
            if (ElementStore.prototype.elements[l].caculate(event)) {
                Setting.prototype.hoverElementId =
                    ElementStore.prototype.elements[l].data.id;
                EventHandler.prototype.trigger(
                    "showDetails",
                    ElementStore.prototype.elements[l].data
                );
                showDetails = true;
                return;
            }
            if (l == ElementStore.prototype.elements.length - 1) {
                Setting.prototype.hoverElementId = 0;
            }
        }
        if (!showDetails) {
            EventHandler.prototype.trigger("showDetails", false);
        }
    },
    onDrag: function(event) {
        let x = event.offsetX - EventHandler.prototype.startDragEvent.offsetX; //横坐标相对于起始位置移动了多少
        let y = event.offsetY - EventHandler.prototype.startDragEvent.offsetY; //纵坐标相对于起始位置移动了多少
        EventHandler.prototype.trigger("drag", x, y);
    }
};