import { CircleElement } from "./CircleElement";
import { RectElement } from "./RectElement";
import { LineElement } from "./LineElement";
import { ElementStore } from "./ElementStore";
import { BezierLineElement } from "./BezierLineElement";
import { format } from "util";

export function ElementCreator() {}
ElementCreator.prototype = {
    eleTypes: {
        circle: function(data) {
            return new CircleElement(data);
        },
        rect: function(data) {
            return new RectElement(data);
        },
        line: function(data) {
            return new LineElement(data);
        },
        BezierLine: function(data) {
            return new BezierLineElement(data);
        }
    },
    addElement: function(data) {
        ElementStore.prototype.saveElement(
            ElementCreator.prototype.eleTypes[data.eleType](data)
        );
    },
    addLines: function(datas) {
        let lines = [];
        for (let l = 0; l < datas.length; l++) {
            console.log(datas[l]);
            console.log(datas[l].type);
            lines.push(ElementCreator.prototype.eleTypes[datas[l].eleType](datas[l]));
        }
        ElementStore.prototype.saveLines(lines);
        console.log(ElementStore.prototype.elements);
    },
    addElements: function(datas) {
        for (let l = 0; l < datas.length; l++) {
            ElementCreator.prototype.addElement(datas[l]);
        }
    }
};