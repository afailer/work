import Setting from "./setting";
import { RoleController } from "./RoleController";
export function LineElement(data) {
    this.data = data;
}
LineElement.prototype = {
    draw: function(pen) {
        pen.beginPath(); //单起一个路径，不会被外部影响
        pen.lineWidth = Setting.prototype.lineWidth; //线条的宽度
        pen.strokeStyle = Setting.prototype.LineColor; //默认线条的颜色
        if (this.data.id == Setting.prototype.hoverElementId) {
            // 悬停时线条的颜色
            console.log(this.data.id + "----");
            pen.lineWidth = Setting.prototype.lineSelectWidth;
            pen.strokeStyle = Setting.prototype.lineHoverColor;
        }
        if (this.data.id == Setting.prototype.SelectElementId) {
            // 点击时线条的颜色
            pen.lineWidth = Setting.prototype.lineSelectWidth;
            pen.strokeStyle = Setting.prototype.lineSelectColor;
        }
        pen.moveTo(this.data.endPoint.x, this.data.endPoint.y);
        pen.lineTo(
            this.data.beginPoint.x + this.data.beginPoint.width / 2,
            this.data.beginPoint.y + this.data.beginPoint.height / 2
        );
        pen.stroke();
        pen.closePath();
        // 箭头
        let x1 = this.data.endPoint.x;
        let y1 = this.data.endPoint.y;
        let x2 = this.data.beginPoint.x + this.data.beginPoint.width / 2;
        let y2 = this.data.beginPoint.y + this.data.beginPoint.height / 2;
        let distance = Math.hypot(y2 - y1, x2 - x1); // 两点圆心间距
        let radius = Setting.prototype.CircleRadius; // 圆形节点的半径
        let vertexX = x1 + radius * (x2 - x1) / distance; // 箭头顶点，在圆上
        let vertexY = y1 + radius * (y2 - y1) / distance;
        let bevel = Setting.prototype.bevel; // 箭头长度
        let bevelAngle = Setting.prototype.bevelAngle; // 箭头两边夹角
        var rotate, xa, xb, ya, yb, translateX, translateY;
        if (x2 >= x1) {
            rotate = Math.asin((y2 - y1) / distance); // 旋转弧度
            translateY = distance / 2 * Math.sin(rotate);
            translateX = distance / 2 * Math.cos(rotate); // 圆心距离的中心点
        } else {
            rotate = Math.PI - Math.asin((y2 - y1) / distance); // 旋转弧度
            translateY = distance / 2 * Math.sin(rotate);
            translateX = distance / 2 * Math.cos(rotate);
        }
        if (x2 >= x1) {
            // 箭头微调的距离
            xa = bevel * Math.cos(rotate - bevelAngle / 2);
            ya = bevel * Math.sin(rotate - bevelAngle / 2);
            xb = bevel * Math.cos(rotate + bevelAngle / 2);
            yb = bevel * Math.sin(rotate + bevelAngle / 2);
        }
        if (x2 < x1) {
            xa = bevel * Math.cos(Math.PI - rotate + bevelAngle / 2);
            ya = bevel * Math.sin(Math.PI - rotate + bevelAngle / 2);
            xb = bevel * Math.cos(Math.PI - rotate - bevelAngle / 2);
            yb = bevel * Math.sin(Math.PI - rotate - bevelAngle / 2);
        }
        pen.beginPath();
        pen.lineWidth = Setting.prototype.lineWidth; // 箭头线条的宽度
        pen.strokeStyle = Setting.prototype.LineColor; // 箭头线条的颜色
        pen.fillStyle = Setting.prototype.LineColor;
        // if (this.data.id == Setting.prototype.hoverElementId) {
        //     // 悬停时箭头的颜色
        //     pen.fillStyle = Setting.prototype.lineHoverColor;
        // }
        // if (this.data.id == Setting.prototype.SelectElementId) {
        //     // 点击时箭头的颜色
        //     pen.fillStyle = Setting.prototype.lineSelectColor;
        // }

        if (x2 >= x1) {
            pen.moveTo(vertexX + xa, vertexY + ya); // 箭头左顶点
            pen.lineTo(vertexX, vertexY); // 圆上节点
            pen.lineTo(vertexX + xb, vertexY + yb); // 箭头右顶点
        }
        if (x2 < x1) {
            pen.moveTo(vertexX - xa, vertexY + ya);
            pen.lineTo(vertexX, vertexY);
            pen.lineTo(vertexX - xb, vertexY + yb);
        }
        pen.fill();
        pen.closePath();
        // 文字矩形
        let rectWidth = Setting.prototype.lineLabelWidth;
        let rectHeight = Setting.prototype.lineLabelHeight;
        let rectOriginX, rectOriginY;
        let rectbevel = Math.hypot(rectWidth, rectHeight) / 2; // 矩形内斜对角一半
        let rectInnerAngle = Math.asin(rectHeight / 2 / rectbevel); // 矩形内斜对角线和矩形宽的夹角
        pen.save();
        pen.beginPath();

        if (x2 >= x1) {
            // x1 + translateX 文字矩形左顶点位于 两点圆心距离的中心点
            rectOriginX =
                x1 + translateX - rectbevel * Math.cos(rotate + rectInnerAngle);
            rectOriginY =
                y1 + translateY - rectbevel * Math.sin(rotate + rectInnerAngle);
            pen.translate(rectOriginX, rectOriginY);
            pen.rotate(rotate);
        } else {
            rectOriginX =
                x1 + translateX + rectbevel * Math.cos(rotate + rectInnerAngle);
            rectOriginY =
                y1 + translateY + rectbevel * Math.sin(rotate + rectInnerAngle);
            pen.translate(rectOriginX, rectOriginY);
            pen.rotate(rotate - Math.PI);
        }
        // 点击文字 需要用到的参数
        this.rectOriginX = rectOriginX;
        this.rectOriginY = rectOriginY;
        this.rectWidth = rectWidth;
        this.rectHeight = rectHeight;

        pen.rect(0, 0, rectWidth, rectHeight);
        pen.fillStyle = Setting.prototype.lineLabelBg; // 矩形背景颜色
        pen.fill();

        pen.fillStyle = Setting.prototype.lineLabelText; // 字体颜色
        pen.font = `${Setting.prototype.lineLabelTextFont}px Arial`;
        if (this.data.id == Setting.prototype.hoverElementId) {
            // 悬停时字体的颜色
            pen.fillStyle = Setting.prototype.lineHoverColor;
            pen.font = `${Setting.prototype.lineLabelTextSelectFont}px Arial`;
        }
        if (this.data.id == Setting.prototype.SelectElementId) {
            // 点击时字体的颜色
            pen.fillStyle = Setting.prototype.lineSelectColor;
            pen.font = `${Setting.prototype.lineLabelTextSelectFont}px Arial`;
        }
        let maxLength = Setting.prototype.lineTextMaxLength;
        pen.textAlign = "center";
        pen.textBaseline = "middle";
        if (this.data.rel.length >= maxLength) {
            this.data.rel = this.data.rel.replace(
                this.data.rel.substring(maxLength),
                "..."
            );
        }
        pen.fillText(this.data.rel, rectWidth / 2, rectHeight / 2);

        pen.closePath();
        pen.restore();
    },
    caculate: function(event) {
        let x1 = this.data.endPoint.x;
        let y1 = this.data.endPoint.y;
        let x2 = this.data.beginPoint.x;
        let y2 = this.data.beginPoint.y;
        let x0 = event.offsetX - RoleController.prototype.translateX; // 点击页面的坐标
        let y0 = event.offsetY - RoleController.prototype.translateY;

        let x1x2 = Math.hypot(y2 - y1, x2 - x1); // 线的长度
        let x0x1 = Math.hypot(y0 - y1, x0 - x1); // 3条边距离
        let x0x2 = Math.hypot(y2 - y0, x2 - x0); // 3条边距离
        let perimeterHalf = (x1x2 + x0x1 + x0x2) / 2; // 三角形周长一半
        let mixDistance = 10; // 设置最小距离
        let lineDistance; // 点击点到线的距离

        if (x1 == x2) {
            // 竖线
            lineDistance = Math.abs(x0 - x1);
            if (x1 == x0) {
                return false;
            }
        } else if (y1 == y2) {
            // 横线
            lineDistance = Math.abs(y0 - y1);
            if (y1 == y0) {
                return false;
            }
        } else if (x1 > x2 && (x0 <= x2 || x0 >= x1)) {
            return false;
        } else if (x1 < x2 && (x0 <= x1 || x0 >= x2)) {
            return false;
        } else {
            lineDistance =
                2 *
                Math.sqrt(
                    perimeterHalf *
                    (perimeterHalf - x1x2) *
                    (perimeterHalf - x0x1) *
                    (perimeterHalf - x0x2)
                ) /
                x1x2;
        }
        if (lineDistance <= mixDistance) {
            return true;
        }
    },
    onClick: function(event) {
        Setting.prototype.SelectElementId = this.data.id;
    },
    update: function(beginPoint, endPoint) {
        this.beginPoint = beginPoint;
        this.endPoint = endPoint;
    },
    living: function() {
        let distanceX = Math.abs(this.data.beginPoint.x - this.data.endPoint.x);
        let distanceY = Math.abs(this.data.beginPoint.y - this.data.endPoint.y);
        let distance = Math.hypot(distanceX, distanceY);
        let SinT = (this.data.beginPoint.x - this.data.endPoint.x) / distance;
        let CosT = (this.data.beginPoint.y - this.data.endPoint.y) / distance;
        let offsetX = 0;
        let offsetY = 0;
        if (distance > 250) {
            offsetX = (distance - 250) * SinT * 0.2;
            offsetY = (distance - 250) * CosT * 0.2;
            if (offsetX > 0 && offsetX > 30) {
                offsetX = 30;
            }
            if (offsetX < 0 && offsetX < -30) {
                offsetX = -30;
            }
            if (offsetY > 0 && offsetY > 30) {
                offsetY = 30;
            }
            if (offsetY < 0 && offsetY < -30) {
                offsetY = -30;
            }
        }
        if (distance < 150) {
            offsetX = (distance - 150) * SinT * 0.2;
            offsetY = (distance - 150) * CosT * 0.2;
        }
        if (!this.data.beginPoint.isActive) {
            this.data.beginPoint.x -= offsetX;
            this.data.beginPoint.y -= offsetY;
        }
        if (!this.data.endPoint.isActive) {
            this.data.endPoint.x += offsetX;
            this.data.endPoint.y += offsetY;
        }
    }
};