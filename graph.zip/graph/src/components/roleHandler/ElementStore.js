export function ElementStore() {}
ElementStore.prototype = {
    elements: [],
    saveLines: function(lines) {
        ElementStore.prototype.elements.splice(0, 0, ...lines);
    },
    saveElement: ele => {
        ElementStore.prototype.elements.push(ele);
    },
    getElements: type => {
        let eles = [];
        for (let l = 0; l < ElementStore.prototype.elements.length; l++) {
            if (ElementStore.prototype.elements[l].data.type == type) {
                eles.push(ElementStore.prototype.elements[l]);
            }
        }
        console.log(eles);
        return eles;
    },
    resetData: () => {
        console.log("resetData");
        for (let l = 0; l < ElementStore.prototype.elements.length; l++) {
            if (ElementStore.prototype.elements[l].data.eleType == "circle") {
                console.log(ElementStore.prototype.elements[l]);
                ElementStore.prototype.elements[l].data.x = parseInt(
                    50 + Math.random() * 700
                );
                ElementStore.prototype.elements[l].data.y = parseInt(
                    50 + Math.random() * 700
                );
                ElementStore.prototype.elements[l].old_x =
                    ElementStore.prototype.elements[l].data.x;
                ElementStore.prototype.elements[l].old_y =
                    ElementStore.prototype.elements[l].data.y;
            }
        }
    }
};