import { ElementStore } from "./ElementStore";

export function RoleController(ctx) {
    this.canvas = ctx;
    this.pen = ctx.getContext("2d");
    this.main_loop = () => {
        this.pen.clearRect(0, 0, 9999, 9999);
        for (let l = 0; l < ElementStore.prototype.elements.length; l++) {
            ElementStore.prototype.elements[l].living();
            ElementStore.prototype.elements[l].draw(this.pen);
        }
        requestAnimationFrame(this.main_loop);
    };
    this.main_loop();
    this.currentX = 0;
    this.currentY = 0;
    this.onDrag = (x, y, eventType) => {
        if (eventType == "down") {
            this.currentX = 0;
            this.currentY = 0;
        } else {
            let translateX = x - this.currentX;
            let translateY = y - this.currentY;
            let shouldTransPen = false;
            if (RoleController.prototype.translateX + translateX < 0) {
                RoleController.prototype.translateX += translateX;
                this.currentX = x;
                shouldTransPen = true;
            } else {
                translateX = 0;
            }
            if (RoleController.prototype.translateY + translateY < 0) {
                RoleController.prototype.translateY += translateY;
                this.currentY = y;
                shouldTransPen = true;
            } else {
                translateY = 0;
            }
            if (shouldTransPen) {
                this.pen.translate(translateX, translateY);
            }
        }
    };
    this.backToStart = () => {
        this.pen.translate(-RoleController.prototype.translateX, -RoleController.prototype.translateY);
        RoleController.prototype.translateX = 0;
        RoleController.prototype.translateY = 0;
        ElementStore.prototype.resetData();
    };
}
RoleController.prototype = {
    translateX: 0,
    translateY: 0
};