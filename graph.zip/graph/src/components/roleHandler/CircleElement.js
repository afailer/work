import { ElementCreator } from "./ElementCreator";
import { RoleController } from "./RoleController";
import Setting from "./setting";
import { Util } from "./Util";
import { EventHandler } from "./EventHandler";
export function CircleElement(data) {
    this.old_x = data.x;
    this.old_y = data.y;
    this.isActive = false;
    this.data = data;
}
CircleElement.prototype = {
    caculate: function(event) {
        let x = event.offsetX - RoleController.prototype.translateX - this.data.x;
        let y = event.offsetY - RoleController.prototype.translateY - this.data.y;
        if (Math.sqrt(x * x + y * y) < Setting.prototype.CircleRadius) {
            return true;
        } else {
            return false;
        }
    },
    draw: function(pen) {
        pen.beginPath(); //单起一个路径，不会被外部影响
        pen.arc(
            this.data.x,
            this.data.y,
            Setting.prototype.CircleRadius,
            0,
            Math.PI * 2,
            false
        ); //圆心x,y,半径，起始弧度，最终弧度，顺时针(逆时针)
        pen.fillStyle = Setting.prototype.CircleBgColor;
        if (this.data.id == Setting.prototype.hoverElementId) {
            pen.fillStyle = Setting.prototype.CircleHoverBgColor;
        }
        if (this.data.id == Setting.prototype.SelectElementId) {
            pen.fillStyle = Setting.prototype.CircleSelectColor;
        }
        pen.fill();
        pen.stroke();

        // 文字
        let text = this.data.name;
        pen.fillStyle = Setting.prototype.CircleTextColor; // 字体颜色
        pen.font = `${Setting.prototype.CircleTextFont}px Arial`; // 字体大小
        if (this.data.id == Setting.prototype.hoverElementId) {
            // 悬停时字体的颜色
            pen.fillStyle = Setting.prototype.CircleTextHoverColor;
            pen.font = `${Setting.prototype.CircleTextSelectFont}px Arial`;
        }
        if (this.data.id == Setting.prototype.SelectElementId) {
            // 点击时字体的颜色
            pen.fillStyle = Setting.prototype.CircleTextSelectColor;
            pen.font = `${Setting.prototype.CircleTextSelectFont}px Arial`;
        }
        pen.textAlign = "center";
        pen.textBaseline = "middle";
        pen.fillText(text, this.data.x, this.data.y);
        pen.closePath();
    },
    update: function(event) {
        this.data.x = event.offsetX - RoleController.prototype.translateX;
        this.data.y = event.offsetY - RoleController.prototype.translateY;
        if (this.data.x - Setting.prototype.CircleRadius < 0) {
            this.data.x = Setting.prototype.CircleRadius;
        }
        if (this.data.y - Setting.prototype.CircleRadius < 0) {
            this.data.y = Setting.prototype.CircleRadius;
        }
    },
    living: function() {
        let vx = (this.data.x - this.old_x) * 0.92,
            vy = (this.data.y - this.old_y) * 0.92;
        this.old_x = this.data.x;
        this.old_y = this.data.y;
        if (!this.data.isActive) {
            this.data.x += vx;
            this.data.y += vy;
        }
        if (this.data.x - Setting.prototype.CircleRadius < 0) {
            this.data.x = Setting.prototype.CircleRadius;
            this.old_x = this.data.x + vx * 0.2;
        }
        if (this.data.y - Setting.prototype.CircleRadius < 0) {
            this.data.y = Setting.prototype.CircleRadius;
            this.old_y = this.data.y + vy * 0.2;
        }
        Util.prototype.changeTragetElement(this);
    },
    addChildren: function(datas) {
        ElementCreator.prototype.addElements(datas);
    },
    onClick: function() {
        Setting.prototype.SelectElementId = this.data.id;
    },
    onDoubleClick: function() {
        EventHandler.prototype.trigger("loadNewData", this.data);
    }
};