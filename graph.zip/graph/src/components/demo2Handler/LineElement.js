export function LineElement(data) {
    this.data = data;
    if (
        this.data.beginPoint.linkNum == undefined &&
        this.data.endPoint.linkNum == undefined
    ) {
        this.data.beginPoint.linkNum = this.data.beginPoint.id;
        this.data.endPoint.linkNum = this.data.beginPoint.id;
    }
    if (
        this.data.beginPoint.linkNum == undefined &&
        this.data.endPoint.linkNum != undefined
    ) {
        this.data.beginPoint.linkNum = this.data.endPoint.linkNum;
    }
    if (
        this.data.beginPoint.linkNum != undefined &&
        this.data.endPoint.linkNum == undefined
    ) {
        this.data.endPoint.linkNum = this.data.beginPoint.linkNum;
    }
}
LineElement.prototype = {
    draw: function(pen) {
        pen.beginPath(); //单起一个路径，不会被外部影响
        pen.lineWidth = 2; //线条的宽度
        pen.strokeStyle = "#333"; //线条的颜色
        pen.moveTo(this.data.endPoint.x, this.data.endPoint.y);
        pen.lineTo(
            this.data.beginPoint.x + this.data.beginPoint.width / 2,
            this.data.beginPoint.y + this.data.beginPoint.height / 2
        );
        pen.stroke();
        pen.closePath();
        // 箭头
        let x1 = this.data.endPoint.x;
        let y1 = this.data.endPoint.y;
        let x2 = this.data.beginPoint.x + this.data.beginPoint.width / 2;
        let y2 = this.data.beginPoint.y + this.data.beginPoint.height / 2;
        let distance = Math.hypot(y2 - y1, x2 - x1);        // 两点圆心间距
        let radius = 20;                                    // 圆形节点的半径
        let vertexX = x1 + radius * (x2 - x1) / distance;   // 箭头顶点，在圆上
        let vertexY = y1 + radius * (y2 - y1) / distance;
        let bevel = 20;                                     // 箭头斜边
        var rotate, xa, xb, ya, yb, translateX, translateY;
        if (x2 >= x1) {
            rotate = Math.asin((y2 - y1) / distance);           // 旋转弧度
            translateY = distance / 2 * Math.sin(rotate);
            translateX = distance / 2 * Math.cos(rotate);       // 圆心距离的中心点
        } else {
            rotate = Math.PI - Math.asin((y2 - y1) / distance); // 旋转弧度
            translateY = distance / 2 * Math.sin(rotate);
            translateX = distance / 2 * Math.cos(rotate);
        }
        if (x2 >= x1) {                                         // 箭头微调的距离
            xa = bevel * Math.cos(rotate - Math.PI / 8);
            ya = bevel * Math.sin(rotate - Math.PI / 8);
            xb = bevel * Math.cos(rotate + Math.PI / 8);
            yb = bevel * Math.sin(rotate + Math.PI / 8);
        }
        if (x2 < x1) {
            xa = bevel * Math.cos(Math.PI - rotate + Math.PI / 8);
            ya = bevel * Math.sin(Math.PI - rotate + Math.PI / 8);
            xb = bevel * Math.cos(Math.PI - rotate - Math.PI / 8);
            yb = bevel * Math.sin(Math.PI - rotate - Math.PI / 8);
        }
        pen.lineWidth = 2;
        pen.strokeStyle = "#333";
        pen.beginPath();
        if (x2 >= x1) {
            pen.moveTo(vertexX + xa, vertexY + ya); // 箭头左顶点
            pen.lineTo(vertexX, vertexY);           // 圆上节点
            pen.lineTo(vertexX + xb, vertexY + yb); // 箭头右顶点
            pen.closePath();
        }
        if (x2 < x1) {
            pen.moveTo(vertexX - xa, vertexY + ya);
            pen.lineTo(vertexX, vertexY);
            pen.lineTo(vertexX - xb, vertexY + yb);
            pen.closePath();
        }
        pen.fill();

        // 文字矩形
        let rectWidth = 60;
        let rectHeight = 20;
        let rectOriginX, rectOriginY;
        let rectbevel = Math.hypot(rectWidth, rectHeight) / 2; // 矩形内斜对角一半
        let rectInnerAngle = Math.asin(rectHeight / 2 / rectbevel); // 矩形内斜对角线和矩形宽的夹角
        pen.save();
        pen.beginPath();

        if (x2 >= x1) {
            // x1 + translateX 文字矩形左顶点位于 两点圆心距离的中心点
            rectOriginX = x1 + translateX - rectbevel * Math.cos(rotate + rectInnerAngle);
            rectOriginY = y1 + translateY - rectbevel * Math.sin(rotate + rectInnerAngle);
            pen.translate(rectOriginX, rectOriginY);
            pen.rotate(rotate);
        } else {
            rectOriginX = x1 + translateX + rectbevel * Math.cos(rotate + rectInnerAngle);
            rectOriginY = y1 + translateY + rectbevel * Math.sin(rotate + rectInnerAngle);
            pen.translate(rectOriginX, rectOriginY);
            pen.rotate(rotate - Math.PI);
        }
        // 点击文字 需要用到的参数
        this.rectOriginX = rectOriginX;
        this.rectOriginY = rectOriginY;
        this.rectWidth = rectWidth;
        this.rectHeight = rectHeight;

        pen.rect(0, 0, rectWidth, rectHeight);
        pen.fillStyle = "#058";                 // 矩形背景颜色
        pen.fill();

        pen.fillStyle = "#fff";                 // 字体颜色
        pen.font = "10px Arial";
        pen.textAlign = "center";
        pen.textBaseline = "middle";
        pen.fillText("1231123123", rectWidth / 2, rectHeight / 2, 60);

        pen.closePath();
        pen.restore();
    },
    caculate: function(event) {
        let x1 = this.data.endPoint.x;
        let y1 = this.data.endPoint.y;
        let x2 = this.data.beginPoint.x;
        let y2 = this.data.beginPoint.y;
        let x0 = event.offsetX;                  // 点击页面的坐标
        let y0 = event.offsetY;
        let x1x2 = Math.hypot(y2 - y1, x2 - x1); // 线的长度
        let x0x1 = Math.hypot(y0 - y1, x0 - x1); // 3条边距离
        let x0x2 = Math.hypot(y2 - y0, x2 - x0); // 3条边距离
        let perimeterHalf = (x1x2+x0x1+x0x2)/2;  // 三角形周长一半
        let mixDistance = 10;                    // 设置最小距离
        let lineDistance;                            // 点击点到线的距离
        if(x1 == x2) {
            // 竖线
            lineDistance = Math.abs(x0-x1);
            if(x1 == x0) {
                return false;
            }
        }else if(y1 == y2) {
            // 横线
            lineDistance = Math.abs(y0-y1);
            if(y1 == y0) {
                return false;
            }
        }
        else if (x1>x2 && (x0<=x2 || x0>=x1)){
            return false;
        }
        else if (x1<x2 && (x0<=x1 || x0>=x2)){
            return false;
        }
        else {
            lineDistance = 2 * Math.sqrt(perimeterHalf*(perimeterHalf-x1x2)*(perimeterHalf-x0x1)*(perimeterHalf-x0x2)) / x1x2;
        }
        if(lineDistance <= mixDistance) {
            return true;
        }
    },
    onClick: function(event) {
        console.log("点击线：line")
    },
    update: function(beginPoint, endPoint) {
        this.beginPoint = beginPoint;
        this.endPoint = endPoint;
    },
    living: function() {
        //endpoint 向beginPoint的方向移动
        let distanceX = Math.abs(this.data.beginPoint.x - this.data.endPoint.x);
        let distanceY = Math.abs(this.data.beginPoint.y - this.data.endPoint.y);
        let distance = Math.hypot(distanceX, distanceY);
        let SinT = (this.data.beginPoint.x - this.data.endPoint.x) / distance;
        let CosT = (this.data.beginPoint.y - this.data.endPoint.y) / distance;
        if (distance > 300) {
            let offsetX = (distance - 300) * SinT * 0.2;
            let offsetY = (distance - 300) * CosT * 0.2;
            if (!this.data.beginPoint.isActive) {
                this.data.beginPoint.x -= offsetX;
                this.data.beginPoint.y -= offsetY;
            }
            if (!this.data.endPoint.isActive) {
                this.data.endPoint.x += offsetX;
                this.data.endPoint.y += offsetY;
            }
        }
    }
};