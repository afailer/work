export function ElementStore() {}
ElementStore.prototype = {
    elements: [],
    saveLines: function(lines) {
        ElementStore.prototype.elements.splice(0, 0, ...lines);
    },
    saveElement: ele => {
        ElementStore.prototype.elements.push(ele);
    },
    getElement: data => {
        for (let l = 0; l < this.elements.length; l++) {
            if (ElementStore.prototype.elements.data.id == data.id) {
                return l;
            }
        }
        return -1;
    }
};