const ProcessData = {};
ProcessData.getCircleDatas = function(nodes) {
    let circles = [];
    for (let l = 0; l < nodes.length; l++) {
        let c = {};
        c.type = "circle";
        c.x = Math.ceil(50 + Math.random() * 700);
        c.y = Math.ceil(50 + Math.random() * 700);
        c.radius = 20;
        c.width = 0;
        c.height = 0;
        Object.assign(c, nodes[l]);
        circles.push(c);
    }
    return circles;
};
ProcessData.getRectDatas = function(nodes) {
    let rects = [];
    for (let l = 0; l < nodes.length; l++) {
        let rect = {};
        rect.type = "rect";
        rect.x = 50 + Math.random() * 700;
        rect.y = 50 + Math.random() * 700;
        rect.radius = 30;
        rect.width = 50;
        rect.height = 30;
        Object.assign(rect, nodes[l]);
        rects.push(rect);
    }
    return rects;
};
ProcessData.getLineDatas = (nodes, relations) => {
    let lines = [];
    for (let l = 0; l < relations.length; l++) {
        let line = {};
        line.type = ProcessData.getLineType(relations[l], relations);
        line.beginPoint =
            nodes[ProcessData.getTargetPoint(nodes, relations[l].startNode)];
        line.endPoint =
            nodes[ProcessData.getTargetPoint(nodes, relations[l].endNode)];
        lines.push(line);
    }
    return lines;
};
ProcessData.getTargetPoint = function(nodes, id) {
    for (let l = 0; l < nodes.length; l++) {
        if (nodes[l].id === id) {
            return l;
        }
    }
};
ProcessData.getLineType = function(rel, relations) {
    for (let l = 0; l < relations.length; l++) {
        if (
            relations[l].endNode == rel.startNode &&
            relations[l].startNode == rel.endNode
        ) {
            return "BezierLine";
        }
    }
    return "line";
};
ProcessData.test = function() {
    alert("datas");
};
export default ProcessData;