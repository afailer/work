import { ElementCreator } from "./ElementCreator";
import { RoleController } from "./RoleController";
import { Util } from "./Util";
export function CircleElement(data) {
    this.old_x = data.x;
    this.old_y = data.y;
    this.isActive = false;
    this.data = data;
}
CircleElement.prototype = {
    caculate: function(event) {
        let x = event.offsetX - RoleController.prototype.translateX - this.data.x;
        let y = event.offsetY - RoleController.prototype.translateY - this.data.y;
        if (Math.sqrt(x * x + y * y) < this.data.radius) {
            return true;
        }
    },
    draw: function(pen) {
        pen.beginPath(); //单起一个路径，不会被外部影响
        pen.arc(this.data.x, this.data.y, this.data.radius, 0, Math.PI * 2, false); //圆心x,y,半径，起始弧度，最终弧度，顺时针(逆时针)
        pen.fillStyle = "#ccc"; //this.data.bg;
        pen.strokeStyle = "#ff0000"; //this.data.border
        pen.fill();
        pen.stroke();
        pen.closePath();
    },
    update: function(event) {
        this.data.x = event.offsetX - RoleController.prototype.translateX;
        this.data.y = event.offsetY - RoleController.prototype.translateY;
        if (this.data.x - this.data.radius < 0) {
            this.data.x = this.data.radius;
        }
        if (this.data.y - this.data.radius < 0) {
            this.data.y = this.data.radius;
        }
    },
    living: function() {
        let vx = (this.data.x - this.old_x) * 0.92,
            vy = (this.data.y - this.old_y) * 0.92;
        this.old_x = this.data.x;
        this.old_y = this.data.y;
        if (!this.data.isActive) {
            this.data.x += vx;
            this.data.y += vy;
        }
        if (this.data.x - this.data.radius < 0) {
            this.data.x = this.data.radius;
            this.old_x = this.data.x + vx * 0.2;
        }
        if (this.data.y - this.data.radius < 0) {
            this.data.y = this.data.radius;
            this.old_y = this.data.y + vy * 0.2;
        }
        Util.prototype.changeTragetElement(this);
    },
    addChildren: function(datas) {
        ElementCreator.prototype.addElements(datas);
    },
    onClick: function() {}
};