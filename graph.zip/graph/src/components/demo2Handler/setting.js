const Setting = {};
Setting.prototype = {
    defaultBorder: 0.1,
    defaultBorderColor: "#ccc",
    RectBgColor: "#f0f",
    RectWidth: 50,
    RectHeight: 30,
    CircleBgColor: "#ff0000",
    CircleRadius: 20, //圆的半径
    CircleHoverBgColor: "#00ff00",
    CircleSelectColor: "#0000ff",
    lineWidth: 2, //线的宽度
    lineSelectWidth: 4, //线被选中时的宽度
    LineColor: "#333", //线的正常颜色
    lineSelectColor: "#0fff00", //线被选中时的颜色
    lineHoverColor: "#0f00f0", //鼠标经过线时的颜色
    lineLabelBg: "#FFFFFF", //线label的背景
    lineLabelWidth: 60, //线label的宽度
    lineLabelHeight: 10, //线label的高度
    hoverElementId: 0, //当时鼠标经过的元素的id
    SelectElementId: 0 //当前被选中元素的id
};
export default Setting;