import { ElementCreator } from "./ElementCreator";
import { EventHandler } from "./EventHandler";
export function RectElement(data) {
    this.data = data;
}
RectElement.prototype = {
    caculate: function(event) {
        let x = event.offsetX - this.data.x;
        let y = event.offsetY - this.data.y;
        if (x > 0 && x < this.data.width && y > 0 && y < this.data.height) {
            return true;
        }
    },
    draw: function(pen) {
        // console.log(this.data.width + " " + this.data.height);
        pen.beginPath(); //单起一个路径，不会被外部影响
        pen.rect(this.data.x, this.data.y, this.data.width, this.data.height);
        pen.fillStyle = this.data.bg;
        pen.strokeStyle = this.data.border;
        pen.fill();
        pen.stroke();
    },
    update: function(event) {
        this.data.x = event.offsetX - this.data.width / 2;
        this.data.y = event.offsetY - this.data.height / 2;
    },
    onClick: function() {
        EventHandler.prototype.trigger("eleClick", "aaa");
        this.addChildren(this.children);
    },
    living: function() {}
};