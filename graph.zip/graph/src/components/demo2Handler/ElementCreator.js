import { CircleElement } from "./CircleElement";
import { RectElement } from "./RectElement";
import { LineElement } from "./LineElement";
import { ElementStore } from "./ElementStore";
import { BezierLineElement } from "./BezierLineElement";
import { format } from "util";

export function ElementCreator() {}
ElementCreator.prototype = {
    types: {
        circle: function(data) {
            return new CircleElement(data);
        },
        rect: function(data) {
            return new RectElement(data);
        },
        line: function(data) {
            return new LineElement(data);
        },
        BezierLine: function(data) {
            return new BezierLineElement(data);
        }
    },
    addElement: function(data) {
        ElementStore.prototype.saveElement(
            ElementCreator.prototype.types[data.type](data)
        );
    },
    addLines: function(datas) {
        let lines = [];
        for (let l = 0; l < datas.length; l++) {
            lines.push(ElementCreator.prototype.types[datas[l].type](datas[l]));
        }
        ElementStore.prototype.saveLines(lines);
    },
    addElements: function(datas) {
        for (let l = 0; l < datas.length; l++) {
            ElementCreator.prototype.addElement(datas[l]);
        }
    }
};