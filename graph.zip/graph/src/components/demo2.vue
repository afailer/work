<template>
  <div class="canvas-container">
    <input type="button" value="backToStart" @click="backToStart"/>
    <canvas ref="canvas" width="800" height="800" class="canvas"></canvas>
  </div>
</template>

<script>
import { RoleController } from "./demo2Handler/RoleController";
import { EventHandler } from "./demo2Handler/EventHandler";
import { ElementCreator } from "./demo2Handler/ElementCreator";
import ProcessData from "./demo2Handler/ProcessData";
export default {
  name: "CanvasDemo",
  data() {
    return {
     nodes: [
        {
          id: 1,
          name: "a"
        },
        {
          id: 2,
          name: "b"
        },
        {
          id: 3,
          name: "b"
        },
        {
          id: 4,
          name: "b"
        },
        {
          id: 5,
          name: "b"
        },
        {
          id: 6,
          name: "b"
        }
      ],
      relationships: [
        {
          startNode: 1,
          endNode: 2,
          rel: "friends"
        },
        {
          startNode: 2,
          endNode: 1,
          rel: "friends"
        },
        {
          startNode: 2,
          endNode: 3,
          rel: "friends"
        },
        {
          startNode: 4,
          endNode: 5,
          rel: "friends"
        }
      ],
      elements: [
        {
          type: "rect",
          bg: "#ff0",
          border: "#f0f",
          name: "dsf"
        }
      ],
      circleDatas: [],
      lines: [],
      roleCtrl: ""
    };
  },
  methods: {
    getCircleDatas() {
      this.circleDatas.splice(0, 0, ...ProcessData.getCircleDatas(this.nodes));
    },
    getLineDatas() {
      this.lines.splice(
        0,
        0,
        ...ProcessData.getLineDatas(this.circleDatas, this.relationships)
      );
    },
    backToStart() {
      this.roleCtrl.backToStart();
    },
    initCanvas() {
      this.roleCtrl = new RoleController(this.$refs.canvas);
      EventHandler.prototype.listen("eleClick", function(a) {
  
      });
      EventHandler.prototype.listen("drag", (x, y, eventType) => {
        this.roleCtrl.onDrag(x, y, eventType);
      });
      this.$refs.canvas.addEventListener(
        "mousedown",
        event => EventHandler.prototype.handleMouseDown(event),
        false
      );
      this.$refs.canvas.addEventListener(
        "mouseup",
        event => EventHandler.prototype.handleMouseUp(event),
        false
      );
      this.$refs.canvas.addEventListener(
        "mousemove",
        event => EventHandler.prototype.handleMouseMove(event),
        false
      );
    },
    resetData() {
      let rects = ProcessData.getRectDatas(this.elements);
      ElementCreator.prototype.addElements(rects);
      ElementCreator.prototype.addElements(this.circleDatas);
      ElementCreator.prototype.addLines(this.lines);
    }
  },
  mounted() {
    this.getCircleDatas();
    this.getLineDatas();
    this.initCanvas();
    this.resetData();
  }
};
</script>

<style scoped>
.canvas-container {
  width: 100%;
  height: 100%;
}
.canvas {
  background: #058;
}
</style>
