import { login, registe, logout, getInfo, getMenu } from '@/api/login'
import { getToken, setToken, removeToken } from '@/utils/auth'
import menus from '@/utils/menus'

const user = {
    state: {
        token: getToken(),
        name: '',
        avatar: '',
        roles: [],
        menu: menus.platform,
        projectId:'',
        namespace:'',
        listInfoName:"",
        projectNameSpace:"",
        modelNumber:"",
        routerFrom:""
    },

    mutations: {
        //赋值
        SET_PROJECTNAMESPACE: (state, namespace) => {
            state.projectNameSpace = namespace
        },

        SET_LISINFONAME: (state, listinforname) => {
            state.listInfoName = listinforname
        },

        SET_MODELNUMBER: (state, number) => {
            state.modelNumber = number
        },

        SET_ROUTERFROM: (state, name) => {
            state.routerFrom = name
        },



        SET_TOKEN: (state, token) => {
            state.token = token
        },
        SET_NAME: (state, name) => {
            state.name = name
        },
        SET_AVATAR: (state, avatar) => {
            state.avatar = avatar
        },
        SET_ROLES: (state, roles) => {
            state.roles = roles
        },
        GET_MENU: (state, menu) => {
            state.menu = menu
        },
        SWITCH_MENU:(state,type)=>{
            state.menu = menus[type]
        },
        CHANGE_PROJECTID:(state,type)=>{
            state.projectId = type
        },
        CHANGE_NAMESPACE:(state,type)=>{
            state.namespace = type
        },
    },

    actions: {
        //赋值

        setProjectNameSpace({ commit }, type){
            commit('SET_PROJECTNAMESPACE', type)
        },

        setListInfoName({ commit }, type){
            commit('SET_LISINFONAME', type)
        },

        setModelnumber({ commit }, type){
            commit('SET_MODELNUMBER', type)
        },

        //保存from

        saveRouter({ commit }, name){
            commit('SET_ROUTERFROM', name)
        },



        //改变projectID
        changeProjectId({ commit }, type){
            commit('CHANGE_PROJECTID', type)
        },
        changeNameSpace({ commit }, type){
            commit('CHANGE_NAMESPACE', type)
        },



        // 获取菜单
        menu({ commit }, memuInfo) {
            commit('GET_MENU', memuInfo)
        },

        //路由切换

        switchMenus({commit},type){
           
            commit('SWITCH_MENU', type)
        },
        // 登录
        Login({ commit }, userInfo) {
            
            const username = userInfo.username.trim()
            return new Promise((resolve, reject) => {
                login(username, userInfo.password).then(response => {
                    const data = response.data
                    setToken(data.token)
                    commit('SET_TOKEN', data.token)
                    

                    // getMenu().then(res => {

                    //     state.menu = res.menuSet
                    // })
                    resolve()
                }).catch(error => {
                    reject(error)
                })
            })
        },
        // 注册
        Registe({ commit }, userInfo) {
            // debugger
            const username = userInfo.username.trim()
            return new Promise((resolve, reject) => {
                registe(username, userInfo.password).then(response => {
                    const data = response.data
                    setToken(data.token)
                    commit('SET_TOKEN', data.token)
                        // debugger

                    // getMenu().then(res => {

                    //     state.menu = res.menuSet
                    // })
                    resolve()
                }).catch(error => {
                    reject(error)
                })
            })
        },

        // 获取用户信息
        GetInfo({ commit, state }) {
            return new Promise((resolve, reject) => {
                getInfo(state.token).then(response => {
                    const data = response.data
                    commit('SET_ROLES', data.roles)
                    commit('SET_NAME', data.name)
                    commit('SET_AVATAR', data.avatar)
                    resolve(response)
                }).catch(error => {
                    reject(error)
                })
            })
        },

        // 登出
        LogOut({ commit, state }) {
            return new Promise((resolve, reject) => {
                logout(state.token).then(() => {
                    commit('SET_TOKEN', '')
                    commit('SET_ROLES', [])
                    removeToken()
                    resolve()
                }).catch(error => {
                    reject(error)
                })
            })
        },

        // 前端 登出
        FedLogOut({ commit }) {
            return new Promise(resolve => {
                commit('SET_TOKEN', '')
                removeToken()
                resolve()
            })
        }
    }
}

export default user