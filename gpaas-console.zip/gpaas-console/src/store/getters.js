const getters = {
    sidebar: state => state.app.sidebar,
    token: state => state.user.token,
    avatar: state => state.user.avatar,
    name: state => state.user.name,
    roles: state => state.user.roles,
    menus: state => state.user.menu,
    projectId: state => state.user.projectId,
    namespace: state => state.user.namespace,

    listInfoName: state => state.user.listInfoName,
    projectNameSpace: state => state.user.projectNameSpace,
    modelNumber: state => state.user.modelNumber,
    routerFrom: state => state.user.routerFrom,
}
export default getters