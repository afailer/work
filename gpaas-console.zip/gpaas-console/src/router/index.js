import Vue from 'vue'
import Router from 'vue-router'

// in development-env not use lazy-loading, because lazy-loading too many pages will cause webpack hot update too slow. so only in production use lazy-loading;
// detail: https://panjiachen.github.io/vue-element-admin-site/#/lazy-loading

Vue.use(Router)

/* Layout */
import Layout from '../views/layout/Layout'

/**
* hidden: true                   if `hidden:true` will not show in the sidebar(default is false)
* alwaysShow: true               if set true, will always show the root menu, whatever its child routes length
*                                if not set alwaysShow, only more than one route under the children
*                                it will becomes nested mode, otherwise not show the root menu
* redirect: noredirect           if `redirect:noredirect` will no redirct in the breadcrumb
* name:'router-name'             the name is used by <keep-alive> (must set!!!)
* meta : {
    title: 'title'               the name show in submenu and breadcrumb (recommend set)
    icon: 'svg-name'             the icon show in the sidebar,
  }
**/
export const constantRouterMap = [{
    path: '/login',
    component: () =>
        import('@/views/login/index'),
    hidden: true
},
{
    path: '/404',
    component: () =>
        import('@/views/404'),
    hidden: true
},

// {
//     path: '/',
//     component: Layout,
//     redirect: '/index',
//     name: '',
//     hidden: true,
//     // children: [{
//     //     path: 'dashboard',
//     //     component: () =>
//     //         import ('@/views/dashboard/index')
//     // }]
// },



{
    path: '/',
    component: Layout,
    redirect: '/dashboard',
    name: 'Dashboard',
    hidden: true,
    children: [{
      path: 'dashboard',
      component: () => import('@/views/dashboard')
    }]
  },
//改版路由 平台管理员

{
    path: '/plant',
    component: Layout,
    redirect: '/plant/tenantManager',
    children: [{
        path: 'tenantManager',
        name: 'Tenant',
        component: () =>
            import('@/views/platformManager/tenant/tenantManager'),
        meta: { title: '租户管理', icon: 'form' }
    },
    {
        path: 'roleManager', //平台管理员
        name: 'role',
        component: () =>
            import('@/views/platformManager/tenant/roleManager'),
        meta: { title: '角色及权限管理', icon: 'form' }
    },
    ]
},

{
    path: '/plantConsole',
    component: Layout,
    redirect: '/plantConsole/nodeManager',
    name: 'plantconsole',
    children: [{
        path: 'nodeManager',
        name: 'plantNode',
        component: () =>
            import('@/views/platformManager/resourceManager/node'),
        meta: { title: '节点管理', icon: 'form' }
    },
    {
        path: 'imageManager', //平台管理员
        name: 'plantImage',
        component: () =>
            import('@/views/platformManager/resourceManager/image'),
        meta: { title: '镜像库管理', icon: 'form' }
    },

    {
        path: 'projectManager', //平台管理员
        name: 'plantProject',
        component: () =>
            import('@/views/platformManager/projectManager/project'),
        meta: { title: '项目管理', icon: 'form' }
    },
    
    ]
},
//平台管理员项目管理
{
    path: '/plantProject',
    component: Layout,
    redirect: '/plantProject/applictionManager',
    name: 'plantproject',
    children: [{
        path: 'applictionManager',
        name: 'plantAppliction',
        component: () =>
            import('@/views/platformManager/resourceManager/node'),
        meta: { title: '应用管理', icon: 'form' }
    },
    {
        path: 'imageManager', //平台管理员
        name: 'plantImage',
        component: () =>
            import('@/views/platformManager/resourceManager/image'),
        meta: { title: '服务管理', icon: 'form' }
    },

    {
        path: 'projectManager', //平台管理员
        name: 'plantProject',
        component: () =>
            import('@/views/platformManager/projectManager/project'),
        meta: { title: '配置管理', icon: 'form' }
    },
    
    ]
},


//改版路由租户管理员
{
    path: '/tenant',
    component: Layout,
    redirect: '/tenant/nodeManager',
    name: 'nodeManager',
    children: [{
        path: 'nodeManager',  //节点管理
        name: 'tenantNode',
        component: () =>
            import('@/views/tenantManager/resourceManager/node'),
        meta: { title: '节点管理', icon: 'tree' }
    },
    {
        path: 'imageManager', //
        name: 'tenantImage',
        component: () =>
            import('@/views/tenantManager/resourceManager/image'),
        meta: { title: '镜像库管理', icon: 'form' }
    },

    {
        path: 'projectManager', //
        name: 'tenantProject',
        component: () =>
            import('@/views/tenantManager/projectManager/project'),
        meta: { title: '项目管理', icon: 'form' }
    },

    {
        path: 'auditManager', //
        name: 'tenantAudit',
        component: () =>
            import('@/views/tenantManager/auditManager/audit'),
        meta: { title: '审计管理', icon: 'form' }
    },

    {
        path: 'ciphertextManager',     //密文管理
        name: 'tenantCiphertext',
        component: () =>
            import('@/views/tenantManager/ciphertextManager/ciphertext'),
        meta: { title: '密钥管理', icon: 'form' }
    },

    {
        path: 'userManager', //
        name: 'tenantUser',
        component: () =>
            import('@/views/tenantManager/userManager/user'),
        meta: { title: '用户管理', icon: 'form' }
    },
    

    ]
},






//租户管理员 管理项目

//租户管理员项目管理
{
    path: '/tenantProject',
    component: Layout,
    redirect: '/tenant/projectManager',
    name: 'tenantproject',
    meta: { title: '管理项目', icon: 'tree' },
    children: [{
        path: 'appliction',
        name: 'tenantAppliction',
        component: () =>
            import('@/views/tenantManager/projectManager/application'),
        meta: { title: '应用管理', icon: 'form' },
        // children: [{
        //     path: 'applicationDetail',
        //     name: 'applicationDetail',
        //     component: () =>
        //         import('@/views/tenantManager/projectManager/applicationDetail'),
        //     meta: { title: '应用详情',icon: 'form'}
        //   }]
    },
    {
        path: 'applicationDetail',
        name: 'applicationDetail',
        component: () =>
            import('@/views/tenantManager/projectManager/applicationDetail'),
        meta: { title: '应用详情',icon: 'form'}
    },
    {
        path: 'service',     //服务管理
        name: 'tenantService',
        component: () =>
            import('@/views/tenantManager/projectManager/service'),
        meta: { title: '服务管理', icon: 'form' },
        children:[
            {
                path: '',     //服务管理 订购列表
                name: 'tenantServiceSub',
                component: () =>
                    import('@/views/tenantManager/projectManager/component/serviceSubList'),
            },
            {
                path: 'bind',     //服务管理 绑定列表
                name: 'tenantServiceBind',
                component: () =>
                    import('@/views/tenantManager/projectManager/component/serviceBindList'),
            },
            {
                path: 'monitor',     //服务管理 監控
                name: 'tenantServiceMonitor',
                component: () =>
                    import('@/views/tenantManager/projectManager/component/serviceMonitor'),
            }
        ]
    },
    {
        path: 'storage',     //存储管理
        name: 'tenantStorage',
        component: () =>
            import('@/views/tenantManager/projectManager/storage'),
        meta: { title: '存储管理', icon: 'form' }
    },
    // {
    //     path: 'ciphertext',     //密文管理
    //     name: 'tenantStorage',
    //     component: () =>
    //         import('@/views/tenantManager/projectManager/ciphertext'),
    //     meta: { title: '密钥管理', icon: 'form' }
    // },
   

    {
        path: 'configure', //平台管理员
        name: 'tenantConfigure',
        component: () =>
            import('@/views/tenantManager/projectManager/configure'),
        meta: { title: '配置管理', icon: 'form' }
    },
    
    ]
},



//用户
{
    path: '/user',
    component: Layout,
    redirect: '/user/projectManager',
    name: 'userProject',
    children: [{
        path: 'nodeManager',  //节点管理
        name: 'userNode',
        component: () =>
            import('@/views/user/node'),
        meta: { title: '节点管理', icon: 'tree' }
    },
    {
        path: 'imageManager', //
        name: 'userImage',
        component: () =>
            import('@/views/user/image'),
        meta: { title: '镜像库管理', icon: 'form' }
    },

    {
        path: 'projectManager', //
        name: 'userProject',
        component: () =>
            import('@/views/user/project'),
        meta: { title: '项目管理', icon: 'form' }
    },
    

    ]
},









{ path: '*', redirect: '/404', hidden: true }
]

export default new Router({
    // mode: 'history', //后端支持可开
    scrollBehavior: () => ({ y: 0 }),
    routes: constantRouterMap
})