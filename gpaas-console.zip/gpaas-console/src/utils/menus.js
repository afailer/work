const menus = {
    "tenant": [{
        "id": "1",
        "name": "租户管理员",
        "path": "/",
        "children": [

            {
                "id": "01",
                "name": "系统面板",
                "path": "/dashboard",
                "icon":"sys",
                "children": [

                ]
            },
            {
                "id": "11",
                "name": "资源管理",
                "path": "/2",
                "icon":"resource",
                "children": [
                    {
                        "id": "111",
                        "name": "节点管理",
                        "icon":"node",
                        "path": "/tenant/nodeManager",
                        "children": []
                    },
                    {
                        "id": "112",
                        "name": "镜像库管理",
                        "icon":"img",
                        "path": "/tenant/imageManager",
                        "children": []
                    },

                ]
            },
            {
                "id": "12",
                "name": "项目管理",
                "icon":"project",
                "path": "/3",
                "children": [
                    {
                        "id": "121",
                        "name": "项目列表",
                        "icon":"project",
                        "path": "/tenant/projectManager",
                        "children": []
                    },

                ]
            },
            {
                "id": "15",
                "name": "审计管理",
                "icon":"shenji",
                "path": "/4",
                "children": [
                    {
                        "id": "131",
                        "name": "审计列表",
                        "icon":"shenji",
                        "path": "/tenant/auditManager",
                        "children": []
                    },

                ]
            },

            {
                "id": "48",
                "name": "密钥管理",
                "icon":"shenji",
                "path": "/10",
                "children": [
                    {
                        "id": "142",
                        "name": "密钥管理",
                        "icon":"shenji",
                        "path": "/tenant/ciphertextManager",
                        "children": []
                    },
    
                ]
            },
            {
                "id": "13",
                "name": "用户管理",
                "icon":"user1",
                "path": "/5",
                "children": [
                    {
                        "id": "131",
                        "name": "用户管理",
                        "icon":"user1",
                        "path": "/tenant/userManager",
                        "children": []
                    },
                    // {
                    //     "id": "132",
                    //     "name": "角色及权限管理",
                    //     "icon":"role",
                    //     "path": "/4",
                    //     "children": []
                    // },

                ]
            }
        ]
    }],

    "tenantProject": [{
        "id": "2",
        "name": "项目控制台",
        "path": "/",
        // "children": [{
        //     "id": "21",
        //     "name": "项目管理",
        //     "path": "/2",
        "children": [
            {
                "id": "211",
                "name": "应用管理",
                "icon":"application",
                "path": "/tenantProject/appliction",
                "children": []
            },
            {
                "id": "212",
                "name": "服务管理",
                "icon":"servce",
                "path": "/tenantProject/service",
                "children": []
            },
            {
                "id": "213",
                "name": "存储管理",
                "icon":"memory",
                "path": "/tenantProject/storage",
                "children": []
            },
            {
                "id": "214",
                "name": "配置管理",
                "icon":"setting",
                "path": "/tenantProject/configure",
                "children": []
            },
            // {
            //     "id": "215",
            //     "name": "密钥管理",
            //     "icon":"key",
            //     "path": "/tenantProject/ciphertext",
            //     "children": []
            // },
           


        ]
        // },

        // ]
    }],


    "platform": [{
        "id": "3",
        "name": "平台管理菜单",
        "path": "/",
        "children": [{
            "id": "31",
            "name": "系统面板",
            "icon":"sys",
            "path": "/dashboard",
            "children": []
        },
        {
            "id": "32",
            "name": "租户管理",
            "icon":"user1",
            "path": "/2",
            "children": [
                {
                    "id": "321",
                    "name": "租户管理",
                    "icon":"user1",
                    "path": "/plant/tenantManager",
                    "children": []
                },
                {
                    "id": "322",
                    "name": "角色管理",
                    "icon":"role",
                    "path": "/plant/roleManager",
                    "children": []
                }
            ]
        }
        ]
    }],
    "platConsole": [{
        "id": "4",
        "name": "租户控制台",
        "path": "/",
        "children": [{
            "id": "41",
            "name": "资源管理",
            "icon":"resource",
            "path": "/2",
            "children": [
                {
                    "id": "411",
                    "name": "节点管理",
                    "icon":"node",
                    "path": "/plantConsole/nodeManager",
                    "children": []
                },
                {
                    "id": "412",
                    "name": "镜像库管理",
                    "icon":"img",
                    "path": "/plantConsole/imageManager",
                    "children": []
                },

            ]
        },
        {
            "id": "42",
            "name": "项目管理",
            "icon":"project",
            "path": "/3",
            "children": [
                {
                    "id": "421",
                    "name": "项目列表",
                    "icon":"project",
                    "path": "/plantConsole/projectManager",
                    "children": []
                },

            ]
        },

        {
            "id": "46",
            "name": "审计管理",
            "icon":"shenji",
            "path": "/9",
            "children": [
                {
                    "id": "141",
                    "name": "审计列表",
                    "icon":"shenji",
                    "path": "/tenant/auditManager",
                    "children": []
                },

            ]
        },

        
        // {
        //     "id": "43",
        //     "name": "用户管理",
        //     "icon":"user1",
        //     "path": "/3",
        //     "children": [
        //         {
        //             "id": "431",
        //             "name": "用户管理",
        //             "icon":"user1",
        //             "path": "/4",
        //             "children": []
        //         },
        //         // {
        //         //     "id": "432",
        //         //     "name": "角色及权限管理",
        //         //     "icon":"role",
        //         //     "path": "/4",
        //         //     "children": []
        //         // },

        //     ]
        // }
        ]
    }],
    "plantProject": [{
        "id": "5",
        "name": "项目控制台",
        "path": "/",
        "children": [{
            "id": "51",
            "name": "项目管理",
            "path": "/2",
            "children": [
                {
                    "id": "511",
                    "name": "应用管理",
                    "path": "/plantConsole/nodeManager",
                    "children": []
                },
                {
                    "id": "512",
                    "name": "服务管理",
                    "path": "/plantConsole/nodeManager",
                    "children": []
                },
                {
                    "id": "513",
                    "name": "存储管理",
                    "path": "/plantConsole/nodeManager",
                    "children": []
                },
                {
                    "id": "514",
                    "name": "配置管理",
                    "path": "/plantConsole/nodeManager",
                    "children": []
                },
                {
                    "id": "515",
                    "name": "密文管理",
                    "path": "/plantConsole/nodeManager",
                    "children": []
                },


            ]
        },

        ]
    }],
    "user": [{
        "id": "6",
        "path": "/",
        "children": [{
            "id": "61",
            "name": "资源管理",
            "icon":"resource",
            "path": "/2",
            "children": [
                {
                    "id": "611",
                    "name": "节点管理",
                    "icon":"node",
                    "path": "/user/nodeManager",
                    "children": []
                },
                {
                    "id": "612",
                    "name": "镜像库管理",
                    "icon":"img",
                    "path": "/user/imageManager",
                    "children": []
                },

            ]
        },
        {
            "id": "62",
            "name": "项目管理",
            "icon":"project",
            "path": "/3",
            "children": [
                {
                    "id": "621",
                    "name": "项目列表",
                    "icon":"project",
                    "path": "/user/projectManager",
                    "children": []
                },

            ]
        }]
    }],
};
export default menus