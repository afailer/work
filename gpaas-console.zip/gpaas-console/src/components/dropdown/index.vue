<template>
    <div class="dropdownClass">
       

        <el-select style="height:27px"  v-if="JSON.parse(user).userType == 3 && showNumber == 1"     v-model="userID"   @change="changeUser()" placeholder="切换用户">
            <el-option  v-for="item in userData" :key="item.code" :label="item.username" :value="item.tenantId" >
            </el-option>
        </el-select>

        <el-select   v-if="JSON.parse(user).userType == 2 && showNumber == 2"  value-key="id"    v-model="project"   @change="changeProject()" placeholder="切换项目">
            <el-option  v-for="item in projectData" :key="item.id" :label="item.name" :value="item" >
            </el-option>
        </el-select>


    </div>

</template>
<script>
import { mapGetters } from "vuex";
export default {
  props: ["user"],

  data() {
    return {
      selectUser: "",
      selectProject: "",
      showNumber: "",
      userData: [],
      projectData:[],
      userID:"",
      project:{}
    };
  },

  created() {
    this.showNumber = sessionStorage.getItem("showMemun");

    if(this.showNumber == 1){
        this.getList();
    }else if(this.showNumber == 2){
        this.getProjectList();
    }
    
  },
  computed: {
    ...mapGetters(["routerFrom"])
  },
  methods: {
    FnSelectUser(info) {
      this.selectUser = info;
    },
    FnSelectProject(info) {
      this.selectProject = info;
    },

    //获取用户列表

    getList() {
      this.$http
        .get(
          "/cloud/tenant/queryAllUser?userType=2" +
            "&pageNum=1" +
            "&pageSize=1000"
        )
        .then(res => {
          this.userData = res.data.obj.result;
        });
    },

    //获取项目列表

    
    getProjectList() {     
      this.$http
        .get(
          "/cloud/project/queryCurrentUserProjectList?pageNum=1" +
            "&pageSize=1000"
        )
        .then(res => {
          this.projectData = res.data.obj.result;
        });
    },
    //切换uesr
    changeUser(){

     sessionStorage.setItem("tenantId", this.userID);

     this.$router.push({
          name: "plantconsole",
          query: { tenantId: this.userID }
        });
    },

    //切换项目

    changeProject(){

      debugger;
      let matched = this.$route.name



     sessionStorage.setItem("projectId", this.project.id);
     sessionStorage.setItem("namespace", this.project.namespace);
    this.$router.push({
          name: matched,
          query: { projectId: this.project.id,namespace:this.project.namespace }
        });

    }


  },
  watch: {
    $route(currentState, oldState) {
     
      if (currentState.fullPath.startsWith("/plantConsole")) {
        this.showNumber = 1;
        this.userID = sessionStorage.getItem("tenantId");
        this.getList();
      } else if(currentState.fullPath.startsWith("/tenantProject")) {
        this.showNumber = 2;
        this.project.id = sessionStorage.getItem("projectId");
        this.getProjectList();
      }else{
          this.showNumber = 3;
      }
    }
  }
};
</script>
<style>
.dropdownClass {
  display: inline-block;
}
.dropdownClass .el-dropdown {
  color: rgb(237, 239, 241);
}

.dropdownClass  input{
    width: 140px;
    height: 27px;
    border-radius: 2px;
}


</style>

