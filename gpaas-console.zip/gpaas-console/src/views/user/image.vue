<style scoped>
.filter-container {
  margin: 10px;
}
</style>
<template>
  <div class=" calendar-list-container">
    <!-- v-loading="listLoading" -->
    <el-table :key='tableKey' :data="imageData" element-loading-text="给我一点时间" border fit highlight-current-row style="width: 100%">
      <el-table-column align="center" label="名称" >
        <template slot-scope="scope">
          <span>{{scope.row.name}}</span>
        </template>
      </el-table-column>
     
      <el-table-column align="center" label="账户名" >
        <template slot-scope="scope">
          <span>{{scope.row.account}}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="地址" >
        <template slot-scope="scope">
          <span>{{scope.row.address}}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="类型" >
        <template slot-scope="scope">
          <span>{{scope.row.type |typeFilters}}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="创建时间" >
        <template slot-scope="scope">
          <span>{{scope.row.createTime |formatDatetwo}}</span>
        </template>
      </el-table-column>
      
       <el-table-column align="center" label="状态" >
        <template slot-scope="scope">
          <span>{{scope.row.approve | statesFilters}}</span>
        </template>
      </el-table-column>

    </el-table>

    <div class="pagination-container">
      <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[10,20,30, 50]" :page-size="100" layout="total, sizes, prev, pager, next, jumper" :total="total">
      </el-pagination>

    </div>

  </div>
</template>

<script>
// import { getTenementList } from '@/api/tenement'
export default {
  name: "complexTable",

  data() {
    return {
      currentPage: 1,
      imageData: [],
      tableKey: 0,
      total: null,
      pageSize: 10,
      listLoading: true,
      listQuery: {
        title: undefined
      },
    };
  },

  filters: {
    statesFilters: function(value) {
      switch (value) {
        case 3:
          return "未通过";
          break;
        case 1:
          return "待审核";
          break;
        case 2:
          return "通过";
          break;
      }
    },
    typeFilters: function(value) {
      switch (value) {
        case 1:
          return "阿里云镜像库";
          break;
        case 2:
          return "第三方镜像库";
          break;
      }
    },
    formatDatetwo: function(time) {
      var re = /-?\d+/;
      var m = re.exec(time);
      var d = new Date(parseInt(m[0]));
      var o = {
        "M+": d.getMonth() + 1, //month
        "d+": d.getDate(), //day
        "h+": d.getHours(), //hour
        "m+": d.getMinutes(), //minute
        "s+": d.getSeconds(), //second
        "q+": Math.floor((d.getMonth() + 3) / 3), //quarter
        S: d.getMilliseconds() //millisecond
      };
      var format = "yyyy-MM-dd";
      if (/(y+)/.test(format)) {
        format = format.replace(
          RegExp.$1,
          (d.getFullYear() + "").substr(4 - RegExp.$1.length)
        );
      }
      for (var k in o) {
        if (new RegExp("(" + k + ")").test(format)) {
          format = format.replace(
            RegExp.$1,
            RegExp.$1.length == 1
              ? o[k]
              : ("00" + o[k]).substr(("" + o[k]).length)
          );
        }
      }
      return format;
    }
  },
  created() {
    this.getList();
  },
  methods: {
    getList() {
      this.$http
        .get(
          "/cloud/mirror/getMirrorLibrarys?pageNum=" +
            this.currentPage +
            "&pageSize=" +
            this.pageSize +
            ""
        )
        .then(res => {
          this.total = res.data.obj.totalCount;
          this.imageData = res.data.obj.result;
        });
    },

    openCreate() {},
    handleFilter() {},
    handleSizeChange(val) {
      this.pageSize = val;
      this.getList();
    },

    //分页查询
    handleCurrentChange(val) {
      this.currentPage = val;
      this.getList();
    },
    handleModifyStatus(row, status) {},

   
  }
};
</script>
<style scoped>
.pagination-container {
  margin-top: 20px;
}
</style>
