<style scoped>
.filter-container{
    margin: 10px;
}
</style>
<template>
  <div class=" calendar-list-container">
    <div style="margin-left: 10px;">
        <el-table :key='tableKey' :data="table"  element-loading-text="给我一点时间" border fit highlight-current-row
        style="width: 100%">
        <el-table-column align="center" label="名称" >
            <template slot-scope="scope">
            <span>{{scope.row.name}}</span>
            </template>
        </el-table-column>
        <el-table-column align="center" label="类型" >
            <template slot-scope="scope">
            <span>{{scope.row.type | nodeFilters}}</span>
            </template>
        </el-table-column>
        <el-table-column align="center" label="CPU" >
            <template slot-scope="scope">
            <span>{{scope.row.cpu | cpuFilter}}</span>

            </template>
        </el-table-column>
        <el-table-column align="center" label="内存" >
            <template slot-scope="scope">
            <span>{{scope.row.memory | memoryFilter}}</span>
            </template>
        </el-table-column>
        <el-table-column align="center" label="存储大小" >
            <template slot-scope="scope">
            <span>{{scope.row.storageSize | storeFilter}}</span>
            </template>
        </el-table-column>
        <el-table-column align="center" label="状态" >
            <template slot-scope="scope">
            <span>{{scope.row.state | statesFilters}}</span>
            </template>
        </el-table-column>
        
        </el-table>

        <div class="pagination-container">
        <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[10,20,30, 50]" :page-size="100" layout="total, sizes, prev, pager, next, jumper" :total="total">
        </el-pagination>
        </div>
    </div> 
  </div>
</template>

<script>
export default {
  name: 'complexTable',

  data() {
    return {
      currentPage:1,
      pageSize:10,
      table:[],
      tableKey: 0,
      list: null,
      total: null,
      
      //是否可执行冻结操作
      // isFreeze : true,
     
    }
  },
  filters: {
    statesFilters:function(value){
      switch( value ){
        case 0 :
          return '不通过';
          break;
        case 1 :
          return '通过';
          break;
        case 2 :
          return '待审核';
          break;
        case 3 :
          return '冻结';
          break;
        case 4 :
          return '待释放';
          break;

      }
    },
    nodeFilters:function(value){
      switch( value ){
        case 1 :
          return '计算节点';
          break;
        case 2 :
          return '存储节点';
          break;
      }
    },
    cpuFilter:function(value){
      return value + "核";
    },
    memoryFilter:function(value){
      return value + "G";
    },
    storeFilter:function(value){
      return value + "G";
    }
  },
  created() {
    this.getList();
    // var getToken = Cookies.get('token')
    // console.log( 'token---------------------------------------')
    // console.log( getToken )
    // // debugger
    // var getUser = JSON.parse(Cookies.get('user'))
    // console.log( 'user---------------------------------------')
    // console.log( getUser.userType )
  },
  methods: {
    getList() {      
       this.$http.get('/cloud/node/queryNodeByPage?pageNum='+this.currentPage+'&pageSize='+this.pageSize+'').then(res => {
        this.total = res.data.obj.totalCount
        this.table = res.data.obj.result
        // console.log( res.data.obj.result )
      })
     
    },
    

    handleSizeChange(val) {
      // console.log( '------------handleSizeChange-----------')
      // console.log( val )
      this.pageSize = val;     
      this.getList();
    },
    handleCurrentChange(val) {
      // console.log( '------------handleCurrentChange-----------')
      // console.log( val )
      this.currentPage = val;
      this.getList();
      // this.listQuery.page = val
      // this.getList()
    },
    
    auditNode(){
      console.log( this.auditNodeForm)
    },
    
    auditNodeReject(){

    },
    
    changeType(){
      this.typeFormVisible= !this.typeFormVisible;
      this.auditNodeForm.cpu="";
      this.auditNodeForm.memory="";
      this.auditNodeForm.storageSize="";
      // console.log(this.typeFormVisible)
    }
    
  }
}
</script>
<style scoped>
.pagination-container{
    margin-top:20px;
}
</style>
