<template>
  <div class="dashboard-container">
    
    
    <panel-group    :user = "user"    @handleSetLineChartData="handleSetLineChartData"></panel-group>    
    <!-- <div class="dashboard-text">name:{{name}}
    </div>
    <div class="dashboard-text">roles:<span v-for='role in roles' :key='role'>{{role}}</span></div> -->
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import PanelGroup from './components/PanelGroup'
import Cookies from 'js-cookie'

const lineChartData = {
  newVisitis: {
    expectedData: [100, 120, 161, 134, 105, 160, 165],
    actualData: [120, 82, 91, 154, 162, 140, 145]
  },
 
}

export default {
  name: 'dashboard',

   components: {
    PanelGroup,
  },

   data() {
    return {
      lineChartData: lineChartData.newVisitis,
      user:"",
      userName:""
    }
  },

  created() {
    this.getuser();
    if( JSON.parse(this.user).userType == 1){
      this.$router.push({
          name: "userProject"
        });
    }
  },
 
  computed: {
    ...mapGetters([
      'name',
      'roles'
    ])
  },
   methods: {
    handleSetLineChartData(type) {
      this.lineChartData = lineChartData[type]
    },
     getuser(){
      //  debugger;
      this.user = Cookies.get('user')
      this.userName = JSON.parse(this.user).username
    },
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.dashboard {
  &-container {
    margin: 30px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
  }
}
</style>
