<style scoped>
.filter-container {
  margin: 10px;
}
</style>
<template>
  <div class=" calendar-list-container">
    <div class="filter-container" >
      <!-- <el-input @keyup.enter.native="handleFilter" style="width: 200px;" placeholder="请输入内容" v-model="listQuery.title"> -->
      <!-- </el-input> -->
      <!-- <el-button  type="primary" icon="el-icon-search" @click="handleFilter">搜索</el-button> -->
     
    </div>
<!-- v-loading="listLoading" -->
    <div style="margin-left:10px">
      <el-table :key='tableKey' :data="projectData"  element-loading-text="给我一点时间" border fit highlight-current-row
        style="width: 100%">
        <el-table-column align="center" label="项目名称" >
          <template slot-scope="scope">
            <span>{{scope.row.name}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="硬盘" >
          <template slot-scope="scope">
            <span>{{scope.row.storageSize | memoryFilters }}</span>
          </template>
        </el-table-column>
          <el-table-column align="center" label="内存总量" >
          <template slot-scope="scope">
            <span>{{scope.row.memory |statesFilters}}</span>
          </template>
        </el-table-column>
        
        <el-table-column align="center" label="cpu" >
          <template slot-scope="scope">
            <span>{{scope.row.cpu | statesFilter}}</span>
          </template>
        </el-table-column>
      
        <el-table-column align="center" label="项目状态" >
          <template slot-scope="scope">
            <span>{{scope.row.state |stateFilter}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="创建时间" >
          <template slot-scope="scope">
            <span>{{scope.row.createTime | formatDatetwo}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="描述" >
          <template slot-scope="scope">
            <span>{{scope.row.description}}</span>
          </template>
        </el-table-column>
        
      
        <el-table-column align="center" label="操作"  class-name="small-padding fixed-width">
          <template slot-scope="scope">
            <!-- <el-button type="primary" size="mini" @click="examine(scope.row)">审核</el-button> -->
            <el-button  size="mini" type="success" @click="editProject(scope.row)">查看详情 
            </el-button>
          
          <!-- <el-button  size="mini" type="danger" @click="goConsole(scope.row)">管理项目
            </el-button> -->
            
          </template>
        </el-table-column>
      </el-table>

        <div class="pagination-container">
            <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[10,20,30, 50]" :page-size="100" layout="total, sizes, prev, pager, next, jumper" :total="total">
            </el-pagination>
    
        </div>
    </div>
        <div style="">
            <el-dialog title="查看项目" :visible.sync="dialogCreateVisible">
            <div style="width:80%;margin:0 auto">
            <el-form ref="careatProgectForm"  :model="careatProgectForm" label-width="100px">
                <el-form-item label="项目名称" >
                    <el-input v-model="careatProgectForm.name" :disabled= "true"></el-input>
                </el-form-item>          
                <el-form-item label="cpu总量" >
                    <el-input v-model="careatProgectForm.cpu" :disabled="true">
                    
                    </el-input>
                </el-form-item> 

                <el-form-item label="内存总量"  >
                    <el-input v-model="careatProgectForm.memory"  :disabled="true">
                    
                    </el-input>
                </el-form-item>   
                <el-form-item label="硬盘总量" >
                    <el-input v-model="careatProgectForm.storageSize" :disabled= "true">
                    
                    </el-input>
                </el-form-item> 
                <el-form-item label="项目描述">
                    <el-input  type="textarea"  v-model="careatProgectForm.description" :disabled= "true">
                    
                    </el-input>
                </el-form-item> 
                
                
                <el-form-item>
                  
                    <el-button @click="dialogCreateVisible = false">关闭</el-button>
                </el-form-item>
                </el-form>
                </div>
            </el-dialog>
        </div>

  </div>
</template>

<script>
// import { getTenementList } from '@/api/tenement'
export default {
  name: "complexTable",

  data() {
    return {
      //创建项目
      careatProgectForm: {
        name: "",
        cpu: "",
        memory: "",
        storageSize: "",
        mirrorId: "",
        description:""
      },
      mirror:"",
      isEdit: false,
      currentPage: 1,
      projectData: [],
      tableKey: 0,
      total: null,
      pageSize: 10,
      listLoading: true,
      listQuery: {
        title: undefined
      },
      //创建用户
      dialogCreateVisible: false,
      tenantId:sessionStorage.getItem("tenantId"),
    };
  },

  filters: {
    statesFilters: function(value) {
      return value + "G";
    },
    statesFilter: function(value) {
      return value + "核";
    },
    memoryFilters: function(value) {
      return value + "G";
    },

    
    stateFilter: function(value){
      switch( value ){
        case 0 :
          return '创建失败';
          break;
        case 1 :
          return '创建成功';
          break;
        case 2 :
          return '命名空间创建成功';
          break;
        case 3 :
          return 'secrets创建成功';
          break;
      }
    },

    formatDatetwo: function(time) {
      var re = /-?\d+/;
      var m = re.exec(time);
      var d = new Date(parseInt(m[0]));
      var o = {
        "M+": d.getMonth() + 1, //month
        "d+": d.getDate(), //day
        "h+": d.getHours(), //hour
        "m+": d.getMinutes(), //minute
        "s+": d.getSeconds(), //second
        "q+": Math.floor((d.getMonth() + 3) / 3), //quarter
        S: d.getMilliseconds() //millisecond
      };
      var format = "yyyy-MM-dd";
      if (/(y+)/.test(format)) {
        format = format.replace(
          RegExp.$1,
          (d.getFullYear() + "").substr(4 - RegExp.$1.length)
        );
      }
      for (var k in o) {
        if (new RegExp("(" + k + ")").test(format)) {
          format = format.replace(
            RegExp.$1,
            RegExp.$1.length == 1
              ? o[k]
              : ("00" + o[k]).substr(("" + o[k]).length)
          );
        }
      }
      return format;
    },
  },
  created() {
    this.getList();
  },
  methods: {
    getList() {

      
      this.$http
        .get(
          "/cloud/project/queryTenantProjectByPage?pageNum=" +
            this.currentPage +
            "&pageSize=" +
            this.pageSize +"&tenantId="+this.tenantId
           
        )
        .then(res => {
          this.total = res.data.obj.totalCount;
          this.projectData = res.data.obj.result;
        });
    },

    openCreate() {},
    handleFilter() {},
    handleSizeChange(val) {
      this.pageSize = val;
      this.getList();
    },

    //分页查询
    handleCurrentChange(val) {
      this.currentPage = val;
      this.getList();
    },
    handleModifyStatus(row, status) {},
    resetTemp() {
      this.temp = {
        id: undefined,
        importance: 1,
        remark: "",
        timestamp: new Date(),
        title: "",
        status: "通过",
        type: ""
      };
    },
    

    //编辑用户

    editProject(row) {
      this.isEdit = true;

        //清空数据
        this.careatProgectForm.name = "";
        this.careatProgectForm.memory = "";
        this.careatProgectForm.cpu = "";
        this.careatProgectForm.storageSize = "";
        this.careatProgectForm.mirrorId = "";
        this.careatProgectForm.description = "";
      //根据ID 查询镜像库详细信息
      this.$http
        .get("/cloud/project/queryProjectById?id=" + row.id)
        .then(res => {
          this.careatProgectForm = res.data.obj;
        });

          this.$http
        .get(
          "/cloud/mirror/getMirrorLibrarys?pageNum=1"+ "&pageSize=10" 
           
        )
        .then(res => {
         
          this.mirror = res.data.obj.result;
        });
     

      this.dialogCreateVisible = true;
    },
   

    //进入控制台

    goConsole(){
      
    }
  }
};
</script>
<style scoped>
.pagination-container {
  margin-top: 20px;
}
</style>
