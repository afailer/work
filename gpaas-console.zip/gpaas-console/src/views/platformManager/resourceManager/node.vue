<style scoped>
.filter-container{
    margin: 10px;
}
</style>
<template>
  <div class=" calendar-list-container">
    <div class="filter-container" >
      <!-- <el-input @keyup.enter.native="searchNode" style="width: 200px;" placeholder="请输入内容" v-model="searchContent"> -->
      <!-- </el-input> -->
      <!-- <el-button  type="primary" icon="el-icon-search" @click="searchNode">搜索</el-button> -->
      <!-- <el-button  type="primary" icon="el-icon-refresh" @click="getList">刷新</el-button> -->
      <!-- <el-button  type="primary" icon="el-icon-plus" @click="openCreate">创建</el-button> -->
    </div>
    <div style="margin-left: 10px;">
      <el-table :key='tableKey' :data="table"  element-loading-text="给我一点时间" border fit highlight-current-row
        style="width: 100%">
        <el-table-column align="center" label="名称" >
          <template slot-scope="scope">
            <span>{{scope.row.name}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="类型" >
          <template slot-scope="scope">
            <span>{{scope.row.type | typeFilter}}</span>
          </template>
        </el-table-column>
        <!-- <el-table-column align="center" label="CPU" >
          <template slot-scope="scope">
            <span>{{scope.row.cpu | cpuFilter}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="内存">
          <template slot-scope="scope">
            <span>{{scope.row.memory | memoryFilter}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="存储大小">
          <template slot-scope="scope">
            <span>{{scope.row.storageSize | storageFilter}}</span>
          </template>
        </el-table-column> -->
        <el-table-column align="center" label="状态" >
          <template slot-scope="scope">
            <span>{{scope.row.state | statesFilters}}</span>
          </template>
        </el-table-column>
      
        <el-table-column align="left" label="操作"  class-name="small-padding fixed-width">
          <template slot-scope="scope">
            <el-button :disabled="show(scope.row.state)" type="primary" size="mini" @click="reviewNode(scope.row)">审核</el-button>
            <!-- <el-button  size="mini" type="success" @click="editNode(scope.row)">编辑</el-button> -->
            <el-button  size="mini" type="danger" @click="delectNode(scope.row.id)" v-if="scope.row.state==3">删除</el-button>
            
            <!-- <el-button  size="mini" @click="handleModifyStatus(scope.row,'draft')">租户管理</el-button> -->
            
          </template>
        </el-table-column>
      </el-table>
      
      <div class="pagination-container">
        <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[10,20,30, 50]" :page-size="100" layout="total, sizes, prev, pager, next, jumper" :total="total">
        </el-pagination>
      </div>
    </div>

    <el-dialog title="审核" :visible.sync="dialogFormVisible">
      
      <el-form ref="auditNodeForm" :model="auditNodeForm" label-width="80px">
          <el-form-item label="节点名称">
            <el-input v-model="auditNodeForm.name" :disabled="true"></el-input>
          </el-form-item>          
          <el-form-item label="CPU" v-if="auditNodeForm.type==1">
            <el-input v-model="auditNodeForm.cpu"  :disabled="true">
               <template slot="append">核</template>
            </el-input>
          </el-form-item>          
          <el-form-item label="内存" v-if="auditNodeForm.type==1">
            <el-input v-model="auditNodeForm.memory" :disabled="true">
               <template slot="append">G</template>
            </el-input>
          </el-form-item> 
          <el-form-item label="存储大小"  v-if="auditNodeForm.type==2">
            <el-input v-model="auditNodeForm.storageSize" :disabled="true">
               <template slot="append">G</template>
            </el-input>
          </el-form-item>         
          <el-form-item label="节点类型">
            <el-radio-group v-model="auditNodeForm.type">              
              <el-radio disabled  :label="1">计算节点</el-radio>
              <el-radio disabled  :label="2">存储节点</el-radio>
            </el-radio-group>
          </el-form-item>
          <!-- 审核不通过 -->
          <el-form :rules="rejectRules" ref="auditNodeForm" :model="auditNodeForm" v-if="showReject" label-width="100px">
            <el-form-item label="不通过原因" prop="auditReason" >
              <el-input v-model="auditNodeForm.auditReason"></el-input>
            </el-form-item>
          </el-form>
          <!-- 审核通过 计算节点-->
          <el-form :rules="passRules" ref="auditNodeForm" :model="auditNodeForm" v-if="showNode" label-width="80px">
            <el-form-item label="IP" prop="ip" >
              <el-input  v-model="auditNodeForm.ip"></el-input>
            </el-form-item>
            <el-form-item label="主机名" prop="hostName" >
              <el-input v-model="auditNodeForm.hostName"></el-input>
            </el-form-item>
          </el-form>
          <!-- 审核通过 存储节点-->
          <el-form :rules="passRules1" ref="auditNodeForm" :model="auditNodeForm" v-if="showNode2" label-width="80px">
            <el-form-item label="集群ID" prop="clusterId" >
              <el-input v-model="auditNodeForm.clusterId"></el-input>
            </el-form-item>
          </el-form>

          <el-form-item>
            <el-button type="primary" @click="auditNodePass" v-if="showBtn">审核通过</el-button>
            <el-button type="danger" @click="auditNodeReject" v-if="showBtn">审核不通过</el-button>
            <el-button type="primary" @click="sureNodeReject('auditNodeForm')" v-if="sureReject">确定</el-button>
            <el-button type="primary" @click="sureNodePass('auditNodeForm')" v-if="surePass">确定</el-button>
            <el-button type="primary" @click="sureNodeDelete('auditNodeForm')" v-if="sureDelete">同意释放</el-button>
            <el-button type="primary" @click="rejectNodeDelete('auditNodeForm')" v-if="sureDelete">不同意释放</el-button>
            <el-button @click="dialogFormVisible = false;">取消</el-button>
          </el-form-item>
        </el-form>
        
    </el-dialog>
  </div>
</template>

<script>
import { getTenementList } from '@/api/tenement'
export default {
  name: 'userConsole',
  data() {
    return {
      searchContent:'',
      auditNodeForm:{
        name:'',
        cpu:'',
        storageSize:'',
        type: '',
        auditReason:'',
        hostName:'',
        ip:'',
        clusterId:''
      },
      currentPage:1,
      pageSize:10,
      table:[],
      tableKey: 0,
      list: null,
      total: null,
      listLoading: true,
      dialogFormVisible: false,
      showBtn:true,
      showNode:false,
      showNode2:false,
      showReject:false,
      surePass:false,
      sureReject:false,
      sureDelete:false,
      tenantId:sessionStorage.getItem("tenantId"),
      rejectRules:{
        auditReason:[{ required: true, message: '请输入不通过原因', trigger: 'blur' }]
      },
      passRules:{
        hostName:[{ required: true, message: '请输入主机名', trigger: 'blur' }],
        ip:[{ required: true, message: '请输入IP', trigger: 'blur' }],
      },
      passRules1:{
        clusterId:[{ required: true, message: '请输入集群ID', trigger: 'blur' }],
      },
    }
  },
  filters: {
    statesFilters:function(value){
      switch( value ){
        case 0 :
          return '不通过';
          break;
        case 1 :
          return '通过';
          break;
        case 2 :
          return '待审核';
          break;
        case 3 :
          return '冻结';
          break;
        case 4 :
          return '待释放';
          break;
      }
    },
    typeFilter:function(value){
        switch( value ){
        case 1 :
          return '计算节点';
          break;
        case 2 :
          return '存储节点';
          break;
      }
    },
    cpuFilter: function(value) {
      return value + "核";
    },
    memoryFilter:function(value){
      return value + "M";
    },
    storageFilter:function(value){
      return value + "G";
    }
  },
  created() {
    this.getList()
  },
  methods: {
    getList() {
        this.$http.get('/cloud/node/queryAllNodeByPage?pageNum='+this.currentPage+'&pageSize='+this.pageSize+"&tenantId=" + this.tenantId).then(res => {
          this.total = res.data.obj.totalCount
          this.table = res.data.obj.result
        })
    },   
    
    handleSizeChange(val) {
      this.pageSize = val;     
      this.getList();
    },
    handleCurrentChange(val) {
      this.currentPage = val;
      this.getList();
    },
    // searchNode() {
    //   // do something
    //   this.$http.get('/cloud/node/queryNodeById?id='+this.searchContent).then(res => {
    //     console.log( res )
    //     if( res.data.success){
    //       this.$message({
    //           message: res.data.msg,
    //           type: 'success'
    //       });
    //       this.table.splice(0,this.table.length)
    //       this.table.push( res.data.obj )
    //     }else{
    //        this.$message({
    //           message: res.data.msg,
    //           type: 'error'
    //       });
    //     }
    //   })
    // },
    //审核节点
    reviewNode(row) {
      this.auditNodeForm = Object.assign({}, row) // copy obj
      this.dialogStatus = 'update'
      this.dialogFormVisible = true;
      this.showBtn=true;
      this.showNode='';
      this.showReject=false;
      this.surePass=false;
      this.sureReject=false;
      this.showNode2=false;
      if(this.auditNodeForm.state==4){
        this.sureDelete=true;
        this.showBtn=false;
      }else{
        this.sureDelete=false;
      }
    },
    type(type){
      if(type==2){
        return true;
      }else{
        return false;
      }
    },
    //判断审核按钮是否可用
    show(state){
      if(state==2 || state==4){
        return false;
      }else{
        return true;
      }
    },
    //审核通过
    auditNodePass(){
      this.showBtn=false;
      this.surePass=true;
      this.auditNodeForm.state = 1;
      var params = {
        node: this.auditNodeForm,
      }
      if(this.auditNodeForm.type==1){
        this.showNode=true;
      }else{
        this.showNode2=true;
      }
    },
    //审核不通过按钮
    auditNodeReject(){
      this.showFlag=true;
      this.auditNodeForm.state = 0;
      this.showReject=true;
      this.sureReject=true;
      this.showBtn=false;
    },
    //确认不通过
    sureNodeReject(auditNodeForm){
      this.auditNodeForm.ip="";
      this.auditNodeForm.hostName="";
      this.auditNodeForm.clusterId="";
      this.$refs[auditNodeForm].validate((valid) => {
        if(valid){
          this.$http.post('/cloud/node/examineNode',this.auditNodeForm).then(res => {
            this.dialogFormVisible = false  
            if( res.data.success){
                this.$message({
                  message: res.data.msg,
                  type: 'success'
                });
                this.getList()
              }else{
                this.$message({
                  message: res.data.msg,
                  type: 'error'
                });
              }   
          })
        }
      }) 
      
    },
    // 确认通过
    sureNodePass(auditNodeForm){
      if(this.auditNodeForm.type==1){
        this.auditNodeForm.clusterId='';
        this.auditNodeForm.auditReason='';
        this.$refs[auditNodeForm].validate((valid) => {
          if(valid){
            this.$http.post('/cloud/node/examineNode',this.auditNodeForm).then(res => {
              this.dialogFormVisible = false  
              if( res.data.success){
                  this.$message({
                    message: res.data.msg,
                    type: 'success'
                  });
                  this.getList()
                }else{
                  this.$message({
                    message: res.data.msg,
                    type: 'error'
                  });
                }   
            })
          }
        })
      }else {
        this.auditNodeForm.ip="";
        this.auditNodeForm.hostName="";
        this.auditNodeForm.auditReason="";
        this.$refs[auditNodeForm].validate((valid) => {
          if(valid){
            this.$http.post('/cloud/node/examineNode',this.auditNodeForm).then(res => {
              this.dialogFormVisible = false  
              if( res.data.success){
                  this.$message({
                    message: res.data.msg,
                    type: 'success'
                  });
                  this.getList()
                }else{
                  this.$message({
                    message: res.data.msg,
                    type: 'error'
                  });
                }   
            })
          }
        })
      }
    },
    //同意释放
    sureNodeDelete(){
      this.$http.get('/cloud/node/releaseNodeById?id='+this.auditNodeForm.id+'&state=3').then(res => {
              this.dialogFormVisible = false  
              if( res.data.success){
                  this.$message({
                    message: res.data.msg,
                    type: 'success'
                  });
                  this.getList()
                }else{
                  this.$message({
                    message: res.data.msg,
                    type: 'error'
                  });
                }   
            })
    },
    //不同意释放
    rejectNodeDelete(){
      this.$http.get('/cloud/node/releaseNodeById?id='+this.auditNodeForm.id+'&state=1').then(res => {
              this.dialogFormVisible = false  
              if( res.data.success){
                  this.$message({
                    message: res.data.msg,
                    type: 'success'
                  });
                  this.getList()
                }else{
                  this.$message({
                    message: res.data.msg,
                    type: 'error'
                  });
                }   
            })
    },
    //删除
    delectNode(id){
      this.$http.get('/cloud/node/deleteAdminNodeById?id='+id).then(res => { 
              if( res.data.success){
                  this.$message({
                    message: res.data.msg,
                    type: 'success'
                  });
                  this.getList()
                }else{
                  this.$message({
                    message: res.data.msg,
                    type: 'error'
                  });
                }   
      })
    }
       
  },

   watch: {
    $route(currentState, oldState) {
      // debugger;
      if (currentState.fullPath.startsWith("/plantConsole")) {
       
        this.tenantId = sessionStorage.getItem("tenantId");
        this.getList();
      } else {
        
        sessionStorage.setItem("showNumber", 3);
      }
    }
  }
}
</script>
<style scoped>
.pagination-container{
    margin-top:20px;
}
</style>
