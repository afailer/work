<style scoped>
.filter-container {
  margin: 10px;
}
</style>
<template>
  <div class=" calendar-list-container">
    <!-- <div class="filter-container" >
      <el-input @keyup.enter.native="handleFilter" style="width: 200px;" placeholder="请输入内容" v-model="listQuery.title">
      </el-input>
      <el-button  type="primary" icon="el-icon-search" @click="handleFilter">搜索</el-button>
    </div> -->
<!-- v-loading="listLoading" -->
    <div style="margin-left:10px">
      <el-table :key='tableKey' :data="imageData"  element-loading-text="给我一点时间" border fit highlight-current-row
        style="width: 100%">
        <el-table-column align="center" label="镜像库名称" >
          <template slot-scope="scope">
            <span>{{scope.row.name}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="状态" >
          <template slot-scope="scope">
            <span>{{scope.row.approve | statesFilters}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="账户名" >
          <template slot-scope="scope">
            <span>{{scope.row.account}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="镜像库地址" >
          <template slot-scope="scope">
            <span>{{scope.row.address}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="创建时间" >
          <template slot-scope="scope">
            <span>{{scope.row.createTime}}</span>
          </template>
        </el-table-column>
        <!-- <el-table-column align="center" label="描述" >
          <template slot-scope="scope">
            <span>{{scope.row.description}}</span>
          </template>
        </el-table-column> -->
        <el-table-column align="center" label="建库类型" >
          <template slot-scope="scope">
            <span>{{scope.row.type |typeFilters}}</span>
          </template>
        </el-table-column>
      
        <el-table-column align="center" label="操作"  class-name="small-padding fixed-width">
          <template slot-scope="scope">
            <el-button type="primary" size="mini" @click="edit(scope.row)" :disabled="!show(scope.row.approve)">编辑</el-button>
            <el-button  size="mini" type="success" :disabled="check(scope.row.approve)"  @click="examineImage(scope.row)">审核
            </el-button>
          
            
          </template>
        </el-table-column>
      </el-table>

        <div class="pagination-container">
            <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[10,20,30, 50]" :page-size="100" layout="total, sizes, prev, pager, next, jumper" :total="total">
            </el-pagination>
    
        </div>
    </div>
        <!-- 审核 -->
        <div style="">
            <el-dialog title="审核镜像库" :visible.sync="dialogCreateVisible">
            <div style="width:80%;margin:0 auto">
            <el-form ref="careatUserForm" :model="careatUserForm" label-width="100px">
                <el-form-item label="镜像库名称">
                    <el-input v-model="careatUserForm.name" disabled></el-input>
                </el-form-item> 

                 <el-form-item label="租户名">
                    <el-input v-model="careatUserForm.tenantName" disabled>
                    
                    </el-input>
                </el-form-item>          
                <el-form-item label="邮箱">
                    <el-input v-model="careatUserForm.email" disabled>
                    
                    </el-input>
                </el-form-item> 

                <el-form-item label="镜像库地址">
                    <el-input v-model="careatUserForm.address" >
                    
                    </el-input>
                </el-form-item>   
                <el-form-item label="镜像库账号">
                    <el-input v-model="careatUserForm.account">
                    
                    </el-input>
                </el-form-item> 
                <el-form-item label="镜像库密码">
                    <el-input v-model="careatUserForm.password">
                    
                    </el-input>
                </el-form-item> 
                
                
                <el-form-item>
                    <el-button type="primary" @click="examinePass" >通过</el-button>
                    <el-button type="primary" @click="examineNopass" >不通过</el-button>
                    
                    <el-button @click="dialogCreateVisible = false">取消</el-button>
                </el-form-item>
                </el-form>
                </div>
            </el-dialog>
        </div>

        <!-- 编辑 -->
        <div style="">
          <el-dialog title="编辑镜像库" :visible.sync="dialogEditVisible">
            <div style="width:80%;margin:0 auto">
            <el-form ref="careatUserForm" :model="careatUserForm" label-width="100px">
                <el-form-item label="镜像库名称">
                    <el-input v-model="careatUserForm.name"></el-input>
                </el-form-item> 

                 <el-form-item label="租户名">
                    <el-input v-model="careatUserForm.tenantName">
                    
                    </el-input>
                </el-form-item>          
                <el-form-item label="邮箱">
                    <el-input v-model="careatUserForm.email">
                    
                    </el-input>
                </el-form-item> 

                <el-form-item label="镜像库地址">
                    <el-input v-model="careatUserForm.address" >
                    
                    </el-input>
                </el-form-item>   
                <el-form-item label="镜像库账号">
                    <el-input v-model="careatUserForm.account">
                    
                    </el-input>
                </el-form-item> 
                <el-form-item label="镜像库密码">
                    <el-input v-model="careatUserForm.password">
                    
                    </el-input>
                </el-form-item> 
                
                
                <el-form-item>
                    <el-button type="primary" @click="sureEdit" >确认编辑</el-button>
                    
                    <el-button @click="dialogEditVisible = false">取消</el-button>
                </el-form-item>
                </el-form>
                </div>
            </el-dialog>
        </div>

  </div>
</template>

<script>
// import { getTenementList } from '@/api/tenement'
export default {
  name: "complexTable",

  data() {
    return {
      //创建用户
      careatUserForm: {
        type: 2,
        name: "",
        email: "",
        address: "",
        account: "",
        password: "",
        tenantName:"",
        id:""

      },
     
      currentPage: 1,
      imageData: [],
      tableKey: 0,
      total: null,
      pageSize: 10,
      listLoading: true,
      listQuery: {
        title: undefined
      },
      //审核
      dialogCreateVisible: false,
      //编辑
      dialogEditVisible:false,
    };
  },

  filters: {
    statesFilters: function(value) {
      switch (value) {
        case 3:
          return "未通过";
          break;
        case 1:
          return "待审核";
          break;
        case 2:
          return "通过";
          break;
      }
    },
    typeFilters: function(value) {
      switch (value) {
        case 1:
          return "阿里云镜像库";
          break;
        case 2:
          return "第三方镜像库";
          break;
      }
    }
  },
  created() {
    this.getList();
  },
  methods: {
    getList() {
      this.$http
        .get("/cloud/mirror/getTenantMirrorLibrarys?pageNum=" +
            this.currentPage +
            "&pageSize=" +
            this.pageSize + "&tenantId=" + sessionStorage.getItem("tenantId") 
           
        )
        .then(res => {
          this.total = res.data.obj.totalCount;
          this.imageData = res.data.obj.result;
        });
    },

    openCreate() {},
    handleFilter() {},
    handleSizeChange(val) {
      this.pageSize = val;
      this.getList();
    },

    //判断审核按钮是否可用
    show(state){
      if(state==1){
        return false;
      }else if(state==3){
        return false;
      }else{
         return true;
      }
    },

    check(state){
      debugger;
      if(state==1){
        return false;
      }else if(state==3){
        return true;
      }else{
         return true;
      }
    },

    //分页查询
    handleCurrentChange(val) {
      this.currentPage = val;
      this.getList();
    },
    handleModifyStatus(row, status) {},
   
    

    //审核镜像库
    examineImage(row){
       this.dialogCreateVisible = true;
      this.careatUserForm.type = row.type;
      this.careatUserForm.name = row.name;
      this.careatUserForm.email = row.email;
      this.careatUserForm.tenantName = row.tenantName;
      this.careatUserForm.id = row.id;
    
    },

   

 

  
    //审核通过

examinePass(){

  this.careatUserForm.approve = 2

     this.$http
        .post("/cloud/mirror/approveMirrorLibrary", this.careatUserForm)
        .then(res => {
          if (res.data.success) {
            this.$message({
              message: res.data.msg,
              type: "success"
            });
            this.dialogCreateVisible = false;
            this.getList();
          } else {
            this.$message({
              message: res.data.msg,
              type: "error"
            });
          }
        });

},


//审核不通过

examineNopass(){
  this.careatUserForm.approve = 3

  this.$http
        .post("/cloud/mirror/approveMirrorLibrary", this.careatUserForm)
        .then(res => {
          if (res.data.success) {
            this.$message({
              message: res.data.msg,
              type: "success"
            });
            this.dialogCreateVisible = false;
            this.getList();
          } else {
            this.$message({
              message: res.data.msg,
              type: "error"
            });
          }
        });

},


//编辑镜像库
    edit(row){
       this.dialogEditVisible = true;
      this.careatUserForm.type = row.type;
      this.careatUserForm.name = row.name;
      this.careatUserForm.email = row.email;
      this.careatUserForm.tenantName = row.tenantName;
      this.careatUserForm.id = row.id;
      this.careatUserForm.address = row.address;
      this.careatUserForm.account = row.account;
      this.careatUserForm.password = row.password;
    },

//确认编辑
    sureEdit() {
      this.$http
        .post("/cloud/mirror/editMirrorLibrary", this.careatUserForm)
        .then(res => {
          if (res.data.success) {
            this.$message({
              message: res.data.msg,
              type: "success"
            });
            this.dialogEditVisible = false;
            this.getList();
          } else {
            this.$message({
              message: res.data.msg,
              type: "error"
            });
          }
        });
    }
  }
};
</script>
<style scoped>
.pagination-container {
  margin-top: 20px;
}
</style>
