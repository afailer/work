<style scoped>
.filter-container {
  margin: 10px;
}
</style>
<template>
  <div class=" calendar-list-container">
    <div class="filter-container" >
      <!-- <el-input @keyup.enter.native="handleFilter" style="width: 200px;" placeholder="请输入内容" v-model="listQuery.title">
      </el-input> -->
      <!-- <el-button  type="primary" icon="el-icon-search" @click="handleFilter">搜索</el-button> -->
      <!-- <el-button  type="primary" icon="el-icon-plus" @click="createUser">创建租户</el-button> -->
    </div>
<!-- v-loading="listLoading" -->
      <div style="margin-left:10px">
        <el-table :key='tableKey' :data="userData"  element-loading-text="给我一点时间" border fit highlight-current-row
          style="width: 100%">
          <!-- <el-table-column align="center" label="租户ID" >
            <template slot-scope="scope">
              <span>{{scope.row.tenantId}}</span>
            </template>
          </el-table-column> -->
          <el-table-column align="center" label="租户名称" >
            <template slot-scope="scope">
              <span>{{scope.row.username}}</span>
            </template>
          </el-table-column>
          
          <el-table-column align="center" label="申请原因" >
            <template slot-scope="scope">
              <span>{{scope.row.reason}}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" label="申请时间" >
            <template slot-scope="scope">
              <span>{{scope.row.registerTime |formatDatetwo}}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" label="状态" >
            <template slot-scope="scope">
              <span>{{scope.row.state | statesFilters}}</span>
            </template>
          </el-table-column>
          <!-- <el-table-column align="center" label="类型" width="120">
            <template slot-scope="scope">
              <span>{{scope.row.storageSize}}</span>
            </template>
          </el-table-column> -->
        
          <el-table-column align="left" label="操作"  class-name="small-padding fixed-width">
            <template slot-scope="scope">
              <el-button type="primary" size="mini" v-show="scope.row.state == 2" @click="examine(scope.row)">审核</el-button>
              <!-- <el-button  size="mini" type="success" v-show="scope.row.state != 5" @click="editNode(scope.row)">编辑 
              </el-button> -->
              <el-button  size="mini" type="danger"  v-if="scope.row.state== 5" @click="frozenTenant(scope.row)">冻结
              </el-button>
              <el-button  size="mini" type="danger"  v-if="scope.row.state== 8" @click="activeTenant(scope.row)">激活
              </el-button>
              <el-button  size="mini" type="danger" @click="goConsole(scope.row)" v-show="scope.row.state !== 2">租户管理
              </el-button>
              
            </template>
          </el-table-column>
        </el-table>

        <div class="pagination-container">
            <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[10,20,30, 50]" :page-size="100" layout="total, sizes, prev, pager, next, jumper" :total="total">
            </el-pagination>
    
        </div>
      </div>
        <!-- 租户审核 -->
        <div style="">
            <el-dialog title="审核租户" :visible.sync="dialogExamineVisible">
            <div style="width:80%;margin:0 auto">
            <el-form ref="auditNodeForm" :model="examinetUserForm" label-width="100px">
                <el-form-item label="租户名称">
                    <el-input v-model="examinetUserForm.username" disabled></el-input>
                </el-form-item>          
                <el-form-item label="code">
                    <el-input v-model="examinetUserForm.code" disabled>
                    
                    </el-input>
                </el-form-item>   
                 <el-form-item label="申请原因">
                   <el-input v-model="examinetUserForm.reason" disabled>
                    
                    </el-input>
                </el-form-item>       
                <el-form-item label="uaaid">
                    <el-input v-model="examinetUserForm.uaaid" disabled>
                    
                    </el-input>
                </el-form-item>          
                <!-- <el-form-item label="注册时间">
                   <el-input v-model="examinetUserForm.startRegisterTime">
                    
                    </el-input>
                </el-form-item> -->

                  <el-form-item label="不通过原因" v-if=showFlag>
                    <el-input type="textarea" v-model="examinetUserForm.auditReason" ></el-input>
                  </el-form-item>
                
                <el-form-item>
                    <el-button type="primary" @click="auditPass" v-if="examinetUserForm.state != 1&&examinetUserForm.state != 0&& !showFlag">通过</el-button>

                    <el-button type="primary" @click="auditNoPass" v-if="examinetUserForm.state != 1&&examinetUserForm.state != 0 && !showFlag">不通过</el-button>
                    <el-button type="primary" @click="sureNoPass" v-if=showFlag>确定</el-button>
                    <!-- <el-button type="danger" @click="auditNodeReject">审核驳回</el-button> -->
                    <el-button @click="dialogExamineVisible = false">取消</el-button>
                </el-form-item>
                </el-form>
                </div>
            </el-dialog>
        </div>


       


  </div>
</template>

<script>
// import { getTenementList } from '@/api/tenement'
export default {
  name: "complexTable",

  data() {
    return {
        //审核详情
      examinetUserForm:{
            username:'',
            code:'',
            reason:'',        
            startRegisterTime:'',
            reason:'',        
            uaaid: '',
            state:'',
            auditReason:''
     },

     showFlag:false,

         //分配用户
      dialogRoleVisible:false,

      roleForm:{
          name:'',
      },
     
      currentPage: 1,
      userData: [],
      tableKey: 0,
      total: null,
       pageSize:10,
      listLoading: true,
      listQuery: {
        page: 1,
        limit: 20,
        importance: undefined,
        title: undefined,
        type: undefined,
        sort: "+id"
      },
 
     
      //审核
      dialogExamineVisible: false,
      dialogPvVisible: false,
      downloadLoading: false
    };
  },
//   filters: {
//     statusFilter(status) {
//       const statusMap = {
//         通过: "success",
//         draft: "info",
//         deleted: "danger"
//       };
//       return statusMap[status];
//     },
//     typeFilter(type) {
//       return calendarTypeKeyValue[type];
//     },
 
//   },
   filters: {
    statesFilters:function(value){
      switch( value ){
        case 0 :
          return '不通过';
          break;
        case 1 :
          return '审核信息通过';
          break;
        case 2 :
          return '待审核';
          break;
           case 3 :
          return '审核配额通过';
          break;
           case 4 :
          return '审核镜像通过';
          break;
           case 5 :
          return '激活';
          break;
           case 6 :
          return '待配额审核';
          break;
           case 7 :
          return '待镜像审核';
          break;
          case 8 :
          return '冻结';
          break;
          case 9 :
          return '废弃';
          break;

      }
    },

    
    formatDatetwo: function(time) {
      var re = /-?\d+/;
      var m = re.exec(time);
      var d = new Date(parseInt(m[0]));
      var o = {
        "M+": d.getMonth() + 1, //month
        "d+": d.getDate(), //day
        "h+": d.getHours(), //hour
        "m+": d.getMinutes(), //minute
        "s+": d.getSeconds(), //second
        "q+": Math.floor((d.getMonth() + 3) / 3), //quarter
        S: d.getMilliseconds() //millisecond
      };
      var format = "yyyy-MM-dd";
      if (/(y+)/.test(format)) {
        format = format.replace(
          RegExp.$1,
          (d.getFullYear() + "").substr(4 - RegExp.$1.length)
        );
      }
      for (var k in o) {
        if (new RegExp("(" + k + ")").test(format)) {
          format = format.replace(
            RegExp.$1,
            RegExp.$1.length == 1
              ? o[k]
              : ("00" + o[k]).substr(("" + o[k]).length)
          );
        }
      }
      return format;
    }
  },
  created() {
    this.getList();
  },
  methods: {
    
    getList() {
      this.$http.get( '/cloud/tenant/queryAllUser?userType=2'+'&pageNum='+this.currentPage+'&pageSize='+this.pageSize+'').then(res => {
       this.total = res.data.obj.totalCount
        this.userData = res.data.obj.result;
      });
      
    },

    openCreate(){

    },
    handleFilter() {
     
    },
    handleSizeChange(val) {
      this.pageSize = val;     
      this.getList();
    },

    //分页查询
     handleCurrentChange(val) {
      
      this.currentPage = val;
      this.getList();
      
    },
    handleModifyStatus(row, status) {
     
    },
   
  //  //创建用户
  //   createUser() {

  //       this.dialogCreateVisible = true;


  //     this.$refs["dataForm"].validate(valid => {
  //       if (valid) {
  //         this.temp.id = parseInt(Math.random() * 100) + 1024; // mock a id
  //         this.temp.author = "vue-element-admin";
    
  //       }
  //     });
  //   },

    //确认创建用户
    suerCreatUser(){

    },

  //进入租户管理
  goConsole(row){

     sessionStorage.setItem("tenantId", row.tenantId);

     this.$router.push({
          name: "plantconsole",
          query: { tenantId: row.tenantId, }
        });

  },


//审核用户
    examine(row) {


      this.dialogExamineVisible = true;
      this.showFlag = false;


      this.examinetUserForm.username = row.username;
      this.examinetUserForm.code = row.code;
      this.examinetUserForm.reason = row.reason;
      this.examinetUserForm.startRegisterTime = row.startRegisterTime;
      this.examinetUserForm.reason = row.reason;
      this.examinetUserForm.uaaid = row.uaaid;
      this.examinetUserForm.state = row.state;

    },
  //审核通过
    auditPass(){

       this.examinetUserForm.state = 1;


        this.$http.post('/cloud/tenant/auditTenant',this.examinetUserForm).then(res => {
          if( res.data.success){
            this.$message({
              message: res.data.msg,
              type: 'success' 
            });
            
            this.dialogExamineVisible = false;
            this.getList();
          }else{
            this.$message({
              message: res.data.msg,
              type: 'error'
            });
            this.dialogExamineVisible = false;
          }
      })

    },

  //审核不通过
    auditNoPass(){
      this.showFlag = true;
    },

    //确定不通过
    sureNoPass(){

         this.examinetUserForm.state = 0;


        this.$http.post('/cloud/tenant/auditTenant',this.examinetUserForm).then(res => {
          if( res.data.success){
            this.$message({
              message: res.data.msg,
              type: 'success'
            });
            
            this.dialogExamineVisible = false;
            this.getList();
          }else{
            this.$message({
              message: res.data.msg,
              type: 'error'
            });
          }
      })


    },


  //冻结租户

  frozenTenant(row){

     this.$http.get( '/cloud/tenant/delOrFreezeTenant?code='+row.code+'&state=8').then(res => {
       
        if( res.data.success){
            this.$message({
              message: res.data.msg,
              type: 'success'
            });
            
            this.getList();
          }else{
            this.$message({
              message: res.data.msg,
              type: 'error'
            });
          }
        


      });

  },

  //激活租户
  activeTenant(row){
    this.$http.get( '/cloud/tenant/activeTenant?code='+row.code).then(res => {
       
        if( res.data.success){
            this.$message({
              message: res.data.msg,
              type: 'success'
            });
            
            this.getList();
          }else{
            this.$message({
              message: res.data.msg,
              type: 'error'
            });
          }
        


      });

  },

  



    

    updateData() {
      this.$refs["dataForm"].validate(valid => {
        if (valid) {
          const tempData = Object.assign({}, this.temp);
          tempData.timestamp = +new Date(tempData.timestamp); // change Thu Nov 30 2017 16:41:05 GMT+0800 (CST) to 1512031311464
        }
      });
    },
   
   
  }
};
</script>
<style scoped>
.pagination-container {
  margin-top: 20px;
}
</style>
