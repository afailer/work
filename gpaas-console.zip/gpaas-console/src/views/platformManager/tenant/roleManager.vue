<style scoped>
.filter-container {
  margin: 10px;
}
</style>
<template>
  <div class=" calendar-list-container">
    <!-- <div class="filter-container" >
      <el-input @keyup.enter.native="handleFilter" style="width: 200px;" placeholder="请输入内容" v-model="listQuery.title">
      </el-input>
      <el-button  type="primary" icon="el-icon-search" @click="handleFilter">搜索</el-button>
       <el-button  type="primary" icon="el-icon-plus" @click="addrole">新增角色</el-button>
    </div> -->
<!-- v-loading="listLoading" -->
      <div style="margin-left:10px">
        <el-table :key='tableKey' :data="roleData"  element-loading-text="给我一点时间" border fit highlight-current-row
          style="width: 100%">
          <el-table-column align="center" label="角色名称" width="120">
            <template slot-scope="scope">
              <span>{{scope.row.username}}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" label="状态" width="120">
            <template slot-scope="scope">
              <span>{{scope.row.state | statesFilters}}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" label="申请原因" width="300">
            <template slot-scope="scope">
              <span>{{scope.row.reason}}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" label="租户ID" width="300">
            <template slot-scope="scope">
              <span>{{scope.row.tenantId}}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" label="类型" width="120">
            <template slot-scope="scope">
              <span>{{scope.row.storageSize}}</span>
            </template>
          </el-table-column>
        
          <el-table-column align="center" label="操作" width="320" class-name="small-padding fixed-width">
            <template slot-scope="scope">
              
              <el-button  size="mini" type="success" @click="editNode(scope.row)">编辑 
              </el-button>
              <el-button  size="mini" type="danger" @click="delectNode(scope.row.id)">删除
              </el-button>
              
              
            </template>
          </el-table-column>
        </el-table>

        <div class="pagination-container">
            <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[10,20,30, 50]" :page-size="100" layout="total, sizes, prev, pager, next, jumper" :total="total">
            </el-pagination>
    
        </div>
      </div>
        




  </div>
</template>

<script>
// import { getTenementList } from '@/api/tenement'
export default {
  name: "complexTable",

  data() {
    return {
     

         //分配用户
      dialogRoleVisible:false,

      roleForm:{
          name:'',
      },
     
      currentPage: 1,
      roleData: [],
      tableKey: 0,
      total: null,
      pageSize:10,
     
      listQuery: {
        title: undefined,
        
      },
  
      dialogCreateVisible: false,
      dialogPvVisible: false,
      downloadLoading: false
    };
  },
   filters: {
    statesFilters:function(value){
      switch( value ){
        case 0 :
          return '不通过';
          break;
        case 1 :
          return '通过';
          break;
        case 2 :
          return '待审核';
          break;

      }
    },
  },
  created() {
    this.getList();
  },
  methods: {
    
    getList() {
      this.$http.get( '/cloud/user/queryTenantUser?pageNum='+this.currentPage+'&pageSize='+this.pageSize+'').then(res => {
       this.total = res.data.obj.totalCount
        this.roleData = res.data.obj.result;
      });
      
    },

    openCreate(){

    },
    handleFilter() {
     
    },
    handleSizeChange(val) {
      this.pageSize = val;     
      this.getList();
    },

    //分页查询
     handleCurrentChange(val) {
      
      this.currentPage = val;
      this.getList();
      
    },

    //新增角色
    addrole(){

    },
    
    
 

  


 

    
   
   
  }
};
</script>
<style scoped>
.pagination-container {
  margin-top: 20px;
}
</style>
