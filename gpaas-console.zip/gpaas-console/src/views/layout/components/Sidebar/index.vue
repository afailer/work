<template>
  <scroll-bar>   
    <span  class="titleClass" v-text="titleName"></span> 
     
    <span class="titleNameClass" v-if="!isCollapse"> {{menus[0].name}}</span>    
    <el-menu mode="vertical" unique-opened :default-active="$route.path" :collapse="isCollapse" 
        background-color="#304156" text-color="#fff" active-text-color="#409EFF">
      <!-- #409EFF  -->
      
      <sidebar-item :menus="menus[0].children"></sidebar-item>
    </el-menu>
  </scroll-bar>
</template>

<script>
import { mapGetters } from 'vuex'
import SidebarItem from './SidebarItem1'
import ScrollBar from '@/components/ScrollBar'

export default {
  components: { SidebarItem, ScrollBar },
  data(){
    return {
      titleName:'HiaCloud Console'
    }
  },
  computed: {
    ...mapGetters([
      'sidebar',
      'menus'
    ]),
    // routes() {
    //   return this.$router.options.routes
    // },
    // menus() {
    //   return this.menu
    // },
    isCollapse() {
      return !this.sidebar.opened
      
    }
  },
  watch: {
    'isCollapse':function(oldValue,newValue){
      console.log( newValue )
      if(newValue){
        this.titleName = 'HiaCloud Console'        
      }else{
        this.titleName = 'HIV'
      }
    }
  },
 
}
</script>
<style scoped>
.titleClass{
  background-color: #3c8dbc;
  color: #ffffff;
  font-size: 20px;  
  width: 100%;
  display: block;
  line-height: 50px;
  text-align: center;
  height: 50px;
}
.titleNameClass{
  background-color: #000508;
  color: #ffffff;
  font-size: 16px;  
  width: 100%;
  display: block;
  line-height: 50px;
  text-align: center;
  height: 50px;
}


</style>

