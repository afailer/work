<template>
  <div class="menu-wrapper">

    <template v-for="item in menus">
      <router-link v-if="!item.children||item.children.length<1" :to="item.path" :key="item.id">
        <el-menu-item :index="item.path">

          <svg-icon v-if="item.icon" :icon-class="item.icon"></svg-icon>
          <svg-icon v-else icon-class="form"></svg-icon>

          <span>{{item.name}}</span>
        </el-menu-item>
      </router-link>

      <el-submenu v-else :index="item.path" :key="item.id">

        <template slot="title">

          <svg-icon v-if="item.icon" :icon-class="item.icon"></svg-icon>
          <svg-icon v-else icon-class="form"></svg-icon>

          <span>{{item.name}}</span>
        </template>
        <template v-for="child in item.children">
          <!-- <sidebar-item class="nest-menu" v-if="child.children&&child.children.length>0" :menus="[child]" :key="child.path"></sidebar-item> -->
          <router-link :to="child.path" :key="child.id">

            <el-menu-item :index="child.path">
              <!-- <i v-if="child.icon" :class="child.icon"></i>

              <i v-else class="el-icon-menu"></i> -->

              <svg-icon v-if="child.icon" :icon-class="child.icon"></svg-icon>
              <svg-icon v-else icon-class="form"></svg-icon>
              <span>{{child.name}}</span>
            </el-menu-item>
          </router-link>
        </template>
      </el-submenu>

    </template>
  </div>
</template>
<script>
export default {
  name: "SidebarItem",
  props: ["menus"]
};
</script>
