<template>
  <el-menu class="navbar" mode="horizontal">
    <hamburger class="hamburger-container" :toggleClick="toggleSideBar" :isActive="sidebar.opened"></hamburger>
    <!-- <breadcrumb></breadcrumb> -->
    <dropdown :user="user"></dropdown>

    

    <div style="float:right;margin-right:30px">
      <span style="color:#fff;margin-right:20px">欢迎您：{{userName}}</span>
      <span style="color:#fff;cursor: pointer;" @click="logout">退出</span>
    </div>

  </el-menu>
</template>

<script>
import { mapGetters } from "vuex";
// import Breadcrumb from '@/components/Breadcrumb'
import Hamburger from "@/components/Hamburger";
import Dropdown from "@/components/dropdown";

import Cookies from "js-cookie";

export default {
  components: {
    // Breadcrumb,
    Hamburger,
    Dropdown
  },

  data() {
    return {
      user: "",
      userName: ""
    };
  },
  computed: {
    ...mapGetters(["sidebar", "avatar"])
  },

  created() {
    this.getuser();
  },
  methods: {
    toggleSideBar() {
      this.$store.dispatch("ToggleSideBar");
    },
    // logout() {
    //   this.$store.dispatch('LogOut').then(() => {
    //     location.reload() // 为了重新实例化vue-router对象 避免bug
    //   })
    // },

    getuser() {
      this.user = Cookies.get("user");
      this.userName = JSON.parse(this.user).username;
    },
    logout() {
      Cookies.set("user", "", { expires: -1, path: "/" });
      window.location.href = "/";
    }
  }
};
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.navbar {
  height: 50px;
  line-height: 50px;
  border-radius: 0px !important;
  background-color: #3c8dbc;
  // background-color: #ffffff;
  .hamburger-container {
    line-height: 58px;
    height: 50px;
    float: left;
    padding: 0 10px;
  }
  .screenfull {
    position: absolute;
    right: 90px;
    top: 16px;
    color: red;
  }
  .avatar-container {
    height: 50px;
    display: inline-block;
    position: absolute;
    right: 35px;
    .avatar-wrapper {
      cursor: pointer;
      margin-top: 5px;
      position: relative;
      .user-avatar {
        width: 40px;
        height: 40px;
        border-radius: 10px;
      }
      .el-icon-caret-bottom {
        position: absolute;
        right: -20px;
        top: 25px;
        font-size: 12px;
      }
    }
  }
}
</style>

