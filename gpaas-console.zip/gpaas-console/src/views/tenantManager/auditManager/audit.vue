<style scoped>
.filter-container {
  margin: 10px;
}
</style>
<template>
  <div class=" calendar-list-container">
    <div class="filter-container">
      <!-- <el-input @keyup.enter.native="handleFilter" style="width: 200px;" placeholder="请输入内容" v-model="listQuery.title"> -->
      <!-- </el-input> -->
      <!-- <el-button  type="primary" icon="el-icon-search" @click="handleFilter">搜索</el-button> -->
      <!-- <el-button style="display:block;float:left;"  type="primary" icon="el-icon-plus" @click="createProject">创建存储卷</el-button> -->

    </div>
    <!-- v-loading="listLoading" -->
    <div style="margin-left:10px">
      <el-table :key='tableKey' :data="storageData" element-loading-text="给我一点时间" border fit highlight-current-row style="width: 100%">
        <el-table-column align="center" label="用户名" min-width="10%">
          <template slot-scope="scope">
            <span>{{scope.row.username }}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="事件类型" min-width="13%">
          <template slot-scope="scope">
            <span>{{scope.row.type |state}}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="事件内容" min-width="25%">
          <template slot-scope="scope">
            <span>{{scope.row.content }}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="时间" min-width="16%">
          <template slot-scope="scope">
            <span>{{scope.row.time | formatDatetwo}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="状态" min-width="13%">
          <template slot-scope="scope">
            <span>{{scope.row.state | typestate}}</span>
          </template>
        </el-table-column>

      </el-table>

      <div class="pagination-container">
        <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[10,20,30, 50]" :page-size="100" layout="total, sizes, prev, pager, next, jumper" :total="total">
        </el-pagination>

      </div>
    </div>

  </div>
</template>

<script>
import { mapActions, mapGetters } from "vuex";

export default {
  name: "complexTable",

  data() {
    var name = (rule, value, callback) => {
      if (/^[a-z][a-z0-9]{2,9}$/.test(value) == false) {
        callback(new Error("项目名不符合规范"));
      } else {
        callback();
      }
    };
    return {
      //创建项目
      createStorageForm: {
        name: "",
        createTime: "",
        storageSize: "",
        description: "",
        type: 1,
        permission: 3,
        projectId: "",
        namespace: ""
      },
      leftResource: [],

      isEdit: false,

      currentPage: 1,
      storageData: [],
      tableKey: 0,
      total: null,
      pageSize: 10,
      listLoading: true,
      listQuery: {
        title: undefined
      },
      //创建用户
      dialogCreateVisible: false,
      radio: 3,
      disabled: "",
      projectId: sessionStorage.getItem("projectId"),
      namespace: sessionStorage.getItem("namespace")
    };
  },
  computed: {
    // ...mapGetters(["projectId","namespace"])
  },

  filters: {
    state: function(value) {
      switch (value) {
        case "1":
          return "create";
          break;
        case "2":
          return "update";
          break;
        case "3":
          return "delete";
          break;
      }
    },

    typestate: function(value) {
      switch (value) {
        case "1":
          return "成功";
          break;
        case "0":
          return "失败";
          break;
      }
    },
    subsFiter: function(value) {
      return Math.round(value * 100) / 100;
    },
    formatDatetwo: function(time) {
      var re = /-?\d+/;
      var m = re.exec(time);
      var d = new Date(parseInt(m[0]));
      var o = {
        "M+": d.getMonth() + 1, //month
        "d+": d.getDate(), //day
        "h+": d.getHours(), //hour
        "m+": d.getMinutes(), //minute
        "s+": d.getSeconds(), //second
        "q+": Math.floor((d.getMonth() + 3) / 3), //quarter
        S: d.getMilliseconds() //millisecond
      };
      var format = "yyyy-MM-dd hh:mm:ss";
      if (/(y+)/.test(format)) {
        format = format.replace(
          RegExp.$1,
          (d.getFullYear() + "").substr(4 - RegExp.$1.length)
        );
      }
      for (var k in o) {
        if (new RegExp("(" + k + ")").test(format)) {
          format = format.replace(
            RegExp.$1,
            RegExp.$1.length == 1
              ? o[k]
              : ("00" + o[k]).substr(("" + o[k]).length)
          );
        }
      }
      return format;
    },
  },
  created() {
    this.getList();
    this.leftRes();
  },
  methods: {
    getList() {
      this.$http
        .get(
          "/cloud/queryListAudit?pageNum=" +
            this.currentPage +
            "&pageSize=" +
            this.pageSize
        )
        .then(res => {
          this.total = res.data.obj.totalCount;
          this.storageData = res.data.obj.result;
        });
    },
    //剩余资源
    leftRes() {
      this.$http
        .get(
          "/cloud/persistentVolume/queryLeftProjectStorageSize?projectId=" +
            this.projectId
        )
        .then(res => {
          this.leftResource = res.data.obj;
        });
    },
    handleFilter() {},
    handleSizeChange(val) {
      this.pageSize = val;
      this.getList();
    },
    // //权限
    // radioChange(value){
    //     this.permission=value;
    // },
    //分页查询
    handleCurrentChange(val) {
      this.currentPage = val;
      this.getList();
    },
    //创建存储卷

    createProject() {
      this.disabled = false;
      this.title = "创建存储卷";
      //清空存储卷对象
      this.createStorageForm.name = "";
      this.createStorageForm.createTime = this.createTime;
      this.createStorageForm.storageSize = "";
      this.createStorageForm.description = "";
      this.createStorageForm.projectId = this.projectId;
      this.createStorageForm.namespace = this.namespace;
      this.dialogCreateVisible = true;
      this.isEdit = false;
    },
    //取消创建
    cancle(createStorageForm) {
      this.$refs[createStorageForm].resetFields();
      this.dialogCreateVisible = false;
    },
    //确认创建存储卷
    sureCreateStorage(formName) {
      console.log(this.createStorageForm);
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.$http
            .post(
              "/cloud/persistentVolume/addPersistentVolume",
              this.createStorageForm
            )
            .then(res => {
              if (res.data.success) {
                this.$message({
                  message: res.data.msg,
                  type: "success"
                });
                this.dialogCreateVisible = false;
                this.getList();
                this.leftRes();
              } else {
                this.$message({
                  message: res.data.msg,
                  type: "error"
                });
              }
            });
        } else {
          return false;
        }
      });
    },

    //删除存储卷

    deletStorage(row) {
      this.$confirm("此操作将永久删除存储卷, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.$http
            .get("/cloud/persistentVolume/deletePersistentVolume?id=" + row.id)
            .then(res => {
              if (res.data.success) {
                this.$message({
                  message: res.data.msg,
                  type: "success"
                });
                this.getList();
                this.leftRes();
              } else {
                this.$message({
                  message: res.data.msg,
                  type: "error"
                });
              }
            });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    }

    //冻结存储卷
    // freezeStorage(row){
    // this.$http
    //   .get("/cloud/persistentVolume/queryPersistentById?id=" + row.id)
    //   .then(res => {
    //     this.createStorageForm = res.data.obj;
    // if(row.state==3){
    //     this.$message({
    //     message: "该项目已冻结",
    //     type: "success"
    //   });
    // }else{
    //   this.$http.get("/cloud/persistentVolume/freezePersistentVolume?id="+row.id)
    //   .then(res =>{
    //     if (res.data.success) {
    //       this.$message({
    //         message: res.data.msg,
    //         type: "success"
    //       });
    //       this.getList();
    //     } else {
    //       this.$message({
    //         message: res.data.msg,
    //         type: "error"
    //       });
    //     }
    //   })
    // }
    // })
    // },

    //编辑存储卷

    // editStorage(row) {

    //    //清空数据
    //     this.createStorageForm.name = "";
    //     this.createStorageForm.createTime = "";
    //     this.createStorageForm.storageSize = "";
    //     this.createStorageForm.description = "";
    //     this.createStorageForm.projectId = "";
    //   //根据ID 查询存储卷详细信息
    //   this.$http
    //     .get("/cloud/persistentVolume/queryPersistentById?id=" + row.id)
    //     .then(res => {
    //       this.createStorageForm = res.data.obj;
    //       if(row.state==3){
    //           this.$message({
    //           message: "冻结状态下不可编辑",
    //           type: "error"
    //         });
    //       }
    //       else{
    //           this.dialogCreateVisible = true;
    //            this.isEdit = true;
    //             this.title = "编辑存储卷";
    //             this.disabled=true;
    //       }
    //     });

    // },
    //保存编辑
    // suerEdit() {
    //   this.$http
    //     .post("/cloud/persistentVolume/updatePersistentVolume", this.createStorageForm)
    //     .then(res => {
    //       if (res.data.success) {
    //         this.$message({
    //           message: res.data.msg,
    //           type: "success"
    //         });
    //         this.dialogCreateVisible = false;
    //         this.getList();
    //         this.leftRes();
    //       } else {
    //         this.$message({
    //           message: res.data.msg,
    //           type: "error"
    //         });
    //       }
    //     });
    // },
  }
};
</script>
<style scoped>
.pagination-container {
  margin-top: 20px;
}
</style>
