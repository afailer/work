export default {
    name: "complexTable",
  
    data() {
      return {
        //创建用户
        careatUserForm: {
          loginname: "",
          password: "",
          realname: "",
          reason: "",
          ids: "",
          groups: ""
        },
        roleCode: "",
        userCode: "", //用户uaaid
        userIfo: "",
        userRoleList: [],
        //分配用户
        dialogRoleVisible: false,
        //审核用户
        dialogExamineVisible: false,
        examinetUserForm: {
          username: "",
          code: "",
          reason: "",
          startRegisterTime: "",
          reason: "",
          uaaid: "",
          state: "",
          auditReason: "",
          ids: "",
          groups: ""
        },
        ids: "",
        groupId: "",
  
        showFlag: false,
  
        roleForm: {
          roleList: ""
        },
  
        currentPage: 1,
        userData: [],
        tableKey: 0,
        total: null,
        pageSize: 10,
        listLoading: true,
        listQuery: {
          title: undefined
        },
        //创建用户
        dialogCreateVisible: false,
        dialogPvVisible: false,
        downloadLoading: false
      };
    },
   
    filters: {
      statesFilters: function(value) {
        switch (value) {
          case 0:
            return "不通过";
            break;
          case 1:
            return "通过";
            break;
          case 2:
            return "待审核";
            break;
        }
      }
    },
    created() {
      this.getList();
    },
    methods: {
      getList() {
        this.$http
          .get(
            "/cloud/user/queryTenantUser?pageNum=" +
              this.currentPage +
              "&pageSize=" +
              this.pageSize +
              ""
          )
          .then(res => {
            this.total = res.data.obj.totalCount;
            this.userData = res.data.obj.result;
          });
      },
  
      openCreate() {},
      handleFilter() {},
      handleSizeChange(val) {
        this.pageSize = val;
        this.getList();
      },
  
      //分页查询
      handleCurrentChange(val) {
        this.currentPage = val;
        this.getList();
      },
      handleModifyStatus(row, status) {},
      resetTemp() {
        this.temp = {
          id: undefined,
          importance: 1,
          remark: "",
          timestamp: new Date(),
          title: "",
          status: "通过",
          type: ""
        };
      },
      //创建用户
      createUser() {
        this.dialogCreateVisible = true;
        this.careatUserForm.loginname = "";
        this.careatUserForm.password = "";
        this.careatUserForm.reason = "";
        this.ids= "";
        this.groupId= "";
         //获取IDS
  
        this.$http.get("/cloud/project/queryCurrentUserProjectList").then(res => {
         
  
          if (res.data.success) {
            this.careatUserForm.ids = res.data.obj.result;
          } else {
          }
        });
  
        //获取groups
  
        this.$http.get("/cloud/userGroup/queryUserGroup").then(res => {
          if (res.data.success) {
            this.careatUserForm.groups = res.data.obj;
          } else {
          }
        });
      },
  
      //确认创建用户
      suerCreatUser() {
        this.$http
          .post("/cloud/tenant/addUserByTenant?ids=" +this.ids +"&groupId=" +this.groupId, this.careatUserForm)
          .then(res => {
            if (res.data.success) {
              this.$message({
                message: res.data.msg,
                type: "success"
              });
              this.dialogCreateVisible = false;
              this.getList();
            } else {
              this.$message({
                message: res.data.msg,
                type: "error"
              });
            }
          });
      },
  
      //审核用户
      examine(row) {
        this.dialogExamineVisible = true;
  
        showFlag: false, (this.examinetUserForm.username = row.username);
        this.examinetUserForm.code = row.code;
        this.examinetUserForm.reason = row.reason;
        this.examinetUserForm.startRegisterTime = row.startRegisterTime;
        this.examinetUserForm.reason = row.reason;
        this.examinetUserForm.uaaid = row.uaaid;
        this.examinetUserForm.state = row.state;
        this.examinetUserForm.auditReason = '';
        this.ids= "";
        this.groupId= "";
  
        //获取IDS
  
        this.$http.get("/cloud/project/queryCurrentUserProjectList").then(res => {
         
  
          if (res.data.success) {
            this.examinetUserForm.ids = res.data.obj.result;
          } else {
          }
        });
  
        //获取groups
  
        this.$http.get("/cloud/userGroup/queryUserGroup").then(res => {
          if (res.data.success) {
            this.examinetUserForm.groups = res.data.obj;
          } else {
          }
        });
      },
  
      //审核通过
      auditPass() {
        this.$http
          .get(
            "/cloud/tenant/updateTenantUser?code=" +
              this.examinetUserForm.code +
              "&state=1" +
              "&ids=" +
              this.ids +
              "&groupId=" +
              this.groupId +
              "&auditReason" +
              this.examinetUserForm.auditReason
          )
          .then(res => {
            if (res.data.success) {
              this.$message({
                message: res.data.msg,
                type: "success"
              });
              this.dialogExamineVisible = false;
              this.getList();
            } else {
              this.$message({
                message: res.data.msg,
                type: "error"
              });
            }
          });
      },
  
      //审核不通过
      auditNoPass() {
        this.showFlag = true;
      },
  
      //确定不通过
      sureNoPass() {
        this.$http
          .get(
            "/cloud/tenant/updateTenantUser?code=" +
              this.examinetUserForm.code +
              "&state=0" +
              "&ids=" +
              this.ids +
              "&groupId=" +
              this.groupId +
              "&auditReason=" +
              this.examinetUserForm.auditReason
          )
          .then(res => {
            if (res.data.success) {
              this.$message({
                message: res.data.msg,
                type: "success"
              });
              this.dialogExamineVisible = false;
              this.getList();
            } else {
              this.$message({
                message: res.data.msg,
                type: "error"
              });
            }
          });
      },
  
      //取消审核
      cancleExamin(){
        this.dialogExamineVisible = false;
        this.examinetUserForm.auditReason = '';
        this.ids= "";
        this.groupId= "";
        this.showFlag=false;
      },
      //删除用户
  
      deleUser(row) {
        this.$confirm("此操作将永久删除用户, 是否继续?", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        })
          .then(() => {
            this.$http.post("/cloud/user/deleteTenantUser", row).then(res => {
              if (res.data.success) {
                this.$message({
                  message: res.data.msg,
                  type: "success"
                });
                this.getList();
              } else {
                this.$message({
                  message: res.data.msg,
                  type: "error"
                });
              }
            });
          })
          .catch(() => {
            this.$message({
              type: "info",
              message: "已取消删除"
            });
          });
      },
  
      //分配角色
      // distributionRole(row) {
      //   this.userCode = row.uaaid;
      //   this.userIfo = row;
  
      //   this.dialogRoleVisible = true;
      //   //查询角色列表
  
      //   this.$http.get("/uaa/role/getRoleListByCurrentUser").then(res => {
      //     if (res.data.success) {
      //       this.roleForm.roleList = res.data.obj;
      //     } else {
      //       this.$message({
      //         message: res.data.msg,
      //         type: "error"
      //       });
      //     }
      //   });
      // },
  
      //确认分配角色
      // allocationRole() {
      
      //   this.userRoleList[0] = {
      //     roleCode: "",
      //     userCode: "",
      //     code: ""
      //   };
      //   this.userRoleList[0].roleCode = this.roleCode;
      //   this.userRoleList[0].userCode = this.userCode;
      //   this.userRoleList[0].code = "";
      //   this.$http
      //     .post(
      //       "/uaa/user/role/addUserRoles?userCode=" + this.userCode,
      //       this.userRoleList
      //     )
      //     .then(res => {
      //       if (res.data.success) {
      //         this.$message({
      //           message: res.data.msg,
      //           type: "success"
      //         });
      //         this.dialogRoleVisible = false;
      //         this.getList();
      //       } else {
      //         this.$message({
      //           message: res.data.msg,
      //           type: "error"
      //         });
      //       }
      //     });
      // }
    }
  };