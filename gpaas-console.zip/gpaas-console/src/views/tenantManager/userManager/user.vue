
<template>
  <div class=" calendar-list-container">
    <div class="filter-container" >
      <!-- <el-input @keyup.enter.native="handleFilter" style="width: 200px;" placeholder="请输入内容" v-model="listQuery.title">
      </el-input>
      <el-button  type="primary" icon="el-icon-search" @click="handleFilter">搜索</el-button> -->
      <el-button  type="primary" icon="el-icon-plus" @click="createUser">创建用户</el-button>
    </div>
<!-- v-loading="listLoading" -->
    <div style="margin-left:10px">
      <el-table :key='tableKey' :data="userData"  element-loading-text="给我一点时间" border fit highlight-current-row
        style="width: 100%">
        <el-table-column align="center" label="用户名称" >
          <template slot-scope="scope">
            <span>{{scope.row.username}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="状态" >
          <template slot-scope="scope">
            <span>{{scope.row.state | statesFilters}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="申请原因" >
          <template slot-scope="scope">
            <span>{{scope.row.reason}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="租户ID" >
          <template slot-scope="scope">
            <span>{{scope.row.tenantId}}</span>
          </template>
        </el-table-column>
      
        <el-table-column width="160" align="left" label="操作"  class-name="small-padding fixed-width">
          <template slot-scope="scope">
            <el-button v-if="scope.row.state == 2" type="primary" size="mini" @click="examine(scope.row)">审核</el-button>
            <!-- <el-button  size="mini" type="success" @click="editNode(scope.row)">编辑  -->
            <!-- </el-button> -->
            <el-button  size="mini" type="danger" @click="deleUser(scope.row)">删除
            </el-button>
            <!-- <el-button  size="mini" @click="distributionRole(scope.row)">分配角色 -->
            </el-button>
            
          </template>
        </el-table-column>
      </el-table>

        <div class="pagination-container">
            <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[10,20,30, 50]" :page-size="100" layout="total, sizes, prev, pager, next, jumper" :total="total">
            </el-pagination>
    
        </div>
    </div>
        <!-- 创建用户 -->
        <div style="">
            <el-dialog title="创建用户" :visible.sync="dialogCreateVisible">
            <div style="width:80%;margin:0 auto">
            <el-form ref="auditNodeForm" :model="careatUserForm" label-width="100px">
                <el-form-item label="用户名称">
                    <el-input v-model="careatUserForm.loginname" placeholder="请输入用户名"></el-input>
                </el-form-item>          
                <el-form-item label="密码">
                    <el-input v-model="careatUserForm.password" placeholder="请输入密码">
                    
                    </el-input>
                </el-form-item> 

                <!-- <el-form-item label="真实姓名">
                    <el-input v-model="careatUserForm.realname">
                    
                    </el-input>
                </el-form-item>    -->
                 <el-form-item label="申请原因">
                    <el-input type="textarea" v-model="careatUserForm.reason"  placeholder="请输入申请原因"></el-input>
                  </el-form-item>

                  <el-form-item label="选择项目">
                        <el-select v-model="ids" placeholder="请选择项目">
                        <el-option
                            v-for="item in careatUserForm.ids"
                            :key="item.value"
                            :label="item.name"
                            :value="item.id">
                            </el-option>
                        </el-select>
                </el-form-item>


                <el-form-item label="选择小组">
                        <el-select v-model="groupId" placeholder="请选择组">
                        <el-option
                            v-for="item in careatUserForm.groups"
                            :key="item.value"
                            :label="item.name"
                            :value="item.groupid">
                            </el-option>
                        </el-select>
                </el-form-item>
                
                <el-form-item>
                    <el-button type="primary" @click="suerCreatUser">创建</el-button>
                    <!-- <el-button type="danger" @click="auditNodeReject">审核驳回</el-button> -->
                    <el-button @click="dialogCreateVisible = false">取消</el-button>
                </el-form-item>
                </el-form>
                </div>
            </el-dialog>
        </div>

        <!-- 审核用户 -->
          <div style="">
            <el-dialog title="审核用户" :visible.sync="dialogExamineVisible">
            <div style="width:80%;margin:0 auto">
            <el-form ref="auditNodeForm" :model="examinetUserForm" label-width="100px">
                <el-form-item label="租户名称">
                    <el-input v-model="examinetUserForm.username"></el-input>
                </el-form-item>          
                <el-form-item label="code">
                    <el-input v-model="examinetUserForm.code">
                    
                    </el-input>
                </el-form-item>   
                 <el-form-item label="申请原因">
                   <el-input v-model="examinetUserForm.reason">
                    
                    </el-input>
                </el-form-item>       
                <el-form-item label="uaaid">
                    <el-input v-model="examinetUserForm.uaaid">
                    
                    </el-input>
                </el-form-item>          
                <!-- <el-form-item label="注册时间">
                   <el-input v-model="examinetUserForm.startRegisterTime">
                    
                    </el-input>
                </el-form-item> -->

                  <el-form-item label="选择项目">
                        <el-select v-model="ids" placeholder="请选择项目">
                        <el-option
                            v-for="item in examinetUserForm.ids"
                            :key="item.value"
                            :label="item.name"
                            :value="item.id">
                            </el-option>
                        </el-select>
                </el-form-item>


                <el-form-item label="选择小组">
                        <el-select v-model="groupId" placeholder="请选择组">
                        <el-option
                            v-for="item in examinetUserForm.groups"
                            :key="item.value"
                            :label="item.name"
                            :value="item.groupid">
                            </el-option>
                        </el-select>
                </el-form-item>

                  <el-form-item label="不通过原因" v-if=showFlag>
                    <el-input type="textarea" v-model="examinetUserForm.auditReason" placeholder="请输入不通过原因" ></el-input>
                  </el-form-item>
                
                <el-form-item>
                    <el-button type="primary" @click="auditPass" v-if="examinetUserForm.state != 1&&examinetUserForm.state != 0&& !showFlag">通过</el-button>

                    <el-button type="primary" @click="auditNoPass" v-if="examinetUserForm.state != 1&&examinetUserForm.state != 0 && !showFlag">不通过</el-button>
                    <el-button type="primary" @click="sureNoPass" v-if=showFlag>确定</el-button>
                    <!-- <el-button type="danger" @click="auditNodeReject">审核驳回</el-button> -->
                    <el-button @click="cancleExamin">取消</el-button>
                </el-form-item>
                </el-form>
                </div>
            </el-dialog>
        </div>

        <!-- 分配角色 -->
         <!-- <div style="">
            <el-dialog title="分配角色" :visible.sync="dialogRoleVisible">
            <div style="width: 400px">
            <el-form ref="auditNodeForm" :model="roleForm" label-width="80px">
                 <el-form-item label="角色名称">
                    <el-input v-model="roleForm.name"></el-input>
                </el-form-item>   
                 <el-form-item label="角色名称">
                        <el-select v-model="roleCode" placeholder="请选择角色">
                        <el-option
                            v-for="item in roleForm.roleList"
                            :key="item.code"
                            :label="item.name"
                            :value="item.code">
                            </el-option>
                        </el-select>
                </el-form-item>

                <el-form-item>
                    <el-button type="primary" @click="allocationRole">确认</el-button>
                    <el-button type="danger" @click="auditNodeReject">审核驳回</el-button>
                    <el-button @click="dialogRoleVisible = false">取消</el-button>
                </el-form-item>
                </el-form>
                </div>
            </el-dialog>
        </div> -->


  </div>
</template>

<script>
  import user from './js/user'
    export default{
        ...user
    }
</script>
<style scoped>
.pagination-container {
  margin-top: 20px;
}

.filter-container {
  margin: 10px;
}
</style>
