<template>
    <div style="margin-left:10px">
        <commandDialog ></commandDialog>
        <logDialog ></logDialog>
        <monitorDialog></monitorDialog>
        <div class="title">
            {{name}}
        </div>
        <el-tabs v-model="activeName" @tab-click="handleClick">
            <el-tab-pane label="详情" name="first">
                <div class="detailWrap">
                    <ul class="detailList list1">
                        <li>
                            <span class="name">状态：</span>
                            <span>{{statusType}}</span><br>
                            <span class="name">状态描述：</span>
                            <span>{{statusReason}}</span>
                        </li>
                        <li>
                            <span class="name">容器数量：</span>
                            <span>可用数量:{{readyReplicas | readyReplicasFilter }}&nbsp;/&nbsp;期望数量:{{replicas}}</span>
                        </li>
                    </ul>
                    <p class="template">应用信息</p>
                    <ul class="detailList" style="margin-top:10px">
                        <li>
                            <span class="name">镜像库地址：</span>
                            <span>{{image}}</span>
                        </li>
                        <li class="mount" v-if="devVisible">
                            <span class="name">挂载路径：</span>
                            <ul>
                                <li v-for="item in devPvcList">
                                    <span v-if="item.volumesType == 1">{{item.name}}</span>
                                    <span v-if="item.volumesType == 2">{{item.configMapName}}</span>→{{item.mountPath}}
                                    <span v-if="item.volumesType == 2">/</span>{{item.path}}
                                    <el-tag size="mini" style="font-size: 12px;color: #409EFF;border-radius:4px;height: 20px;padding: 0 5px;line-height: 19px;margin-left:10px">{{item.volumesType | typeFilter }}</el-tag>
                                </li>
                                
                            </ul>
                        </li>
                        <li>
                            <span class="name">最大内存：</span>
                            <span>{{maxMemory | memoryFilter }}</span>
                        </li>
                         <li>
                            <span class="name">最小内存：</span>
                            <span>{{minMemory | memoryFilter }}</span>
                        </li>
                        <li>
                            <span class="name">最大CPU：</span>
                            <span>{{maxCpu | cpuFilter }}</span>
                        </li>
                        <li>
                            <span class="name">最小CPU：</span>
                            <span>{{minCpu | cpuFilter }}</span>
                        </li>

                    </ul>
                    <!-- <div v-if="devVisible">
                        <p class="template">挂载卷信息</p>
                        <ul class="detailList" v-for="item in devPvcList" style="margin-top:10px">
                            <li>
                                <span class="name">类型：</span>
                                <span>{{item.volumesType | typeFilter }}</span>
                            </li>
                            <li v-if="item.volumesType == 1">
                                <span class="name">挂载卷名称：</span>
                                <span>{{item.claimName}}</span>
                            </li>
                            <li v-if="item.volumesType == 2">
                                <span class="name">配置文件名称：</span>
                                <span>{{item.configMapName}}</span>
                            </li>
                        </ul>
                    </div> -->
                    

                    <div class="circleWrap">
                        <div class="bCircle">
                            <div class="sCircle">
                                <p v-model="replicas" style="font-size:28px">{{replicas}}</p>
                                <p>容器</p>
                            </div>
                        </div>
                        <i class="el-icon-arrow-up up" @click="add" v-loading.fullscreen.lock="fullscreenLoading" element-loading-text="正在操作,稍后刷新查看" element-loading-background="rgba(255, 255, 255, 0.5)"></i>
                        <i class="el-icon-arrow-down down" @click="reduce" v-loading.fullscreen.lock="fullscreenLoading" element-loading-text="正在操作,稍后刷新查看" element-loading-background="rgba(255, 255, 255, 0.5)"></i>
                    </div>
                </div>
                <!-- 容器组 -->
                <el-table :data="containerGroup" style="width:97%;margin-bottom:20px;">
                    <el-table-column label="容器组">
                        <el-table-column label="名称" sortable>
                            <template slot-scope="scope">
                                <i class="el-icon-circle-check" style="color:green"></i>
                                 <!-- <i style="margin-right:5px" class="el-icon-loading"></i> -->
                                <span style="margin-left: 10px">{{ scope.row.name }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="节点" width="150">
                            <template slot-scope="scope">
                                <span style="margin-left: 10px">{{ scope.row.nodeName }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="状态" sortable width="140">
                            <template slot-scope="scope" >
                                <span  v-if="scope.row.status == Running"  style="margin-left: 10px;background:#4ECDCD;color:#fff;padding:5px 10px;border-radius:2px"><i class="el-icon-circle-check" style="color:#fff"></i> {{ scope.row.status }}</span>
                                <span  v-else-if="scope.row.status == Pending"   style="margin-left: 10px;background:#FFD700;color:#fff;padding:5px 10px;border-radius:2px"> <i style="color:#fff;margin-right:2px" class="el-icon-loading"></i> {{ scope.row.status }}</span>
                                <span  v-else-if="scope.row.status == waiting"    style="margin-left: 10px;background:#FFD700;color:#fff;padding:5px 10px;border-radius:2px"> <i style="color:#fff;margin-right:2px" class="el-icon-loading"></i>{{ scope.row.status }}</span>
                                <span  v-else-if="scope.row.status == terminating"    style="margin-left: 10px;background:#FFD700;color:#fff;padding:5px 10px;border-radius:2px"> <i style="color:#fff;margin-right:2px" class="el-icon-loading"></i>{{ scope.row.status }}</span>
                                 <span  v-else  style="margin-left: 10px;background:red;color:#fff;padding:5px 10px;border-radius:2px"> <i class="el-icon-circle-close" style="color:#fff"></i>  {{ scope.row.status }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="已重启" width="120">
                            <template slot-scope="scope">
                                <span style="margin-left: 10px">{{ scope.row.restartCount }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="已创建" sortable width="180">
                            <template slot-scope="scope">
                                <span style="margin-left: 10px">{{ scope.row.creationTimestamp | formatDatetwo}}</span>
                            </template>
                        </el-table-column>
                        <!-- <el-table-column label="CPU(核)" width="120"></el-table-column> -->
                        <!-- <el-table-column label="内存(字节)" width="120"></el-table-column> -->
                        <el-table-column label="操作">
                            <template slot-scope="scope">
                                <a><el-button type="text" @click="command(scope.row)" style="color:#409EFF">执行命令</el-button></a>
                                <el-button type="text" @click="log(scope.row)" style="color:#409EFF">日志</el-button>
                                <el-button type="text" @click="showEvent(scope.row)" style="color:#409EFF">事件</el-button>
                                <el-button type="text" @click="delApplication(scope.row)" style="color:#409EFF">删除</el-button>
                                <el-button type="text" @click="monitorApplication(scope.row)" style="color:#409EFF">监控</el-button>
                            </template>
                        </el-table-column>
                    </el-table-column>
                </el-table>
                <!-- 服务 -->
                <el-table v-if="serviceVisible" :data="service" style="width:97%;margin-bottom:20px;">
                    <el-table-column label="服务">
                        <el-table-column label="名称" sortable>
                            <template slot-scope="scope">
                                <i class="el-icon-circle-check" style="color:green"></i>
                                <span style="margin-left: 10px">{{ scope.row.name }}</span>
                            </template>
                        </el-table-column>
                        <!-- <el-table-column label="标签">
                            <template slot-scope="scope">
                                <span>{{ scope.row.labels }}</span>
                            </template>
                        </el-table-column> -->
                        <el-table-column label="集群IP" width="140">
                            <template slot-scope="scope">
                                <span>{{ scope.row.clusterIP }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="内部入口">
                            <template slot-scope="scope">
                                <span>{{ scope.row.innerIp }}&nbsp;:&nbsp;<span  style="margin-left:5px" v-for="item in ports">{{ item }} </span></span>
                            </template>
                        </el-table-column>
                        <el-table-column label="外部入口">
                            <template slot-scope="scope">
                                <span v-if="nodeVisible">{{nodeIp}}&nbsp;
                                    <!-- <span v-if="!nodePorts==''">:&nbsp;<a  style="text-decoration:underline;color:blue"  v-for="item in changeArry(nodePorts)"   @click="openOther(nodeIp,item)">  {{item}} </a> </span> -->
                                      <span v-if="!nodePorts==''">:&nbsp;<a  v-for="item in changeArry(nodePorts)"  >  {{item}} </a> </span>
                                </span>
                                <span v-if="!nodeVisible">-</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="已创建" sortable>
                            <template slot-scope="scope">
                                <span>{{ scope.row.createTime | formatDatetwo }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="类型" sortable>
                            <template slot-scope="scope">
                                <span>{{ scope.row.type}}</span>
                            </template>
                        </el-table-column>
                    </el-table-column>
                </el-table>
                <!-- http -->
                <el-table v-if="portVisible" :data="http" style="width:97%;margin-bottom:20px;">
                    <el-table-column label="HTTP代理">
                        <el-table-column label="域名" align="center">
                            <template slot-scope="scope">
                                <span style="margin-left: 10px">{{ scope.row.host }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column label="端口" align="center">
                            <template slot-scope="scope">
                                <span style="margin-left: 10px">
                                    <a  style="text-decoration:underline;color:blue"  @click="openPort(scope.row.host,nodePort,scope.row.http.paths[0].path)">{{ nodePort }}</a></span>
                            </template>
                        </el-table-column>
                        <el-table-column label="路径" align="center">
                            <template slot-scope="scope">
                                <span style="margin-left: 10px">{{ scope.row.http.paths[0].path }}</span>
                            </template>
                        </el-table-column>
                    </el-table-column>
                </el-table>
            </el-tab-pane>
            <el-tab-pane label="环境变量" name="second">
                <ul class="list" v-if="!envVisible">
                    <li>
                        <span>名称</span>
                        <span>值</span>
                    </li>
                    <li class="item" v-for="item in envList">
                        <span class="name">{{item.name}}</span>
                        <span>{{item.value}}</span>
                    </li>
                </ul>
                <div v-if="envVisible">该应用未设置环境变量!</div>
            </el-tab-pane>
            <el-tab-pane label="事件" name="third">
                <!-- <div class="box">
                        <p class="wrap">
                            <el-input placeholder="Filter by keyword" v-model="searchText"></el-input>
                        </p>
                </div> -->
                <el-table v-if="!eventVisible" :data="eventList" style="width: 95%">
                    <el-table-column label="时间">
                        <template slot-scope="scope">
                            <span>{{scope.row.lastTimestamp | formatDatetwo }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="事件类型">
                        <template slot-scope="scope">
                            <span>{{scope.row.reason }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="描述">
                        <template slot-scope="scope">
                            <span>{{scope.row.message }}</span>
                        </template>
                    </el-table-column>
                </el-table>
                <div v-if="eventVisible">该应用无事件!</div>
            </el-tab-pane>
        </el-tabs>
         <!-- 事件 -->
         <el-dialog title="事件"  :visible.sync="eventDialogVisible" width="80%">
            <el-table :data="containerEventList" style="width: 95%">
                <el-table-column label="时间">
                    <template slot-scope="scope">
                        <span>{{scope.row.lastTimestamp | formatDatetwo }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="事件类型">
                    <template slot-scope="scope">
                        <span>{{scope.row.reason }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="描述">
                    <template slot-scope="scope">
                        <span>{{scope.row.message }}</span>
                    </template>
                </el-table-column>
            </el-table>
        </el-dialog>
    </div>
</template>


<script>
    import applicationDetail from './js/applicationDetail'
    export default{
        ...applicationDetail
    }
</script>

<style scoped>
* {
  margin: 0;
  padding: 0;
  font-size: 14px;
  color: #606266;
}
ul {
  list-style: none;
}
.title {
  height: 100px;
  line-height: 100px;
  font-size: 28px;
}
.list li {
  height: 34px;
  line-height: 34px;
}
.list .item {
    height: auto;
  margin-bottom: 17px;
}
.list span {
  display: inline-block;
  width: 45%;
  padding:0 5px;
}
.list .item>span {
  background: rgb(246, 245, 244);
  border: 1px solid rgb(208,206, 202);
  color: rgb(174, 173, 171);
}
.list .item .name{
    display: block;
    float: left;
    margin-right: 5px;
}
.box {
  height: 68px;
  width: 95%;
}
.box .wrap {
  margin: 15px 0 0 15px;
  height: 38px;
  width: 375px;
  float: left;
}
.detailWrap {
  width: 800px;
  position: relative;
}
.detailList {
  margin-bottom: 15px;
}
.detailList>li {
  height: 30px;
  line-height: 30px;
  margin-left: 10px;
}
.detailList .mount{
    height: auto;
}
.detailList .mount>span{
    vertical-align: top;
}
.detailList .mount ul{
    display: inline-block;
}
.detailList .mount ul li{
    height: 30px;
  line-height: 30px;
}
.list1>li{
    height: 60px;
}
.detailList .name {
  width: 155px;
  display: inline-block;
}
.detailWrap .template {
  border-bottom: 1px solid rgb(241, 240, 239);
  height: 46px;
  line-height: 46px;
  font-weight: bold;
}
.circleWrap {
  width: 248px;
  height: 200px;
  padding-top: 5px;
  position: absolute;
  top: 0;
  right: 0;
}
.bCircle {
  width: 164px;
  height: 164px;
  border-radius: 100%;
  background: #07bce4;
  position: absolute;
}
.sCircle {
  width: 144px;
  height: 144px;
  border-radius: 100%;
  background: #fff;
  position: absolute;
  top: 11px;
  left: 11px;
  text-align: center;
  padding-top: 48px;
}
.circleWrap i {
  font-weight: bold;
  font-size: 30px;
  color: #bebbb5;
  cursor: pointer;
  position: absolute;
  right: 35px;
}
.circleWrap .up {
  top: 50px;
}
.circleWrap .down {
  top: 100px;
}
</style>

