
<template>
  <div class=" calendar-list-container">
    <div class="filter-container" style="margin:10px">
      <!-- <el-input @keyup.enter.native="handleFilter" style="width: 200px;" placeholder="请输入内容" v-model="listQuery.title">
      </el-input>
      <el-button  type="primary" icon="el-icon-search" @click="handleFilter">搜索</el-button> -->
      <el-button style="display:block;float:left;"  type="primary" icon="el-icon-plus" @click="createProject">创建项目</el-button>
      <el-card style="display: block;float: left;margin: 0 20px 15px;height: 43px;font-size:14px">
        <span style="font-weight:bold;color:#606266;">
          剩余节点资源：</span> CPU：{{leftResource.leftCpu |subsFiter}}核 / 内存：{{leftResource.leftMemory |subsFiter}}G / 硬盘：{{leftResource.leftStorageSize}}G
      </el-card>
    </div>
<!-- v-loading="listLoading" -->
    <div style="margin-left:10px">
      <el-table :key='tableKey' :data="projectData"  element-loading-text="给我一点时间" border fit highlight-current-row
        style="width: 100%">
        <el-table-column align="center" label="项目名称" >
          <template scope="scope">
            <a style="text-decoration:underline;color:blue" @click="goConsole(scope.row)">{{scope.row.name}}</a>

          </template>
        </el-table-column>
        <el-table-column align="center" label="硬盘" >
          <template slot-scope="scope">
            <span>{{scope.row.storageSize | memoryFilters }}</span>
          </template>
        </el-table-column>
          <el-table-column align="center" label="内存总量">
          <template slot-scope="scope">
            <span>{{scope.row.memory |statesFilters}}</span>
          </template>
        </el-table-column>
        
        <el-table-column align="center" label="cpu" >
          <template slot-scope="scope">
            <span>{{scope.row.cpu | cpuFilters}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="项目状态" >
          <template slot-scope="scope">
            <span>{{scope.row.state | stateFilter}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="创建时间">
          <template slot-scope="scope">
            <span>{{scope.row.createTime |formatDatetwo}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="描述" >
          <template slot-scope="scope">
            <span>{{scope.row.description}}</span>
          </template>
        </el-table-column>
        
      
        <el-table-column align="center" label="操作" width="300" class-name="small-padding fixed-width">
          <template slot-scope="scope">
            <!-- <el-button type="primary" size="mini" @click="examine(scope.row)">审核</el-button> -->
            <el-button  size="mini" type="success" @click="editProject(scope.row)">编辑 
            </el-button>
            <el-button  size="mini" type="danger" @click="deleUser(scope.row)">删除
            </el-button>
          <el-button  size="mini" type="danger" @click="goConsole(scope.row)">管理项目
            </el-button>            
          </template>
        </el-table-column>
      </el-table>
    
        <div class="pagination-container">
            <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[10,20,30, 50]" :page-size="100" layout="total, sizes, prev, pager, next, jumper" :total="total">
            </el-pagination>
    
        </div>
    </div>
        <!-- 创建和编辑 -->
        <div style="">
            <el-dialog :title="title" :visible.sync="dialogCreateVisible">
            <div style="width:80%;margin:0 auto">
            <el-form ref="careatProgectForm" :rules="rules" :model="careatProgectForm" label-width="100px">
                <el-form-item label="项目名称" prop="name">
                    <el-input v-model="careatProgectForm.name" :disabled="isEdit" placeholder="请输入项目名称"></el-input>
                </el-form-item>          
                <el-form-item label="cpu总量" prop="cpu">
                    <el-input v-model="careatProgectForm.cpu" placeholder="请输入CPU大小">
                       <template slot="append">核</template>
                    </el-input>
                </el-form-item> 

                <el-form-item label="内存总量" prop="memory" >
                    <el-input v-model="careatProgectForm.memory" placeholder="请输入内存大小">
                         <template slot="append">G</template>
                    </el-input>
                </el-form-item>   
                <el-form-item label="硬盘总量" prop="storageSize">
                    <el-input v-model="careatProgectForm.storageSize" placeholder="请输入硬盘大小">
                         <template slot="append">G</template>
                    </el-input>
                </el-form-item> 

                <el-form-item label="项目描述">
                    <el-input  type="textarea"  v-model="careatProgectForm.description" placeholder="请输入项目描述">
                    
                    </el-input>
                </el-form-item> 
                
                
                <el-form-item>
                    <el-button type="primary" @click="suerCreatUser('careatProgectForm')" v-if="!isEdit">创建</el-button>
                    <el-button type="danger" @click="suerEdit" v-if="isEdit">保存</el-button>
                    <el-button @click="dialogCreateVisible = false">取消</el-button>
                </el-form-item>
                </el-form>
                </div>
            </el-dialog>
        </div>

  </div>
</template>

<script>
 import project from './js/project'
    export default{
        ...project
    }


</script>
<style scoped>
.pagination-container {
  margin-top: 20px;
}
</style>
