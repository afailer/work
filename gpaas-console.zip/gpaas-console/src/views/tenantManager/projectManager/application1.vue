
<template>
  <div class="calendar-list-container">
    <div class="filter-container" style="margin:10px">
      <!-- <el-input @keyup.enter.native="handleFilter" style="width: 200px;" placeholder="请输入内容" v-model="listQuery.title">
      </el-input>
      <el-button type="primary" icon="el-icon-search" @click="handleFilter">搜索</el-button> -->
      <el-button type="primary" icon="el-icon-plus" @click="createApplication">创建应用</el-button>
    </div>
    <!-- v-loading="listLoading" -->
    <div style="margin-left:10px">
      <el-table :key='tableKey' :data="projectData" element-loading-text="给我一点时间" border fit highlight-current-row style="width: 100%">
        <el-table-column align="center" label="应用名称">
          <template slot-scope="scope">
            <a style="text-decoration:underline;color:blue" @click="detail(scope.row)">{{scope.row.name}}</a>
            <span v-if="scope.row.type==2">
              <el-tag size="mini">服务</el-tag>
            </span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="持久化">
          <template slot-scope="scope">
            <span>{{scope.row.devPvcList |longFilters }}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="镜像地址">
          <template slot-scope="scope">
            <span>{{scope.row.imageurl}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="创建时间">
          <template slot-scope="scope">
            <span>{{scope.row.createTime}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="描述">
          <template slot-scope="scope">
            <span>{{scope.row.description}}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="操作" class-name="small-padding fixed-width">
          <template slot-scope="scope">
            <!-- <el-button type="primary" size="mini" @click="examine(scope.row)">审核</el-button> -->
            <el-button size="mini" type="success" @click="editProject(scope.row)">更新
            </el-button>
            <el-button size="mini" type="danger" @click="deleUser(scope.row)">删除
            </el-button>
           

          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="pagination-container">
      <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[10,20,30, 50]" :page-size="100" layout="total, sizes, prev, pager, next, jumper" :total="total">
      </el-pagination>

    </div>

    <div class="dialog" style="">
      <el-dialog :title="title" width="80%" :fullscreen="isFull" :visible.sync="dialogCreateVisible">

        <el-row style="background:#dcdfe6;padding:5px;border-radius:2px;margin-bottom:10px">
          <el-col>
            <div class="grid-content bg-purple">

              <div style="width:600px;margin:0 auto">
                <span>剩余资源：</span>
                <span style="margin-left:60px"> CPU：
                  <span style="color:red"> {{leftResource.leftCpu |subsFiter}} </span> 核</span>
                <span style="margin-left:60px"> 内存：
                  <span style="color:red"> {{leftResource.leftMemory |subsFiter}}</span> M </span>
                <span style="margin-left:60px"> 硬盘：
                  <span style="color:red"> {{leftResource.leftStorageSize}} </span> G</span>

              </div>

            </div>
          </el-col>
        </el-row>

        <div style="width:80%;margin:0 auto">
          <el-form :rules="rules" ref="applicationForm" :model="applicationForm" label-width="100px">

            <el-row>
              <el-col :span="12">
                <div class="grid-content bg-purple">
                  <el-form-item label="应用名称">
                    <el-input v-model="applicationForm.name" :disabled="isEdit" placeholder="请输入应用名称"></el-input>
                  </el-form-item>
                </div>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="12">
                <div class="grid-content bg-purple">
                  <el-form-item label="选择镜像库" prop="mirrorId">
                    <el-select v-model="applicationForm.mirrorId" value-key="id" placeholder="选择镜像库" style="width:100%">
                      <el-option v-for="item in  mirror" :key="item.value" :label="item.name" :value="item">
                      </el-option>

                    </el-select>
                  </el-form-item>

                </div>
              </el-col>
              <el-col :span="12">
                <div class="grid-content bg-purple-light">
                  <el-form-item label="镜像名称" prop="mirrorName">
                    <el-input v-model="applicationForm.mirrorName" placeholder="请输入镜像名称">

                    </el-input>
                  </el-form-item>
                </div>
              </el-col>
            </el-row>

            <el-row>
              <el-col :span="12">
                <div class="grid-content bg-purple">

                  <el-form-item label="最大CPU" prop="maxCpu">
                    <el-input v-model.number="applicationForm.maxCpu" placeholder="请输入最大CPU">
                      <template slot="append">核</template>
                    </el-input>
                  </el-form-item>
                </div>
              </el-col>
              <el-col :span="12">
                <div class="grid-content bg-purple-light">
                  <el-form-item label="最小CPU" prop="minCpu">
                    <el-input v-model.number="applicationForm.minCpu" placeholder="请输入最小CPU">
                      <template slot="append">核</template>

                    </el-input>
                  </el-form-item>

                </div>
              </el-col>
            </el-row>

            <el-row>
              <el-col :span="12">
                <div class="grid-content bg-purple">
                  <el-form-item label="最大内存" prop="maxMemory">
                    <el-input v-model.number="applicationForm.maxMemory" placeholder="请输入最大内存">
                      <template slot="append">M</template>
                    </el-input>
                  </el-form-item>
                </div>
              </el-col>
              <el-col :span="12">
                <div class="grid-content bg-purple-light">
                  <el-form-item label="最小内存" prop="minMemory">
                    <el-input v-model.number="applicationForm.minMemory" placeholder="请输入最小内存">
                      <template slot="append">M</template>
                    </el-input>
                  </el-form-item>

                </div>
              </el-col>
            </el-row>

            <el-row>
              <el-col :span="12">

                <div class="grid-content bg-purple">
                  <el-form-item label="配置环境变量">

                    <el-form-item>
                      <el-input style="width:120px" placeholder="key" v-model="envForm.newEnv.name"></el-input>
                      <span style="font-size:22px"> :</span>
                      <el-input style="width:120px" placeholder="value" v-model="envForm.newEnv.value"></el-input>
                      <el-button style="float:right;" type="primary" :disabled="addEnvDisabled" @click.prevent="saveEnv()">保存</el-button>
                    </el-form-item>

                    <template v-for="(property,index) in envForm.env">

                      <el-input disabled v-model="property.name" style="width:120px;margin-top:5px"></el-input>
                      <span style="font-size:22px">:</span>
                      <el-input disabled v-model="property.value" style="width:120px"></el-input>
                      <el-button style="float:right;" @click.prevent="delEnv(property)">删除</el-button>

                    </template>

                  </el-form-item>
                </div>
              </el-col>
              <el-col :span="12">
                <div class="grid-content bg-purple-light" style="margin-bottom:10px">
                  <div class="grid-content bg-purple">
                    <el-checkbox v-model="isPVC" :disabled="isCanChoice">是否选择挂载卷</el-checkbox>
                    <span style="color:red;margin-left:20px" v-if="isCanChoice">
                      <i class="el-icon-warning"></i>该项目不允许选择挂载卷！！</span>
                  </div>

                  <el-form-item label="选择挂载卷" v-if="isPVC">
                    <el-select v-model="devPvcList" placeholder="请选择" value-key="id" 　@change="selectedPvc">
                      <el-option v-for="item in options" :key="item.name" :label="item.name" :value="item">
                      </el-option>
                    </el-select>
                  </el-form-item>

                  <el-form-item v-if="isChoice">
                    <el-input style="width:200px" placeholder="安装路径" v-model="pvcForm.newProperty.mountPath"></el-input>
                    <el-button style="float:right;" type="primary" :disabled="addPvcDisabled" @click.prevent="savePvc()">保存</el-button>
                  </el-form-item>

                  <template v-for="(property,index) in pvcForm.properties">
                    <el-form-item>
                      <span> 所选挂载卷：{{property.name}}</span>
                      <span style="margin-left:20px"> 路径：{{property.mountPath}}</span>

                      <span style="margin-left:20px"><el-button  @click.prevent="delProperty(property)">删除</el-button></span>

                      <!-- <el-input v-model="property.mountPath" style="width:200px"></el-input>

                      <el-input v-model="property.devPvcList.name" style="width:200px"></el-input> -->

                  
                    </el-form-item>
                  </template>

                </div>
              </el-col>
            </el-row>

            <el-row>
              <el-col :span="8">

              </el-col>
              <el-col :span="16">
                <div class="grid-content bg-purple-light">

                </div>
              </el-col>
            </el-row>

            <el-form-item label="项目描述">
              <el-input type="textarea" v-model="applicationForm.description" placeholder="请输入项目描述">

              </el-input>
            </el-form-item>

            <div class="grid-content bg-purple">
              <el-checkbox v-model="isPush">访问设置</el-checkbox>
            </div>
            <el-form :rules="rules1" ref="service" :model="service" label-width="100px" v-if="isPush">
              <el-row>
                <el-col :span="5">
                  <div class="grid-content bg-purple">
                    <el-form-item label="名称" prop="name">
                      <el-input v-model.number="envForm.newports.name">

                      </el-input>
                    </el-form-item>
                  </div>
                </el-col>
                <el-col :span="5">
                  <div class="grid-content bg-purple">
                    <el-form-item label="服务端口">
                      <el-input v-model.number="envForm.newports.port">

                      </el-input>
                    </el-form-item>
                  </div>
                </el-col>

                <el-col :span="5">
                  <div class="grid-content bg-purple-light">
                    <el-form-item label="容器端口" style="margin-left:5px">
                      <el-input v-model.number="envForm.newports.targetPort">

                      </el-input>
                    </el-form-item>
                  </div>
                </el-col>
                <el-col :span="9">
                  <div class="grid-content bg-purple">
                    <el-form-item label="协议" prop="protocol">
                      <el-select v-model="envForm.newports.protocol" placeholder="请选择" style="width:140px">
                        <el-option label="TCP" value="TCP"></el-option>
                        <el-option label="UDP" value="UDP"></el-option>
                      </el-select>
                      <el-button style="float:right;" type="primary" :disabled="addPortDisabled" @click.prevent="savePorts()">保存</el-button>
                    </el-form-item>
                  </div>
                </el-col>
                <span style="margin-left:90%;color:red" v-if="saveSetting">保存您的设置！！</span>

              </el-row>
              <el-row v-for="(portProperty,index) in envForm.ports" style="background:#dcdfe6;padding:5px;border-radius:2px;margin-bottom:10px">
                <el-col>
                  <div class="grid-content bg-purple" style="margin-top:5px">
                    <span style="margin-left:60px"> 名称：{{portProperty.name}}</span>
                    <span style="margin-left:60px"> 服务端口：{{portProperty.port}}</span>
                    <span style="margin-left:60px"> 容器端口：{{portProperty.targetPort}}</span>
                    <span style="margin-left:60px"> 协议：{{portProperty.protocol}}</span>

                    <el-button size="mini" style="float:right;" type="primary" :disabled="!addPortDisabled" @click.prevent="deletePorts(portProperty)">删除</el-button>
                  </div>
                </el-col>

              </el-row>

              <el-row v-if="isPush">

                <el-col :span="6">
                  <div class="grid-content bg-purple-light" v-if="isName">
                    <el-form-item label="访问类型" prop="type">
                      <el-select v-model="service.type" placeholder="type" @change="changeVistType(service.type)">
                        <el-option label="平台内" value="ClusterIP"></el-option>
                        <el-option label="平台外" value="NodePort"></el-option>
                      </el-select>
                    </el-form-item>
                  </div>
                </el-col>
                <el-col :span="6" v-if="showProtocol">
                  <div class="grid-content bg-purple-light">
                    <el-form-item prop="type">
                      <el-select v-model="serviceProtocol" placeholder="选择协议" @change="changeProtocol(serviceProtocol)">
                        <el-option label="TCP" value="TCP"></el-option>
                        <el-option label="HTTP" value="HTTP"></el-option>
                      </el-select>
                    </el-form-item>
                  </div>
                </el-col>

              </el-row>

              <el-row v-if="choiceHttp">

                <el-col :span="6">
                  <div class="grid-content bg-purple-light">
                    <el-form-item label="访问路径" prop="type">

                      <el-input v-model="newRules[0].http.paths[0].path" placeholder="请以'/'开头">

                      </el-input>

                    </el-form-item>
                  </div>
                </el-col>
                <el-col :span="6">
                  <div class="grid-content bg-purple-light">
                    <el-form-item label="服务端口" prop="type">
                      <el-select v-model="newRules[0].http.paths[0].backend.servicePort" placeholder="请选择">
                        <el-option v-for="item in  envForm.ports" :key="item.port" :label="item.port" :value="item.port"></el-option>
                      </el-select>
                    </el-form-item>
                  </div>
                </el-col>

              </el-row>
            </el-form>

            <el-form-item style="margin-top:20px">
              <el-button type="primary" @click="suerCreatUser(applicationForm)" v-if="!isEdit">创建</el-button>
              <el-button type="danger" @click="suerEdit" v-if="isEdit">更新</el-button>
              <el-button @click="dialogCreateVisible = false">取消</el-button>
            </el-form-item>
          </el-form>
        </div>
      </el-dialog>
    </div>
    <router-view></router-view>
  </div>
</template>

<script>
import application from './js/application'
    export default{
        ...application
    }


</script>
<style scoped>
.pagination-container {
  margin-top: 20px;
}

.el-checkbox {
  margin-left: 100px;
}
</style>
