
<template>
  <div class=" calendar-list-container">
    <div class="filter-container">
    
      <!-- <input  type="file"    @onchange="jsReadFiles(this.files)"> 读取文件</input> -->
    
      <el-button style="display:block;float:left; margin-bottom: 10px;margin-left: 10px" type="primary" icon="el-icon-plus" @click="createProject">创建配置</el-button>

    </div>
    <!-- v-loading="listLoading" -->
    <div style="margin-left:10px;">
      <el-table :key='tableKey' :data="configureData" element-loading-text="给我一点时间" border fit highlight-current-row style="width: 100%">
        <el-table-column align="center" label="名称" :span="6">
          <template slot-scope="scope">
            <span>{{scope.row.name}}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="命名空间" :span="6">
          <template slot-scope="scope">
            <span>{{scope.row.namespace }}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="创建时间" :span="6">
          <template slot-scope="scope">
            <span>{{scope.row.createTime | formatDatetwo}}</span>
          </template>
        </el-table-column>

        <el-table-column width="220" align="left" label="操作" :span="6" class-name="small-padding fixed-width">
          <template slot-scope="scope">
            <el-button size="mini" type="success" @click="editconfigure(scope.row)">编辑
            </el-button>
            <el-button size="mini" type="success" @click="configureDetial(scope.row)">详情
            </el-button>
            <el-button size="mini" type="danger" @click="deletConfigure(scope.row)">删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-container">
        <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[10,20,30, 50]" :page-size="100" layout="total, sizes, prev, pager, next, jumper" :total="total">
        </el-pagination>

      </div>
    </div>
    <!-- 创建和更新 -->
    <div style="">
      <el-dialog :title="title" :visible.sync="dialogCreateVisible" @close='closeDialog'>
        <div style="width:80%;margin:0 auto">
          <el-form ref="createStorageForm" :model="createStorageForm" :rules="rule" label-width="100px">
            <el-form-item label="配置名称" prop="name">
              <el-input :disabled="isedit" v-model="createStorageForm.name" prop="name" placeholder="不支持大写字母和特殊字符"></el-input>
            </el-form-item>

            <el-form-item label="键值配置">

              <el-form-item>
                <el-input style="width:100px;display:block;float:left" placeholder="键" v-model="envForm.newEnv.name"></el-input>
                <span style="font-size:22px;width:22px;text-align:center;display:block;float:left"> :</span>
                <!-- <el-input style="width:180px;height:40px" placeholder="value" type="textarea" :rows="1" v-model="envForm.newEnv.value"></el-input> -->
                <!-- <textarea class="value" rows="1" placeholder="值" v-model="envForm.newEnv.value"></textarea> -->

                <!-- <div  class="test_box"    contenteditable="true" v-model="envForm.newEnv.value"></div> -->
                <textarerNew v-model='envForm.newEnv.value'>  </textarerNew>

                <el-button style="float:right;" type="primary" :disabled="addEnvDisabled" @click.prevent="saveEnv()">保存</el-button>
              </el-form-item>

              <template v-for="(property,index) in envForm.env">
                <div>
                  <el-input disabled v-model="property.name" style="width:100px;display:block;float:left"></el-input>
                  <span style="font-size:22px;width:22px;text-align:center;display:block;float:left">:</span>
                  <!-- <el-input :disabled="!isedit" v-model="property.value" type="textarea" :rows="1" style="width:180px;height:40px"></el-input> -->
                  <!-- <textarea class="value" style="background-color: #f5f7fa;" :disabled="!isedit" rows="1" v-model="property.value"></textarea> -->
                    <textarerNew :disabled="!isedit" v-model='property.value'>  </textarerNew>
                  <el-button style="float:right;" @click.prevent="delEnv(property)">删除</el-button>
                </div>

              </template>

            </el-form-item>

            <el-form-item>
              <el-button type="primary" v-if="!isedit" @click="sureCreateStorage('createStorageForm')">创建</el-button>


              <el-button type="primary"  v-if="isedit" @click="updateConfig('createStorageForm')">保存</el-button>

              <el-button @click="cancle('createStorageForm')">取消</el-button>
            </el-form-item>
          </el-form>
        </div>
      </el-dialog>
    </div>
  <!-- 详情 -->
  <div style="height:500px;">
      <el-dialog title="配置详情" :visible.sync="dialogDetialVisible"   >
        <div style="width:100%;margin:0 auto;height:500px;overflow-y:auto">

              <span>配置名称：{{configName}}</span>
              <hr style="height:1px;border:none;border-top:1px dashed #0066CC;">

              配置信息：

              <el-table v-if="!envVisible" :data="envList" style="width: 95%">
                <el-table-column type="expand">
                  <template slot-scope="props">
                    <el-form label-position="left" inline class="demo-table-expand">
                      <el-form-item >
                        <span>{{ props.row.value }}</span>
                      </el-form-item>
                    </el-form>
                  </template>
                </el-table-column>
                <el-table-column label="key" width="100">
                  <template slot-scope="scope">
                    <span>{{scope.row.name}}</span>
                  </template>
                </el-table-column>
                <el-table-column label="value">
                  <template slot-scope="scope">
                    <span>{{scope.row.value |subFilter}}</span>
                  </template>
                </el-table-column>
              </el-table>



                <div v-if="envVisible">该配置暂未设置环境变量!</div>
                <hr style="height:1px;border:none;border-top:1px dashed #0066CC;">
                <span> 使用该配置的应用：</span>
                <el-table v-if="!eventVisible" :data="detailList" style="width: 95%">
                    <el-table-column label="应用名称">
                        <template slot-scope="scope">
                           <a style="text-decoration:underline;color:blue" @click="appdetail(scope.row)">{{scope.row.name}}</a>
                            <!-- <span>{{scope.row.name }}</span> -->
                        </template>
                    </el-table-column>
                     <el-table-column label="已使用的KEY">
                        <template slot-scope="scope">
                            <span>{{scope.row.configkeys}}</span>
                        </template>
                    </el-table-column>
                    
                   
                </el-table>
                <div v-if="eventVisible">暂时没有应用使用此配置！！!</div>

                

                
           
        </div>
        <!-- <div>
          <el-button @click="">关闭</el-button>
        </div> -->
         
      </el-dialog>
    </div>




  </div>
</template>
<script>
import configure from "./js/configure";
export default {
  ...configure
};
</script>
<style scoped>
.pagination-container {
  margin-top: 20px;
}

ul {
  list-style: none;
}

.list li {
  height: 32px;
  line-height: 32px;
}
.list .item {
  margin-bottom: 17px;
}
.list span {
  display: inline-block;
  width: 45%;
  text-indent: 5px;
}
.list .item span {
  background: #f5f7fa;
  border: 1px solid #e4e7ed;
  color: #c0c4cc;
}
.value{
  width:180px;
  height: 100px;
  min-height: 180px;
  /* line-height:34px; */
  color: #606266;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
}
textarea{
  resize: none;
}

.test_box {
    width: 300px; 
    min-height: 34px; 
    max-height: 180px;
    /* _height: 120px;  */
    margin-left: auto; 
    margin-right: auto; 
    padding: 3px; 
    outline: 0; 
    border: 1px solid #a0b3d6; 
    font-size: 12px; 
    line-height: 24px;
    padding: 2px;
    word-wrap: break-word;
    overflow-x: hidden;
    overflow-y: auto;

    border-color: rgba(82, 168, 236, 0.8);
	box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1), 0 0 8px rgba(82, 168, 236, 0.6);
}
</style>
