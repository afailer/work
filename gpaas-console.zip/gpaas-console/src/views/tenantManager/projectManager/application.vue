
<template>
  <div class="calendar-list-container">
    <div class="filter-container" style="margin:10px">
      <!-- <el-input @keyup.enter.native="handleFilter" style="width: 200px;" placeholder="请输入内容" v-model="listQuery.title">
      </el-input>
      <el-button type="primary" icon="el-icon-search" @click="handleFilter">搜索</el-button> -->
      <el-button style="display:block;float:left;"  type="primary" icon="el-icon-plus" @click="createApplication">创建应用</el-button>
      <el-card style="display: block;float: left;margin: 0 20px 15px;height: 43px;font-size:14px">
        <span style="font-weight:bold;color:#606266;">
          剩余节点资源：</span> CPU：{{leftResource.leftCpu |subsFiter}}核 / 内存：{{leftResource.leftMemory |subsFiter}}G / 硬盘：{{leftResource.leftStorageSize}}G
      </el-card>
    </div>
    <!-- v-loading="listLoading" -->
    <div style="margin-left:10px">
      <!-- 表格 -->
      <el-table :key='tableKey' :data="projectData" element-loading-text="给我一点时间" border fit highlight-current-row style="width: 100%">
        <el-table-column align="center" label="应用名称">
          <template slot-scope="scope">
            <a style="text-decoration:underline;color:blue" @click="detail(scope.row)">{{scope.row.name}}</a>
            <span v-if="scope.row.type==2">
              <el-tag size="mini">服务</el-tag>
            </span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="持久化">
          <template slot-scope="scope">
            <span>{{scope.row.devPvcList |longFilters }}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="镜像地址">
          <template slot-scope="scope">
            <span>{{scope.row.imageurl}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="创建时间">
          <template slot-scope="scope">
            <span>{{scope.row.createTime | formatDatetwo}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="描述">
          <template slot-scope="scope">
            <span>{{scope.row.description}}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="操作" class-name="small-padding fixed-width">
          <template slot-scope="scope">
            <!-- <el-button type="primary" size="mini" @click="examine(scope.row)">审核</el-button> -->
            <el-button size="mini" type="success" @click="editProject(scope.row)">更新
            </el-button>
            <el-button size="mini" type="danger" @click="deleUser(scope.row)">删除
            </el-button>

          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="pagination-container">
      <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[10,20,30, 50]" :page-size="100" layout="total, sizes, prev, pager, next, jumper" :total="total">
      </el-pagination>

    </div>
    <!-- 创建与编辑 -->
    <div class="dialog" style="">
      <el-dialog :title="title" width="80%" :fullscreen="isFull" :visible.sync="dialogCreateVisible">
        <!-- 剩余资源 -->
        <el-row style="background:#dcdfe6;padding:5px;border-radius:2px;margin-bottom:10px">
          <el-col>
            <div class="grid-content bg-purple">

              <div style="width:600px;margin:0 auto">
                <span>剩余资源：</span>
                <span style="margin-left:60px"> CPU：
                  <span style="color:red"> {{leftResource.leftCpu |subsFiter}} </span> 核</span>
                <span style="margin-left:60px"> 内存：
                  <span style="color:red"> {{leftResource.leftMemory |subsFiter}}</span> M </span>
                <span style="margin-left:60px"> 硬盘：
                  <span style="color:red"> {{leftResource.leftStorageSize}} </span> G</span>
              </div>
            </div>
          </el-col>
        </el-row>

        <div style="width:90%;margin:0 auto">
          <el-form :rules="rules" label-position="left" ref="applicationForm" :model="applicationForm" label-width="100px">
            <el-row>
              <el-col :span="12">
                <div class="grid-content bg-purple">
                  <el-form-item label="应用名称" prop="name">
                    <el-input v-model="applicationForm.name" :disabled="isEdit" placeholder="请输入应用名称"></el-input>
                  </el-form-item>
                </div>
              </el-col>
            </el-row>

            <el-row>
              <el-col :span="10">
                <div class="grid-content bg-purple">
                  <el-form-item label="选择镜像库" prop="mirrorId">
                    <el-select v-model="applicationForm.mirrorId" value-key="id" placeholder="选择镜像库" style="width:100%">
                      <el-option v-for="item in  mirror" :key="item.value" :label="item.name" :value="item">
                      </el-option>

                    </el-select>
                  </el-form-item>

                </div>
              </el-col>
              <el-col :span="10" :offset="2">
                <div class="grid-content bg-purple-light">
                  <el-form-item label="镜像名称" prop="mirrorName">
                    <el-input v-model="applicationForm.mirrorName" placeholder="请输入镜像名称">

                    </el-input>
                  </el-form-item>
                </div>
              </el-col>
            </el-row>

            <el-row>
              <el-col :span="10">
                <div class="grid-content bg-purple">

                  <el-form-item label="最大CPU" prop="maxCpu">
                    <el-input v-model.number="applicationForm.maxCpu" placeholder="请输入最大CPU">
                      <template slot="append">核</template>
                    </el-input>
                  </el-form-item>
                </div>
              </el-col>
              <el-col :span="10" :offset="2">
                <div class="grid-content bg-purple-light">
                  <el-form-item label="最小CPU" prop="minCpu">
                    <el-input v-model.number="applicationForm.minCpu" placeholder="请输入最小CPU">
                      <template slot="append">核</template>
                    </el-input>
                  </el-form-item>
                </div>
              </el-col>
            </el-row>

            <el-row>
              <el-col :span="10">
                <div class="grid-content bg-purple">
                  <el-form-item label="最大内存" prop="maxMemory">
                    <el-input v-model.number="applicationForm.maxMemory" placeholder="请输入最大内存">
                      <template slot="append">M</template>
                    </el-input>
                  </el-form-item>
                </div>
              </el-col>
              <el-col :span="10" :offset="2">
                <div class="grid-content bg-purple-light">
                  <el-form-item label="最小内存" prop="minMemory">
                    <el-input v-model.number="applicationForm.minMemory" placeholder="请输入最小内存">
                      <template slot="append">M</template>
                    </el-input>
                  </el-form-item>

                </div>
              </el-col>
            </el-row>
            <el-row>
              <template v-for="(property,index) in containerData">
                <el-form-item label="容器端口">
                  <el-input v-model.number="property.containerPort" style="width:200px;margin-right:20px" placeholder="输入端口" @blur="Getport(index,property,containerData)"></el-input>
                  <span style="width:60px;display:inline-block">协议</span>
                  <el-select v-model="property.protocol" placeholder="请选择" style="width:140px">
                    <el-option label="TCP" value="TCP"></el-option>
                    <el-option label="UDP" value="UDP"></el-option>
                  </el-select>
                  <el-button @click.prevent="addcontainerData(index,property,containerData)">＋</el-button>
                  <el-button @click.prevent="delcontainerData(index,containerData)">×</el-button>
                </el-form-item>
              </template>
            </el-row>

            <el-row>
              <el-col :span="22">
                <el-form-item label="项目描述">
                  <el-input type="textarea" v-model="applicationForm.description" placeholder="请输入项目描述"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
          <el-tabs v-model="activeName" @tab-click="handleClick" style="min-height:300px">
            <el-tab-pane label="环境变量" name="first">
              <el-form :rules="rules" label-position="left">
                <template v-for="(property,index) in envForm.env">
                  <el-form-item>
                    <el-input v-model="property.name" style="width:200px;margin-right:20px" placeholder="key"></el-input>
                    <el-input v-model="property.value" style="width:200px" placeholder="value"></el-input>
                    <el-button @click.prevent="addEnv(index,property,envForm.env)">＋</el-button>
                    <el-button @click.prevent="deleteEnv(index,envForm.env)">×</el-button>
                  </el-form-item>
                </template>
                <el-form-item>
                  <el-button @click.prevent="addEnvConfig">从配置文件中添加</el-button>
                </el-form-item>
              </el-form>
            </el-tab-pane>
            <el-tab-pane label="存储设置" name="second">
              <el-form :rules="rules" label-position="left">
                <template v-for="(property,index) in pvcForm.properties">
                  <el-form-item>
                    <el-select style="width:300px" v-model="property.data" placeholder="选择挂载卷" value-key="id">
                      <el-option v-for="item in options" :key="item.name" :label="item.name" :value="item">
                      </el-option>
                    </el-select>
                    <el-input style="width:300px" placeholder="挂载路径(如: /opt/test)" v-model="property.mountPath"></el-input>
                    <el-button @click.prevent="addEnv(index,property,pvcForm.properties)">＋</el-button>
                    <el-button @click.prevent="deletePvc(index,pvcForm.properties)">×</el-button>
                  </el-form-item>
                </template>
                <template>
                  <el-row v-for="(property,index) in configArr" style="background:#dcdfe6;padding:5px;border-radius:2px;margin-bottom:10px;width:80%">
                    <el-col>
                      <div class="grid-content bg-purple" style="margin-top:5px">
                        <span style="margin-left:60px"> 配置文件：{{property.configMapName}}</span>
                        <span style="margin-left:60px"> KEY：{{property.configMapKey}}</span>
                        <span style="margin-left:60px"> 挂载文件名称：{{property.path}}</span>
                        <span style="margin-left:60px"> 挂载路径:{{property.mountPath}}</span>

                        <el-button size="mini" style="float:right" type="primary" @click.prevent="deleteConfig(property)">删除</el-button>
                        <!-- <el-button size="mini" style="float:right;margin-right:20px" type="primary" v-if="isEdit" @click.prevent="editpvcConfig(property)">编辑</el-button> -->
                      </div>
                    </el-col>
                  </el-row>
                  <el-button @click.prevent="addConfig()">添加配置文件</el-button>
                </template>
              </el-form>
            </el-tab-pane>
            <el-tab-pane label="访问设置" name="third">
              <div class="grid-content bg-purple">
                <el-checkbox v-model="isPush">是否发布为服务</el-checkbox>
              </div>

              <el-form :rules="rules" label-position="left" ref="service" :model="service" v-if="isPush">
                <el-form-item label="访问类型" prop="type">
                  <el-select v-model="service.type" placeholder="访问类型">
                    <el-option label="平台内" value="ClusterIP"></el-option>
                    <el-option label="平台外" value="NodePort"></el-option>
                  </el-select>
                  <!-- <el-select v-model="serviceProtocol" placeholder="选择协议" v-if="isIgruse" @change="changeProtocol(serviceProtocol)">
                    <el-option label="IP" value="TCP"></el-option>
                    <el-option label="域名" value="HTTP"></el-option>
                  </el-select> -->
                </el-form-item>

                <el-row>
                  <template v-for="(property,index) in serviceAllPorts">
                    <el-form-item label="服务端口">
                      <el-input v-model.number="property.port" style="width:200px;margin-right:20px" placeholder="输入端口" @blur="GetservicePort()"></el-input>

                      <span style="width:60px;display:inline-block">容器端口</span>
                      <el-select style="width:120px" v-model.number="property.targetPort">
                        <el-option v-for="item in conPort" :key="item" :label="item" :value="item">
                        </el-option>
                      </el-select>
                      <span style="width:60px;display:inline-block;margin-left: 20px;">协议</span>
                      <el-select v-model="property.protocol" placeholder="请选择" style="width:140px">
                        <el-option label="TCP" value="TCP"></el-option>
                        <el-option label="UDP" value="UDP"></el-option>
                      </el-select>
                      <el-button @click.prevent="addserviceData(index,property,serviceAllPorts)">＋</el-button>
                      <el-button @click.prevent="delserviceData(index,serviceAllPorts)">×</el-button>
                    </el-form-item>
                  </template>
                </el-row>

              </el-form>
            </el-tab-pane>
            <el-tab-pane label="HTTP路由" name="fourth">

              <el-form :rules="rules" label-position="left" ref="service">

                <el-row>
                  <template v-for="(property,index) in ingressList">
                    <el-form-item>

                      <el-select style="width:120px" v-model="property.sourceType">
                        <el-option v-for="item in plantList" :key="item.label" :label="item.label" :value="item.value">
                        </el-option>
                      </el-select>
                      <el-input v-model.number="property.region" style="width:160px;margin-right:20px" placeholder="请输入域名" @blur="checkRegion(index,property,ingressList)"></el-input>
                      <el-select v-model="property.serverPort" placeholder="请选择服务端口" style="width:120px">
                        <el-option v-for="item in checkServicePort" :key="item" :label="item" :value="item">
                        </el-option>
                      </el-select>

                      <el-input style="width:200px" v-model="property.path" placeholder="请输入访问路径以'/'开头"></el-input>
                      <el-checkbox style=" margin-left: 15px" v-model="property.isShowSubdomain">是否启用子域名</el-checkbox>
                      <el-button @click.prevent="addingressData(index,property,ingressList)">＋</el-button>
                      <el-button @click.prevent="delingressData(index,ingressList)">×</el-button>
                    </el-form-item>

                  </template>
                  <div>
                    <p>说明:</p>
                     1.HTTP路由分为平台生成和手工添加两种类型,平台生成会根据您填写的域名前缀，平台自动生成一个域名，如您填写的域名前缀为example，则平台生成的域名为example.hiacloud.net.cn，域名前缀必须符合域名的校验规则；手动添加则需要您填写一个完整的域名并且保证您的域名已指向您的计算节点,手工添加的域名必须符合域名的校验规则。
                     <br>
                     2.服务端口：对应您在访问设置中设置的服务端口 
                     <br>
                     3.访问路径：访问路径是您的应用默认的访问路径，默认为/,必须以/开头 
                     <br>
                     4.子域名访问：如果您启用了子域名访问，则除了您设置的域名可以访问该应用外，该域名的子域名也可以访问该应用，如您设置的域名为example.test.com，则example.example.test.com也可以访问该应用。
                     <br>
                     5.您可以为应用设置一个或者多个域名，域名在全局是唯一的，一个域名只能对应一个应用的一个服务端口，平台生成的方式您必须保证您输入的域名前缀在项目中是唯一的，手动添加的方式您必须保证您输入的域名在所有项目中是唯一的。
                  </div>
                </el-row>

              </el-form>
            </el-tab-pane>
          </el-tabs>

          <div>
            <div style="width:400px;margin:0 auto">
              <el-button type="primary" @click="suerCreatUser(applicationForm)" v-if="!isEdit">保存</el-button>
              <el-button type="primary" @click="suerEdit(applicationForm)" v-if="isEdit">更新</el-button>
              <el-button @click="closedModel(applicationForm)">取消</el-button>
            </div>

          </div>

        </div>

      </el-dialog>
      <el-dialog title="选择配置文件" :visible.sync=" configureDialogVisible" width="40%">
        <el-select v-model="checkConfigData" placeholder="选择配置" @change="changeenvConfug(checkConfigData)">
          <el-option v-for="item in envConfigData" :key="item.name" :label="item.name" :value="item.dataList">
          </el-option>
        </el-select>
        <span slot="footer" class="dialog-footer">
          <el-button type="primary" @click="sureCheckfonfig">确 定</el-button>
        </span>
      </el-dialog>

      <!-- 存储弹框 -->
      <el-dialog title="选择配置文件" :visible.sync=" configurePvcVisible" width="60%">

        <div style="height:600px;overflow-y:scroll">
          <el-select style="width:200px" v-model="configData" placeholder="配置文件" value-key="id" @change="selectedPvc(configData)">
            <el-option v-for="item in pvcConfigList" :key="item.name" :label="item.name  " :value="item">
            </el-option>
          </el-select>

          <el-table :data="tableData5" ref="multipleTable" tooltip-effect="dark" @selection-change="handleSelectionChange" style="width: 100%">
            <el-table-column type="selection" width="55">
            </el-table-column>
            <el-table-column type="expand">
              <template slot-scope="props">
                <el-form label-position="left" inline class="demo-table-expand">
                  <el-form-item label="value:">
                    <span>{{ props.row.value }}</span>
                  </el-form-item>
                </el-form>
              </template>
            </el-table-column>
            <el-table-column label="Key" prop="name">
            </el-table-column>
            <el-table-column label="Value" prop="value" :formatter="stateFormat">
            </el-table-column>
            <el-table-column label="挂载文件名称">
              <template slot-scope="scope">
                <el-input size="small" v-model="scope.row.path" placeholder="(如: nginx.config)"></el-input>

              </template>
            </el-table-column>
            <el-table-column label="挂载路径">
              <template slot-scope="scope">
                <el-input size="small" v-model="scope.row.mountPath" placeholder="(如: /opt/test)"></el-input>

              </template>
            </el-table-column>
          </el-table>

          <span slot="footer" class="dialog-footer">
            <div style="width:400px;margin:20px auto 0;">
              <el-button @click="toggleSelection()">取消选择</el-button>
              <el-button type="primary" @click="surePvcConfig">确 定</el-button>
            </div>

          </span>
        </div>
      </el-dialog>
    </div>

  </div>

</template>

<script>
import application from "./js/application";
export default {
  ...application
};
</script>
<style scoped>
.pagination-container {
  margin-top: 20px;
}

.el-checkbox {
  margin-left: 100px;
}
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  width: 90px;
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 50%;
}
</style>
