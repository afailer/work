<template>

  <div style="margin:0 10px">
    <el-tabs v-model="activeName" @tab-click="handleClick">
      <el-tab-pane label="我的服务" name="first">
        <router-view></router-view>

      </el-tab-pane>
      <el-tab-pane label="服务目录" name="second">
        <div style="height:40px;line-height:40px">
            <span>剩余资源：</span>
            <span style="margin-left:60px"> CPU：
            <span style="color:red"> {{leftResource.leftCpu |subsFiter}} </span> 核</span>
            <span style="margin-left:60px"> 内存：
            <span style="color:red"> {{leftResource.leftMemory |subsFiter}}</span> M </span>
            <span style="margin-left:60px"> 硬盘：
            <span style="color:red"> {{leftResource.leftStorageSize}} </span> G</span>

        </div>
        <el-table :data="serviceData" element-loading-text="给我一点时间" border fit highlight-current-row style="width: 100%">
          <el-table-column align="center" label="服务名称">
            <template slot-scope="scope">
              <span>{{scope.row.spec.externalMetadata.listing.name}}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" label="分类">
            <template slot-scope="scope">
              <span>{{scope.row.spec.externalMetadata.listing.classification}}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" label="订购所需CPU">
            <template slot-scope="scope">
              <span>{{scope.row.spec.externalMetadata.listing.cpu  | cpuFilter}}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" label="订购所需内存">
            <template slot-scope="scope">
              <span>{{scope.row.spec.externalMetadata.listing.memory | memoryFilter}}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" label="订购所需硬盘">
            <template slot-scope="scope">
              <span>{{scope.row.spec.externalMetadata.listing.storageSize | storeFilter}}</span>
            </template>
          </el-table-column>
          <!-- <el-table-column align="center" label="订阅时间" >
                  <template slot-scope="scope">
                    <span>{{scope.row.createTime |formatDatetwo}}</span>
                  </template>
                </el-table-column> -->

          <!-- <el-table-column align="center" label="状态">
                  <template slot-scope="scope">
                    <span>{{scope.row.cpu}}</span>
                  </template>
                </el-table-column> -->
          <el-table-column align="center" label="描述">
            <template slot-scope="scope">
              <span>{{scope.row.spec.description}}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" label="操作" class-name="small-padding fixed-width">
            <template slot-scope="scope">
              <!-- <el-button type="primary" size="mini" @click="examine(scope.row)">审核</el-button> -->
              <el-button size="mini" type="success" @click="subscribeService(scope.row)">订购
              </el-button>

            </template>
          </el-table-column>
        </el-table>

        <el-dialog title="订购实例" :visible.sync="dialogSubscribeVisible">
          <el-form :model="subscribeForm">
            <el-form-item label="实例名称" required :label-width="formLabelWidth">
              <el-input v-model="subscribeForm.instanceName" auto-complete="off" width="200" placeholder="请输入实例名称"></el-input>
            </el-form-item>
           
            <div style="margin-left:42px">
              <el-checkbox v-model="custom">自定义</el-checkbox>
            </div>
            <div v-if="custom">
              <el-form-item label="CPU" :label-width="formLabelWidth">
                <el-input v-model="subscribeForm.cpu" auto-complete="off" width="200" placeholder="请输入cpu大小">
                  <template slot="append">核</template>
                </el-input>
              </el-form-item>
              <el-form-item label="内存" :label-width="formLabelWidth">
                <el-input v-model="subscribeForm.memory" auto-complete="off" width="200" placeholder="请输入内存大小">
                  <template slot="append">M</template>
                </el-input>
              </el-form-item>
              <el-form-item label="硬盘" :label-width="formLabelWidth">
                <el-input v-model="subscribeForm.storageSize" auto-complete="off" width="200" placeholder="请输入硬盘大小">
                  <template slot="append">G</template>
                </el-input> 
              </el-form-item>
            </div>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogSubscribeVisible = false">取 消</el-button>
            <el-button type="primary" @click="sureSubscribe()">确 定</el-button>
          </div>
        </el-dialog>

      </el-tab-pane>

    </el-tabs>
  </div>

</template>

<script>

 import service from './js/service'
    export default{
        ...service,
    }

</script>

<style scoped>
.tab-container {
  margin: 30px;
}

.el-input {
  width: 50%;
}
</style>
