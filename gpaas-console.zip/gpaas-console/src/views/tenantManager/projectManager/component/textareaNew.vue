<template>
    <div class="edit-div" v-html="innerText" :contenteditable="canEdit" @focus="isLocked = true" @blur="isLocked = false" @input="changeText">
    </div>
</template>
<script type="text/ecmascript-6">
export default {
  name: "editDiv",
  props: {
    value: {
      type: String,
      default: ""
    },
    canEdit: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      innerText: this.value,
      isLocked: false
    };
  },
  watch: {
    value() {
      if (!this.isLocked || !this.innerText) {
        this.innerText = this.value;
      }
    }
  },
  methods: {
    changeText() {
      this.$emit("input", this.$el.innerHTML);
    }
  }
};
</script>
<style lang="scss" rel="stylesheet/scss">
.edit-div {
  width: 350px;
  display: inline-block;
  min-height: 40px;
  max-height: 180px;
  /* _height: 120px;  */
  margin-left: auto;
  margin-right: auto;
  padding: 3px;
  outline: 0;
  border: 1px solid #a0b3d6;
  font-size: 12px;
  line-height: 24px;
  padding: 2px;
  word-wrap: break-word;
  overflow-x: auto;
  overflow-y: auto;
  border-color: rgba(82, 168, 236, 0.8);
//   box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1),
//     0 0 8px rgba(82, 168, 236, 0.6);
  text-align: left;
  &[contenteditable="true"] {
    user-modify: read-write-plaintext-only;
    &:empty:before {
      content: attr(placeholder);
      //display: block;
      color: #ccc;
    }
  }
}
</style>