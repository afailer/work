<template>
  <div>
    <div ref="cpu" style="width:100%;min-height:200px">
    </div>
    <div ref="memory" style="width:100%;min-height:200px">
    </div>
    <div ref="network" style="width:100%;min-height:200px">
    </div>
  </div>
</template>

<script>
import echarts from "echarts";
import { mapGetters } from "vuex";
export default {
  data() {
    return {
      title: "监控详情",
      name: "",
      dialogMonitor: true,
      loglist: "",
      chart: null,
      alive:null,
      cpuDta: [],
      cpuList: [],
      cpuValue: [],
      memoryData: [],
      networkData: []
    };
  },

  methods: {
    closedModel(msg) {
      this.dialogMonitor = false;
    },

    childFn(){
      
       window.clearInterval(this.alive);
       this.alive = null;
    },

    getData() {
      this.$http
        .get(
          "/api/v1/namespaces/kube-system/services/heapster/proxy/api/v1/model/namespaces/"+this.projectNameSpace+"/pods/"+this.listInfoName+"/metrics/cpu/usage_rate"
        )
        .then(res => {
          this.cpuData = res.data.metrics;
          this.initCpuChart();
        });

      this.$http
        .get(
          "/api/v1/namespaces/kube-system/services/heapster/proxy/api/v1/model/namespaces/"+this.projectNameSpace+"/pods/"+this.listInfoName+"/metrics/memory/usage"
        )
        .then(res => {
          this.memoryData = res.data.metrics;
          this.initMemoryChart();
        });

      this.$http
        .get(
          "/api/v1/namespaces/kube-system/services/heapster/proxy/api/v1/model/namespaces/"+this.projectNameSpace+"/pods/"+this.listInfoName+"/metrics/network/tx_rate"
        )
        .then(res => {
          this.networkData = res.data.metrics;
          this.initNetChart();
        });
    },

    initCpuChart() {
      this.cpuchart = echarts.init(this.$refs.cpu);
     

      var cpuData = this.cpuData;
    

      var date1List = cpuData.map(function(item) {
        return item.timestamp;
      });
      var value1List = cpuData.map(function(item) {
        return item.value;
      });

    

      this.cpuchart.setOption({
        tooltip: {
          trigger: "axis"
        },

        title: {
          left: "center",
          text: "cpu"
        },

        xAxis: {
          type: "category",
          data: date1List,
          name:'时间'
        },
        yAxis: {
          type: "value",
          name:"核",
          axisLabel: {                   
            formatter: function (value, index) {           
            return value/10;      
            }                
          }
        },
        series: [
          {
            data: value1List,
            type: "line"
          }
        ]
      });
    },
    initMemoryChart() {
      
       this.memorychart = echarts.init(this.$refs.memory);
      
       var memoryData = this.memoryData;
    

      var date2List = memoryData.map(function(item) {
        return item.timestamp;
      });
      var value2List = memoryData.map(function(item) {
        return item.value;
      });

      // var date3List = networkData.map(function(item) {
      //   return item.timestamp;
      // });
      // var value3List = networkData.map(function(item) {
      //   return item.value;
      // });

      this.memorychart.setOption({
        tooltip: {
          trigger: "axis"
        },

        title: {
          left: "center",
          text: "内存"
        },

        xAxis: {
          type: "category",
          data: date2List,
          name:'时间'
        },
        yAxis: {
          type: "value",
          name:"MB",
          axisLabel: {                   
            formatter: function (value, index) {           
               var a=value/(1024*1024);      
               return a.toFixed(2);
            }                
          }
        },
        series: [
          {
            data: value2List,
            type: "line"
          }
        ]
      });
    },
    initNetChart() {
     
       this.networkchart = echarts.init(this.$refs.network);

       var networkData = this.networkData;

      var date3List = networkData.map(function(item) {
        return item.timestamp;
      });
      var value3List = networkData.map(function(item) {
        return item.value;
      });

      this.networkchart.setOption({
        tooltip: {
          trigger: "axis"
        },

        title: {
          left: "center",
          text: "网络"
        },

        xAxis: {
          type: "category",
          data: date3List,
          name: '时间'
        },
        yAxis: {
          type: "value",
          name: '(MB/秒)',
          axisLabel: {                   
            formatter: function (value, index) {           
            var a=value/(1024*1024)
            return a.toFixed(2);      
            }
          }
        },
        series: [
          {
            data: value3List,
            type: "line"
          }
        ]
      });
    }
  },
  mounted() {
    this.getData();
    var that = this;

     that.alive =  window.setInterval(function() {
        that.getData();
    },30* 1000);

    

    console.log(this.$refs.dervice);
    this.chart = null;
  },
  created() {},
  computed: {
    ...mapGetters(["listInfoName", "projectNameSpace"])
  },
};
</script>
