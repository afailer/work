<template>
  <div>
    <el-dialog :title=title   :visible.sync="dialogMonitor"  @close="closeDialog">
      <div class="container">
        <my-terminal  v-on:titleChanged="closedModel()" ref="child"></my-terminal>
      </div>
    </el-dialog>
  </div>
</template>

<script>

// import { addUser, editUser } from "@/api/user.js";
import monitor from "./monitor";
export default {
  name: "editeuser-dialog",
  data() {
    return {
      title: "监控",
      dialogMonitor: false,
    
    };
  },
  components: {
    "my-terminal": monitor
  },

  computed: {},
  methods: {
    closedModel(msg) {
      this.dialogMonitor = false;
    },
    closeDialog(){
      
      this.$refs.child.childFn()
    }
  },
  created() {
    this.$bus.$on("openMonitor", (row) => {
    
      this.name = row.name;
      this.dialogMonitor = true;
      
    });
  }
};
</script>
<style>
  .xterm .xterm-viewport{
    width: 100% !important;
  }
</style>

