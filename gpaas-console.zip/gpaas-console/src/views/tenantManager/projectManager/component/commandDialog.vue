<template>
  <div>
    <el-dialog :title=title   :visible.sync="dialogCommand">
      <div class="container">
        <my-terminal :terminal="terminal" v-on:titleChanged="closedModel()"></my-terminal>
      </div>
    </el-dialog>
  </div>
</template>

<script>

// import { addUser, editUser } from "@/api/user.js";
import Console from "./Console";
export default {
  name: "editeuser-dialog",
  data() {
    return {
      title: "执行命令",
      dialogCommand: false,
      terminal: {
        pid: 1,
        name: "terminal",
        cols: 80,
        rows: 40,
        modelNumber:0
        // listInfo: "",
        // namespace: ""
      }
    };
  },
  components: {
    "my-terminal": Console
  },

  computed: {},
  methods: {
    closedModel(msg) {
      this.dialogCommand = false;
    }
  },
  created() {
    this.$bus.$on("openCommand", (name,namespace) => {
     
      // this.terminal.listInfo = row;
      // this.terminal.namespace = namespace;
      this.dialogCommand = true;

       this.$bus.$emit("openConsole",name,namespace)

    });
  }
};
</script>
<style>
  .xterm .xterm-viewport{
    width: 100% !important;
  }
</style>

