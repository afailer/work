<template>
  <div>
    <el-dialog :title=title :visible.sync="dialogLog" width="1000px" style="height: 800px;">
      <div class="container">

        <div style="width:99%;margin:0 auto;background:#333333;color:#ffffff;height: 500px;overflow-x: scroll;">
          <pre class="innterHtml"  ref="innterHtml" >
              

          </pre>
        </div>
        
      </div>

    </el-dialog>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
export default {
  name: "editeuser-dialog",
  data() {
    return {
      title: "日志详情",
      name:"",
      dialogLog: false,
      loglist:""
    
    };
  },
 

  computed: {
    ...mapGetters([ "projectNameSpace"])
  },
  methods: {
    closedModel(msg) {
      this.dialogLog = false;
    },


     //获取事件
    getLog(name, namespace){
      // debugger;
      this.$http.get("/cloud/appDetail/getpodLog?name="+this.name +"&namespace=" + namespace)
      .then(res=>{
        if(res.data.success){
           
            if(res.data.obj){
              debugger;
                this.loglist = res.data.obj

                this.$refs.innterHtml.innerHTML = this.loglist;
            }else{
              this.$refs.innterHtml.innerHTML  = "暂无数据！！！"
            }

        
        }
      })
    },
  },
  created() {
    this.$bus.$on("openLog", (row) => {
      this.name = row.name;
      this.dialogLog = true;
      this.getLog(this.name ,this.projectNameSpace);
    });
     
  },
 
};
</script>
