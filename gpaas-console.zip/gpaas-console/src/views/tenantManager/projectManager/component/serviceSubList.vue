<template>
    <div>
        <el-row>
            <div class="grid-content bg-purple box-shadow">

              <el-table :data="subscribeData" element-loading-text="给我一点时间" border fit highlight-current-row style="width: 100%">
                <el-table-column align="center" label="实例名称" width="130">
                  <template slot-scope="scope">
                    <span>{{scope.row.metadata.name}}</span>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="所属服务" width="170">
                  <template slot-scope="scope">
                    <span>{{scope.row.spec.servicecname }}</span>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="状态" width="60">
                  <template slot-scope="scope">
                    <span>{{scope.row.status.conditions[0].status }}</span>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="描述">
                  <template slot-scope="scope">
                    <span>{{scope.row.status.conditions[0].message }}</span>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="资源">
                  <template slot-scope="scope">
                    <span>CPU:{{scope.row.spec.parameters.resources.cpu | cpuFilter }}</span><br>
                    <span>内存:{{scope.row.spec.parameters.resources.memory}}</span><br>
                    <span>存储卷:{{scope.row.spec.parameters.resources.storageSize}}</span>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="订购时间" >
                  <template slot-scope="scope">
                    <span>{{scope.row.metadata.creationTimestamp |formatDatetwo }}</span>
                  </template>
                </el-table-column>


                </el-table-column>
                <el-table-column align="left" label="操作" width="340">
                  <template slot-scope="scope">
                    <!-- <el-button type="primary" size="mini" @click="examine(scope.row)">审核</el-button> -->
                    <el-button size="mini" type="success" v-if="scope.row.status.conditions[0].status == 'True'" @click="bindSub(scope.row)">绑定
                    </el-button>
                    <el-button size="mini" type="danger" @click="delSub(scope.row)">删除
                    </el-button>
                    <el-button size="mini" type="success" @click="getBinList(scope.row.metadata.name)">绑定列表
                    </el-button>
                    <el-button size="mini" type="success" @click="monitor(scope.row.metadata.name,scope.row.spec.clusterServiceClassExternalName)">监控
                    </el-button>

                  </template>
                </el-table-column>
              </el-table>

              <div class="pagination-container">
                <el-pagination background @size-change="subSizeChange" @current-change="subCurrentChange" :current-page="currentSubPage" :page-sizes="[10,20,30, 50]" :page-size="100" layout="total, sizes, prev, pager, next, jumper" :total="subTotal">
                </el-pagination>

              </div>
              <!-- 绑定模态层 -->
              <el-dialog title="绑定" :visible.sync="dialogBindVisible">
                <el-form :model="bindForm">
                  <el-form-item label="绑定名称" required :label-width="formLabelWidth">
                    <el-input v-model="bindForm.servicebindName" auto-complete="off" width="200" placeholder="请输入绑定名称"></el-input>
                  </el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer">
                  <el-button @click="dialogBindVisible = false">取 消</el-button>
                  <el-button type="primary" @click="sureBind()">确 定</el-button>
                </div>
              </el-dialog>

            </div>

        </el-row>
    </div>
</template>
<script>
    import serviceSubList from '../js/serviceSubList'
    export default{
        ...serviceSubList
    }
</script>
<style>

</style>
