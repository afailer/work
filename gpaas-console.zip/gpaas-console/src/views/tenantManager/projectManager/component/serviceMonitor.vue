<template>
    <div>
        <div style="margin:10px 0">
          <el-breadcrumb separator="/">
            <el-breadcrumb-item :to="{ path: '/tenantProject/service' }">{{name}}</el-breadcrumb-item>
            <el-breadcrumb-item>监控</el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        <el-table :data="containerGroup" style="width:97%;margin-bottom:20px;">
            <el-table-column label="容器组">
                <el-table-column label="名称" sortable>
                    <template slot-scope="scope">
                        <i class="el-icon-circle-check" style="color:green"></i>
                        <span style="margin-left: 10px">{{ scope.row.metadata.name }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="节点" width="150">
                    <template slot-scope="scope">
                        <span style="margin-left: 10px">{{ scope.row.spec.nodeName }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="状态" sortable width="120">
                    <template slot-scope="scope">
                        <span style="margin-left: 10px">{{ scope.row.status.phase }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="已重启" width="120">
                    <template slot-scope="scope">
                        <span style="margin-left: 10px">{{ scope.row.status.containerStatuses[0].restartCount }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="已创建" sortable width="180">
                    <template slot-scope="scope">
                        <span style="margin-left: 10px">{{ scope.row.metadata.creationTimestamp | formatDatetwo }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="操作">
                    <template slot-scope="scope">
                        <el-button type="text" @click="monitorPod(scope.row.metadata.name)" style="color:#409EFF">监控</el-button>
                    </template>
                </el-table-column>
            </el-table-column>
        </el-table>
        <!-- 監控 -->
        <el-dialog title="监控详情"  :visible.sync="monitorVisible" width="80%">
            <div class="container">
              <div ref="cpu" style="width:100%;min-height:200px">
              </div>
              <div ref="memory" style="width:100%;min-height:200px">
              </div>
              <div ref="network" style="width:100%;min-height:200px">
              </div>
            </div>
        </el-dialog>
    </div>
</template>
<script>
import serviceMonitor from '../js/serviceMonitor'
    export default{
        ...serviceMonitor,
    }

</script>
<style>

</style>
