<template>
    <div>
       <div style="margin:10px 0">
          <el-breadcrumb separator="/">
            <el-breadcrumb-item :to="{ path: '/tenantProject/service' }">{{name}}</el-breadcrumb-item>
            <el-breadcrumb-item>绑定列表</el-breadcrumb-item>
          </el-breadcrumb>
        </div>
         <el-row>
            <div class="grid-content bg-purple-light">

              <el-table :key='tableKey' :data="bindData" element-loading-text="给我一点时间" border fit highlight-current-row style="width: 100%">
                <el-table-column align="center" label="绑定名称">
                  <template slot-scope="scope">
                    <span>{{scope.row.servciebindName}}</span>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="所属实例名称">
                  <template slot-scope="scope">
                    <span>{{scope.row.instanceName }}</span>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="绑定时间">
                  <template slot-scope="scope">
                    <span>{{scope.row.bindTime | formatDatetwo }}</span>
                  </template>
                </el-table-column>

                <el-table-column align="center" label="操作" width="200" class-name="small-padding fixed-width">
                  <template slot-scope="scope">
                    <el-button size="mini" type="success" @click="showBind(scope.row)">访问凭证
                    </el-button>
                    <el-button size="mini" type="danger" @click="delBind(scope.row)">删除绑定
                    </el-button>

                  </template>
                </el-table-column>
              </el-table>

              <div class="pagination-container">
                <el-pagination background @size-change="binSizeChange" @current-change="binCurrentChange" :current-page="currentBinPage" :page-sizes="[10,20,30, 50]" :page-size="100" layout="total, sizes, prev, pager, next, jumper" :total="binTotal">
                </el-pagination>

              </div>

              <el-dialog title="访问凭证" :visible.sync="dialogInstanceDetail">

                <p v-for="(val, key, index) in voucherData">
                  <span style="font-size:18px">{{key}}</span> ：
                  <span>{{val}}</span>
                </p>
                <div slot="footer" class="dialog-footer">
                  <el-button @click="dialogInstanceDetail = false">关闭</el-button>
                </div>
              </el-dialog>

            </div>
          </el-row>
    </div>
</template>
<script>
    import serviceBindList from '../js/serviceBindList'
    export default{
        ...serviceBindList
    }
</script>
<style>

</style>
