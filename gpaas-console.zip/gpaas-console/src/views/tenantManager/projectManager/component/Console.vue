<template>
  <div>
    <div class="console" ref="terminal"></div>
    <div style="margin-top:20px;margin-left:90%">
      <!-- <button @click="distroyModel"> 关闭 </button> -->
       <el-button size="mini" type="warning"  @click="distroyModel" >关闭</el-button>
    </div>
  </div>

</template>
<script>
import Terminal from "../js/Xterm";
import { mapGetters } from "vuex";
export default {
  name: "Console",
  props: {
    terminal: {
      type: Object,
      default: {}
    }
  },
  data() {
    return {
      term: null,
      terminalSocket: null,
      selfLink: "/api/v1/namespaces/default/pods/tomcat1",
      accessToken:
        "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJrdWJlLXN5c3RlbSIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VjcmV0Lm5hbWUiOiJhZG1pbi10b2tlbi1wcTZ6biIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VydmljZS1hY2NvdW50Lm5hbWUiOiJhZG1pbiIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VydmljZS1hY2NvdW50LnVpZCI6IjIzZjU0YzlkLTMyODQtMTFlOC04MjBjLTAwNTA1NmEwMGI3ZiIsInN1YiI6InN5c3RlbTpzZXJ2aWNlYWNjb3VudDprdWJlLXN5c3RlbTphZG1pbiJ9.a7jtAv24Z46ZgykLXqeDkOYphEhZE9MMA0q8hyZffnzQAEzQFqaMi1acrLGb80227GAmrHlTx8t4CyypjupRWkK_m3ROaluuRE57MIC3Fy2yOFOkncw8Ysuli7KwFi8N4lndqwFcKy7ls05YLPngcDRvNORZhF7myhW9qdZ-lh2tugzv80VsWAvCJA7_g4a_dH8SoOTGAzO-BXOr-pRqTCSmOaYMg8ANWjIUQICUSPlyOdXWb0glSBOZ3qzDmNcQWkCY2PfHw_5GCUEgyMTyYa9kl47cyXxZw2r5opDJalZ3Wy439S-LfQW5nh85STe8lqgCGAGhln3hwRwiV0DoHg",
      first: true,
      alive: null,
      defaultCols: 80,
      rows: 40
    };
  },
  methods: {
    b64_to_utf8(str) {
      return decodeURIComponent(window.escape(window.atob(str)));
    },

    utf8_to_b64(str) {
      return window.btoa(window.unescape(encodeURIComponent(str)));
    },

    fatal(message) {
      if (!message && this.first)
        message =
          "Could not connect to the container. Do you have sufficient privileges?";
      if (!message) message = "disconnected";
      if (!this.first) message = "\r\n" + message;
      this.term.write("\x1b[31m" + message + "\x1b[m\r\n");
    },

    sizeViewport() {
     
      var cols = this.defaultCols;
      if (!this.term.charMeasure.width) {
        return;
      }
      var xtermViewport = document.getElementsByClassName("xterm-viewport")[0];
      // character width * number of columns + space for a scrollbar
      // TODO determine the max width of a scrollbar across browsers
      xtermViewport.style.width =
        this.term.charMeasure.width * cols + 17 + "px";
    },

    sizeTerminal() {
      var cols = this.defaultCols;
      var rows = this.defaultRows;
      this.term.resize(cols, rows);
      this.sizeViewport();
      if (this.terminalSocket && this.terminalSocket.readyState === 1) {
        this.terminalSocket.send(
          "4" + window.btoa('{"Width":' + cols + ',"Height":' + rows + "}")
        );
      }
    },

    runRealTerminal(that) {
      
      that.alive = window.setInterval(function() {
        that.terminalSocket.send("0");
      }, 30 * 1000);
      that.sizeTerminal();
    },
    errorRealTerminal() {
      console.log(this.terminalSocket);
    },
    closeRealTerminal(ev) {
      this.fatal(ev.reason);
      console.log(ev.reason);
    },

    onmessageTerminal(ev) {
      
      var data = ev.data.slice(1);
      switch (ev.data[0]) {
        case "1":
        case "2":
        case "3":
          console.log(data);
          this.term.write(this.b64_to_utf8(data));
          break;
      }

      if (this.first) {
        this.first = false;
        this.term.showCursor();
        if (this.term.element) {
          this.term.focus();
        }
      }
    },

    startconnect() {
      this.disconnect();
      this.term.reset();
      var wbUrl =
        "ws://"+  this.globalURL.BASE_URL  +"/api/v1/namespaces/" +
        this.projectNameSpace +
        "/pods/" +
        this.listInfoName +
        "/exec?stdout=1&stdin=1&stderr=1&tty=1&command=%2Fbin%2Fsh&command=-i&access_token=" +
        this.accessToken;
      // open websocket
      this.terminalSocket = new WebSocket(wbUrl, "base64.channel.k8s.io");
      this.terminalSocket.onmessage = this.onmessageTerminal;
      this.terminalSocket.onclose = this.closeRealTerminal;
      this.terminalSocket.onerror = this.errorRealTerminal;

      this.term._initialized = true;

      this.term.charMeasure.on("charsizechanged", this.sizeViewport);
    },

    disconnect() {
      
      if (this.term) {
        this.term.cursorHidden = true;
        this.term.refresh(this.term.buffer.y, this.term.buffer.y);
      }

      if (this.terminalSocket) {
        this.terminalSocket.onopen = this.terminalSocket.onmessage = this.terminalSocket.onerror = this.terminalSocket.onclose = null;
        if (this.terminalSocket.readyState < 2)
          // CLOSING
          this.terminalSocket.close();
        this.terminalSocket = null;
      }

      window.clearInterval(this.alive);
      this.alive = null;
    },
    distroyModel() {
      this.disconnect();
      this.$emit("titleChanged");
    }
  },
  mounted() {
    
    this.term = new Terminal({
      cols: this.defaultCols,
      rows: this.defaultRows,
      cursorBlink: true,
      fontFamily: "'Courier New', 'Courier', monospace",
      fontSize: 12,
      lineHeight: 1,
      theme: {
        foreground: "#f0f0f0"
      },
      screenKeys: true,
      applicationCursor: true, // Needed for proper scrollback behavior in applications like vi
      mouseEvents: true // Needed for proper scrollback behavior in applications like vi
    });
    this.term.open(this.$refs.terminal);
    this.term.refresh(this.term.buffer.y, this.term.buffer.y);

    this.startconnect();
    var that = this;
    this.terminalSocket.onopen = this.runRealTerminal(that);
    that.term.on("data", function(data) {
      if (that.terminalSocket && that.terminalSocket.readyState === 1)
        that.terminalSocket.send(
          "0" + window.btoa(window.unescape(encodeURIComponent(data)))
        );
    });
  },
  created() {
    
  },
  computed: {
    ...mapGetters(["listInfoName", "projectNameSpace","modelNumber"])
  },

  watch: {
    modelNumber: function(oldValue, newValue) {
      console.log(newValue);
      if (newValue) {
        this.startconnect();
      } else {
      }
    }
  }
};
</script>