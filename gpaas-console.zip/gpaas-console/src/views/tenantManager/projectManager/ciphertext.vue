<style scoped>
.filter-container {
  margin: 10px;
}
</style>
<template>
  <div class=" calendar-list-container">
    <div class="filter-container">
      <el-button type="primary" @click="showCipher">查看密文</el-button>
      <el-card v-show="show" class="box-card">
          <div v-model="ciphertext" style="word-wrap:break-word; overflow:hidden;">
            {{ciphertext}}
          </div>
      </el-card>
    </div>
  
  </div>
</template>

<script>
 import ciphertext from './js/ciphertext'
    export default{
        ...ciphertext
    }
</script>
<style scoped>
.pagination-container {
  margin-top: 20px;
}

.el-checkbox {
  margin-left: 100px;
}

.box-card{
    width:100%;
    margin:10px 0;
}
</style>
