import {  mapActions,mapGetters } from "vuex";

export default {
  name: "complexTable",

  data() {
     var name=(rule,value,callback)=>{
      if(/^[a-z][a-z\d\-]{1,30}[a-z0-9]$/.test(value)==false){
        callback(new Error('名称不符合规范，以小写字母开头不包含除-外的特殊字符，以小写字母和数字结尾，最多32位 ！！'));
      }else{
        callback();
      }
    };
    return {
      //创建项目
      createStorageForm: {
        name: "",
        createTime:"",
        storageSize: "",
        description:"",
        type:1,
        permission:3,
        projectId:"",
        namespace:"",
      },
      leftResource:[],
      rules: {
          name: [
            { validator:name, trigger: 'blur' },
          ],
           storageSize: [
            { required: true, message: '请输入存储卷大小', trigger: 'blur' },
             { type: 'number', message: '请输入数字类型' }
          ],
        },
      
      isEdit: false,
      title:"创建存储卷",
      currentPage: 1,
      storageData: [],
      tableKey: 0,
      total: null,
      pageSize: 10,
      listLoading: true,
      listQuery: {
        title: undefined
      },
      //创建用户
      dialogCreateVisible: false,
      radio: 3,
      disabled:"",
      projectId:sessionStorage.getItem("projectId"),
      namespace:sessionStorage.getItem("namespace"),
    };
  },
  computed:{
     
    // ...mapGetters(["projectId","namespace"])
  },

  filters: {
    statesFilters: function(value) {
      return value + "G";
    },
    state:function(value){
      switch( value ){
        case 1 :
          return '激活';
          break;
        case 3 :
          return '冻结';
          break;

      }
    },
    subsFiter:function(value){
      return Math.round(value*100)/100
    },


    storagefilter:function(value){
      if(value.length>0){
        return value[0].appName
      }else {
        return "-"
      }
    },

    formatDatetwo: function(timestamp) {
      // var date = new Date(timestamp); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
      //   var Y = date.getFullYear() + "-";
      //   var M =
      //     (date.getMonth() + 1 < 10
      //       ? "0" + (date.getMonth() + 1)
      //       : date.getMonth() + 1) + "-";
      //   var D = date.getDate() + " ";
      //   var h = date.getHours() + ":";
      //   var m = date.getMinutes() + ":";
      //   var s = date.getSeconds();
      //   return Y + M + D + h + m + s;
      var re = /-?\d+/;
      var m = re.exec(timestamp);
      var d = new Date(parseInt(m[0]));
      var o = {
        "M+": d.getMonth() + 1, //month
        "d+": d.getDate(), //day
        "h+": d.getHours(), //hour
        "m+": d.getMinutes(), //minute
        "s+": d.getSeconds(), //second
        "q+": Math.floor((d.getMonth() + 3) / 3), //quarter
        S: d.getMilliseconds() //millisecond
      };
      var format = "yyyy-MM-dd hh:mm:ss";
      if (/(y+)/.test(format)) {
        format = format.replace(
          RegExp.$1,
          (d.getFullYear() + "").substr(4 - RegExp.$1.length)
        );
      }
      for (var k in o) {
        if (new RegExp("(" + k + ")").test(format)) {
          format = format.replace(
            RegExp.$1,
            RegExp.$1.length == 1
              ? o[k]
              : ("00" + o[k]).substr(("" + o[k]).length)
          );
        }
      }
      return format;
    }
   
  },
  created() {
    this.getList();
    this.leftRes();
  },
  methods: {
    
    getList() {
      this.$http
        .get(
          "/cloud/persistentVolume/queryPersistentVolumeByUserPage?projectId=" +
            this.projectId +
            "&pageNum=" +
            this.currentPage +
            "&pageSize=" +
            this.pageSize 
        )
        .then(res => {
          this.total = res.data.obj.totalCount;
          this.storageData = res.data.obj.result;
        });
    },
    //剩余资源
    leftRes(){
      this.$http.get(
        "/cloud/persistentVolume/queryLeftProjectStorageSize?projectId="+this.projectId
      ).then(res=>{
        this.leftResource=res.data.obj;
      })
    },
    handleFilter() {},
    handleSizeChange(val) {
      this.pageSize = val;
      this.getList();
    },
    // //权限
    // radioChange(value){
    //     this.permission=value;
    // },
    //分页查询
    handleCurrentChange(val) {
      this.currentPage = val;
      this.getList();
    },
    //创建存储卷

    createProject() {
      this.disabled=false;
      this.title = "创建存储卷"
      //清空存储卷对象
      this.createStorageForm.name = "";
      this.createStorageForm.createTime = this.createTime;
      this.createStorageForm.storageSize = "";
      this.createStorageForm.description = "";
      this.createStorageForm.projectId = this.projectId;
      this.createStorageForm.namespace=this.namespace;
      this.dialogCreateVisible = true;
      this.isEdit = false;
    },
    //取消创建
     cancle(createStorageForm){
      this.$refs[createStorageForm].resetFields();
     this. dialogCreateVisible = false
    },
    //确认创建存储卷
    sureCreateStorage(formName) {
      console.log(this.createStorageForm);
       this.$refs[formName].validate((valid) => {
          if (valid) {
            this.$http
              .post("/cloud/persistentVolume/addPersistentVolume", this.createStorageForm)
              .then(res => {
                if (res.data.success) {
                  this.$message({
                    message: res.data.msg,
                    type: "success"
                  });
                  this.dialogCreateVisible = false;
                  this.getList();
                  this.leftRes();
                } else {
                  this.$message({
                    message: res.data.msg,
                    type: "error"
                  });
                }
              });

          } else {
            return false;
          }
        });
    },

    //删除存储卷

    deletStorage(row) {

     
            this.$confirm("此操作将永久删除存储卷, 是否继续?", "提示", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
      })
        .then(() => {
          this.$http
            .get("/cloud/persistentVolume/deletePersistentVolume?id=" + row.id)
            .then(res => {
              if (res.data.success) {
                this.$message({
                  message: res.data.msg,
                  type: "success"
                });
                this.getList();
                this.leftRes();
              } else {
                this.$message({
                  message: res.data.msg,
                  type: "error"
                });
              }
            });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
         

      
    },

    //冻结存储卷
    // freezeStorage(row){
      // this.$http
      //   .get("/cloud/persistentVolume/queryPersistentById?id=" + row.id)
      //   .then(res => {
      //     this.createStorageForm = res.data.obj;
          // if(row.state==3){
          //     this.$message({
          //     message: "该项目已冻结",
          //     type: "success"
          //   });
          // }else{
          //   this.$http.get("/cloud/persistentVolume/freezePersistentVolume?id="+row.id)
          //   .then(res =>{
          //     if (res.data.success) {
          //       this.$message({
          //         message: res.data.msg,
          //         type: "success"
          //       });
          //       this.getList();
          //     } else {
          //       this.$message({
          //         message: res.data.msg,
          //         type: "error"
          //       });
          //     }
          //   })
          // }
        // })
    // },

    //编辑存储卷

    // editStorage(row) {

    //    //清空数据
    //     this.createStorageForm.name = "";
    //     this.createStorageForm.createTime = "";
    //     this.createStorageForm.storageSize = "";
    //     this.createStorageForm.description = "";
    //     this.createStorageForm.projectId = "";
    //   //根据ID 查询存储卷详细信息
    //   this.$http
    //     .get("/cloud/persistentVolume/queryPersistentById?id=" + row.id)
    //     .then(res => {
    //       this.createStorageForm = res.data.obj;
    //       if(row.state==3){
    //           this.$message({
    //           message: "冻结状态下不可编辑",
    //           type: "error"
    //         });
    //       }
    //       else{
    //           this.dialogCreateVisible = true;
    //            this.isEdit = true;
    //             this.title = "编辑存储卷";
    //             this.disabled=true;
    //       }
    //     });
        
    // },
    //保存编辑
    // suerEdit() {
    //   this.$http
    //     .post("/cloud/persistentVolume/updatePersistentVolume", this.createStorageForm)
    //     .then(res => {
    //       if (res.data.success) {
    //         this.$message({
    //           message: res.data.msg,
    //           type: "success"
    //         });
    //         this.dialogCreateVisible = false;
    //         this.getList();
    //         this.leftRes();
    //       } else {
    //         this.$message({
    //           message: res.data.msg,
    //           type: "error"
    //         });
    //       }
    //     });
    // },
  },
  watch: {
    $route(currentState, oldState) {
      debugger
      if (currentState.fullPath.startsWith("/tenantProject")) {
        this.projectId = sessionStorage.getItem("projectId");
        this.namespace = sessionStorage.getItem("namespace");
        this.getList();
      } else {
        sessionStorage.setItem("showNumber", 3);
      }
    },

  }
};