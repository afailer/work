
export default {
    data() {
      return {
        subscribeData: [],
        subTotal: null,
        subPageSize: 10,
        currentSubPage: 1,
        tableKey: 0,
        dialogBindVisible: false,
        bindForm: {
          servicebindName: ""
        },
        formLabelWidth: "120px",
        projectId:sessionStorage.getItem("projectId"),
        namespace:sessionStorage.getItem("namespace"),
        bind:false,
      };
      
    },
    filters:{
      cpuFilter: function(value){
        return value.substring(0,value.indexOf("m"))/1000 + '核';
      },
      // formatDatetwo: function(timestamp) {

      //     var ss = Date.parse(timestamp)
      //   var date = new Date(ss); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
      //   var Y = date.getFullYear() + "-";
      //   var M =
      //     (date.getMonth() + 1 < 10
      //       ? "0" + (date.getMonth() + 1)
      //       : date.getMonth() + 1) + "-";
      //   var D = date.getDate() + " ";
      //   var h = date.getHours() + ":";
      //   var m = date.getMinutes() + ":";
      //   var s = date.getSeconds();
      //   return Y + M + D + h + m + s;
      // },
      formatDatetwo: function(time) {
        var ss = Date.parse(time)
        var re = /-?\d+/;
        var m = re.exec(ss);
        var d = new Date(parseInt(m[0]));
        var o = {
          "M+": d.getMonth() + 1, //month
          "d+": d.getDate(), //day
          "h+": d.getHours(), //hour
          "m+": d.getMinutes(), //minute
          "s+": d.getSeconds(), //second
          "q+": Math.floor((d.getMonth() + 3) / 3), //quarter
          S: d.getMilliseconds() //millisecond
        };
        var format = "yyyy-MM-dd hh:mm:ss";
        if (/(y+)/.test(format)) {
          format = format.replace(
            RegExp.$1,
            (d.getFullYear() + "").substr(4 - RegExp.$1.length)
          );
        }
        for (var k in o) {
          if (new RegExp("(" + k + ")").test(format)) {
            format = format.replace(
              RegExp.$1,
              RegExp.$1.length == 1
                ? o[k]
                : ("00" + o[k]).substr(("" + o[k]).length)
            );
          }
        }
        return format;
      },
    },
    created() {
      this.getSubList();
    },
    methods: {
        //获取列表
      getSubList() {
  
        this.$http
          .get(
            "/cloud/serviceManage/serviceInstances?pageNum=" +
              this.currentSubPage +
              "&pageSize=" +
              this.subPageSize +
              "&namespace=" +
              this.namespace
          )
          .then(res => {
            this.subTotal = res.data.obj.totalCount;
            this.subscribeData = res.data.obj.items;

          });
      },
      //换页
      subSizeChange(val) {
        this.subPageSize = val;
        this.getSubList();
      },
      //分页查询订阅
      subCurrentChange(val) {
        this.currentSubPage = val;
        this.getSubList();
      },
      //删除订阅
  
      delSub(row) {
        this.$confirm("此操作将永久删除订阅, 是否继续?", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        })
          .then(() => {
            this.$http
              .delete(
                "/cloud/serviceManage/deleteService?namespace=" +
                  this.namespace +
                  "&instanceName=" +
                  row.metadata.name
              )
              .then(res => {
                if (res.data.success) {
                  this.$message({
                    message: res.data.msg,
                    type: "success"
                  });
                  // this.getSubList();   
                  // debugger; 
                  setTimeout(() => {  
                    this.getSubList(); 
                  },1000);  
                } else {
                  this.$message({
                    message: res.data.msg,
                    type: "error"
                  });
                }
              });
          })
          .catch(() => {
            this.$message({
              type: "info",
              message: "已取消删除"
            });
          });
      },
      //创建绑定
      bindSub(row) {
        (this.instanceName = ""), (this.instanceName = row.metadata.name);
        this.bindForm.servicebindName = "";
        this.dialogBindVisible = true;
      },
      sureBind() {
        this.$http
          .get(
            "/cloud/serviceManage/createBind?namespace=" +
              this.namespace +
              "&instanceName=" +
              this.instanceName +
              "&servicebindName=" +
              this.bindForm.servicebindName
          )
          .then(res => {
            if (res.data.success) {
              this.$message({
                message: res.data.msg,
                type: "success"
              });
              this.dialogBindVisible = false;
              // this.getBinList(this.instanceName);
              
            } else {
              this.$message({
                message: res.data.msg,
                type: "error"
              });
            }
          });
      },
      //监控
      monitor(name,monitor){
        this.$router.push('/tenantProject/service/monitor');
        sessionStorage.setItem("name", name);
        sessionStorage.setItem("monitor", monitor);
      },
      getBinList(name){
        sessionStorage.setItem("name", name);
        this.$router.push('/tenantProject/service/bind');
      },
    },
    watch: {
      $route(currentState, oldState) {
        debugger
        if (currentState.fullPath.startsWith("/tenantProject")) {
          this.projectId = sessionStorage.getItem("projectId");
          this.namespace = sessionStorage.getItem("namespace");
          this.getSubList();
        } else {
          sessionStorage.setItem("showNumber", 3);
        }
      },

    }
}