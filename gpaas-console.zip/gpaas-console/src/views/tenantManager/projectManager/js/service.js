import serviceSubList from '../component/serviceSubList'
import serviceBindList from '../component/serviceBindList'
import serviceMonitor from '../component/serviceMonitor'
export default {
    data() {
      return {
        activeName: "first",
        serviceData: [],
        instanceName: "",
        currentSubPage:1,
        subPageSize:10,
        dialogBindVisible: false,
        bindForm: {
          servicebindName: ""
        },
        formLabelWidth: "120px",
        dialogInstanceDetail: false,
        visitForm: {
          inside: "",
          external: ""
        },
        dialogSubscribeVisible: false,
        subscribeForm: {
          instanceName: "",
          cpu:"",
          memory:"",
          storageSize:""
        },
        rowService: {},
        voucherData: {},
        projectId:sessionStorage.getItem("projectId"),
        namespace:sessionStorage.getItem("namespace"),
        bind:false,
        //剩余容量
        leftResource: [],
        type:1,
        custom:false,
        subscribeData:[]
      };
      
    },
    components:{ serviceSubList, serviceBindList,serviceMonitor },
    filters: {
      formatDatetwo: function(timestamp) {
        var date = new Date(timestamp); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
        var Y = date.getFullYear() + "-";
        var M =
          (date.getMonth() + 1 < 10
            ? "0" + (date.getMonth() + 1)
            : date.getMonth() + 1) + "-";
        var D = date.getDate() + " ";
        var h = date.getHours() + ":";
        var m = date.getMinutes() + ":";
        var s = date.getSeconds();
        return Y + M + D + h + m + s;
      },
      int:function(value){
        return parseInt(value) 
      },
      cpuFilter: function(value){
        return value+"核"
      },
      memoryFilter: function(value){
        return value + "M"
      },
      storeFilter:function(value){
        return value + "G"
      },
      subsFiter: function(value) {
        return Math.round(value * 100) / 100;
      },
    },
    created() {
      // this.getSubList();
      this.getSubscribeList();
      this.getLeftSource();
    },
    methods: {
      handleClick(tab, event) {
        console.log(tab, event);
      },
        //获取列表
        getSubList() {
  
          this.$http
            .get(
              "/cloud/serviceManage/serviceInstances?pageNum=" +
                this.currentSubPage +
                "&pageSize=" +
                this.subPageSize +
                "&namespace=" +
                this.namespace
            )
            .then(res => {
              this.subTotal = res.data.obj.totalCount;
              debugger
              this.subscribeData = res.data.obj.items;
            });
        },
  
      //服务列表
  
      getSubscribeList() {
        this.$http.get("/cloud/serviceManage/getServices").then(res => {
          //this.subscribeTotal = res.data.obj.totalCount;
          this.serviceData = res.data.obj.items;
        });
        this.dialogCreateVisible = true;
        this.isEdit = false;
      },
   //获取剩余容量
      getLeftSource(){
        this.$http
          .get(
            "/cloud/app/queryLeftProjectCpuAndMemory?projectId=" + this.projectId
          )
          .then(res => {
            this.leftResource = res.data.obj;
          });
      },
      
  
      //订阅
      subscribeService(row) {
        
        this.rowService = {};
        this.rowService = row;
        this.subscribeForm.instanceName = '';
        this.dialogSubscribeVisible = true;
        this.custom = false;
        this.type = 1;
      },
  
      //订阅服务
  
      sureSubscribe() {
       
        var classPlanName;
        if (this.rowService.spec.externalName == "mysql-service") {
          classPlanName = "self-define";
        } else if (this.rowService.spec.externalName == "rabbitmq-service") {
          classPlanName = "self-define";
        } else {
          classPlanName = "default";
        }
        if(this.custom == true){
          this.type = 2;
          this.$http.get(
            "/cloud/serviceManage/createService?instanceName=" +this.subscribeForm.instanceName +
              "&namespace=" +this.namespace +
              "&serviceName=" +this.rowService.spec.externalName +
              "&classPlanName=" +classPlanName +
              "&cpu=" +this.subscribeForm.cpu +
              "&memory=" +this.subscribeForm.memory +
              "&storageSize=" +this.subscribeForm.storageSize +
              "&type=" + this.type
          )
          .then(res => {
            if (res.data.success) {
              this.$message({
                message: res.data.msg,
                type: "success"
              });
              this.dialogSubscribeVisible = false;
              this.getSubList();
              this.getLeftSource();
            } else {
              this.$message({
                message: res.data.msg,
                type: "error"
              });
            }
          });
        }
        else{
          this.type = 1;
          this.$http.get(
            "/cloud/serviceManage/createService?instanceName=" +this.subscribeForm.instanceName +
              "&namespace=" +this.namespace +
              "&serviceName=" +this.rowService.spec.externalName +
              "&classPlanName=" +classPlanName +
              "&type=" + this.type
          )
          .then(res => {
            if (res.data.success) {
              this.$message({
                message: res.data.msg,
                type: "success"
              });
              this.dialogSubscribeVisible = false;
              this.getSubList();
              this.getLeftSource();
            } else {
              this.$message({
                message: res.data.msg,
                type: "error"
              });
            }
          });
        }
        
      },
      subSizeChange(val) {
        this.subPageSize = val;
        this.getSubList();
      },
      binSizeChange(val) {
        this.binPageSize = val;
      },
  
      
  
      //分页查询订阅
      subCurrentChange(val) {
        this.currentSubPage = val;
        this.getSubList();
      },
      binCurrentChange(val) {
        this.currentBinPage = val;
      },
  
      //删除订阅
  
      delSub(row) {
        this.$confirm("此操作将永久删除订阅, 是否继续?", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        })
          .then(() => {
            this.$http
              .delete(
                "/cloud/serviceManage/deleteService?namespace=" +
                  this.namespace +
                  "&instanceName=" +
                  row.metadata.name
              )
              .then(res => {
                if (res.data.success) {
                  this.$message({
                    message: res.data.msg,
                    type: "success"
                  });
                  // this.getSubList();   
                  // debugger; 
                  setTimeout(() => {  
                    this.getSubList(); 
                  },1000);  
                } else {
                  this.$message({
                    message: res.data.msg,
                    type: "error"
                  });
                }
              });
          })
          .catch(() => {
            this.$message({
              type: "info",
              message: "已取消删除"
            });
          });
      },
      //创建绑定
      bindSub(row) {
        (this.instanceName = ""), (this.instanceName = row.metadata.name);
        this.bindForm.servicebindName = "";
        this.dialogBindVisible = true;
      },
      sureBind() {
        this.$http
          .get(
            "/cloud/serviceManage/createBind?namespace=" +
              this.namespace +
              "&instanceName=" +
              this.instanceName +
              "&servicebindName=" +
              this.bindForm.servicebindName
          )
          .then(res => {
            if (res.data.success) {
              this.$message({
                message: res.data.msg,
                type: "success"
              });
              this.dialogBindVisible = false;
              this.getBinList(this.instanceName);
              
            } else {
              this.$message({
                message: res.data.msg,
                type: "error"
              });
            }
          });
      },
      //访问凭证
      showBind(row) {
        var Base64 = {
          _keyStr:
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
          encode: function(e) {
            var t = "";
            var n, r, i, s, o, u, a;
            var f = 0;
            e = Base64._utf8_encode(e);
            while (f < e.length) {
              n = e.charCodeAt(f++);
              r = e.charCodeAt(f++);
              i = e.charCodeAt(f++);
              s = n >> 2;
              o = ((n & 3) << 4) | (r >> 4);
              u = ((r & 15) << 2) | (i >> 6);
              a = i & 63;
              if (isNaN(r)) {
                u = a = 64;
              } else if (isNaN(i)) {
                a = 64;
              }
              t =
                t +
                this._keyStr.charAt(s) +
                this._keyStr.charAt(o) +
                this._keyStr.charAt(u) +
                this._keyStr.charAt(a);
            }
            return t;
          },
          decode: function(e) {
            var t = "";
            var n, r, i;
            var s, o, u, a;
            var f = 0;
            e = e.replace(/[^A-Za-z0-9+/=]/g, "");
            while (f < e.length) {
              s = this._keyStr.indexOf(e.charAt(f++));
              o = this._keyStr.indexOf(e.charAt(f++));
              u = this._keyStr.indexOf(e.charAt(f++));
              a = this._keyStr.indexOf(e.charAt(f++));
              n = (s << 2) | (o >> 4);
              r = ((o & 15) << 4) | (u >> 2);
              i = ((u & 3) << 6) | a;
              t = t + String.fromCharCode(n);
              if (u != 64) {
                t = t + String.fromCharCode(r);
              }
              if (a != 64) {
                t = t + String.fromCharCode(i);
              }
            }
            t = Base64._utf8_decode(t);
            return t;
          },
          _utf8_encode: function(e) {
            e = e.replace(/rn/g, "n");
            var t = "";
            for (var n = 0; n < e.length; n++) {
              var r = e.charCodeAt(n);
              if (r < 128) {
                t += String.fromCharCode(r);
              } else if (r > 127 && r < 2048) {
                t += String.fromCharCode((r >> 6) | 192);
                t += String.fromCharCode((r & 63) | 128);
              } else {
                t += String.fromCharCode((r >> 12) | 224);
                t += String.fromCharCode(((r >> 6) & 63) | 128);
                t += String.fromCharCode((r & 63) | 128);
              }
            }
            return t;
          },
          _utf8_decode: function(e) {
            var t = "";
            var n = 0;
            var c1, c2;
            var r = (c1 = c2 = 0);
            while (n < e.length) {
              r = e.charCodeAt(n);
              if (r < 128) {
                t += String.fromCharCode(r);
                n++;
              } else if (r > 191 && r < 224) {
                c2 = e.charCodeAt(n + 1);
                t += String.fromCharCode(((r & 31) << 6) | (c2 & 63));
                n += 2;
              } else {
                c2 = e.charCodeAt(n + 1);
                c3 = e.charCodeAt(n + 2);
                t += String.fromCharCode(
                  ((r & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63)
                );
                n += 3;
              }
            }
            return t;
          }
        };
  
        this.$http
          .get(
            "/cloud/serviceManage/getSecret?namespace=" +
              this.namespace +
              "&secretName=" +
              row.servciebindName +
              "-secret"
          )
          .then(res => {
          
            var saveObj = res.data.obj.data;
  
            var assmleObj = {};
  
            for (var key in saveObj) {
              assmleObj[key] = Base64.decode(saveObj[key]);
            }
  
            this.voucherData = assmleObj;
  
            // this.visitForm.inside = Base64.decode(res.data.obj.data["inter-url"]);
            // this.visitForm.external = Base64.decode(
            //   res.data.obj.data["outer-url"]
            // );
          });
  
        this.dialogInstanceDetail = true;
      },
  
      //删除绑定
      delBind(row) {
        this.$confirm("此操作将永久删除绑定, 是否继续?", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        })
          .then(() => {
            this.$http
              .delete(
                "/cloud/serviceManage/deleteBindService?namespace=" +
                  this.namespace +
                  "&servicebindName=" +
                  row.servciebindName
              )
              .then(res => {
                if (res.data.success) {
                  this.$message({
                    message: res.data.msg,
                    type: "success"
                  });
                  this.getBinList(row.instanceName);
                } else {
                  this.$message({
                    message: res.data.msg,
                    type: "error"
                  });
                }
              });
          })
          .catch(() => {
            this.$message({
              type: "info",
              message: "已取消删除"
            });
          });
      },
      //订阅
  
      Subscribe() {}
    },
   
  };