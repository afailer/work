import { mapActions, mapGetters } from "vuex";
import textarerNew from '../component/textareaNew';

export default {
  data() {
    var name = (rule, value, callback) => {
      if (!value || value.length <3) {
        return callback(new Error('配置名称不能为空且长度不小于三个字符'));
      }else if(/^[a-z][a-z\d\-]{1,30}[a-z0-9]$/.test(value) == false){
        return callback(new Error('名称不符合规范，以小写字母开头不包含除-外的特殊字符，以小写字母和数字结尾，最多32位 ！！'))
      }
    }
    return {
      //创建项目
      createStorageForm: {
        name: "",
      },
      envForm: {
        //环境变量配置
        env: [],
        newEnv: {
          name: "",
          value: ""
        },
      },
      envList:[],
      envVisible:false,
      saveFlag: false,
      configName:"",
      title: "创建配置",
      isedit: false,
      configId:"",
      detailList:[],
      eventVisible:false,
      currentPage: 1,
      configureData: [],
      tableKey: 0,
      total: null,
      pageSize: 10,
      listLoading: true,
      listQuery: {
        title: undefined
      },
      //创建用户
      dialogCreateVisible: false,
      //详情
      dialogDetialVisible: false,

      disabled: "",
      projectId: sessionStorage.getItem("projectId"),
      namespace: sessionStorage.getItem("namespace"),
      rule: {
        name: [
          { validator: name, trigger: 'blur' },
        ]}
    };
  },
  computed: {

    addEnvDisabled: function () {
      if (this.isEmpty(this.envForm.newEnv.name)) {
        return true;
      }
      if (this.isEmpty(this.envForm.newEnv.value)) {
        return true;
      }
      return false;
    },

  },
  components: {
    textarerNew,
  },

  filters: {
    statesFilters: function (value) {
      return value + "G";
    },
    state: function (value) {
      switch (value) {
        case 1:
          return '激活';
          break;
        case 3:
          return '冻结';
          break;

      }
    },
    subFilter: function(value) {
      if(value.length>20){
        return value.substr(0,20) + "...";
      }
      else{
        return value;
      }
    },
    formatDatetwo: function (timestamp) {
      var ss = Date.parse(timestamp)
      var date = new Date(ss); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
      var Y = date.getFullYear() + "-";
      var M =
        (date.getMonth() + 1 < 10
          ? "0" + (date.getMonth() + 1)
          : date.getMonth() + 1) + "-";
      var D = date.getDate() + " ";
      var h = date.getHours() + ":";
      var m = date.getMinutes() + ":";
      var s = date.getSeconds();
      return Y + M + D + h + m + s;
      // var re = /-?\d+/;
      // var m = re.exec(time);
      // var d = new Date(parseInt(m[0]));
      // var o = {
      //   "M+": d.getMonth() + 1, //month
      //   "d+": d.getDate(), //day
      //   "h+": d.getHours(), //hour
      //   "m+": d.getMinutes(), //minute
      //   "s+": d.getSeconds(), //second
      //   "q+": Math.floor((d.getMonth() + 3) / 3), //quarter
      //   S: d.getMilliseconds() //millisecond
      // };
      // var format = "yyyy-MM-dd";
      // if (/(y+)/.test(format)) {
      //   format = format.replace(
      //     RegExp.$1,
      //     (d.getFullYear() + "").substr(4 - RegExp.$1.length)
      //   );
      // }
      // for (var k in o) {
      //   if (new RegExp("(" + k + ")").test(format)) {
      //     format = format.replace(
      //       RegExp.$1,
      //       RegExp.$1.length == 1
      //         ? o[k]
      //         : ("00" + o[k]).substr(("" + o[k]).length)
      //     );
      //   }
      // }
      // return format;
    }

  },
  created() {
    this.getList();

  },
  methods: {

    // jsReadFiles(files){
    //   debugger;
    //   if (files.length) {
    //     for (let i in files) {
    //         let file = files[i];
    //         console.log(file);
    //         let reader = new FileReader();//new一个FileReader实例
    //         // if (/javascript+/.test(file.type)) {//判断文件类型，是不是JavaScript类型
    //         //     reader.onload = function () {
    //         //         $('body').append('<pre>' + this.result + '</pre>');
    //         //     };
    //         //     reader.readAsText(file);
    //         // }
    //     }
    // }
    // },

    getList() {
      this.$http
        .get(
          "/cloud/Configmap/queryConfigmapByPage?projectId=" +
          this.projectId +
          "&pageNum=" +
          this.currentPage +
          "&pageSize=" +
          this.pageSize
        )
        .then(res => {
          this.total = res.data.obj.totalCount;
          this.configureData = res.data.obj.result;
        });
    },

    handleFilter() { },
    handleSizeChange(val) {
      this.pageSize = val;
      this.getList();
    },

    //分页查询
    handleCurrentChange(val) {
      this.currentPage = val;
      this.getList();
    },



    //判断重复

    in_array(arry, element) {
      for (var i = 0; i < arry.length; i++) {
        if (arry[i] == element) {
          return true;
        }
      }
      return false;
    },


    //保存环境变量配置
    saveEnv() {
      if(/^[a-z][a-z\d\-]{1,30}[a-z0-9]$/.test(this.envForm.newEnv.name) == false){
        this.$message({
          message: '键名不符合规范，以小写字母开头不包含除-外的特殊字符，以小写字母和数字结尾且长度不小于3位字符 ！！',
          type: 'error'
        });
      }else{
        var envProperty = this.deepClone(this.envForm.newEnv);
        this.envForm.newEnv.name = "";
        this.envForm.newEnv.value = "";
     
      

      var newArry = [];

      for (var j = 0; j < this.envForm.env.length; j++) {
        newArry.push(this.envForm.env[j].name)
      }


      if (newArry.length != 0) {
        if (this.in_array(newArry, envProperty.name)) {
          this.$message({
            message: "KEY值不可以重复！！！",
            type: "error",
            duration: 2000
          });
        } else {
          this.envForm.env.push(envProperty);
        }
      


      } else {
        this.envForm.env.push(envProperty);
      }
    }



    },

    //删除环境变量
    delEnv(property) {
      var index = this.envForm.env.indexOf(property);
      if (index !== -1) {
        this.envForm.env.splice(index, 1);
      }
    },




    //创建存储卷

    createProject() {
      this.disabled = false;
      this.title = "创建配置"
      //
      this.isedit = false;
      this.createStorageForm.name = "";
      this.envForm.env = [],
        this.envForm.newEnv.name = "",
        this.envForm.newEnv.value = "",
        this.dialogCreateVisible = true;

    },
    //取消创建
    cancle(createStorageForm) {
      this.$refs[createStorageForm].resetFields();
      this.getList();
      this.dialogCreateVisible = false
    },
    closeDialog(){
      this.getList();
    },
    //组成保存参数

    parameters() {
      var sendObj = {
        name: "",
        data: "",
        projectId: ""
      }

      sendObj.name = this.createStorageForm.name;
      sendObj.projectId = this.projectId
      if(this.envForm.env.length > 0){
        sendObj.data = JSON.stringify(this.envForm.env)
      }else {
        this.$message({
          message: "最少设置一条环境变量",
          type: "error"
        });
        return;
      }
      // sendObj.data = JSON.stringify(this.envForm.env)

      return sendObj;

    },


    //确认创建存储卷
    sureCreateStorage(formName) {


      this.$http
        .post("/cloud/Configmap/createConfigmap", this.parameters())
        .then(res => {
          if (res.data.success) {
            this.$message({
              message: res.data.msg,
              type: "success"
            });
            this.dialogCreateVisible = false;
            this.getList();

          } else {
            this.$message({
              message: res.data.msg,
              type: "error"
            });
          }
        });


    },

    //删除配置

    deletConfigure(row) {
      this.$confirm("此操作将永久删除配置, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.$http
            .get("/cloud/Configmap/deleteConfigmap?id=" + row.id)
            .then(res => {
              if (res.data.success) {
                this.$message({
                  message: res.data.msg,
                  type: "success"
                });
                this.getList();

              } else {
                this.$message({
                  message: res.data.msg,
                  type: "error"
                });
              }
            });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });

    },


    cleanAll() {
      this.createStorageForm.name = "";
      this.envForm.env = [];
        this.envForm.newEnv.name = "";
        this.envForm.newEnv.value = "";
        this.dialogCreateVisible = true;
    },

    //更新
    editconfigure(row) {
      this.cleanAll();

      this.title = "编辑配置"
      this.createStorageForm.name = row.name;
      this.envForm.env = row.dataList;
      this.isedit = true;
      this.configId =  row.id;
      this.dialogCreateVisible = true;

    },


    //确认编辑】

    updateConfig(){

      var sendObj = {
        name: "",
        data: "",
        projectId: ""
      }

      sendObj.name = this.createStorageForm.name;
      sendObj.projectId = this.projectId

      if(this.envForm.env.length > 0){
        sendObj.data = JSON.stringify(this.envForm.env)
      }else {
        this.$message({
          message: "最少设置一条环境变量",
          type: "error"
        });
        return;
      }
    
      sendObj.id = this.configId
      sendObj.namespace = this.namespace


      this.$http
        .post("/cloud/Configmap/updateConfigmap", sendObj)
        .then(res => {
          if (res.data.success) {
            this.$message({
              message: res.data.msg,
              type: "success"
            });
            this.dialogCreateVisible = false;
            this.getList();

          } else {
            this.$message({
              message: res.data.msg,
              type: "error"
            });
          }
        });



    },

    // 详情

    configureDetial(row) {


      this.$http
        .get("/cloud/Configmap/queryConfigmapDetail?id=" + row.id)
        .then(res => {
          if (res.data.success) {
            
            this.configName = res.data.obj.result[0].name
            if(res.data.obj.result[0].dataList.length==0){
              this.envVisible=true;
            }else{
              this.envVisible=false;
              this.envList=res.data.obj.result[0].dataList;
            }


            if(res.data.obj.result[0].deploymentList==0){
              this.eventVisible=true;
            }else{
              this.eventVisible=false;
              this.detailList =  res.data.obj.result[0].deploymentList
            }
            this.dialogDetialVisible = true;
          } else {
            this.$message({
              message: res.data.msg,
              type: "error"
            });
          }
        });

    },

    //跳转应用详情


    appdetail(row){
      sessionStorage.setItem("id", row.id);
      sessionStorage.setItem("name", row.name);
      this.$router.push({
        name: "applicationDetail",
        query: { id: row.id, name: row.name }
      });
    },

    closeDetial() {
      this.dialogDetialVisible = false;
    }




  },
  watch: {
    $route(currentState, oldState) {
      debugger
      if (currentState.fullPath.startsWith("/tenantProject")) {
        this.projectId = sessionStorage.getItem("projectId");
        this.namespace = sessionStorage.getItem("namespace");
        this.getList();
      } else {
        sessionStorage.setItem("showNumber", 3);
      }
    },

  }
};