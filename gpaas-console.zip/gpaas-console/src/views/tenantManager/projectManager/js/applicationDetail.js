
import commandDialog from "../component/commandDialog";
import logDialog from "../component/logDialog";
import monitorDialog from "../component/monitorDialog";
export default {
  data() {
    return {
      activeName: "first",
      searchText: "",
      number: "2",
      envList: [],
      envVisible: false,
      portVisible: true,
      eventVisible: false,
      eventList: [],
      containerGroup: [],
      service: [],
      nodeVisible: true,
      serviceVisible: true,
      http: [],
      nodePort: '',
      statusReason: '',
      statusType: '',
      replicas: '',
      readyReplicas: '',
      image: '',
      minMemory: '',
      maxMemory: '',
      minCpu: '',
      maxCpu: '',
      ports: '',
      devPvcList: [],
      devVisible: true,
      containerEventList: [],
      eventDialogVisible: false,
      fullscreenLoading: false,
      id: sessionStorage.getItem("id"),
      name: sessionStorage.getItem("name"),
      projectNamespace: sessionStorage.getItem("namespace"),
      //command
      modelNumber: 1,
      deploNameSpace: "",
      developName: "",

      deploymentSocket: null,
      podSocket: null,
      serviceSocket: null,
      ingressSocket: null,
      nodePorts:"",
      nodeIp:"",

      Running:"running",
      Pending:"Pending",
      treminated:"treminated",
      waiting:"waiting",
      terminating:"terminating"

    };
  },
  mounted() {
    this.getData();
    this.getEventList();
    this.startconnect();
  },
  components: {
    commandDialog,
    logDialog,
    monitorDialog

  },
  filters: {
    readyReplicasFilter: function (value) {
      if (value == undefined) {
        return 0
      } else {
        return value
      }
    },
    typeFilter: function (value) {
      switch (value) {
        case 1:
          return '存储卷类型';
          break;
        case 2:
          return '引用配置文件类型';
          break;
      }

    },
    cpuFilter: function (value) {
      return value + '核';
    },
    memoryFilter: function (value) {
      return value + 'M';
    },

    // formatDatetwo: function(timestamp) {
    //   var date = new Date(timestamp); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
    //   var Y = date.getFullYear() + "-";
    //   var M =
    //     (date.getMonth() + 1 < 10
    //       ? "0" + (date.getMonth() + 1)
    //       : date.getMonth() + 1) + "-";
    //   var D = date.getDate() + " ";
    //   var h = date.getHours() + ":";
    //   var m = date.getMinutes() + ":";
    //   var s = date.getSeconds();
    //   return Y + M + D + h + m + s;
    // },
    // formatDatetwo: function(time) {     
    //   var re = /-?\d+/;
    //   var m = re.exec(time);
    //   var d = new Date(parseInt(m[0]));
    //   var o = {
    //     "M+": d.getMonth() + 1, //month
    //     "d+": d.getDate(), //day
    //     "h+": d.getHours(), //hour
    //     "m+": d.getMinutes(), //minute
    //     "s+": d.getSeconds(), //second
    //     "q+": Math.floor((d.getMonth() + 3) / 3), //quarter
    //     S: d.getMilliseconds() //millisecond
    //   };
    //   var format = "yyyy-MM-dd hh:mm:ss";
    //   if (/(y+)/.test(format)) {
    //     format = format.replace(
    //       RegExp.$1,
    //       (d.getFullYear() + "").substr(4 - RegExp.$1.length)
    //     );
    //   }
    //   for (var k in o) {
    //     if (new RegExp("(" + k + ")").test(format)) {
    //       format = format.replace(
    //         RegExp.$1,
    //         RegExp.$1.length == 1
    //           ? o[k]
    //           : ("00" + o[k]).substr(("" + o[k]).length)
    //       );
    //     }
    //   }
    //   return format;
    // },

    formatDatetwo: function(time) {   
        var ss = Date.parse(time)
      var re = /-?\d+/;
      var m = re.exec(ss);
      var d = new Date(parseInt(m[0]));
      var o = {
        "M+": d.getMonth() + 1, //month
        "d+": d.getDate(), //day
        "h+": d.getHours(), //hour
        "m+": d.getMinutes(), //minute
        "s+": d.getSeconds(), //second
        "q+": Math.floor((d.getMonth() + 3) / 3), //quarter
        S: d.getMilliseconds() //millisecond
      };
      var format = "yyyy-MM-dd hh:mm:ss";
      if (/(y+)/.test(format)) {
        format = format.replace(
          RegExp.$1,
          (d.getFullYear() + "").substr(4 - RegExp.$1.length)
        );
      }
      for (var k in o) {
        if (new RegExp("(" + k + ")").test(format)) {
          format = format.replace(
            RegExp.$1,
            RegExp.$1.length == 1
              ? o[k]
              : ("00" + o[k]).substr(("" + o[k]).length)
          );
        }
      }
      return format;
    },
  },
  methods: {
    // 获取详情
    getData() {
      this.$http
        .get("/cloud/appDetail/getAppInfo?code=" + this.id)
        .then(res => {
          if (res.data.success) {
            this.deploNameSpace = res.data.obj.deployment.namespace
            this.developName = res.data.obj.deployment.name
            // this.containerGroup=res.data.obj.podList;
            if (res.data.obj.deployment.service == null) {
              this.serviceVisible = false;
              this.portVisible = false;
            } else {
              this.serviceVisible = true;
              // this.service = [];

              this.nodePorts = res.data.obj.deployment.service.nodePorts
              this.nodeIp = res.data.obj.deployment.service.nodeIp

              // this.service.push(res.data.obj.deployment.service);
              // if (res.data.obj.deployment.service.type == 'NodePort') {
              //   this.nodeVisible = true;
              // } else {
              //   this.nodeVisible = false;
              // }

              // var serviceTemp = "{" + this.service[0].ports + "}";
              // var servicePorts = JSON.parse(serviceTemp).ports;
              // var arr = [];
              // for (var i in servicePorts) {
              //   arr.push(servicePorts[i].port);

              // }
              // this.ports = arr;
             
              if(res.data.obj.ingressList.length>0){
                var ingressList = res.data.obj.ingressList;
                if (ingressList == null) {
                  this.portVisible = false;
                } else {
                  //this.http = [];
                  this.nodePort = ingressList[0].nodePort;
                  // for (var i in ingressList) {
                  //   this.portVisible = true;
                  //   var rules = ingressList[i].rules;
                  //   var ss = JSON.parse(rules);
                  //   this.http.push(ss);
                  // }
                }
              }else{
                this.portVisible = false;
              }
           
              

            }

            var statusList = res.data.obj.state.conditions;
            //  this.statusType = statusList[statusList.length-1].type;
            // this.statusReason = statusList[statusList.length-1].reason;
            // this.replicas = res.data.obj.deployment.replicas;
            // this.readyReplicas = res.data.obj.state.readyReplicas;
            this.minMemory = res.data.obj.deployment.minMemory;
            this.maxMemory = res.data.obj.deployment.maxMemory;
            this.minCpu = res.data.obj.deployment.minCpu;
            this.maxCpu = res.data.obj.deployment.maxCpu;
            this.image = res.data.obj.deployment.imageurl;
            if (res.data.obj.deployment.devPvcList == null) {
              this.devVisible = false;
            } else {
              if (res.data.obj.deployment.devPvcList.length == 0) {
                this.devVisible = false;
              } else {
                this.devVisible = true;
                this.devPvcList = res.data.obj.deployment.devPvcList;
              }
            }

            var env = "{" + res.data.obj.deployment.env + "}";
            if (JSON.parse(env).env.length == 0) {
              this.envVisible = true;
            } else {
              this.envVisible = false;
              this.envList = JSON.parse(env).env;
            }

          } else {
            this.$message({
              message: res.data.msg,
              type: "error"
            });
          }
        });
    },
    //获取事件
    getEventList() {
      this.$http.get("/cloud/appDetail/getDeploymentEvent?name=" + this.name)
        .then(res => {
          if (res.data.success) {
            if (res.data.obj.items.length == 0) {
              this.eventVisible = true;
            } else {
              this.eventVisible = false;
              this.eventList = res.data.obj.items;
            }
          }
        })
    },
    handleClick(tab, event) {
      console.log(tab, event);
    },

    // 转换字符串为 数组

    changeArry(string) {
      return string.split(",");
    },

    //打开新页面

    openOther(ip, port) {
      
      var ss = "http://" + ip + ":" + port;
      window.open(ss);
    },
    openPort(host, port, path) {
      var aa = "http://" + host + ":" + port + path;

      window.open(aa);
    },


    //加
    add() {
      if (this.replicas == 5) {
        return 5;
      } else {
        this.replicas++;
        this.pods();
      }
    },
    //减
    reduce() {
      if (this.replicas == 0) {
        return 0;
      } else {
        this.replicas--;
        this.pods();
      }
    },
    //pods
    pods() {
      this.$http.get("/cloud/app/podUpdate?id=" + this.id + "&replicas=" + this.replicas)
        .then(res => {
          if (res.data.success) {
            //this.openFullScreen();
          } else {
            this.$message({
              message: res.data.msg,
              type: "error"
            });
          }
        })
    },
    //执行命令
    command(row) {
      this.$bus.$emit("openCommand", row);
      this.$store.dispatch('setProjectNameSpace', this.deploNameSpace);
      this.$store.dispatch('setListInfoName', row.name);
      this.$store.dispatch('setModelnumber', this.modelNumber++);
      this.$bus.$emit("openCommand", row.name, this.deploNameSpace);
    },
    //日志
    log(row) {
      this.$store.dispatch('setProjectNameSpace', this.deploNameSpace);
      this.$bus.$emit("openLog", row);
    },

    //停止
    delApplication(row) {
      debugger;
      this.$confirm("确定删除?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.$http
            .get("/cloud/appDetail/deletePodByName?podName=" + row.name + "&deploymentName=" + this.developName + "&namespace=" + this.deploNameSpace)
            .then(res => {
              if (res.data.success) {
                this.$message({
                  message: res.data.msg,
                  type: "success"
                });
                // this.openFullScreen();
              } else {
                this.$message({
                  message: res.data.msg
                });
              }
            });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });

    },

    //监控
    monitorApplication(row) {

      this.$store.dispatch('setProjectNameSpace', this.deploNameSpace);
      this.$store.dispatch('setListInfoName', row.name);
      this.$bus.$emit("openMonitor", row);
    },

    //加载
    openFullScreen() {
      this.fullscreenLoading = true;
      setTimeout(() => {
        this.fullscreenLoading = false;
        this.getData();
      }, 3000);
    },
    //事件
    showEvent(row) {
      this.$http.get("/cloud/appDetail/getPodEvent?name=" + row.name)
        .then(res => {
          if (res.data.success) {
            this.containerEventList = res.data.obj.items;
            this.eventDialogVisible = true;
          }
        })
    },

    //-----------------------------------------------------------websorcket方法--------------------------------------------------------------

    //应用

    deploymentonmessage(ev) {
      var deploymentData = JSON.parse(ev.data).object.status.conditions;
      this.statusType = deploymentData[deploymentData.length - 1].type
      this.statusReason = deploymentData[deploymentData.length - 1].reason;
      if(JSON.parse(ev.data).object.status.replicas){
        this.replicas = JSON.parse(ev.data).object.status.replicas;
      }else{
        this.replicas = 0
      }
      
      this.readyReplicas = JSON.parse(ev.data).object.status.readyReplicas;
    },
    deploymentonclose() {

    },
    deploymenterror() {

    },


    //pod

    podonmessage(ev) {

      var podData = JSON.parse(ev.data)
      if (podData.type == "ADDED") {
        var podObj = {};
        podObj.name = podData.object.metadata.name;
        podObj.nodeName = podData.object.spec.nodeName;
       
        if (podData.object.status.containerStatuses) {
          podObj.restartCount = podData.object.status.containerStatuses[0].restartCount;
          podObj.status =    Object.keys( podData.object.status.containerStatuses[0].state)[0] ;
        }else {
          podObj.status =  podData.object.status.phase
        }
        podObj.creationTimestamp = podData.object.metadata.creationTimestamp  
        this.containerGroup.push(podObj);
      } else if (podData.type == "MODIFIED") {

        for (var i = 0; i < this.containerGroup.length; i++) {
          if (this.containerGroup[i].name == podData.object.metadata.name) {
            this.containerGroup[i].nodeName = podData.object.spec.nodeName;
            if (podData.object.status.containerStatuses) {
              this.containerGroup[i].restartCount = podData.object.status.containerStatuses[0].restartCount;
              this.containerGroup[i].status =Object.keys( podData.object.status.containerStatuses[0].state)[0]
            }else {
              this.containerGroup[i].status =  podData.object.status.phase
            }
            this.containerGroup[i].creationTimestamp =podData.object.metadata.creationTimestamp
          }
        }
      } else if (podData.type == "DELETED") {
        for (var i = 0; i < this.containerGroup.length; i++) {
          if (this.containerGroup[i].name == podData.object.metadata.name) {
            this.containerGroup[i].nodeName = podData.object.spec.nodeName;
            if (podData.object.status.containerStatuses) {
              this.containerGroup[i].restartCount = podData.object.status.containerStatuses[0].restartCount;
              this.containerGroup[i].status =Object.keys( podData.object.status.containerStatuses[0].state)[0]
            }else {
              this.containerGroup[i].status =  podData.object.status.phase
            }
            this.containerGroup[i].creationTimestamp =podData.object.metadata.creationTimestamp

            this.containerGroup.splice(i, 1);
          }
        }
      }

    },
    podonclose() {

    },
    poderror() {

    },

    //服务
    serviceonmessage(ev) {
      var serviceData = JSON.parse(ev.data);
      if (serviceData.type == "ADDED") {
        var serviceObj = {};
        serviceObj.name = serviceData.object.metadata.name;
        serviceObj.clusterIP = serviceData.object.spec.clusterIP;
        serviceObj.createTime = serviceData.object.metadata.creationTimestamp ;
        serviceObj.type = serviceData.object.spec.ports[0].protocol

        serviceObj.innerIp = serviceData.object.metadata.name + "." + serviceData.object.metadata.namespace + ".svc.cluster.local"
        var arr = [];
        for (var i = 0; i < serviceData.object.spec.ports.length; i++) {
          arr.push(serviceData.object.spec.ports[i].port);
         
        }
        this.ports = arr;
        if (serviceData.object.spec.type == 'NodePort') {
          this.nodeVisible = true;
        } else {
          this.nodeVisible = false;
        }
        this.service.push(serviceObj);
      } else if (serviceData.type == "MODIFIED") {

        for (var i = 0; i < this.service.length; i++) {
          if (this.service[i].name == serviceData.object.metadata.name) {
            this.service[i].clusterIP = serviceData.object.spec.clusterIP;
            this.service[i].createTime =  serviceData.object.metadata.creationTimestamp ;
           this.service[i].type = serviceData.object.spec.ports[0].protocol
          }
        }
      } else if (serviceData.type == "DELETED") {
        for (var i = 0; i < this.service.length; i++) {
          if (this.service[i].name == serviceData.object.metadata.name) {
            this.service.splice(i, 1);
          }
        }
      }

    },
    serviceonclose() {

    },
    serviceerror() {

    },



    // inguress
    ingressonmessage(ev) {
      debugger;
      var httpData = JSON.parse(ev.data);
      if (httpData.type == "ADDED") {
        var httpObj = {};

        var newArry = []
        for (var i = 0; i < httpData.object.spec.rules.length; i++) {
          if (!httpData.object.spec.rules[i].host.startsWith("*")) {
            newArry.push(httpData.object.spec.rules[i])
          }
        }
        this.http = newArry;
      } else if (httpData.type == "MODIFIED") {

        // for (var i = 0; i < this.service.length; i++) {
        //   if (this.service[i].name == serviceData.object.metadata.name) {
        //     this.service[i].clusterIP =serviceData.object.spec.clusterIP;
        //     this.service[i].createTime = serviceData.object.metadata.creationTimestamp;
        //   }
        // }
      } else if (httpData.type == "DELETED") {
        for (var i = 0; i < this.service.length; i++) {
          if (this.http[i].name == httpData.object.metadata.name) {
            this.http.splice(i, 1);
          }
        }
      }

    },
    ingressonclose() {

    },
    ingresserror() {

    },



    //-----------------------------------------------------------websorcket------------------------------------------------------------------------

    startconnect() {
    

      var deploymentUrl =
        "ws://" + this.globalURL.BASE_URL + "/apis/extensions/v1beta1/watch/namespaces/" +
        this.projectNamespace +
        "/deployments/" +
        this.name


      var podUrl =
        "ws://" + this.globalURL.BASE_URL + "/api/v1/watch/namespaces/" +
        this.projectNamespace +
        "/pods?labelSelector=app=" +
        this.name


      var serviceUrl =
        "ws://" + this.globalURL.BASE_URL + "/api/v1/watch/namespaces/" +
        this.projectNamespace +
        "/services/" +
        this.name


      var ingressUrl =
        "ws://" + this.globalURL.BASE_URL + "/apis/extensions/v1beta1/watch/namespaces/" +
        this.projectNamespace +
        "/ingresses/" +
        this.name


      // open websocket
      this.deploymentSocket = new WebSocket(deploymentUrl);
      this.deploymentSocket.onmessage = this.deploymentonmessage;
      this.deploymentSocket.onclose = this.deploymentonclose;
      this.deploymentSocket.onerror = this.deploymenterror;



      this.podSocket = new WebSocket(podUrl);
      this.podSocket.onmessage = this.podonmessage;
      this.podSocket.onclose = this.podonclose;
      this.podSocket.onerror = this.poderror;


      this.serviceSocket = new WebSocket(serviceUrl);
      this.serviceSocket.onmessage = this.serviceonmessage;
      this.serviceSocket.onclose = this.serviceonclose;
      this.serviceSocket.onerror = this.serviceerror;


      this.ingressSocket = new WebSocket(ingressUrl);
      this.ingressSocket.onmessage = this.ingressonmessage;
      this.ingressSocket.onclose = this.ingressonclose;
      this.ingressSocket.onerror = this.ingresserror;


    },


    disconnect() {

      if (this.deploymentSocket) {
        this.deploymentSocket.onopen = this.deploymentSocket.onmessage = this.deploymentSocket.onerror = this.deploymentSocket.onclose = null;
        if (this.deploymentSocket.readyState < 2)
          // CLOSING
          this.deploymentSocket.close();
        this.deploymentSocket = null;
      }

      if (this.podSocket) {
        this.podSocket.onopen = this.podSocket.onmessage = this.podSocket.onerror = this.podSocket.onclose = null;
        if (this.podSocket.readyState < 2)
          // CLOSING
          this.podSocket.close();
        this.podSocket = null;
      }

      if (this.serviceSocket) {
        this.serviceSocket.onopen = this.serviceSocket.onmessage = this.serviceSocket.onerror = this.serviceSocket.onclose = null;
        if (this.serviceSocket.readyState < 2)
          // CLOSING
          this.serviceSocket.close();
        this.serviceSocket = null;
      }

      if (this.ingressSocket) {
        this.ingressSocket.onopen = this.ingressSocket.onmessage = this.ingressSocket.onerror = this.ingressSocket.onclose = null;
        if (this.ingressSocket.readyState < 2)
          // CLOSING
          this.ingressSocket.close();
        this.ingressSocket = null;
      }

    },






  },
  // watch: {
  //   $route() {
  //     alert("qiehuan")
  //   }
  // },
  // beforeDestroy(){
  //   alert("222222")
  // },
  destroyed() {
    
    this.disconnect();

  }
};