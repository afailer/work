import echarts from "echarts";
export default {
    data() {
        return {
            containerGroup:[],
            monitorVisible:false,
            //监控
            cpuDta: [],
            cpuList: [],
            cpuValue: [],
            memoryData: [],
            networkData: [],
            echarts:echarts,
            namespace:sessionStorage.getItem("namespace"),
            name:sessionStorage.getItem("name"),
            monitor:sessionStorage.getItem("monitor"),
        }
    },
    filters:{
      formatDatetwo: function(time) {
        var ss = Date.parse(time)
        var re = /-?\d+/;
        var m = re.exec(ss);
        var d = new Date(parseInt(m[0]));
        var o = {
          "M+": d.getMonth() + 1, //month
          "d+": d.getDate(), //day
          "h+": d.getHours(), //hour
          "m+": d.getMinutes(), //minute
          "s+": d.getSeconds(), //second
          "q+": Math.floor((d.getMonth() + 3) / 3), //quarter
          S: d.getMilliseconds() //millisecond
        };
        var format = "yyyy-MM-dd hh:mm:ss";
        if (/(y+)/.test(format)) {
          format = format.replace(
            RegExp.$1,
            (d.getFullYear() + "").substr(4 - RegExp.$1.length)
          );
        }
        for (var k in o) {
          if (new RegExp("(" + k + ")").test(format)) {
            format = format.replace(
              RegExp.$1,
              RegExp.$1.length == 1
                ? o[k]
                : ("00" + o[k]).substr(("" + o[k]).length)
            );
          }
        }
        return format;
      },
    },
    created(){
      this.getList();
    },
    methods: {
        getList(){
          this.$http.get("/api/v1/namespaces/"+this.namespace+"/pods?labelSelector=release="+this.name).then(res => {
            this.containerGroup = res.data.items;
          })
        },
        monitorPod(name){
            this.monitorVisible = true;
            this.getData(echarts,name)
        },
        //获取监控数据
        
        getData(echarts,name) {
          this.$http
            .get(
              "/api/v1/namespaces/kube-system/services/heapster/proxy/api/v1/model/namespaces/"+this.namespace+"/pods/"+name+"/metrics/cpu/usage_rate"
            )
            .then(res => {
              this.cpuData = res.data.metrics;
              this.initCpuChart(echarts);
            });
    
          this.$http
            .get(
              "/api/v1/namespaces/kube-system/services/heapster/proxy/api/v1/model/namespaces/"+this.namespace+"/pods/"+name+"/metrics/memory/usage"
            )
            .then(res => {
              this.memoryData = res.data.metrics;
              this.initMemoryChart(echarts);
            });
    
          this.$http
            .get(
              "/api/v1/namespaces/kube-system/services/heapster/proxy/api/v1/model/namespaces/"+this.namespace+"/pods/"+name+"/metrics/network/tx_rate"
            )
            .then(res => {
              this.networkData = res.data.metrics;
              this.initNetChart(echarts);
            });
        },
  
      //初始化监控
  
  
      initCpuChart(echarts) {
        this.cpuchart = echarts.init(this.$refs.cpu);
       
  
        var cpuData = this.cpuData;
      
  
        var date1List = cpuData.map(function(item) {
          return item.timestamp;
        });
        var value1List = cpuData.map(function(item) {
          return item.value;
        });
  
      
  
        this.cpuchart.setOption({
          tooltip: {
            trigger: "axis"
          },
  
          title: {
            left: "center",
            text: "cpu"
          },
  
          xAxis: {
            type: "category",
            data: date1List,
            name: '时间',
          },
          yAxis: {
            type: "value",
            name:"核",
            axisLabel: {                   
              formatter: function (value, index) {           
              return value/10;      
              }                
            }
          },
          series: [
            {
              data: value1List,
              type: "line"
            }
          ]
        });
      },
      initMemoryChart(echarts) {
        
         this.memorychart = echarts.init(this.$refs.memory);
        
         var memoryData = this.memoryData;
      
  
        var date2List = memoryData.map(function(item) {
          return item.timestamp;
        });
        var value2List = memoryData.map(function(item) {
          return item.value;
        });
  
        this.memorychart.setOption({
          tooltip: {
            trigger: "axis"
          },
  
          title: {
            left: "center",
            text: "内存"
          },
  
          xAxis: {
            type: "category",
            data: date2List,
            name: '时间',
          },
          yAxis: {
            type: "value",
            name:"MB",
            axisLabel: {                   
              formatter: function (value, index) {           
                 var a=value/(1024*1024);      
                 return a.toFixed(2);
              }                
            }
          },
          series: [
            {
              data: value2List,
              type: "line"
            }
          ]
        });
      },
      initNetChart(echarts) {
       
         this.networkchart = echarts.init(this.$refs.network);
  
         var networkData = this.networkData;
  
        var date3List = networkData.map(function(item) {
          return item.timestamp;
        });
        var value3List = networkData.map(function(item) {
          return item.value;
        });
  
        this.networkchart.setOption({
          tooltip: {
            trigger: "axis"
          },
  
          title: {
            left: "center",
            text: "网络"
          },
  
          xAxis: {
            type: "category",
            data: date3List,
            name: '时间',
          },
          yAxis: {
            type: "value",
            name: '(MB/秒)',
            axisLabel: {                   
              formatter: function (value, index) {           
              var a=value/(1024*1024)
              return a.toFixed(2);      
              }
            }
          },
          series: [
            {
              data: value3List,
              type: "line",
            },
          ]
        });
      }
    }
}