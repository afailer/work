
export default {
    data() {
      return {
        bindData: [],
        binTotal: null,
        binPageSize: 10,
        currentBinPage: 1,
        tableKey: 0,
        instanceName: "",
        formLabelWidth: "120px",
        dialogInstanceDetail: false,
        visitForm: {
          inside: "",
          external: ""
        },
        dialogSubscribeVisible: false,
        rowService: {},
        voucherData: {},
        projectId:sessionStorage.getItem("projectId"),
        namespace:sessionStorage.getItem("namespace"),
        name:sessionStorage.getItem("name"),
      };
      
    },
    filters: {
      formatDatetwo: function(time) {
        var re = /-?\d+/;
        var m = re.exec(time);
        var d = new Date(parseInt(m[0]));
        var o = {
          "M+": d.getMonth() + 1, //month
          "d+": d.getDate(), //day
          "h+": d.getHours(), //hour
          "m+": d.getMinutes(), //minute
          "s+": d.getSeconds(), //second
          "q+": Math.floor((d.getMonth() + 3) / 3), //quarter
          S: d.getMilliseconds() //millisecond
        };
        var format = "yyyy-MM-dd hh:mm:ss";
        if (/(y+)/.test(format)) {
          format = format.replace(
            RegExp.$1,
            (d.getFullYear() + "").substr(4 - RegExp.$1.length)
          );
        }
        for (var k in o) {
          if (new RegExp("(" + k + ")").test(format)) {
            format = format.replace(
              RegExp.$1,
              RegExp.$1.length == 1
                ? o[k]
                : ("00" + o[k]).substr(("" + o[k]).length)
            );
          }
        }
        return format;
      },
    },
    
    methods: {
      getBinList(name) {
        this.bindData=[];
        this.$http
          .get(
            "/cloud/serviceManage/getBindServces?pageNum=" +
              this.currentBinPage +
              "&pageSize=" +
              this.binPageSize +
              "&namespace=" +
              this.namespace+
              "&instanceName="+this.name
          )
          .then(res => {
            this.binTotal = res.data.obj.totalCount;
            this.bindData = res.data.obj.result;
          });
      },
    
      binSizeChange(val) {
        this.binPageSize = val;
      },
  
      
  
      //分页查询订阅
      
      binCurrentChange(val) {
        this.currentBinPage = val;
      },
  
     
      //访问凭证
      showBind(row) {
        this.voucherData = {}
        var Base64 = {
          _keyStr:
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
          encode: function(e) {
            var t = "";
            var n, r, i, s, o, u, a;
            var f = 0;
            e = Base64._utf8_encode(e);
            while (f < e.length) {
              n = e.charCodeAt(f++);
              r = e.charCodeAt(f++);
              i = e.charCodeAt(f++);
              s = n >> 2;
              o = ((n & 3) << 4) | (r >> 4);
              u = ((r & 15) << 2) | (i >> 6);
              a = i & 63;
              if (isNaN(r)) {
                u = a = 64;
              } else if (isNaN(i)) {
                a = 64;
              }
              t =
                t +
                this._keyStr.charAt(s) +
                this._keyStr.charAt(o) +
                this._keyStr.charAt(u) +
                this._keyStr.charAt(a);
            }
            return t;
          },
          decode: function(e) {
            var t = "";
            var n, r, i;
            var s, o, u, a;
            var f = 0;
            e = e.replace(/[^A-Za-z0-9+/=]/g, "");
            while (f < e.length) {
              s = this._keyStr.indexOf(e.charAt(f++));
              o = this._keyStr.indexOf(e.charAt(f++));
              u = this._keyStr.indexOf(e.charAt(f++));
              a = this._keyStr.indexOf(e.charAt(f++));
              n = (s << 2) | (o >> 4);
              r = ((o & 15) << 4) | (u >> 2);
              i = ((u & 3) << 6) | a;
              t = t + String.fromCharCode(n);
              if (u != 64) {
                t = t + String.fromCharCode(r);
              }
              if (a != 64) {
                t = t + String.fromCharCode(i);
              }
            }
            t = Base64._utf8_decode(t);
            return t;
          },
          _utf8_encode: function(e) {
            e = e.replace(/rn/g, "n");
            var t = "";
            for (var n = 0; n < e.length; n++) {
              var r = e.charCodeAt(n);
              if (r < 128) {
                t += String.fromCharCode(r);
              } else if (r > 127 && r < 2048) {
                t += String.fromCharCode((r >> 6) | 192);
                t += String.fromCharCode((r & 63) | 128);
              } else {
                t += String.fromCharCode((r >> 12) | 224);
                t += String.fromCharCode(((r >> 6) & 63) | 128);
                t += String.fromCharCode((r & 63) | 128);
              }
            }
            return t;
          },
          _utf8_decode: function(e) {
            var t = "";
            var n = 0;
            var c1, c2;
            var r = (c1 = c2 = 0);
            while (n < e.length) {
              r = e.charCodeAt(n);
              if (r < 128) {
                t += String.fromCharCode(r);
                n++;
              } else if (r > 191 && r < 224) {
                c2 = e.charCodeAt(n + 1);
                t += String.fromCharCode(((r & 31) << 6) | (c2 & 63));
                n += 2;
              } else {
                c2 = e.charCodeAt(n + 1);
                c3 = e.charCodeAt(n + 2);
                t += String.fromCharCode(
                  ((r & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63)
                );
                n += 3;
              }
            }
            return t;
          }
        };
  
        this.$http
          .get(
            "/cloud/serviceManage/getSecret?namespace=" +
              this.namespace +
              "&secretName=" +
              row.servciebindName +
              "-secret"
          )
          .then(res => {
           
  
            var saveObj = res.data.obj.data;
  
            var assmleObj = {};
  
            for (var key in saveObj) {
              assmleObj[key] = Base64.decode(saveObj[key]);
            }
  
            this.voucherData = assmleObj;
  
            // this.visitForm.inside = Base64.decode(res.data.obj.data["inter-url"]);
            // this.visitForm.external = Base64.decode(
            //   res.data.obj.data["outer-url"]
            // );
          });
  
        this.dialogInstanceDetail = true;
      },
  
      //删除绑定
      delBind(row) {
        this.$confirm("此操作将永久删除绑定, 是否继续?", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        })
          .then(() => {
            this.$http
              .delete(
                "/cloud/serviceManage/deleteBindService?namespace=" +
                  this.namespace +
                  "&servicebindName=" +
                  row.servciebindName
              )
              .then(res => {
                if (res.data.success) {
                  this.$message({
                    message: res.data.msg,
                    type: "success"
                  });
                  this.getBinList(row.instanceName);
                } else {
                  this.$message({
                    message: res.data.msg,
                    type: "error"
                  });
                }
              });
          })
          .catch(() => {
            this.$message({
              type: "info",
              message: "已取消删除"
            });
          });
      },
    },
    created() {
        this.getBinList(this.name);
    },
  };