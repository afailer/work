import { mapGetters } from "vuex";

export default {
  data() {
    var checkPorts = (rule, value, callback) => {
      if (
        /^([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])$/.test(
          value
        ) == false
      ) {
        callback(new Error("端口号不能大于65535"));
      } else {
        callback();
      }
    };

    var checkName = (rule, value, callback) => {

      if (!value && value.length < 3) {
        return callback(new Error('名称不能为空且长度最少为3个字符！'));
      } else if (
        /^[a-z][a-z\d\-]{1,30}[a-z0-9]$/.test(
          value
        ) == false
      ) {
        return callback(new Error('名称不符合规范，以小写字母开头不包含除-外的特殊字符，以小写字母和数字结尾，最多32位 ！！'));
      } else {
        callback();
      }

    };

    return {
      //创建项目
      applicationForm: {
        name: "",
        maxCpu: "",
        minCpu: "",
        maxMemory: "",
        minMemory: "",
        labels: "",
        mirrorId: "",
        mirrorName: "",
        description: ""
      },
      isService: false,
      isFull: true,
      title: "",
      envForm: {
        //环境变量配置
        env: [],
        newEnv: {
          name: "",
          value: ""
        },
        ports: [],
        newports: {
          port: "",
          targetPort: "",
          protocol: "TCP",
          name: ""
        },
        senPorts: []
      },
      envConfigData: [],//configenv  查询数据
      checkConfigData: [],//选中configData
      checkPvcData: {},//选中的挂在卷
      pvcConfigList: [], //挂在卷配置列表
      pvcKey: [], //key

      configurePvcVisible: false,//pvc模态层
      configData: {},//选中的配置文件

      configArr: [],
      //isIgruse: false,
      configMap: {
        configMapName: "",
        configMapKey: "",
        path: "",
        mountPath: "",
        volumesType: 2
      },  //配置文件选中信息


      containerData: [],//容器端口
     // isHTTP: false,
     // isPorts: false, //是否设置端口
     // isPVC: false, //挂载
     // isChoice: false, //
      pvcForm: {
        properties: [],
        pvcConfigdata: [],
        newProperty: {
          mountPath: ""
        }
      },

      isPush: false, //是否发布为应用
     // isName: false, //
     // serviceProtocol: "", //选择是TCP  或者HTTP

     // choiceHttp: false, //是否选择http
     // saveSetting: false, //保存你的设置

      service: {
        port: "",
        type: "",
      },
      serviceAllPorts: [],
      ingressList: [],
      plantList: [{ label: "平台生成", value: 1 }, { label: "手动输入", value: 2 }],
      applicationId: "",
      options: [],
      devPvcList: {}, //选中的挂在卷
      count: 0,
      mirror: "",
      isEdit: false,
      currentPage: 1,
      projectData: [],
      tableKey: 0,
      total: null,
      pageSize: 10,    
      //创建应用
      dialogCreateVisible: false,
      //创建应用
      isCreate: true,

      //剩余容量
      leftResource: [],

      //表单验证
      rules: {
        name: [{ validator: checkName, trigger: "blur", }],
        // labels: [{ required: true, message: "请填写标签", trigger: "blur" }],
        maxCpu: [
          {
            required: true,
            type: "number",
            message: "请填写数字",
            trigger: "blur"
          }
        ],
        minCpu: [
          {
            required: true,
            type: "number",
            message: "请填写数字",
            trigger: "blur"
          }
        ],
        maxMemory: [
          {
            required: true,
            type: "number",
            message: "请填写数字",
            trigger: "blur"
          }
        ],
        minMemory: [
          {
            required: true,
            type: "number",
            message: "请填写数字",
            trigger: "blur"
          }
        ],
        mirrorId: [
          { required: true, message: "请选择镜像库", trigger: "change" }
        ],
        mirrorName: [
          { required: true, message: "请输入镜像名称", trigger: "blur" }
        ],
        ports: [
          { validator: checkPorts, trigger: "blur", }
        ]
      },
      rules1: {
        // port: [{ validator: port, trigger: "blur" }],
        // targetPort: [{ validator: port, trigger: "blur" }],
        protocol: [
          { required: true, message: "请选择协议", trigger: "change" }
        ],
        type: [{ required: true, message: "请选择类型", trigger: "change" }]
      },

      projectId: sessionStorage.getItem("projectId"),
      namespace: sessionStorage.getItem("namespace"),
      activeName: 'first',
      //环境变量配置文件
      configureDialogVisible: false,
      conPort: [],
      checkServicePort: [],
      tableData3: [],
      multipleSelection: [],
      tableData5: []

    };
  },

  filters: {
    statesFilters: function (value) {
      return value + "M";
    },
    memoryFilters: function (value) {
      return value + "G";
    },

    subsFiter: function (value) {
      return Math.round(value * 100) / 100;
    },

    longFilters: function (value) {
      if (value != null && value.length > 0) {
        return "是";
      } else {
        return "否";
      }
    },

  
    formatDatetwo: function(time) {
      var ss = Date.parse(time)
      var re = /-?\d+/;
      var m = re.exec(ss);
      var d = new Date(parseInt(m[0]));
      var o = {
        "M+": d.getMonth() + 1, //month
        "d+": d.getDate(), //day
        "h+": d.getHours(), //hour
        "m+": d.getMinutes(), //minute
        "s+": d.getSeconds(), //second
        "q+": Math.floor((d.getMonth() + 3) / 3), //quarter
        S: d.getMilliseconds() //millisecond
      };
      var format = "yyyy-MM-dd hh:mm:ss";
      if (/(y+)/.test(format)) {
        format = format.replace(
          RegExp.$1,
          (d.getFullYear() + "").substr(4 - RegExp.$1.length)
        );
      }
      for (var k in o) {
        if (new RegExp("(" + k + ")").test(format)) {
          format = format.replace(
            RegExp.$1,
            RegExp.$1.length == 1
              ? o[k]
              : ("00" + o[k]).substr(("" + o[k]).length)
          );
        }
      }
      return format;
    },
  },

  computed: {
    addPvcDisabled: function () {
      if (this.isEmpty(this.pvcForm.newProperty.mountPath)) {
        return true;
      }
      return false;
    },

    addPortDisabled: function () {
      if (this.isEmpty(this.envForm.newports.port)) {
        return true;
      }
      if (this.isEmpty(this.envForm.newports.targetPort)) {
        return true;
      }
      if (this.isEmpty(this.envForm.newports.protocol)) {
        return true;
      }
      if (this.isEmpty(this.envForm.newports.name)) {
        return true;
      }
      return false;
    }
  },
  created() {
    this.getList();
    this.getleftSource();
  },
  methods: {
    //-------------------------------------------------------列表--------------------------------------------------------------------------
    getList() {
      this.$http
        .get(
          "/cloud/app/appGetItemList?pageNum=" +
          this.currentPage +
          "&pageSize=" +
          this.pageSize +
          "&projectId=" +
          this.projectId
        )
        .then(res => {
          this.total = res.data.obj.totalCount;
          this.projectData = res.data.obj.result;
        });
    },

    getleftSource(){
      //获取剩余容量

      this.$http
        .get(
          "/cloud/app/queryLeftProjectCpuAndMemory?projectId=" + this.projectId
        )
        .then(res => {
          this.leftResource = res.data.obj;
        });
    },

    openCreate() { },
    handleFilter() { },
    handleSizeChange(val) {
      this.pageSize = val;
      this.getList();
    },

    //分页查询
    handleCurrentChange(val) {
      this.currentPage = val;
      this.getList();
    },
    handleModifyStatus(row, status) { },

    //--------------------------------------------------------------------环境变量---------------------------------------------------------------
    //添加env
    addEnv(index, row, rows) {
      var copy = Object.assign({}, {});
      rows.splice(index + 1, 0, copy);
    },
    //删除env
    deleteEnv(index, rows) {
    
      // if(index == 0){
      //   return;
      // }else{
      //   rows.splice(index, 1);
      // }     
      if (rows.length > 1) {
        rows.splice(index, 1);
      } else {
        this.envForm.env = [{}]
      }

    },

    //删除挂载卷
    deletePvc(index, rows) {
      
      // if(index == 0){
      //   return;
      // }else{
      //   rows.splice(index, 1);
      // }     
      if (rows.length > 1) {
        rows.splice(index, 1);
      } else {
        this.pvcForm.properties = [{}]
      }

    },

    changeenvConfug(data) {

      this.checkConfigData = [];
      this.checkConfigData = data;

    },

    //从配置文件中添加env 
    addEnvConfig() {
      this.checkConfigData = [],
        this.$http
          .get(
            "/cloud/Configmap/queryConfigmapByPage?projectId=" +
            this.projectId +
            "&pageNum=1" +
            "&pageSize=1000"
          )
          .then(res => {
            this.envConfigData = res.data.obj.result;
          });
      this.configureDialogVisible = true
    },
    //确定选择envconfig
    sureCheckfonfig() {
      this.envForm.env = this.envForm.env.concat(this.checkConfigData)
      this.configureDialogVisible = false
    },



    // ------------------------------------------------------存储设置------------------------------------------------------------------



    //选中的值

    toggleSelection(rows) {
      if (rows) {
        rows.forEach(row => {
          this.$refs.multipleTable.toggleRowSelection(row);
        });
      } else {
        this.$refs.multipleTable.clearSelection();
      }
    },
    handleSelectionChange(val) {

      this.multipleSelection = val;
    },



    //添加配置文件
    addConfig() {

      this.tableData5 = [];
      this.configData = {};
      this.configMap.configMapName = ""
      this.configMap.configMapKey = ""
      this.configMap.path = ""
      this.configMap.volumesType = 2
      this.configMap.mountPath = ""
      this.configurePvcVisible = true;
    },

    stateFormat: function (row, column) {
      var date = row[column.property];
      if (date.length > 20) {
        return date.substr(0, 20) + "..."
      } else {
        return date
      }

    },



    //选中配置文件
    selectedPvc(data, data2) {

      this.pvcKey = data.dataList
      this.tableData5 = data.dataList;
    },
    //保存选中配置
    surePvcConfig() {
      var multipleArry = []
      for (var i = 0; i < this.multipleSelection.length; i++) {
        this.multipleSelection[i].configMapName = this.configData.name
        multipleArry[i] = {}
        multipleArry[i].name = this.configData.name
        if (this.multipleSelection[i].mountPath && this.multipleSelection[i].path) {
          if (this.multipleSelection[i].mountPath.startsWith("/")) {
            multipleArry[i].mountPath = this.multipleSelection[i].mountPath
          } else {
            multipleArry[i].mountPath = "/" + this.multipleSelection[i].mountPath
          }
        } else {
          //alert("挂载文件名称和挂载路径为必填项 ！！！")
          this.$message({
            message: "挂载文件名称和挂载路径为必填项 ！！！",
            type: "error"
          });
          return;
        }
        multipleArry[i].path = this.multipleSelection[i].path
        multipleArry[i].configMapKey = this.multipleSelection[i].name
        multipleArry[i].configMapName = this.configData.name
        multipleArry[i].volumesType = 2
        // this.multipleSelection[i].volumesType = 2
      };
      var checkArry = [];
      for (var j = 0; j < multipleArry.length; j++) {
        checkArry.push(multipleArry[j].mountPath)
      }
      var nary = checkArry.sort();
      for (var i = 0; i < checkArry.length; i++) {
        if (nary[i] == nary[i + 1]) {

          this.$message({
            message: "不可以挂载相同的路径 ！！",
            type: "error"
          });
          return;
        }
      }

      this.configArr = this.configArr.concat(multipleArry)
      this.configurePvcVisible = false;

    },

    //删除配置文件

    deleteConfig(portProperty) {

      var index = this.configArr.indexOf(portProperty);
      if (index !== -1) {
        this.configArr.splice(index, 1);
      }
    },
    //---------------------------------------------------------------访问设置----------------------------------------------------------

    Getport(index, row, rows){
      this.getcontinerPort();

    },
    GetservicePort(){
      this.getServicePort();
    },
    addcontainerData(index, row, rows) {

      if (JSON.stringify(row) != "{}") {
        if (!Number.isInteger(row.containerPort)) {
          this.$message({
            message: "输入数字类型 ！！",
            type: "error"
          });
        } else if (/^([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])$/.test(row.containerPort) == false) {
          this.$message({
            message: "不可以大于65535 ！！",
            type: "error"
          });
        } else {
          var copy = Object.assign({}, {});
          rows.splice(index + 1, 0, copy);
        }
      } else {
        this.$message({
          message: "请填写容器端口 ！！",
          type: "error"
        });
      }

    },

    delcontainerData(index, rows) {
      if (rows.length > 1) {
        rows.splice(index, 1);
      } else {
        this.containerData = [{}]
      }

    },


    addserviceData(index, row, rows) {

      if (JSON.stringify(row) != "{}") {
        if (!Number.isInteger(row.port)) {
          this.$message({
            message: "输入数字类型 ！！",
            type: "error"
          });
        } else if (/^([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])$/.test(row.port) == false) {
          this.$message({
            message: "不可以大于65535 ！！",
            type: "error"
          });
        } else {
          var copy = Object.assign({}, {});
          rows.splice(index + 1, 0, copy);
        }
      } else {
        this.$message({
          message: "请填写容器端口 ！！",
          type: "error"
        });
      }

    },
    delserviceData(index, rows) {
      if (rows.length > 1) {
        rows.splice(index, 1);
      } else {
        this.serviceAllPorts = [{}]
      }
    },
    addingressData(index, row, rows) {
      var copy = Object.assign({}, {});
      rows.splice(index + 1, 0, copy);
    },

    delingressData(index, rows) {
      if (rows.length > 1) {
        rows.splice(index, 1);
      } else {
        this.ingressList = [{}]
      }
    },


    //检查域名重复

    checkRegion(index, row, rows) {
      var id = ""
      if(rows[index].id){
        id = rows[index].id
      }else{
        id = ""
      }


      this.$http
        .get(
          "/cloud/ingress/checkExistThirdRegion?region=" +
          row.region +
          "&sourceType=" +
          row.sourceType +
          "&namespace=" +
          this.namespace + "&id=" + id
        )
        .then(res => {
           if(res.data.success){

           }else{
            this.$message({
              message:res.data.msg ,
              type: "error"
            });
            return;
           }
        });

    },
    //切换协议

    // changeProtocol(protocol) {
    //   if (protocol == "HTTP") {
    //     this.isHTTP = true;
    //   } else {
    //     this.isHTTP = false;
    //   }
    // },

    getcontinerPort() {
      
      var continerPort = [];
      if (this.containerData.length > 0) {
        for (var i = 0; i < this.containerData.length; i++) {
          continerPort.push(this.containerData[i].containerPort)
        }
      }
      this.conPort = continerPort;
    },


    getServicePort() {
      
      var allservicePort = [];

      if (this.serviceAllPorts.length > 0) {
        for (var i = 0; i < this.serviceAllPorts.length; i++) {
          allservicePort.push(this.serviceAllPorts[i].port)
        }
      }
      this.checkServicePort = allservicePort;
    },

    //-------------------------------------------------------保存应用----------------------------------------------------
    //去除大括号
    removeBlock(str) {
      if (str) {
        var reg = /^\{/gi;
        var reg2 = /\}$/gi;
        str = str.replace(reg, "");
        str = str.replace(reg2, "");
        return str;
      } else {
        return str;
      }
    },

    cleanAll() {

      this.applicationForm.name = "";
      this.applicationForm.labels = "";
      this.applicationForm.maxMemory = "";
      this.applicationForm.minMemory = "";
      this.applicationForm.maxCpu = "";
      this.applicationForm.minCpu = "";
      this.applicationForm.description = "";
      this.applicationForm.mirrorId = {};
      this.applicationForm.mirrorName = "";
      this.envForm.env = [{}];
      this.containerData = [{}];
      this.configArr = [];
      this.pvcForm.properties = [{}];
      this.pvcForm.pvcConfigdata = [{}];
      this.serviceAllPorts = [{}];
      this.ingressList = [{}];
      this.service.ports = [];
      this.isPush = false;
      this.leftResource = [];
      this.service.type = "";
      this.service.protocol = "TCP";
     // this.isIgruse = false;
    // this.saveSetting = false;
    },

    getAllData() {
      //获取镜像
      this.$http
        .get("/cloud/mirror/getMirrorLibrarys?pageNum=1" + "&pageSize=10")
        .then(res => {
          var mirrors = res.data.obj.result;
          var temp = [];
          for (var k in mirrors) {
            if (mirrors[k].approve == 2) {
              temp.push(mirrors[k]);
            }
          }
          this.mirror = temp;
        });

      //获取配置文件

      this.$http
        .get(
          "/cloud/Configmap/queryConfigmapByPage?projectId=" +
          this.projectId +
          "&pageNum=1" +
          "&pageSize=1000"
        )
        .then(res => {
          this.pvcConfigList = res.data.obj.result;
        });

         //获取剩余容量

      this.$http
      .get(
        "/cloud/app/queryLeftProjectCpuAndMemory?projectId=" + this.projectId
      )
      .then(res => {
        this.leftResource = res.data.obj;
      });
      

    },

    //创建应用
    createApplication() {
      this.cleanAll();

      this.isCreate = true;
      this.title = "创建应用";
      this.getAllData();
      //获取挂载卷
      this.$http
        .get(
          "/cloud/persistentVolume/queryPersistentVolumesByProjectId?projectId=" +
          this.projectId
        )
        .then(res => {
          if (res.data.success) {
            this.options = res.data.obj;
          } else {
           
          }
        });
      this.dialogCreateVisible = true;
      this.isEdit = false;
    },

    //确认创建应用
    suerCreatUser(applicationForm) {

      var sendObj = {
        name: "",
        namespace: "",
        maxMemory: "",
        minMemory: "",
        maxCpu: "",
        minCpu: "",
        mirrorId: "",
        imageurl: "",
        projectId: "",
        env: "",
        ports: "",
        devPvcList: [],
        description: "",
        service: {
          type: "",
          ports: "",
          ingressList: []
        },
        type: 1
      };

      (sendObj.name = this.applicationForm.name.trim()),
        (sendObj.namespace = this.namespace),
        (sendObj.projectId = this.projectId),
        // (sendObj.labels = this.applicationForm.labels),
        (sendObj.maxMemory = this.applicationForm.maxMemory),
        (sendObj.minMemory = this.applicationForm.minMemory),
        (sendObj.maxCpu = this.applicationForm.maxCpu),
        (sendObj.minCpu = this.applicationForm.minCpu),
        (sendObj.description = this.applicationForm.description),
        (sendObj.mirrorId = this.applicationForm.mirrorId.id),

        (sendObj.imageurl = this.applicationForm.mirrorId.address + "/" + this.applicationForm.mirrorName.trim())
      //组装 env
      var checknev = {
        env: []
      };
      //去除env 增加的空数据
      var envForArry = [];
      for (var i = 0; i < this.envForm.env.length; i++) {
        if (JSON.stringify(this.envForm.env[i]) != "{}") {
          envForArry.push(this.envForm.env[i])
        }
      }

      for (var i = 0; i < envForArry.length; i++) {

        if (/^[a-zA-Z][a-zA-Z\d\-\_]{1,30}[a-zA-Z0-9]$/.test(envForArry[i].name) == false) {
          this.$message({
            message: "环境变量名称不符合规范！！",
            type: "error"
          });
          return
        }
      }


      if (envForArry.length > 0) {
        checknev.env = envForArry;
      } else {
        checknev.env = [];
      }

      (sendObj.env = this.removeBlock(JSON.stringify(checknev)))
      //组装ports
      var checkports = {
        ports: []
      };

      //去除ports  中的空数据
      var checkPortArry = [];
      for (var i = 0; i < this.containerData.length; i++) {
        if (JSON.stringify(this.containerData[i]) != "{}") {
          checkPortArry.push(this.containerData[i])
        }
      }
      for (var i = 0; i < checkPortArry.length; i++) {
        if (!Number.isInteger(checkPortArry[i].containerPort)) {
          this.$message({
            message: "容器端口为数字类型 ！！",
            type: "error"
          });
          return;
        } else if (/^([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])$/.test(checkPortArry[i].containerPort) == false) {
          this.$message({
            message: "容器端口不可以大于65535 ！！",
            type: "error"
          });
          return
        }
      }
      checkports.ports = checkPortArry;

      (sendObj.ports = this.removeBlock(JSON.stringify(checkports)))
      var Assemble = []
      for (var i = 0; i < this.pvcForm.properties.length; i++) {
        Assemble[i] = {}
        if (this.pvcForm.properties[i].data) {
          Assemble[i].pvcId = this.pvcForm.properties[i].data.id;
          Assemble[i].name = this.pvcForm.properties[i].data.name;
          Assemble[i].mountPath = this.pvcForm.properties[i].mountPath
        }
      }
      //去除挂载卷的空数据

      var pvcArry = [];
      for (var i = 0; i < Assemble.length; i++) {
        if (JSON.stringify(Assemble[i]) != '{}') {
          pvcArry.push(Assemble[i])
        }
      }
      //判断相同路径
      var samePath = [];
      if (pvcArry.length > 0) {
        samePath = pvcArry.concat(this.configArr)
      } else {
        
        samePath = this.configArr
      }
      var allMountPath = [];
      for (var j = 0; j < samePath.length; j++) {
        allMountPath.push(samePath[j].mountPath)
      }
      var resetArry = allMountPath.sort();
      for (var i = 0; i < allMountPath.length - 1; i++) {
        if (resetArry[i] == resetArry[i + 1]) {
          this.$message({
            message: "不可以挂载相同的路径 ！！",
            type: "error"
          });
          return;
        }
      }
      sendObj.devPvcList = samePath;
      if (this.isPush == true) {
        sendObj.type = 2;
        sendObj.service.type = this.service.type;
        //组装service Ports
        var serviceports = {
          ports: []
        };
        //去除serviceports  中的空数据
        var servicePortArry = [];
        for (var i = 0; i < this.serviceAllPorts.length; i++) {
          if (JSON.stringify(this.serviceAllPorts[i]) != "{}") {
            servicePortArry.push(this.serviceAllPorts[i])
          }
        }

        //给serviceport增加name
        if (servicePortArry.length > 0) {
          for (var i = 0; i < servicePortArry.length; i++) {
            servicePortArry[i].name = servicePortArry[i].protocol.toLowerCase() + "-" + servicePortArry[i].port
            if (!Number.isInteger(servicePortArry[i].port)) {
              this.$message({
                message: "服务端口为数字类型 ！！",
                type: "error"
              });
              return;
            } else if (/^([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])$/.test(servicePortArry[i].port) == false) {
              this.$message({
                message: "服务端口不可以大于65535 ！！",
                type: "error"
              });
              return
            }
          }
        }
        serviceports.ports = servicePortArry;
        sendObj.service.ports = this.removeBlock(JSON.stringify(serviceports));
        //拼ingressList
        //去除ingressLis的空数据
        var ingressArry = [];
        for (var i = 0; i < this.ingressList.length; i++) {
          if (JSON.stringify(this.ingressList[i]) != '{}') {
            ingressArry.push(this.ingressList[i])
          }
        }
        //组装值
        for (var j = 0; j < ingressArry.length; j++) {

          if (ingressArry[j].isShowSubdomain) {
            ingressArry[j].isShowSubdomain = 1
          } else {
            ingressArry[j].isShowSubdomain = 0
          }
          if(ingressArry[j].path){
            if (ingressArry[j].path.startsWith("/")) {
              ingressArry[j].path = ingressArry[j].path
            } else {
              ingressArry[j].path = "/" + ingressArry[j].path
            }
          }else{
            this.$message({
              message: "输入路径 ！",
              type: "error"
            });
            return
          }
        }
        //域名校验
        if (ingressArry.length > 0) {
          for (var i = 0; i < ingressArry.length; i++) {
            if (ingressArry[i].sourceType == 2) {
              if (/^([a-zA-Z\d][a-zA-Z\d-_]+\.)+[a-zA-Z\d-_][^ ]*$/.test(ingressArry[i].region) == false) {
                this.$message({
                  message: "请输入正确的域名！！",
                  type: "error"
                });
                return
              }
            }
          }
        }
        var allserviceregion = [];
        for (var j = 0; j < ingressArry.length; j++) {
          allserviceregion.push(ingressArry[j].region)
        }
        var resetregionArry = allserviceregion.sort();
        for (var i = 0; i < allserviceregion.length - 1; i++) {
          if (resetregionArry[i] == resetregionArry[i + 1]) {
            this.$message({
              message: "域名不可以重复 ！！",
              type: "error"
            });
            return;
          }
        }

        if(ingressArry.length > 0){
          sendObj.service.ingressList = ingressArry
        }else{
          sendObj.service.ingressList = [];
        }
        this.$refs.service.validate(valid => {
          if (valid) {
            this.$refs.applicationForm.validate(valid => {
              if (valid) {
                // console.log(sendObj);
                this.$http
                  .post("/cloud/app/deploymentCreate", sendObj)
                  .then(res => {
                    if (res.data.success) {
                      this.$message({
                        message: res.data.msg,
                        type: "success"
                      });
                      this.dialogCreateVisible = false;
                      this.getList();
                    } else {
                      this.$message({
                        message: res.data.msg,
                        type: "error"
                      });
                    }
                  });
              } else {
                return false;
              }
            });
          } else {
            return false;
          }
        });
      } else {
        sendObj.service.ingressList = [];
        this.$refs.applicationForm.validate(valid => {
          if (valid) {
            this.$http
              .post("/cloud/app/deploymentCreate", sendObj)
              .then(res => {
                if (res.data.success) {
                  this.$message({
                    message: res.data.msg,
                    type: "success"
                  });
                  this.dialogCreateVisible = false;
                  this.getList();
                } else {
                  this.$message({
                    message: res.data.msg,
                    type: "error"
                  });
                }
              });
          } else {
            return false;
          }
        });
      }
    },



    //切换访问类型


    //------------------------------------------------------------------------删除应用---------------------------------------------------------

    //删除应用

    deleUser(row) {
      this.$confirm("此操作将永久删除应用, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.$http
            .get("/cloud/app/deploymentDelete?id=" + row.id)
            .then(res => {
              if (res.data.success) {
                this.$message({
                  message: res.data.msg,
                  type: "success"
                });
                this.getList();
              } else {
                this.$message({
                  message: res.data.msg,
                  type: "error"
                });
              }
            });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },
    //------------------------------------------------------------------------------编辑应用--------------------------------------------------------------------------

    editpvcConfig(row) {
      this.configurePvcVisible = true;
    },

    editProject(row) {
      debugger;

      this.title = "编辑应用";
      this.cleanAll();
      this.applicationId = row.id;
      this.isCreate = false;
      this.applicationForm.name = row.name;
      this.applicationForm.labels = row.labels;
      this.applicationForm.maxMemory = row.maxMemory;
      this.applicationForm.minMemory = row.minMemory;
      this.applicationForm.maxCpu = row.maxCpu;
      this.applicationForm.minCpu = row.minCpu;
      this.applicationForm.description = row.description;
      this.applicationForm.mirrorId.id = row.mirrorId;
      var index = row.imageurl.lastIndexOf("/");
      this.applicationForm.mirrorName = row.imageurl.substring(
        index + 1,
        row.imageurl.length
      );

      this.applicationForm.mirrorId.address = row.imageurl.substring(0, index);
      //回显env
      var ss = "{" + row.env + "}";

      if (JSON.parse(ss).env.length == 0) {
        this.envForm.env = [{}]
      } else {
        this.envForm.env = JSON.parse(ss).env;
      }
      //回显ports

      var sendPort = "{" + row.ports + "}";
      if (JSON.parse(sendPort).ports.length > 0) {
        this.containerData = JSON.parse(sendPort).ports;
      } else {
        this.containerData = [{}];
      }

      //回显pvclist

      if (row.devPvcList && row.devPvcList.length > 0) {
        var assmData = [];
        for (var i = 0; i < row.devPvcList.length; i++) {

          if (row.devPvcList[i].volumesType == 1) {
            this.pvcForm.properties = [];
            assmData.push(row.devPvcList[i]);

          } else if (row.devPvcList[i].volumesType == 2) {
            this.configArr.push(row.devPvcList[i])
          }
        }
        if (assmData.length > 0) {
          for (var i = 0; i < assmData.length; i++) {
            var assmObject = {}
            var asmObj = {}
            asmObj.name = assmData[i].name
            asmObj.id = assmData[i].pvcId
            var pvcmountPath = assmData[i].mountPath
            assmObject.data = asmObj;
            assmObject.mountPath = pvcmountPath
            this.pvcForm.properties.push(assmObject)
          }
        } else {
          this.pvcForm.properties = [{}];
        }
      } else {
        this.pvcForm.properties = [{}];
      }

      if (row.type == 2) {
        this.isPush = true;
        this.service.type = row.service.type;
        var servicePort = "{" + row.service.ports + "}";

        if (JSON.parse(servicePort).ports == 0) {
          this.serviceAllPorts = [{}]
        } else {
          this.serviceAllPorts = JSON.parse(servicePort).ports
        }
        var getIngress
        if(row.service.ingressList){
          getIngress = row.service.ingressList;
        }else{
          getIngress =[];
        }
        
        if (getIngress.length == 0) {
          this.ingressList = [{}]
        } else {
          var changeshow = [];
          for (var i = 0; i < getIngress.length; i++) {
            if (getIngress[i].isShowSubdomain == 1) {
              getIngress[i].isShowSubdomain = true
            } else {
              getIngress[i].isShowSubdomain = false
            }

            changeshow.push(getIngress[i])

          }
          this.ingressList = changeshow
        }
      }


      this.getAllData();
      //获取挂载卷
      this.$http
        .get(
          "/cloud/persistentVolume/queryPersistentVolumesByProjectId?projectId=" +
          this.projectId + "&deploymentId=" + row.id
        )
        .then(res => {
          if (res.data.success) {
            this.options = res.data.obj;
          } 
        });
      this.isEdit = true;
      this.dialogCreateVisible = true;
    },
    //确认编辑
    suerEdit() {
debugger;
      var sendObj = {
        id: this.applicationId,
        name: "",
        namespace: "",
        maxMemory: "",
        minMemory: "",
        maxCpu: "",
        minCpu: "",
        mirrorId: "",
        imageurl: "",
        projectId: "",
        env: "",
        ports: "",
        devPvcList: [],
        description: "",
        service: {
          type: "",
          ports: "",
          ingressList: []
        },
        type: 1
      };

      (sendObj.name = this.applicationForm.name.trim()),
        (sendObj.namespace = this.namespace),
        (sendObj.projectId = this.projectId),
        // (sendObj.labels = this.applicationForm.labels),
        (sendObj.maxMemory = this.applicationForm.maxMemory),
        (sendObj.minMemory = this.applicationForm.minMemory),
        (sendObj.maxCpu = this.applicationForm.maxCpu),
        (sendObj.minCpu = this.applicationForm.minCpu),
        (sendObj.description = this.applicationForm.description),
        (sendObj.mirrorId = this.applicationForm.mirrorId.id),
        (sendObj.imageurl = this.applicationForm.mirrorId.address + "/" + this.applicationForm.mirrorName.trim())
      //组装 env
      var checknev = {
        env: []
      };
      //去除env 增加的空数据
      var envForArry = [];
      for (var i = 0; i < this.envForm.env.length; i++) {
        if (JSON.stringify(this.envForm.env[i]) != "{}") {
          envForArry.push(this.envForm.env[i])
        }
      }

      for (var i = 0; i < envForArry.length; i++) {

        if (/^[a-z][a-z\d\-]{1,30}[a-z0-9]$/.test(envForArry[i].name) == false) {
          this.$message({
            message: "环境变量名称不符合规范！！",
            type: "error"
          });
          return
        }
      }
      if (envForArry.length > 0) {
        checknev.env = envForArry;
      } else {
        checknev.env = [];
      }


      (sendObj.env = this.removeBlock(JSON.stringify(checknev)))
      //组装ports
      var checkports = {
        ports: []
      };

      //去除ports  中的空数据
      var checkPortArry = [];
      for (var i = 0; i < this.containerData.length; i++) {
        if (JSON.stringify(this.containerData[i]) != "{}") {
          checkPortArry.push(this.containerData[i])
        }
      }

      for (var i = 0; i < checkPortArry.length; i++) {
        if (!Number.isInteger(checkPortArry[i].containerPort)) {
          this.$message({
            message: "容器端口为数字类型 ！！",
            type: "error"
          });
          return;
        } else if (/^([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])$/.test(checkPortArry[i].containerPort) == false) {
          this.$message({
            message: "容器端口不可以大于65535 ！！",
            type: "error"
          });
          return
        }
      }

      checkports.ports = checkPortArry;
      (sendObj.ports = this.removeBlock(JSON.stringify(checkports)))


      var Assemble = []
      for (var i = 0; i < this.pvcForm.properties.length; i++) {
        Assemble[i] = {}
        if (this.pvcForm.properties[i].data) {
          Assemble[i].pvcId = this.pvcForm.properties[i].data.id;
          Assemble[i].name = this.pvcForm.properties[i].data.name;
          Assemble[i].mountPath = this.pvcForm.properties[i].mountPath
        }

      }
      //去除挂载卷的空数据

      var pvcArry = [];

      for (var i = 0; i < Assemble.length; i++) {
        if (JSON.stringify(Assemble[i]) != '{}') {
          pvcArry.push(Assemble[i])
        }
      }

      //判断相同路径
      var samePath = [];
      if (pvcArry.length > 0) {
        samePath = pvcArry.concat(this.configArr)
        // sendObj.devPvcList = pvcArry.concat(this.configArr)
      } else {
        //sendObj.devPvcList = this.configArr
        samePath = this.configArr
      }
      var allMountPath = [];
      for (var j = 0; j < samePath.length; j++) {
        allMountPath.push(samePath[j].mountPath)
      }

      var resetArry = allMountPath.sort();
      for (var i = 0; i < allMountPath.length - 1; i++) {
        if (resetArry[i] == resetArry[i + 1]) {

          this.$message({
            message: "不可以挂载相同的路径 ！！",
            type: "error"
          });
          return;
        }
      }
      sendObj.devPvcList = samePath;


      if (this.isPush == true) {
        sendObj.type = 2;
        sendObj.service.type = this.service.type;
        var serviceports = {
          ports: []
        };

        //去除serviceports  中的空数据
        var servicePortArry = [];
        for (var i = 0; i < this.serviceAllPorts.length; i++) {
          if (JSON.stringify(this.serviceAllPorts[i]) != "{}") {
            servicePortArry.push(this.serviceAllPorts[i])
          }
        }

        //给serviceport增加name
        if (servicePortArry.length > 0) {
          for (var i = 0; i < servicePortArry.length; i++) {
            servicePortArry[i].name = servicePortArry[i].protocol.toLowerCase() + "-" + servicePortArry[i].port
            if (!Number.isInteger(servicePortArry[i].port)) {
              this.$message({
                message: "服务端口为数字类型 ！！",
                type: "error"
              });
              return;
            } else if (/^([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])$/.test(servicePortArry[i].port) == false) {
              this.$message({
                message: "服务端口不可以大于65535 ！！",
                type: "error"
              });
              return
            }
          }
        }
        serviceports.ports = servicePortArry;
        sendObj.service.ports = this.removeBlock(JSON.stringify(serviceports));
        //拼ingressList
        //去除ingressLis的空数据
        var ingressArry = [];
        for (var i = 0; i < this.ingressList.length; i++) {
          if (JSON.stringify(this.ingressList[i]) != '{}') {
            ingressArry.push(this.ingressList[i])
          }
        }
        //组装值
        for (var j = 0; j < ingressArry.length; j++) {

          if (ingressArry[j].isShowSubdomain) {
            ingressArry[j].isShowSubdomain = 1
          } else {
            ingressArry[j].isShowSubdomain = 0
          }
          if(ingressArry[j].path){
            if (ingressArry[j].path.startsWith("/")) {
              ingressArry[j].path = ingressArry[j].path
            } else {
              ingressArry[j].path = "/" + ingressArry[j].path
            }
          }else{
            this.$message({
              message: "输入路径 ！",
              type: "error"
            });
            return
          }
         
        }


        var allserviceregion = [];
        for (var j = 0; j < ingressArry.length; j++) {
          allserviceregion.push(ingressArry[j].region)
        }

        var resetregionArry = allserviceregion.sort();
        for (var i = 0; i < allserviceregion.length - 1; i++) {
          if (resetregionArry[i] == resetregionArry[i + 1]) {
            this.$message({
              message: "域名不可以重复 ！！",
              type: "error"
            });
            return;
          }
        }

        
        if(ingressArry.length > 0){
          sendObj.service.ingressList = ingressArry
        }else{
          sendObj.service.ingressList = [];
        }

        // this.$refs.service.validate(valid => {
        //   if (valid) {
            this.$refs.applicationForm.validate(valid => {
              if (valid) {
                // console.log(sendObj);
                this.$http.post("/cloud/app/deploymentUpdate", sendObj).then(res => {
                  if (res.data.success) {
                    this.$message({
                      message: res.data.msg,
                      type: "success"
                    });
                    this.dialogCreateVisible = false;
                    this.getList();
                  } else {
                    this.$message({
                      message: res.data.msg,
                      type: "error"
                    });
                  }
                });
              } else {
                return false;
              }
            });
          // } else {
          //   return false;
          // }
        // });
      } else {
        sendObj.service.ingressList = [];
        this.$refs.applicationForm.validate(valid => {
          if (valid) {
            this.$http.post("/cloud/app/deploymentUpdate", sendObj).then(res => {
              if (res.data.success) {
                this.$message({
                  message: res.data.msg,
                  type: "success"
                });
                this.dialogCreateVisible = false;
                this.getList();
              } else {
                this.$message({
                  message: res.data.msg,
                  type: "error"
                });
              }
            });;
          } else {
            return false;
          }
        });
      }


    },


    //关闭
    closedModel() {
      this.dialogCreateVisible = false;
      this.getList();
    },
    //查看详情
    detail(row) {
      sessionStorage.setItem("id", row.id);
      sessionStorage.setItem("name", row.name);
      this.$router.push({
        name: "applicationDetail",
        query: { id: row.id, name: row.name }
      });
    },

    handleClick(tab, event) {
      console.log(tab, event);
    }
  },

  watch: {
    $route(currentState, oldState) {
      if (currentState.fullPath.startsWith("/tenantProject")) {
        this.projectId = sessionStorage.getItem("projectId");
        this.getList();
      } else {
        sessionStorage.setItem("showNumber", 3);
      }
    },

    containerData: function (oldValue, newValue) {
      if (newValue) {
        this.getcontinerPort();
      } else {
      }
    },
    serviceAllPorts: function (oldValue, newValue) {
      if (newValue) {
        this.getServicePort();
      } else {
      }
    }
  }
};