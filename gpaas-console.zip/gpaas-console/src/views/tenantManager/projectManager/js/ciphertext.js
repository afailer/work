export default{
    name: "complexTable",
    data(){
        return {
            show:false,
            ciphertext:"",
        }
    },
    methods:{
        showCipher(){
            this.$http.get("/cloud/userToken/getToken")
            .then(res=>{
                if(res.data.success){
                    this.ciphertext=res.data.obj;
                    this.show=!this.show;
                }else{
                    this.$message({
                        message: res.data.msg,
                        type: "error"
                    });
                }
            })
        }
    }
}