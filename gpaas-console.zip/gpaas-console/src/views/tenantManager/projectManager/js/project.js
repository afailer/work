import { mapState, mapActions } from "vuex";

export default {
  name: "complexTable",

  data() {
    var name=(rule,value,callback)=>{
      if(/^[a-zA-Z][a-zA-Z0-9]{1,19}$/.test(value)==false){
        callback(new Error("项目名不符合规范"));
      }else{
        callback();
      }
    };
    return {
      //创建项目
      careatProgectForm: {
        name: "",
        cpu: "",
        memory: "",
        storageSize: "",
        // mirrorId: "",
        description:""
      },
      data:[1,2,3,4,5],
      leftResource:[],
      rules: {
          name: [
            { validator:name, trigger: 'blur' },
          ],
          cpu: [
            { required: true, message: '请输入cpu总量', trigger: 'blur' },
             { type: 'number', message: '请输入数字类型', transform: value => +value },
          ],


          memory: [
            { required: true, message: '请输入内存总量', trigger: 'blur' },
             { type: 'number', message: '请输入数字类型',transform: value => +value  }
          ],
           storageSize: [
            { required: true, message: '请输入硬盘总量', trigger: 'blur' },
             { type: 'number', message: '请输入数字类型', transform: value => +value  }
          ],
         
          // mirrorId: [
          //   { required: true, message: '请至少选择一个镜像', trigger: 'change' }
          //],
         
        },
      mirror:"",
      isEdit: false,
      title:"创建项目",
      currentPage: 1,
      projectData: [],
      tableKey: 0,
      total: null,
      pageSize: 10,
      listLoading: true,
      listQuery: {
        title: undefined
      },
      //创建用户
      dialogCreateVisible: false
    };
  },

  computed:{
     ...mapState([
      "projectId", //  数据
      "namespace",
    
    ]),
  },

  filters: {
    statesFilters: function(value) {
      return value + "G";
    },
    cpuFilters: function(value) {
      return value + "核";
    },
    memoryFilters: function(value) {
      return value + "G";
    },

    subsFiter:function(value){
      return Math.round(value*100)/100
    },

    // formatDatetwo: function(timestamp) {
      
    //   var date = new Date(timestamp); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
    //     var Y = date.getFullYear() + "-";
    //     var M =
    //       (date.getMonth() + 1 < 10
    //         ? "0" + (date.getMonth() + 1)
    //         : date.getMonth() + 1) + "-";
    //     var D = date.getDate() + " ";
    //     var h = date.getHours() + ":";
    //     var m = date.getMinutes() + ":";
    //     var s = date.getSeconds();
    //     return Y + M + D + h + m + s;
    //   // var re = /-?\d+/;
    //   // var m = re.exec(time);
    //   // var d = new Date(parseInt(m[0]));
    //   // var o = {
    //   //   "M+": d.getMonth() + 1, //month
    //   //   "d+": d.getDate(), //day
    //   //   "h+": d.getHours(), //hour
    //   //   "m+": d.getMinutes(), //minute
    //   //   "s+": d.getSeconds(), //second
    //   //   "q+": Math.floor((d.getMonth() + 3) / 3), //quarter
    //   //   S: d.getMilliseconds() //millisecond
    //   // };
    //   // var format = "yyyy-MM-dd";
    //   // if (/(y+)/.test(format)) {
    //   //   format = format.replace(
    //   //     RegExp.$1,
    //   //     (d.getFullYear() + "").substr(4 - RegExp.$1.length)
    //   //   );
    //   // }
    //   // for (var k in o) {
    //   //   if (new RegExp("(" + k + ")").test(format)) {
    //   //     format = format.replace(
    //   //       RegExp.$1,
    //   //       RegExp.$1.length == 1
    //   //         ? o[k]
    //   //         : ("00" + o[k]).substr(("" + o[k]).length)
    //   //     );
    //   //   }
    //   // }
    //   // return format;
    // },

    formatDatetwo: function(time) {
      var re = /-?\d+/;
      var m = re.exec(time);
      var d = new Date(parseInt(m[0]));
      var o = {
        "M+": d.getMonth() + 1, //month
        "d+": d.getDate(), //day
        "h+": d.getHours(), //hour
        "m+": d.getMinutes(), //minute
        "s+": d.getSeconds(), //second
        "q+": Math.floor((d.getMonth() + 3) / 3), //quarter
        S: d.getMilliseconds() //millisecond
      };
      var format = "yyyy-MM-dd hh:mm:ss";
      if (/(y+)/.test(format)) {
        format = format.replace(
          RegExp.$1,
          (d.getFullYear() + "").substr(4 - RegExp.$1.length)
        );
      }
      for (var k in o) {
        if (new RegExp("(" + k + ")").test(format)) {
          format = format.replace(
            RegExp.$1,
            RegExp.$1.length == 1
              ? o[k]
              : ("00" + o[k]).substr(("" + o[k]).length)
          );
        }
      }
      return format;
    },
    
    stateFilter: function(value){
      switch( value ){
        case 0 :
          return '创建失败';
          break;
        case 1 :
          return '创建成功';
          break;
        case 2 :
          return '命名空间创建成功';
          break;
        case 3 :
          return 'secrets创建成功';
          break;
      }
    },
  },
  created() {
    this.getList();
    this.leftRes();
  },
  methods: {
    ...mapActions([
      "changeProjectId",
      "changeNameSpace",
     
    ]),



    getList() {
      this.$http
        .get(
          "/cloud/project/queryCurrentUserProjectList?pageNum=" +
            this.currentPage +
            "&pageSize=" +
            this.pageSize +
            ""
        )
        .then(res => {
          this.total = res.data.obj.totalCount;
          this.projectData = res.data.obj.result;
        });
    },

    //剩余资源
    leftRes(){
      this.$http.get(
        "/cloud/project/queryLeftNode"
      ).then(res=>{
        this.leftResource=res.data.obj;
      })
    },

    openCreate() {},
    handleFilter() {},
    handleSizeChange(val) {
      this.pageSize = val;
      this.getList();
    },

    //分页查询
    handleCurrentChange(val) {
      this.currentPage = val;
      this.getList();
    },
    handleModifyStatus(row, status) {},
    resetTemp() {
      this.temp = {
        id: undefined,
        importance: 1,
        remark: "",
        timestamp: new Date(),
        title: "",
        status: "通过",
        type: ""
      };
    },
    //创建用户

    createProject() {

      this.title = "创建项目"
      //创建用户
      this.careatProgectForm.name = "";
      this.careatProgectForm.memory = "";
      this.careatProgectForm.cpu = "";
      this.careatProgectForm.storageSize = "";
      // this.careatProgectForm.mirrorId = "";
      this.careatProgectForm.description = "";

      this.$http
        .get(
          "/cloud/mirror/getMirrorLibrarys?pageNum=1"+ "&pageSize=10" 
           
        )
        .then(res => {
         
          this.mirror = res.data.obj.result;
        });
     

      this.dialogCreateVisible = true;
      this.isEdit = false;
    },

    //确认创建项目
    suerCreatUser(formName) {
      
       this.$refs[formName].validate((valid) => {
          if (valid) {
            
                    
            this.$http
              .post("/cloud/project/addProject", this.careatProgectForm)
              .then(res => {
                if (res.data.success) {
                  this.$message({
                    message: res.data.msg,
                    type: "success"
                  });
                  this.dialogCreateVisible = false;
                  this.getList();
                  this.leftRes();
                } else {
                  this.$message({
                    message: res.data.msg,
                    type: "error"
                  });
                }
              });

          } else {
            console.log('error submit!!');
            return false;
          }
        });
    },

    //删除项目

    deleUser(row) {
      this.$confirm("此操作将永久删除项目, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.$http
            .get("/cloud/project/deleteProject?id=" + row.id)
            .then(res => {
              if (res.data.success) {
                this.$message({
                  message: res.data.msg,
                  type: "success"
                });
                this.getList();
                this.leftRes();
              } else {
                this.$message({
                  message: "请先删除项目下的：" +  "应用数量：" + res.data.obj.appdeployment + 
                   "  绑定实例 ：" + res.data.obj.servicebind + 
                   "  存储卷数量：" + res.data.obj.storagepvc + 
                   "  实例数量：" + res.data.obj.serviceinstance +
                   "  配置数量：" + res.data.obj.appconfigmap  ,
                  type: "error",
                  duration:3000,
                  
                });
              }
            });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },

    //编辑用户

    editProject(row) {
      this.isEdit = true;
      this.title = "编辑项目"

        //清空数据
        this.careatProgectForm.name = "";
        this.careatProgectForm.memory = "";
        this.careatProgectForm.cpu = "";
        this.careatProgectForm.storageSize = "";
        this.careatProgectForm.mirrorId = "";
        this.careatProgectForm.description = "";
      //根据ID 查询镜像库详细信息
      this.$http
        .get("/cloud/project/queryProjectById?id=" + row.id)
        .then(res => {
          this.careatProgectForm = res.data.obj;
        });

          this.$http
        .get(
          "/cloud/mirror/getMirrorLibrarys?pageNum=1"+ "&pageSize=10" 
           
        )
        .then(res => {
         
          this.mirror = res.data.obj.result;
        });
     

      this.dialogCreateVisible = true;
    },
    //确认编辑
    suerEdit() {
      this.$http
        .post("/cloud/project/updateProject", this.careatProgectForm)
        .then(res => {
          if (res.data.success) {
            this.$message({
              message: res.data.msg,
              type: "success"
            });
            this.dialogCreateVisible = false;
            this.getList();
            this.leftRes();
          } else {
            this.$message({
              message: res.data.msg,
              type: "error"
            });
          }
        });
    },

    //进入控制台

    goConsole(row){
      // this.changeProjectId(row.id),
      // this.changeNameSpace(row.namespace),
       sessionStorage.setItem("projectId", row.id);
       sessionStorage.setItem("namespace", row.namespace);

      this.$router.push({
          name: "tenantAppliction",
          query: { projectId: row.id,namespace:row.namespace }
        });
      
    }
  },
  
};