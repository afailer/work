import { mapGetters } from "vuex";

export default {
  name: "complexTable",

  data() {
    var port = (rule, value, callback) => {
      if (
        /^([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])$/.test(
          value
        ) == false
      ) {
        callback(new Error("端口号不能大于65535"));
      } else {
        callback();
      }
    };
    return {
      //创建项目
      applicationForm: {
        name: "",
        maxCpu: "",
        minCpu: "",
        maxMemory: "",
        minMemory: "",
        labels: "",
        mirrorId: "",
        mirrorName: "",
        description: ""
      },
      isService: false,
      isFull: true,
      title: "",
      envForm: {
        //环境变量配置
        env: [],
        newEnv: {
          name: "",
          value: ""
        },
        ports: [],
        newports: {
          port: "",
          targetPort: "",
          protocol: "TCP",
          name: ""
        },
        senPorts: []
      },
      isPorts: false, //是否设置端口
      isPVC: false, //挂载
      isChoice: false, //
      isCanChoice: false, //是否可以选择挂载卷
      pvcForm: {
        properties: [],
        newProperty: {
          mountPath: ""
        }
      },

      isPush: false, //是否发布为应用
      isName: false, //
      serviceProtocol: "", //选择是TCP  或者HTTP
      showProtocol: false, //是否选择平台外
      choiceHttp: false, //是否选择http
      saveSetting: false, //保存你的设置

      newRules: [
        {
          http: {
            paths: [
              {
                backend: {
                  serviceName: "",
                  servicePort: ""
                },
                path: ""
              }
            ]
          }
        }
      ],
      service: {
        port: "",
        targetPort: "",
        type: "",
        protocol: "TCP"
      },
      applicationId: "",
      options: [],
      devPvcList: {}, //选中的挂在卷
      savedevPvcList: [], //存储选中的挂在卷
      count: 0,
      mirror: "",
      isEdit: false,
      currentPage: 1,
      projectData: [],
      tableKey: 0,
      total: null,
      pageSize: 10,
      listLoading: true,
      listQuery: {
        title: undefined
      },
      //创建应用
      dialogCreateVisible: false,
      //创建应用
      isCreate: true,

      //剩余容量
      leftResource: [],

      //表单验证
      rules: {
        name: [{ validator: name, trigger: "blur" }],
        // labels: [{ required: true, message: "请填写标签", trigger: "blur" }],
        maxCpu: [
          {
            required: true,
            type: "number",
            message: "请填写数字",
            trigger: "blur"
          }
        ],
        minCpu: [
          {
            required: true,
            type: "number",
            message: "请填写数字",
            trigger: "blur"
          }
        ],
        maxMemory: [
          {
            required: true,
            type: "number",
            message: "请填写数字",
            trigger: "blur"
          }
        ],
        minMemory: [
          {
            required: true,
            type: "number",
            message: "请填写数字",
            trigger: "blur"
          }
        ],
        mirrorId: [
          { required: true, message: "请选择镜像库", trigger: "change" }
        ],
        mirrorName: [
          { required: true, message: "请输入镜像名称", trigger: "blur" }
        ]
      },
      rules1: {
        port: [{ validator: port, trigger: "blur" }],
        targetPort: [{ validator: port, trigger: "blur" }],
        protocol: [
          { required: true, message: "请选择协议", trigger: "change" }
        ],
        type: [{ required: true, message: "请选择类型", trigger: "change" }]
      },

      projectId: sessionStorage.getItem("projectId"),
      namespace: sessionStorage.getItem("namespace"),
      activeName: 'first',
      //配置文件
      configureDialogVisible: false,
    };
  },

  filters: {
    statesFilters: function(value) {
      return value + "M";
    },
    memoryFilters: function(value) {
      return value + "G";
    },

    subsFiter: function(value) {
      return Math.round(value * 100) / 100;
    },

    longFilters: function(value) {
      if (value != null && value.length > 0) {
        return "是";
      } else {
        return "否";
      }
    },

    formatDatetwo: function(time) {
      var re = /-?\d+/;
      var m = re.exec(time);
      var d = new Date(parseInt(m[0]));
      var o = {
        "M+": d.getMonth() + 1, //month
        "d+": d.getDate(), //day
        "h+": d.getHours(), //hour
        "m+": d.getMinutes(), //minute
        "s+": d.getSeconds(), //second
        "q+": Math.floor((d.getMonth() + 3) / 3), //quarter
        S: d.getMilliseconds() //millisecond
      };
      var format = "yyyy-MM-dd";
      if (/(y+)/.test(format)) {
        format = format.replace(
          RegExp.$1,
          (d.getFullYear() + "").substr(4 - RegExp.$1.length)
        );
      }
      for (var k in o) {
        if (new RegExp("(" + k + ")").test(format)) {
          format = format.replace(
            RegExp.$1,
            RegExp.$1.length == 1
              ? o[k]
              : ("00" + o[k]).substr(("" + o[k]).length)
          );
        }
      }
      return format;
    }
  },

  computed: {
    addPvcDisabled: function() {
      if (this.isEmpty(this.pvcForm.newProperty.mountPath)) {
        return true;
      }
      return false;
    },
    addEnvDisabled: function() {
      if (this.isEmpty(this.envForm.newEnv.name)) {
        return true;
      }
      if (this.isEmpty(this.envForm.newEnv.value)) {
        return true;
      }
      return false;
    },
    addPortDisabled: function() {
      if (this.isEmpty(this.envForm.newports.port)) {
        return true;
      }
      if (this.isEmpty(this.envForm.newports.targetPort)) {
        return true;
      }
      if (this.isEmpty(this.envForm.newports.protocol)) {
        return true;
      }
      if (this.isEmpty(this.envForm.newports.name)) {
        return true;
      }
      return false;
    }
  },
  created() {
    this.getList();
  },
  methods: {
    getList() {
      this.$http
        .get(
          "/cloud/app/appGetItemList?pageNum=" +
            this.currentPage +
            "&pageSize=" +
            this.pageSize +
            "&projectId=" +
            this.projectId
        )
        .then(res => {
          this.total = res.data.obj.totalCount;
          this.projectData = res.data.obj.result;
        });
    },



   
    //保存环境变量配置
    saveEnv() {
      var envProperty = this.deepClone(this.envForm.newEnv);
      this.envForm.newEnv.name = "";
      this.envForm.newEnv.value = "";
      this.envForm.env.push(envProperty);
    },

    //删除环境变量
    delEnv(property) {
      var index = this.envForm.env.indexOf(property);
      if (index !== -1) {
        this.envForm.env.splice(index, 1);
      }
    },

    addEnv(index, row, rows) {
      var copy = Object.assign({}, {});
      rows.splice(index + 1, 0, copy);
    },
    deleteEnv(index, rows) {
      if(index == 0){
        return;
      }else{
        rows.splice(index, 1);
      }
      
    },

    //保存ports

    savePorts() {
      this.saveSetting = false;
      var portProperty = this.deepClone(this.envForm.newports);
      var senportProperty = {
        containerPort: "",
        protocol: ""
      };
      senportProperty.containerPort = portProperty.port;
      senportProperty.protocol = portProperty.protocol;
      this.envForm.newports.port = "";
      this.envForm.newports.targetPort = "";
      this.envForm.newports.protocol = "";
      this.envForm.newports.name = "";
      this.envForm.ports.push(portProperty);

      if (this.envForm.ports.length > 0) {
        this.isName = true;
      }
      this.envForm.senPorts.push(senportProperty);
    },
    //删除ports
    deletePorts(portProperty) {
      var index = this.envForm.ports.indexOf(portProperty);
      if (index !== -1) {
        this.envForm.ports.splice(index, 1);
        if (this.envForm.ports.length < 1) {
          this.isName = false;
          this.showProtocol = false;
          this.choiceHttp = false;
        }
        this.envForm.senPorts.splice(index, 1);
      }
    },




    //保存挂载卷的属性
    savePvc() {
      
      this.isChoice = false;
      var property = this.deepClone(this.pvcForm.newProperty);

      property.name = this.devPvcList.name;
      this.pvcForm.newProperty.mountPath = "";
      this.pvcForm.properties.push(property);

      var pveList = {
        mountPath: "",
        pvcId: "",
        name: ""
      };

      pveList.mountPath = this.pvcForm.properties[this.count].mountPath.trim();
      pveList.name = this.devPvcList.name;
      pveList.pvcId = this.devPvcList.id;
      this.count++;

      this.savedevPvcList.push(pveList);
    },

    //删除挂载卷
    delProperty(property) {
      var index = this.pvcForm.properties.indexOf(property);
      if (index !== -1) {
        this.pvcForm.properties.splice(index, 1);
        this.savedevPvcList.splice(index, 1);
      }

      this.count--;
    },
    selectedPvc(value) {
      this.isChoice = true;
    },
    openCreate() {},
    handleFilter() {},
    handleSizeChange(val) {
      this.pageSize = val;
      this.getList();
    },

    //分页查询
    handleCurrentChange(val) {
      this.currentPage = val;
      this.getList();
    },
    handleModifyStatus(row, status) {},

    //切换访问类型

    changeVistType(type) {
      if (type == "NodePort") {
        this.showProtocol = true;
      } else {
        this.showProtocol = false;
        this.choiceHttp = false;
        this.newRules = [
        {
          http: {
            paths: [
              {
                backend: {
                  serviceName: "",
                  servicePort: ""
                },
                path: ""
              }
            ]
          }
        }
      ];
        this.serviceProtocol = "";
      }
    },

    //切换协议

    changeProtocol(protocol) {
      if (protocol == "HTTP") {
        this.choiceHttp = true;
      } else {
        this.choiceHttp = false;
      }
    },

    //创建应用

    cleanAll() {
      this.applicationForm.name = "";
      this.applicationForm.labels = "";
      this.applicationForm.maxMemory = "";
      this.applicationForm.minMemory = "";
      this.applicationForm.maxCpu = "";
      this.applicationForm.minCpu = "";
      this.applicationForm.description = "";
      this.applicationForm.mirrorId = {};
      this.applicationForm.mirrorName = "";
      this.envForm.env = [];
      this.envForm.ports = [];
      this.envForm.newEnv.name = "";
      this.envForm.newEnv.value = "";
      this.pvcForm.newProperty.mountPath = "";
      this.pvcForm.properties = [];
      this.service.ports = [];
      this.service.rules = [];
      (this.showProtocol = false), //是否选择平台外
        (this.choiceHttp = false), //是否选择http
        (this.serviceProtocol = "");
      this.newRules = [
        {
          http: {
            paths: [
              {
                backend: {
                  serviceName: "",
                  servicePort: ""
                },
                path: ""
              }
            ]
          }
        }
      ];

      this.leftResource = [];

      this.service.type = "ClusterIP";
      this.service.protocol = "TCP";
      this.savedevPvcList = [];
      this.count = 0;
      this.saveSetting = false;
    },

    createApplication() {
      this.cleanAll();
      this.isPVC = false;

      this.isCanChoice = false;
      this.isPush = false;
      this.isCreate = true;
      this.title = "创建应用";

      this.$http
        .get("/cloud/mirror/getMirrorLibrarys?pageNum=1" + "&pageSize=10")
        .then(res => {
         
          var mirrors = res.data.obj.result;
          var temp = [];
          for (var k in mirrors) {
            if (mirrors[k].approve == 2) {
              temp.push(mirrors[k]);
            }
          }
          this.mirror = temp;
        });

      this.$http
        .get(
          "/cloud/persistentVolume/queryPersistentVolumesByProjectId?projectId=" +
            this.projectId
        )
        .then(res => {
          if (res.data.success) {
            this.options = res.data.obj;
          } else {
            this.isCanChoice = true;
          }
        });

      //获取剩余容量

      this.$http
        .get(
          "/cloud/app/queryLeftProjectCpuAndMemory?projectId=" + this.projectId
        )
        .then(res => {
          this.leftResource = res.data.obj;
        });

      this.dialogCreateVisible = true;
      this.isEdit = false;
    },

    //去除大括号
    removeBlock(str) {
      if (str) {
        var reg = /^\{/gi;
        var reg2 = /\}$/gi;
        str = str.replace(reg, "");
        str = str.replace(reg2, "");
        return str;
      } else {
        return str;
      }
    },
    //确认创建应用
    suerCreatUser(applicationForm) {
      var sendObj = {
        name: "",
        // labels: "",
        namespace: "",
        maxMemory: "",
        minMemory: "",
        maxCpu: "",
        minCpu: "",
        mirrorId: "",
        imageurl: "",
        projectId: "",
        env: "",
        ports: "",
        devPvcList: [],
        description: "",
        service: {
          type: "",
          ports: "",
          rules: []
        },
        type: 1
      };

      var checknev = {
        env: []
      };
      var checkports = {
        ports: []
      };
      var senPorts = {
        ports: []
      };

      checknev.env = this.envForm.env;
      checkports.ports = this.envForm.ports;
      senPorts.ports = this.envForm.senPorts;
      (sendObj.name = this.applicationForm.name.trim()),
        (sendObj.namespace = this.namespace),
        (sendObj.projectId = this.projectId),
        // (sendObj.labels = this.applicationForm.labels),
        (sendObj.maxMemory = this.applicationForm.maxMemory),
        (sendObj.minMemory = this.applicationForm.minMemory),
        (sendObj.maxCpu = this.applicationForm.maxCpu),
        (sendObj.minCpu = this.applicationForm.minCpu),
        (sendObj.mirrorId = this.applicationForm.mirrorId.id),
        (sendObj.imageurl =
          this.applicationForm.mirrorId.address +
          "/" +
          this.applicationForm.mirrorName.trim()),
        (sendObj.env = this.removeBlock(JSON.stringify(checknev))),
        (sendObj.ports = this.removeBlock(JSON.stringify(senPorts))),
        (sendObj.devPvcList = this.savedevPvcList);

      sendObj.description = this.applicationForm.description;
      // sendObj = JSON.stringify(sendObj)

      if (this.isPush == true) {
        sendObj.type = 2;
        // sendObj.service.port = this.service.port;
        // sendObj.service.targetPort = this.service.targetPort;
        sendObj.service.type = this.service.type;

        if (this.serviceProtocol == "HTTP") {
          sendObj.service.type = "ClusterIP";
          this.newRules[0].http.paths[0].backend.serviceName = this.applicationForm.name;
          sendObj.service.rules = JSON.stringify(this.newRules);
        } else {
          sendObj.service.type = "NodePort";
          sendObj.service.rules = "";
        }
        if (checkports.ports.length > 0) {
          sendObj.service.ports = this.removeBlock(JSON.stringify(checkports));
        } else {
          this.saveSetting = true;
        }

        this.$refs.service.validate(valid => {
          if (valid) {
            this.$refs.applicationForm.validate(valid => {
              if (valid) {
                // console.log(sendObj);
                this.$http
                  .post("/cloud/app/deploymentCreate", sendObj)
                  .then(res => {
                    if (res.data.success) {
                      this.$message({
                        message: res.data.msg,
                        type: "success"
                      });
                      this.dialogCreateVisible = false;
                      this.getList();
                    } else {
                      this.$message({
                        message: res.data.msg,
                        type: "error"
                      });
                    }
                  });
              } else {
                return false;
              }
            });
          } else {
            return false;
          }
        });
      } else {
        sendObj.service.rules = "";
        this.$refs.applicationForm.validate(valid => {
          if (valid) {
            this.$http
              .post("/cloud/app/deploymentCreate", sendObj)
              .then(res => {
                if (res.data.success) {
                  this.$message({
                    message: res.data.msg,
                    type: "success"
                  });
                  this.dialogCreateVisible = false;
                  this.getList();
                } else {
                  this.$message({
                    message: res.data.msg,
                    type: "error"
                  });
                }
              });
          } else {
            return false;
          }
        });
      }
    },
    //删除应用

    deleUser(row) {
      this.$confirm("此操作将永久删除应用, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.$http
            .get("/cloud/app/deploymentDelete?id=" + row.id)
            .then(res => {
              if (res.data.success) {
                this.$message({
                  message: res.data.msg,
                  type: "success"
                });
                this.getList();
              } else {
                this.$message({
                  message: res.data.msg,
                  type: "error"
                });
              }
            });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },



    

    //编辑

    editProject(row) {
      this.title = "编辑应用";
      this.cleanAll();
      this.isPVC = false;
      if (row.type == 2) {
        this.isPush = true;
      }
      this.applicationId = row.id;
      this.isCreate = false;
      this.applicationForm.name = row.name;
      this.applicationForm.labels = row.labels;
      this.applicationForm.maxMemory = row.maxMemory;
      this.applicationForm.minMemory = row.minMemory;
      this.applicationForm.maxCpu = row.maxCpu;
      this.applicationForm.minCpu = row.minCpu;
      this.applicationForm.description = row.description;
      this.applicationForm.mirrorId.id = row.mirrorId;
      var index = row.imageurl.lastIndexOf("/");
      this.applicationForm.mirrorName = row.imageurl.substring(
        index + 1,
        row.imageurl.length
      );
      this.applicationForm.mirrorId.address = row.imageurl.substring(0, index);
      var ss = "{" + row.env + "}";
      this.envForm.env = JSON.parse(ss).env;
      var sendPort = "{" + row.ports + "}";
      this.envForm.senPorts = JSON.parse(sendPort).ports;
      if (row.devPvcList != [] && row.devPvcList != null) {
        this.isPVC = true;
        this.savedevPvcList = row.devPvcList;
      }
      if (row.devPvcList && row.devPvcList.length > 0) {
        this.count = row.devPvcList.length;
        for (var i = 0; i < row.devPvcList.length; i++) {
          this.pvcForm.properties[i] = {
            name: "",
            mountPath: ""
          };
          this.pvcForm.properties[i].name = row.devPvcList[i].name;
          this.pvcForm.properties[i].mountPath = row.devPvcList[i].mountPath;
        }
      } else {
        this.count = 0;
      }
      if (row.service) {
        this.service.type = row.service.type;

        var servicePort = "{" + row.service.ports + "}";
        this.envForm.ports = JSON.parse(servicePort).ports;
        if (this.envForm.ports.length > 0) {
          this.isName = true;
        }
        if (row.service.rules != "") {
          var rulesList = JSON.parse(row.service.rules);
          if (rulesList && rulesList.length > 0) {
            (this.showProtocol = true),
              (this.choiceHttp = true),
              (this.serviceProtocol = "HTTP");
            this.service.type = "NodePort";

            this.newRules = rulesList;
          } else {
            this.serviceProtocol = "TCP";
          }
        } else {
          if (row.service.type == "NodePort") {
            this.showProtocol = true;
            this.serviceProtocol = "TCP";
          } else {
            this.showProtocol = false;
          }
        }

        // this.service.port = row.service.port;
        // this.service.targetPort = row.service.targetPort;

        this.service.protocol = row.service.protocol;
      }

      this.isEdit = true;

      this.$http
        .get("/cloud/mirror/getMirrorLibrarys?pageNum=1" + "&pageSize=10")
        .then(res => {
          this.mirror = res.data.obj.result;
        });

      this.$http
        .get(
          "/cloud/persistentVolume/queryPersistentVolumesByProjectId?projectId=" +
            this.projectId
        )
        .then(res => {
          if (res.data.success) {
            this.options = res.data.obj;
          } else {
            this.isCanChoice = true;
          }
        });

      //获取剩余容量

      this.$http
        .get(
          "/cloud/app/queryLeftProjectCpuAndMemory?projectId=" + this.projectId
        )
        .then(res => {
          this.leftResource = res.data.obj;
        });

      this.dialogCreateVisible = true;
    },
    //确认编辑
    suerEdit() {
      debugger;
      var sendObj = {
        id: this.applicationId,
        name: "",
        labels: "",
        namespace: "",
        maxMemory: "",
        minMemory: "",
        maxCpu: "",
        minCpu: "",
        mirrorId: "",
        imageurl: "",
        projectId: "",
        env: "",
        devPvcList: [],
        ports: "",
        description: "",
        service: {
          type: "",
          ports: "",
          rules: []
        },
        type: 1
      };

      var checknev = {
        env: []
      };

      var checkports = {
        ports: []
      };

      var senPorts = {
        ports: []
      };

      checknev.env = this.envForm.env;
      checkports.ports = this.envForm.ports;
      senPorts.ports = this.envForm.senPorts;

      (sendObj.name = this.applicationForm.name.trim()),
        (sendObj.namespace = this.namespace),
        (sendObj.projectId = this.projectId),
        (sendObj.labels = this.applicationForm.labels),
        (sendObj.maxMemory = this.applicationForm.maxMemory),
        (sendObj.minMemory = this.applicationForm.minMemory),
        (sendObj.maxCpu = this.applicationForm.maxCpu),
        (sendObj.minCpu = this.applicationForm.minCpu),
        (sendObj.mirrorId = this.applicationForm.mirrorId.id),
        (sendObj.imageurl =
          //"registry.cn-beijing.aliyuncs.com/hiacloud/ts-data-query:product-v1.0.0-beta"),
          this.applicationForm.mirrorId.address +
          "/" +
          this.applicationForm.mirrorName.trim()),
        (sendObj.env = this.removeBlock(JSON.stringify(checknev))),
        (sendObj.ports = this.removeBlock(JSON.stringify(senPorts))),
        (sendObj.devPvcList = this.savedevPvcList);

      sendObj.description = this.applicationForm.description;
      // sendObj = JSON.stringify(sendObj)

      if (this.isPush == true) {
        sendObj.type = 2;
        if (checkports.ports.length > 0) {
          sendObj.service.ports = this.removeBlock(JSON.stringify(checkports));
        } else {
          this.saveSetting = true;
        }
        sendObj.service.type = this.service.type;

        if (this.serviceProtocol == "HTTP") {
          sendObj.service.type = "ClusterIP";
          this.newRules[0].http.paths[0].backend.serviceName = this.applicationForm.name;
          sendObj.service.rules = JSON.stringify(this.newRules);
        } else if (this.serviceProtocol == "TCP") {
          sendObj.service.type = "NodePort";
          sendObj.service.rules = "";
        } else {
          sendObj.service.type = "ClusterIP";
          sendObj.service.rules = "";
        }
      } else {
        sendObj.type = 1;
        sendObj.service.rules = "";
      }

      this.$http.post("/cloud/app/deploymentUpdate", sendObj).then(res => {
        if (res.data.success) {
          this.$message({
            message: res.data.msg,
            type: "success"
          });
          this.dialogCreateVisible = false;
          this.getList();
        } else {
          this.$message({
            message: res.data.msg,
            type: "error"
          });
        }
      });
    },
    //查看详情
    detail(row) {
      sessionStorage.setItem("id", row.id);
      sessionStorage.setItem("name", row.name);
      this.$router.push({
        name: "applicationDetail",
        query: { id: row.id, name: row.name }
      });
    },




    handleClick(tab, event) {
      console.log(tab, event);
    }
  },

  watch: {
    $route(currentState, oldState) {
      if (currentState.fullPath.startsWith("/tenantProject")) {
        this.projectId = sessionStorage.getItem("projectId");
        this.getList();
      } else {
        sessionStorage.setItem("showNumber", 3);
      }
    }
  }
};