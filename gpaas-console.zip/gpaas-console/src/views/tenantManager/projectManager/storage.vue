<style scoped>
.filter-container {
  margin: 10px;
}
</style>
<template>
  <div class=" calendar-list-container">
    <div class="filter-container" >
      <!-- <el-input @keyup.enter.native="handleFilter" style="width: 200px;" placeholder="请输入内容" v-model="listQuery.title"> -->
      <!-- </el-input> -->
      <!-- <el-button  type="primary" icon="el-icon-search" @click="handleFilter">搜索</el-button> -->
      <el-button style="display:block;float:left;"  type="primary" icon="el-icon-plus" @click="createProject">创建存储卷</el-button>
      <el-card style="display: block;float: left;margin: 0 20px 15px;height: 43px;font-size:14px">
        <span style="font-weight:bold;color:#606266;">
          剩余项目资源：</span> 硬盘：{{leftResource.leftStorageSize}}G
      </el-card>
    </div>
<!-- v-loading="listLoading" -->
    <div style="margin-left:10px">
      <el-table :key='tableKey' :data="storageData"  element-loading-text="给我一点时间" border fit highlight-current-row
        style="width: 100%">
        <el-table-column align="center" label="存储卷名称" :span="6">
          <template slot-scope="scope">
            <span>{{scope.row.name}}</span>
            <span v-if="scope.row.deploymentPVCList.length >0">
              <el-tag size="mini">已使用</el-tag>
            </span>
          </template>
        </el-table-column>

          <el-table-column align="center" label="总量" :span="6">
          <template slot-scope="scope">
            <span>{{scope.row.storageSize |statesFilters}}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="创建时间" :span="6">
          <template slot-scope="scope">
            <span>{{scope.row.createTime | formatDatetwo}}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="应用名称" :span="6">
          <template slot-scope="scope">
            <span>{{scope.row.deploymentPVCList | storagefilter }}</span>
          </template>
        </el-table-column>

        <el-table-column align="center" label="状态" width="120">
          <template slot-scope="scope">
            <span>{{scope.row.state | state}}</span>
          </template>
        </el-table-column>

        <el-table-column align="left" label="操作" :span="6" class-name="small-padding fixed-width">
          <template slot-scope="scope">
            <!-- <el-button  size="mini" type="success" v-if="scope.row.state==3" @click="editStorage(scope.row)">编辑 
            </el-button> -->
            <!-- <el-button  size="mini" type="success" v-if="!iscope.row.state==3" @click="freezeStorage(scope.row)">冻结 
            </el-button> -->
            <el-button  size="mini" type="danger"  @click="deletStorage(scope.row)">删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>

        <div class="pagination-container">
            <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[10,20,30, 50]" :page-size="100" layout="total, sizes, prev, pager, next, jumper" :total="total">
            </el-pagination>
    
        </div>
    </div>
        <div style="">
            <el-dialog :title="title" :visible.sync="dialogCreateVisible">
            <div style="width:80%;margin:0 auto">
            <el-form ref="createStorageForm" :rules="rules" :model="createStorageForm" label-width="100px">
                <el-form-item label="存储卷名称" prop="name">
                    <el-input v-model="createStorageForm.name" :disabled="isEdit" placeholder="请输入存储卷名称"></el-input>
                </el-form-item>   

                <el-form-item label="总量" prop="storageSize" >
                    <el-input v-model.number="createStorageForm.storageSize" placeholder="请输入内存总量">
                    <template slot="append">G</template>
                    </el-input>
                </el-form-item> 

                <el-form-item label="存储卷描述">
                    <el-input  type="textarea"  v-model="createStorageForm.description" placeholder="请输入存储卷描述">
                    
                    </el-input>
                </el-form-item> 
                
                <!-- <el-form-item label="存储卷权限">
                    <el-radio-group v-model="radio" @change="radioChange">
                        <el-radio :disabled="disabled" :label="1">仅读写一次</el-radio>
                        <el-radio :disabled="disabled" :label="2">只读</el-radio>
                        <el-radio :disabled="disabled" :label="3">读写</el-radio>
                    </el-radio-group>
                </el-form-item> -->

                
                <el-form-item>
                    <el-button type="primary" @click="sureCreateStorage('createStorageForm')" v-if="!isEdit">创建</el-button>
                    <el-button type="danger" @click="suerEdit" v-if="isEdit">保存</el-button>
                    <el-button @click="cancle('createStorageForm')">取消</el-button>
                </el-form-item>
                </el-form>
                </div>
            </el-dialog>
        </div>

  </div>
</template>

<script>
 import storage from './js/storage'
    export default{
        ...storage
    }

</script>
<style scoped>
.pagination-container {
  margin-top: 20px;
}
</style>
