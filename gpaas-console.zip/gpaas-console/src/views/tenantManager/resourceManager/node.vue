<style scoped>
.filter-container {
  margin: 10px;
}
</style>
<template>
  <div class=" calendar-list-container">
    <div class="filter-container" >
      <!-- <el-input @keyup.enter.native="searchNode" style="width: 200px;" placeholder="请输入搜索内容" v-model="searchContent">
      </el-input> -->
      <!-- <el-button  type="primary" icon="el-icon-search" @click="searchNode">搜索</el-button> -->
      <!-- <el-button  type="primary" icon="el-icon-refresh" @click="getList">清空</el-button> -->
      <el-button  type="primary" icon="el-icon-plus" @click="openCreate">申请节点</el-button>
    </div>
<!-- v-loading="listLoading" -->
<div style="margin-left: 10px;">
    <el-table :key='tableKey' :data="table"  element-loading-text="给我一点时间" border fit highlight-current-row
      style="width: 100%">
      <el-table-column align="center" label="名称" >
        <template slot-scope="scope">
          <span>{{scope.row.name}}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="类型" >
        <template slot-scope="scope">
          <span>{{scope.row.type | nodeFilters}}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="CPU" >
        <template slot-scope="scope">
          <span>{{scope.row.cpu | cpuFilter}}</span>

        </template>
      </el-table-column>
      <el-table-column align="center" label="内存" >
        <template slot-scope="scope">
          <span>{{scope.row.memory | memoryFilter}}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="存储大小" >
        <template slot-scope="scope">
          <span>{{scope.row.storageSize | storeFilter}}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="状态" >
        <template slot-scope="scope">
          <span>{{scope.row.state | statesFilters}}</span>
        </template>
      </el-table-column>
     
      <el-table-column width="200" align="left" label="操作" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button  size="mini" type="success" @click="editNode(scope.row)" v-if="scope.row.state==0">编辑</el-button>
          <el-button  size="mini" type="success" @click="detailNode(scope.row)" :disabled="scope.row.state==2">详情</el-button>
          <el-button  size="mini" type="danger" @click="deleteNode(scope.row.id)" v-if="scope.row.state==0">删除</el-button>
          <!-- <el-button  size="mini" type="success" @click="freezeNode(scope.row.id)" v-if="isFreeze(scope.row.state)">冻结 </el-button> -->
          <el-button  size="mini" type="danger" @click="delectNode(scope.row.id)" v-if="scope.row.state==1">申请释放 </el-button>
          <!-- <el-button  size="mini" @click="handleModifyStatus(scope.row,'draft')">租户管理</el-button> -->
          
        </template>
      </el-table-column>
    </el-table>

    <div class="pagination-container">
      <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[10,20,30, 50]" :page-size="100" layout="total, sizes, prev, pager, next, jumper" :total="total">
      </el-pagination>
    </div>
</div> 
<!-- 创建和编辑 -->
<div style="">
    <el-dialog :title="title" :visible.sync="dialogFormVisible">
      <div style="width: 400px">
      <el-form :rules="rules" ref="auditNodeForm" :model="auditNodeForm" label-width="80px">
          <el-form-item label="节点名称" prop="name">
            <el-input v-model="auditNodeForm.name" :disabled="isEdit" placeholder="请输入节点名称"></el-input>
          </el-form-item>
            <el-form-item label="CPU" prop="cpu" v-show="typeFormVisible">


              <el-select v-model="auditNodeForm.cpu" placeholder="请选择">
                <el-option
                  v-for="item in cpuOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
                
              </el-select>
              <el-tag medium  type="info">核</el-tag>
            <!-- <el-input v-model="auditNodeForm.cpu">
               <template slot="append">核</template>
            </el-input> -->
            </el-form-item>          
            <el-form-item label="内存" prop="memory" v-show="typeFormVisible">
              <el-select v-model="auditNodeForm.memory" placeholder="请选择">
                <el-option
                  v-for="item in memoryOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
                
              </el-select>
              <el-tag medium  type="info">G</el-tag>
            </el-form-item>
            <el-form-item label="磁盘大小" prop="storageSize" v-show="!typeFormVisible">
              <el-input v-model.number="auditNodeForm.storageSize">
                <template slot="append">G</template>
              </el-input>
            </el-form-item>              
          <el-form-item label="节点类型">
            <el-radio-group v-model="auditNodeForm.type" @change="changeType">              
              <el-radio :disabled="isEdit" :label="1">计算节点</el-radio>
              <el-radio :disabled="isEdit" :label="2">存储节点</el-radio>
            </el-radio-group>
          </el-form-item>
          
          <el-form-item>
            <el-button v-if="!isEdit" type="primary" @click="createNode('auditNodeForm')">创建</el-button>
            <el-button v-if="isEdit" type="primary" @click="sureSubmit('auditNodeForm')">保存</el-button>
            <el-button @click="cancleNode('auditNodeForm')">取消</el-button>
          </el-form-item>
        </el-form>
        </div>
    </el-dialog>
</div>
  
  <!-- 详情 -->
    <el-dialog title="详情"  :visible.sync="detailVisible" width="80%" @close="closeDetail">
      <div style="min-height: 400px;">
        <el-tabs v-model="activeName" @tab-click="handleClick">
          <el-tab-pane label="详情" name="first">
            <div style="width: 400px">
              <el-form ref="detailNodeForm" :model="detailNodeForm" label-width="100px">
                <el-form-item label="节点名称">
                  <el-input v-model="detailNodeForm.name" disabled></el-input>
                </el-form-item>
                <el-form-item label="集群ID" v-if="detailNodeForm.type==2"  v-show="!detailNodeForm.state==0">
                <el-input v-model="detailNodeForm.clusterId"  disabled>
                </el-input>
                </el-form-item>          
                <el-form-item label="主机名" v-if="detailNodeForm.type==1" v-show="!detailNodeForm.state==0">
                  <el-input v-model="detailNodeForm.hostName"  disabled>
                </el-input>
                </el-form-item>
                <el-form-item label="不通过原因" v-if="detailNodeForm.state==0"  v-show="detailNodeForm.state==0">
                  <el-input v-model="detailNodeForm.auditReason" disabled>
                  </el-input>
                </el-form-item>              
                <el-form-item label="IP" v-if="detailNodeForm.type==1"  v-show="!detailNodeForm.state==0">
                  <el-radio-group v-model="detailNodeForm.ip">              
                    <el-input v-model="detailNodeForm.ip" disabled></el-input>
                  </el-radio-group>
                </el-form-item>
            </el-form>
          </div>
          </el-tab-pane>
          <el-tab-pane label="事件" name="second" v-if="eventVisible">
            <el-table :data="nodeevent" style="width: 95%">
                  <el-table-column label="时间">
                      <template slot-scope="scope">
                          <span>{{scope.row.lastTimestamp }}</span>
                      </template>
                  </el-table-column>
                  <el-table-column label="事件类型">
                      <template slot-scope="scope">
                          <span>{{scope.row.reason }}</span>
                      </template>
                  </el-table-column>
                  <el-table-column label="描述">
                      <template slot-scope="scope">
                          <span>{{scope.row.message }}</span>
                      </template>
                  </el-table-column>
              </el-table>
          </el-tab-pane>
          <el-tab-pane label="监控" name="third" v-if="eventVisible">
             <div class="container">
              <div ref="cpu" style="width:100%;min-height:200px">
              </div>
              <div ref="memory" style="width:100%;min-height:200px">
              </div>
              <div ref="network" style="width:100%;min-height:200px">
              </div>
            </div>
          </el-tab-pane>
        </el-tabs>
      </div>
    </el-dialog>
  
  </div>
</template>

<script>
import node from './js/node'
    export default{
        ...node
    }
</script>
<style scoped>
.pagination-container {
  margin-top: 20px;
}
</style>
