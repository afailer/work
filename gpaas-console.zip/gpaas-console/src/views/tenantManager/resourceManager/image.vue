<style scoped>
.filter-container {
  margin: 10px;
}
</style>
<template>
  <div class=" calendar-list-container">
    <div class="filter-container">
      <!-- <el-input @keyup.enter.native="handleFilter" style="width: 200px;" placeholder="请输入内容" v-model="listQuery.title">
      </el-input> -->
      <!-- <el-button type="primary" icon="el-icon-search" @click="handleFilter">搜索</el-button> -->
      <el-button type="primary" icon="el-icon-plus" @click="createUser">添加第三方镜像库</el-button>
      <el-button type="primary" icon="el-icon-plus" @click="applyImg">申请镜像库</el-button>
    </div>
    <!-- v-loading="listLoading" -->
    <div style="margin-left:10px">
      <el-table :key='tableKey' :data="imageData" element-loading-text="给我一点时间" border fit highlight-current-row style="width: 100%">
        <el-table-column align="center" label="名称" >
          <template slot-scope="scope">
            <span>{{scope.row.name}}</span>
          </template>
        </el-table-column>
      
        <el-table-column align="center" label="账户名" >
          <template slot-scope="scope">
            <span>{{scope.row.account}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="密码" >
          <template slot-scope="scope">
            <span>{{scope.row.password}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="地址" >
          <template slot-scope="scope">
            <span>{{scope.row.address}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="类型" >
          <template slot-scope="scope">
            <span>{{scope.row.type |typeFilters}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="创建时间" >
          <template slot-scope="scope">
            <span>{{scope.row.createTime |formatDatetwo}}</span>
          </template>
        </el-table-column>
        
        <el-table-column align="center" label="状态" >
          <template slot-scope="scope">
            <span>{{scope.row.approve | statesFilters}}</span>
          </template>
        </el-table-column>

        <el-table-column width="160" align="left" label="操作"  class-name="small-padding fixed-width">
          <template slot-scope="scope">
            <!-- <el-button type="primary" size="mini" @click="examine(scope.row)">审核</el-button> -->
            <el-button size="mini" type="success" :disabled="scope.row.type == 1" @click="editImage(scope.row)">编辑
            </el-button>
            <el-button size="mini" type="danger" @click="deleUser(scope.row)" v-if="scope.row.type==2">删除
            </el-button>
              <el-button size="mini" type="danger" @click="deleUser(scope.row)" v-if="scope.row.approve != 2">删除
            </el-button>

          </template>
        </el-table-column>
      </el-table>
    
      <div class="pagination-container">
        <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[10,20,30, 50]" :page-size="100" layout="total, sizes, prev, pager, next, jumper" :total="total">
        </el-pagination>

      </div>
    </div>
<!-- 添加第三方镜像库 -->
    <div style="">
      <el-dialog :title="imageTitle" :visible.sync="dialogCreateVisible">
        <div style="width:80%;margin:0 auto">
          <el-form ref="careatUserForm" :model="careatUserForm" :rules="rules" label-width="100px">
            <el-form-item label="名称" prop="name">
              <el-input v-model="careatUserForm.name" placeholder="请输入镜像库名称"></el-input>
            </el-form-item>
             <el-form-item label="地址" prop="address">
              <el-input v-model="careatUserForm.address" placeholder="请输入地址">

              </el-input>
            </el-form-item>
            <el-form-item label="邮箱" prop="email">
              <el-input v-model="careatUserForm.email" placeholder="请输入邮箱">

              </el-input>
            </el-form-item>

           
            <el-form-item label="账号">
              <el-input v-model="careatUserForm.account"  placeholder="请输入账号">

              </el-input>
            </el-form-item>
            <el-form-item label="密码">
              <el-input v-model="careatUserForm.password" type="password"  placeholder="请输入密码">

              </el-input>
            </el-form-item>
            <el-form-item label="登录地址" prop="loginAddress">
              <el-input v-model="careatUserForm.loginAddress"  placeholder="请输入登录地址">

              </el-input>
            </el-form-item>

            <el-form-item>
              <el-button type="primary" @click="suerCreatUser('careatUserForm')" v-if="!isEdit">创建</el-button>
              <el-button type="danger" @click="suerEdit" v-if="isEdit">保存</el-button>
              <el-button @click="dialogCreateVisible = false">取消</el-button>
            </el-form-item>
          </el-form>
        </div>
      </el-dialog>
    </div>
<!-- 添加镜像库 -->
    <div style="">
      <el-dialog :title="applyTitle" :visible.sync="dialogApplyVisible">
        <div style="width:80%;margin:0 auto">
          <el-form ref="applyForm" :model="applyForm" :rules="rules" label-width="100px">
            <el-form-item label="名称" prop="name">
              <el-input v-model="applyForm.name" placeholder="请输入镜像库名称"></el-input>
            </el-form-item>
            <el-form-item label="邮箱" prop="email">
              <el-input v-model="applyForm.email" placeholder="请输入邮箱">

              </el-input>
            </el-form-item>

            <el-form-item>
              <el-button type="primary" @click="suerApply('applyForm')" v-if="!applyIsEdit">创建</el-button>
              <el-button type="danger" @click="suerApplyEdit" v-if="applyIsEdit">保存</el-button>
              <el-button @click="dialogApplyVisible = false">取消</el-button>
            </el-form-item>
          </el-form>
        </div>
      </el-dialog>
    </div>

  </div>
</template>

<script>
import image from './js/image'
    export default{
        ...image
    }
</script>
<style scoped>
.pagination-container {
  margin-top: 20px;
}
</style>
