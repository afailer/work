export default {
    name: "complexTable",
  
    data() {
      var email=(rule,value,callback)=>{
        if(/^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/.test(value)==false){
          callback(new Error("邮箱不符合规范"));
        }
      }
      return {
        //添加第三方
        careatUserForm: {
          type: 2,
          name: "",
          email: "",
          address: "",
          account: "",
          password: "",
          loginAddress: ""
        },
        //申请
        applyForm: {
          type: 1,
          name: "",
          email: ""
        },
        imageTitle: "添加第三方镜像库",
        applyTitle: "申请镜像库",
  
        rules: {
          name: [{ required: true, message: "请输镜像库名称", trigger: "blur" }],
         
          address: [
            { required: true, message: "请输镜像库地址", trigger: "blur" }
          ],
           email:[{  trigger:"blur",required: true, message: "请输邮箱"}],
           loginAddress:[{  trigger:"blur",required: true, message: "请输登录地址"}]
        },
        isEdit: false,
        applyIsEdit: false,
        currentPage: 1,
        imageData: [],
        tableKey: 0,
        total: null,
        pageSize: 10,
        listLoading: true,
        listQuery: {
          title: undefined
        },
        //创建用户
        dialogCreateVisible: false,
        dialogApplyVisible: false
      };
    },
  
    filters: {
      statesFilters: function(value) {
        switch (value) {
          case 3:
            return "未通过";
            break;
          case 1:
            return "待审核";
            break;
          case 2:
            return "通过";
            break;
        }
      },
      typeFilters: function(value) {
        switch (value) {
          case 1:
            return "阿里云镜像库";
            break;
          case 2:
            return "第三方镜像库";
            break;
        }
      },
      formatDatetwo: function(time) {
        var re = /-?\d+/;
        var m = re.exec(time);
        var d = new Date(parseInt(m[0]));
        var o = {
          "M+": d.getMonth() + 1, //month
          "d+": d.getDate(), //day
          "h+": d.getHours(), //hour
          "m+": d.getMinutes(), //minute
          "s+": d.getSeconds(), //second
          "q+": Math.floor((d.getMonth() + 3) / 3), //quarter
          S: d.getMilliseconds() //millisecond
        };
        var format = "yyyy-MM-dd hh:mm:ss";
        if (/(y+)/.test(format)) {
          format = format.replace(
            RegExp.$1,
            (d.getFullYear() + "").substr(4 - RegExp.$1.length)
          );
        }
        for (var k in o) {
          if (new RegExp("(" + k + ")").test(format)) {
            format = format.replace(
              RegExp.$1,
              RegExp.$1.length == 1
                ? o[k]
                : ("00" + o[k]).substr(("" + o[k]).length)
            );
          }
        }
        return format;
      },
    },
    created() {
      this.getList();
    },
    methods: {
      getList() {
        this.$http
          .get(
            "/cloud/mirror/getMirrorLibrarys?pageNum=" +
              this.currentPage +
              "&pageSize=" +
              this.pageSize +
              ""
          )
          .then(res => {
            this.total = res.data.obj.totalCount;
            this.imageData = res.data.obj.result;
          });
      },
  
      openCreate() {},
      handleFilter() {},
      handleSizeChange(val) {
        this.pageSize = val;
        this.getList();
      },
  
      //分页查询
      handleCurrentChange(val) {
        this.currentPage = val;
        this.getList();
      },
      handleModifyStatus(row, status) {},
  
      //创建第三方
      createUser() {
        this.careatUserForm.type = 2;
        this.careatUserForm.name = "";
        this.careatUserForm.email = "";
        this.careatUserForm.address = "";
        this.careatUserForm.account = "";
        this.careatUserForm.password = "";
        this.careatUserForm.loginAddress = "";
  
        this.dialogCreateVisible = true;
        this.isEdit = false;
        this.imageTitle = "添加第三方镜像库";
      },
  
      //确认添加第三方镜像库
      suerCreatUser(formName) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            this.$http
              .post("/cloud/mirror/registMirrorLibrary", this.careatUserForm)
              .then(res => {
                if (res.data.success) {
                  this.$message({
                    message: res.data.msg,
                    type: "success"
                  });
                  this.dialogCreateVisible = false;
                  this.getList();
                } else {
                  this.$message({
                    message: res.data.msg,
                    type: "error"
                  });
                }
              });
          } else {
            console.log("error submit!!");
            return false;
          }
        });
      },
  
      //删除镜像库
  
      deleUser(row) {
        this.$confirm("此操作将永久删除镜像库, 是否继续?", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        })
          .then(() => {
            this.$http
              .delete("/cloud/mirror/deleteMirrorLibrary?id=" + row.id)
              .then(res => {
                if (res.data.success) {
                  this.$message({
                    message: res.data.msg,
                    type: "success"
                  });
                  this.getList();
                } else {
                  this.$message({
                    message: res.data.msg,
                    type: "error"
                  });
                }
              });
          })
          .catch(() => {
            this.$message({
              type: "info",
              message: "已取消删除"
            });
          });
      },
  
      //编辑第三方
  
      editImage(row) {
        // debugger;
  
        if (row.type == "2") {
          this.isEdit = true;
          this.imageTitle = "编辑第三方镜像库";
        } else if (row.type == "1") {
          this.applyIsEdit = true;
          this.applyTitle = "编辑申请镜像库";
        }
        //根据ID 查询镜像库详细信息
        this.$http
          .get("/cloud/mirror/queryMirrorLibraryById?id=" + row.id)
          .then(res => {
            if (row.type == "2") {
              this.careatUserForm = res.data.obj;
              this.dialogCreateVisible = true;
            } else if (row.type == "1") {
              this.applyForm = res.data.obj;
              this.dialogApplyVisible = true;
            }
          });
      },
      //确认编辑
      suerEdit() {
        this.$http
          .post("/cloud/mirror/editMirrorLibrary", this.careatUserForm)
          .then(res => {
            if (res.data.success) {
              this.$message({
                message: res.data.msg,
                type: "success"
              });
              this.dialogCreateVisible = false;
              this.getList();
            } else {
              this.$message({
                message: res.data.msg,
                type: "error"
              });
            }
          });
      },
  
      //申请镜像库
  
      applyImg() {
        this.dialogApplyVisible = true;
        this.applyForm.type = 1;
        this.applyForm.name = "";
        this.applyForm.email = "";
        this.applyIsEdit = false;
      },
  
      suerApply(formName) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            this.$http
              .post("/cloud/mirror/registMirrorLibrary", this.applyForm)
              .then(res => {
                if (res.data.success) {
                  this.$message({
                    message: res.data.msg,
                    type: "success"
                  });
                  this.dialogApplyVisible = false;
                  this.getList();
                } else {
                  this.$message({
                    message: res.data.msg,
                    type: "error"
                  });
                }
              });
          } else {
            console.log("error submit!!");
            return false;
          }
        });
      },
  
      suerApplyEdit() {
        this.$http
          .post("/cloud/mirror/editMirrorLibrary", this.applyForm)
          .then(res => {
            if (res.data.success) {
              this.$message({
                message: res.data.msg,
                type: "success"
              });
              this.dialogCreateVisible = false;
              this.getList();
            } else {
              this.$message({
                message: res.data.msg,
                type: "error"
              });
            }
          });
      }
    }
  };