import echarts from "echarts";

export default {
  name: "complexTable",
  data() {
    return {
      searchContent: "",
      title: "创建节点",
      isEdit: false,
      auditNodeForm: {
        name: "",
        cpu: "",
        memory: "",
        type: 1,
        storageSize: 0
      },
      detailNodeForm: {
        name: "",
        hostName: "",
        auditReason: "",
        clusterId: "",
        ip: "",
        state: "",
        type: ""
      },
      //cpu下拉选择框
      cpuOptions: [
        {
          value: "4",
          label: "4"
        },
        {
          value: "8",
          label: "8"
        },
        {
          value: "16",
          label: "16"
        },
        {
          value: "32",
          label: "32"
        },
        {
          value: "64",
          label: "64"
        }
      ],
      //内存下拉框
      memoryOptions: [
        {
          value: "8",
          label: "8"
        },
        {
          value: "16",
          label: "16"
        },
        {
          value: "32",
          label: "32"
        },
        {
          value: "64",
          label: "64"
        },
        {
          value: "128",
          label: "128"
        },
        {
          value: "256",
          label: "256"
        },
        {
          value: "512",
          label: "512"
        }
      ],
      rules: {
        name: [{ required: true, message: "请输入节点名称", trigger: "blur" }],
        cpu: [{ required: true, message: "请选择CPU", trigger: "change" }],
        memory: [{ required: true, message: "请选择内存", trigger: "change" }],
        type: [
          { required: true, message: "请选择节点类型", trigger: "change" }
        ],
        storageSize: [
          { required: true, message: "磁盘大小不能为空" },
          { type: "number", message: "磁盘大小必须为数字值" }
        ]
      },
    //监控
      cpuDta: [],
      cpuList: [],
      cpuValue: [],
      memoryData: [],
      networkData: [],
      echarts:echarts,



      currentPage: 1,
      pageSize: 10,
      table: [],
      tableKey: 0,
      list: null,
      total: null,
      dialogFormVisible: false,
      typeFormVisible: true,
      eventVisible: true,
      detailVisible: false,
      activeName: "first",
      nodeevent: []
      //是否可执行冻结操作
      // isFreeze : true,
    };
  },
  filters: {
    statesFilters: function(value) {
      switch (value) {
        case 0:
          return "不通过";
          break;
        case 1:
          return "通过";
          break;
        case 2:
          return "待审核";
          break;
        case 3:
          return "冻结";
          break;
        case 4:
          return "待释放";
          break;
      }
    },
    nodeFilters: function(value) {
      switch (value) {
        case 1:
          return "计算节点";
          break;
        case 2:
          return "存储节点";
          break;
      }
    },
    cpuFilter: function(value) {
      if (value == 0) {
        return "-";
      } else {
        return value + "核";
      }
    },
    memoryFilter: function(value) {
      if (value == 0) {
        return "-";
      } else {
        return value + "G";
      }
    },
    storeFilter: function(value) {
      if (value == 0) {
        return "-";
      } else {
        return value + "G";
      }
    }
  },
  created() {
    this.getList();
    // var getToken = Cookies.get('token')
    // console.log( 'token---------------------------------------')
    // console.log( getToken )
    // // debugger
    // var getUser = JSON.parse(Cookies.get('user'))
    // console.log( 'user---------------------------------------')
    // console.log( getUser.userType )
  },
  methods: {
    getList() {
      this.$http
        .get(
          "/cloud/node/queryNodeByPage?pageNum=" +
            this.currentPage +
            "&pageSize=" +
            this.pageSize
        )
        .then(res => {
          this.total = res.data.obj.totalCount;
          this.table = res.data.obj.result;
          // console.log( res.data.obj.result )
        });
    },
    //tab切换
    handleClick(tab, event,name) {
      var  echarts = this.echarts
      var name = this.detailNodeForm.hostName;
      console.log(name)
      if(tab.name == "third"){
        this.getData(echarts,name)
      }
      console.log(tab.name);
    },
    openCreate() {
      this.dialogFormVisible = true;
      this.title = "创建节点";
      this.isEdit = false;
      this.auditNodeForm.name = "";
      this.auditNodeForm.memory = "";
      this.auditNodeForm.cpu = "";
      this.auditNodeForm.type = 1;
      this.auditNodeForm.storageSize = 0;
      this.typeFormVisible = true;
    },

    handleSizeChange(val) {
      this.pageSize = val;
      this.getList();
    },
    handleCurrentChange(val) {
      this.currentPage = val;
      this.getList();
    },
    //编辑节点
    editNode(row) {
      this.auditNodeForm.name = "";
      this.auditNodeForm.cpu = "";
      this.auditNodeForm.memory = "";
      this.auditNodeForm.type = "";
      this.auditNodeForm.storageSize = "";
      this.$http.get("/cloud/node/queryNodeById?id=" + row.id).then(res => {
        this.auditNodeForm = res.data.obj;
        if (this.auditNodeForm.state == 3) {
          this.$message({
            message: "冻结状态下不可编辑",
            type: "error"
          });
        } else {
          this.dialogFormVisible = true;
          this.isEdit = true;
          this.title = "编辑节点";
          this.typeFormVisible = true;
          if (this.auditNodeForm.type == 2) {
            this.typeFormVisible = false;
          }
        }
      });
    },
    //详情
    detailNode(row) {
      if (row.type == 1 && row.state == 1) {
        this.eventVisible = true;
      } else {
        this.eventVisible = false;
      }
      this.detailNodeForm.name = "";
      this.detailNodeForm.auditReason = "";
      this.detailNodeForm.ip = "";
      this.detailNodeForm.hostName = "";
      this.detailNodeForm.clusterId = "";
      this.detailNodeForm.state = "";
      this.detailNodeForm.type = "";
      this.$http.get("/cloud/node/queryNodeById?id=" + row.id).then(res => {
        this.detailNodeForm = res.data.obj;
        this.detailVisible = true;
      });
      this.$http
        .get("/cloud/node/queryNodeEvent?name=" + row.hostName)
        .then(res => {
          if (res.data.success) {
            this.nodeevent = res.data.obj.items;
          } else {
            this.$message({
              message: res.data.msg,
              type: "error"
            });
          }
        });


       
    },
    //关闭详情
    closeDetail(){
      this.activeName = 'first';
    },
    //确认保存更改
    sureSubmit(auditNodeForm) {
      this.$http
        .post("/cloud/node/updateNode", this.auditNodeForm)
        .then(res => {
          if (res.data.success) {
            this.$message({
              message: res.data.msg,
              type: "success"
            });
            this.dialogFormVisible = false;
            this.getList();
          } else {
            this.$message({
              message: res.data.msg,
              type: "error"
            });
          }
        });
    },
    //申请释放节点
    delectNode(nodeId) {
      this.$confirm("此操作将永久释放节点, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.$http
            .get("/cloud/node/freezeNodeById?id=" + nodeId)
            .then(res => {
              if (res.data.success) {
                this.$message({
                  message: res.data.msg,
                  type: "success"
                });
                this.getList();
              } else {
                this.$message({
                  message: res.data.msg,
                  type: "error"
                });
              }
            });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },
    // 删除
    deleteNode(id) {
      this.$http.get("/cloud/node/deleteTenantNodeById?id=" + id).then(res => {
        if (res.data.success) {
          this.$message({
            message: res.data.msg,
            type: "success"
          });
          this.getList();
        } else {
          this.$message({
            message: res.data.msg,
            type: "error"
          });
        }
      });
    },
    //创建节点
    createNode(auditNodeForm) {
      if (this.auditNodeForm.type == 1) {
        this.$refs[auditNodeForm].validate(valid => {
          if (valid) {
            this.$http
              .post("/cloud/node/addNode", this.auditNodeForm)
              .then(res => {
                if (res.data.success) {
                  this.$message({
                    message: res.data.msg,
                    type: "success"
                  });
                  this.dialogFormVisible = false;
                  this.$refs[auditNodeForm].resetFields();
                  this.getList();
                } else {
                  this.$message({
                    message: res.data.msg,
                    type: "error"
                  });
                }
              });
          } else {
            return false;
          }
        });
      } else {
        this.$http.post("/cloud/node/addNode", this.auditNodeForm).then(res => {
          if (res.data.success) {
            this.$message({
              message: res.data.msg,
              type: "success"
            });
            this.dialogFormVisible = false;
            this.$refs[auditNodeForm].resetFields();
            this.getList();
          } else {
            this.$message({
              message: res.data.msg,
              type: "error"
            });
          }
        });
      }
    },
    //取消
    cancleNode(auditNodeForm) {
      this.$refs[auditNodeForm].resetFields();
      this.dialogFormVisible = false;
    },
    changeType() {
      this.typeFormVisible = !this.typeFormVisible;
      this.auditNodeForm.cpu = "";
      this.auditNodeForm.memory = "";
      this.auditNodeForm.storageSize = 0;
    },



    //获取监控数据

    getData(echarts,name) {
      this.$http
        .get(
          "/api/v1/namespaces/kube-system/services/heapster/proxy/api/v1/model/nodes/"+name+"/metrics/cpu/usage_rate"
        )
        .then(res => {
          this.cpuData = res.data.metrics;
          this.initCpuChart(echarts);
        });

      this.$http
        .get(
          "/api/v1/namespaces/kube-system/services/heapster/proxy/api/v1/model/nodes/"+name+"/metrics/memory/usage"
        )
        .then(res => {
          this.memoryData = res.data.metrics;
          this.initMemoryChart(echarts);
        });

      this.$http
        .get(
          "/api/v1/namespaces/kube-system/services/heapster/proxy/api/v1/model/nodes/"+name+"/metrics/network/tx_rate"
        )
        .then(res => {
          this.networkData = res.data.metrics;
          this.initNetChart(echarts);
        });
    },


    //初始化监控


      initCpuChart(echarts) {
      this.cpuchart = echarts.init(this.$refs.cpu);
     

      var cpuData = this.cpuData;
    

      var date1List = cpuData.map(function(item) {
        return item.timestamp;
      });
      var value1List = cpuData.map(function(item) {
        return item.value;
      });

    

      this.cpuchart.setOption({
        tooltip: {
          trigger: "axis"
        },

        title: {
          left: "center",
          text: "cpu"
        },

        xAxis: {
          type: "category",
          data: date1List,
          name: '时间',
        },
        yAxis: {
          type: "value",
          name:"核",
          axisLabel: {                   
            formatter: function (value, index) {           
            return value/10;      
            }                
          }
        },
        series: [
          {
            data: value1List,
            type: "line"
          }
        ]
      });
    },
    initMemoryChart(echarts) {
      
       this.memorychart = echarts.init(this.$refs.memory);
      
       var memoryData = this.memoryData;
    

      var date2List = memoryData.map(function(item) {
        return item.timestamp;
      });
      var value2List = memoryData.map(function(item) {
        return item.value;
      });

      this.memorychart.setOption({
        tooltip: {
          trigger: "axis"
        },

        title: {
          left: "center",
          text: "内存"
        },

        xAxis: {
          type: "category",
          data: date2List,
          name: '时间',
        },
        yAxis: {
          type: "value",
          name:"MB",
          axisLabel: {                   
            formatter: function (value, index) {           
               var a=value/(1024*1024);      
               return a.toFixed(2);
            }                
          }
        },
        series: [
          {
            data: value2List,
            type: "line"
          }
        ]
      });
    },
    initNetChart(echarts) {
     
       this.networkchart = echarts.init(this.$refs.network);

       var networkData = this.networkData;

      var date3List = networkData.map(function(item) {
        return item.timestamp;
      });
      var value3List = networkData.map(function(item) {
        return item.value;
      });

      this.networkchart.setOption({
        tooltip: {
          trigger: "axis"
        },

        title: {
          left: "center",
          text: "网络"
        },

        xAxis: {
          type: "category",
          data: date3List,
          name: '时间',
        },
        yAxis: {
          type: "value",
          name: '(MB/秒)',
          axisLabel: {                   
            formatter: function (value, index) {           
            var a=value/(1024*1024)
            return a.toFixed(2);      
            }
          }
        },
        series: [
          {
            data: value3List,
            type: "line",
          },
        ]
      });
    }
  }
};