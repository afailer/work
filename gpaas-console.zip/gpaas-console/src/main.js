import Vue from 'vue'
import 'xterm/dist/xterm.css'
import 'normalize.css/normalize.css' // A modern alternative to CSS resets

import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'

import locale from 'element-ui/lib/locale/lang/zh-CN'

import '@/styles/index.scss' // global css

import App from './App'
import router from './router'
import store from './store'
import global from '../static/config/global' 

import '@/icons' // icon
//import '@/permission' // permission control
import Cookies from 'js-cookie'


Vue.use(ElementUI, { locale })

import Axios from 'axios'

Vue.prototype.globalURL = global

Vue.prototype.$http = Axios
Axios.interceptors.request.use(function (config) {
    // 这里的config包含每次请求的内容
    // var user = Cookies.get('user')
    // console.log(user)
    var getToken = Cookies.get('token')
    if (getToken) {
        config.headers.Authorization = 'bearer ' + getToken; // 设置请求头
    }
    return config;
}, function (err) {
    return Promise.reject(err);
});


// respone interceptor
Axios.interceptors.response.use(
    response => response,
    error => {
        
        console.log('err' + error) // for debug
        if (error.response.status === 401) {
          Cookies.set("user", "", { expires: -1, path: "/" });
           window.location.href = '/';        
        } else {          
        }
        return Promise.reject(error)
    })


Vue.config.productionTip = false




var routeList = [];

router.beforeEach((to, from, next) => {

    debugger;
   
    var user = Cookies.get('user')
    if (!user) {
        window.location.href = "/"
    }
    if (JSON.parse(user).userType == 3) {
        if (to.path.startsWith("/plantConsole")) {
            store.dispatch('switchMenus', 'platConsole');
            sessionStorage.setItem("showMemun", 1);
        } else if (to.path.startsWith("/plantProject")) {
            store.dispatch('switchMenus', 'plantProject');
            sessionStorage.setItem("showMemun", 3);
        } else if (to.path.startsWith("/dashboard")) {
            store.dispatch('switchMenus', 'platform');
            sessionStorage.setItem("showMemun", 3);
        }
    } else if (JSON.parse(user).userType == 2) {

        store.dispatch('switchMenus', 'tenant');
        sessionStorage.setItem("showMemun", 3);
        if (to.path.startsWith("/tenantProject")) {
            store.dispatch('switchMenus', 'tenantProject');
            sessionStorage.setItem("showMemun", 2);
        } else if (to.path.startsWith("/dashboard")) {
            store.dispatch('switchMenus', 'tenant');
            sessionStorage.setItem("showMemun", 3);
        }
    }else if(JSON.parse(user).userType == 1){
        store.dispatch('switchMenus', 'user');
        sessionStorage.setItem("showMemun", 3);
        if (to.path.startsWith("/user")) {
            store.dispatch('switchMenus', 'user');
            sessionStorage.setItem("showMemun", 2);
        } 
        else if (to.path.startsWith("/tenantProject")) {
            store.dispatch('switchMenus', 'tenantProject');
            sessionStorage.setItem("showMemun", 2);
        }
    }
    next();
})





Vue.prototype.deepClone = function (initalObj) {
    var obj = {};
    obj = JSON.parse(JSON.stringify(initalObj));
    return obj;
};


Vue.prototype.isEmpty = function (obj) {
    if (obj === null) return true;
    if (typeof obj === 'undefined') {
        return true;
    }
    if (typeof obj === 'string') {
        if (obj === "") {
            return true;
        }
        var reg = new RegExp("^([ ]+)|([　]+)$");
        return reg.test(obj);
    }
    return false;
}

const eventBus = {
    install(Vue, options) {
        Vue.prototype.$bus = new Vue()
    }
};

Vue.use(eventBus)

new Vue({
    el: '#app',
    router,
    store,
    template: '<App/>',
    components: { App }
})