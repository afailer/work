import request from '@/utils/request'

// export function getTenementList(query) {
//     return request({
//         url: '/cloud/node/queryNodeByPage',
//         method: 'get',
//         params: query
//     })
// }
export function getTenementList() {
    return request({
        url: '/cloud/node/queryNodeByPage?pageNum=1&pageSize=10',
        method: 'get',
        // params: query
    })
}


// export function createArticle(data) {
//     return request({
//         url: '/article/create',
//         method: 'post',
//         data
//     })
// }