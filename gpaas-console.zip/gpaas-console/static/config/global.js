const BASE_URL = '192.168.66.133:18181'  

export default {  
  BASE_URL  
} 






















