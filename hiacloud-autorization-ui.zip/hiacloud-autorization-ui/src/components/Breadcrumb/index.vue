<template>
  <el-breadcrumb class="app-breadcrumb" separator="/">
    <transition-group name="breadcrumb">
      <el-breadcrumb-item v-for="(item,index)  in levelList" :key="item.code">
        <span @click="backToZone(index)">{{item.name}}</span>
      </el-breadcrumb-item>
    </transition-group>
  </el-breadcrumb>
</template>

<script>
import { mapGetters } from "vuex";
export default {
  name: "breadcrumb",
  data() {
    return {
      levelList: [{ name: "本域", code: "" }]
    };
  },
  computed: {
    ...mapGetters(["user", "childZones"])
  },
  watch: {
    childZones: function() {
      let code = this.user.zoneCode;
      let level = [{ name: "本域", code: code }];
      level.splice(1, 0, ...this.childZones);
      this.levelList = level;
      console.log("watch:", level);
    }
  },
  methods: {
    backToZone(index) {
      // 能解决N多菜单问题
      if(index == this.levelList.length -1){
        return;
      }
      this.$store.dispatch("currentZoneCode", this.levelList[index].code);
      this.childZones.splice(index, this.childZones.length);
      this.$store.dispatch("childZones", this.childZones);
    }
  }
};
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.app-breadcrumb.el-breadcrumb {
  font-size: 14px;
  line-height: 36px;
  padding-left: 10px;
  background: #ecf0f5;
  .no-redirect {
    color: #97a8be;
    cursor: text;
  }
}
</style>
