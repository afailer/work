<template>
   <div class = "login-user"> 
     <span class="user-title">欢迎您：{{user.name}}</span> 
     <span class="user-logout" @click="logout">退出</span>
   </div>
</template>

<script>
import { mapGetters } from "vuex";
import { removeToken } from "@/utils/auth";
export default {
  name: "header-user",
  computed: {
    ...mapGetters(["user"])
  },
  methods: {
    logout() {
      removeToken();
      window.location.href = "/";
    }
  }
};
</script>

<style  rel="stylesheet/scss" lang="scss" >
.login-user {
  margin-right: 200px;
  .user-title {
    color: #fff;
    margin-right: 20px;
  }
  .user-logout {
    color: rgb(255, 255, 255);
    cursor: pointer;
    border: 1px solid white;
    padding: 5px 10px 5px 10px;
    border-radius: 7px;
  }
}
</style>