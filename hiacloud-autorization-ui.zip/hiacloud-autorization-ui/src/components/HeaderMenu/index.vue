<template>
	<div>
		<span class="header-region" >当前域：{{currentZone}}</span>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
export default {
  name: "header-menu",
  computed: {
    ...mapGetters(["childZones"])
  },
  data() {
    return {
      currentZone: "本域"
    };
  },
  watch: {
    childZones: function() {
      if (this.childZones.length > 0) {
        this.currentZone = this.childZones[this.childZones.length - 1].name;
        console.log(this.childZones.length + "  " + this.currentZone);
      } else {
        this.currentZone = "";
      }
    }
  }
};
</script>

<style>
.header-region {
  margin-left: 80px;
  font-weight: 700;
  color: white;
}
.el-select input {
  background-color: #2b3643;
}
</style>