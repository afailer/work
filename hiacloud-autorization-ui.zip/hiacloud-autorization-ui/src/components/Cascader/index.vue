<template>
	<div>
	  <ul v-for="item in options" :key="item.code">
	    <li :key="item.id" @click="handleItemClick(item)" v-bind:class="{ background: item.code == currentOption.code}" @contextmenu="showMenu($event,item)">
	    	<i class="iconfont icon-jiahao cascad-width" v-if="item.children.length > 0 && !item.isOpen" @click="spreadMenu($event,item)"></i>
				<i class="iconfont icon-jianhao cascad-width" v-if="item.children.length > 0 && item.isOpen" @click="spreadMenu($event,item)"></i>
	    	<i class="cascad-width" v-if="item.children.length == 0"></i>
				{{item.name}}
	    </li>
	    <cascader v-if="item.isOpen" :currentOption=currentOption :options="item.children" :handler="handler"></cascader>
	  </ul>
  </div>
</template>
<script>
  export default {
    name: 'cascader',
    props:[
			'options',
			'currentOption',
      'handler'
		],
    methods:{
      spreadMenu(event,item){
				item.isOpen = !item.isOpen
				event.stopPropagation();
      },
      handleItemClick(item){
				this.handler.handleItemClick(item);
				console.log(item)
      },
      showMenu(event,item){
      	event.cancelBubble=true;
				event.returnvalue=false;
      	this.handler.handleRightClick(event,item);
      	return false
			}
    },
    
    data() {
      return {
      }
    }
  }
</script>
<style type="text/css" lang="scss" scoped="scoped">
	ul{
		margin-left: 25px;
		
		li{
			text-align: left;
			cursor: pointer;
			line-height: 26px;
			height: 26px;
		}
		li:hover{
			background: rgb(145, 223, 252);
			color: #FFFFFF;
		}
		.background{
			background: #20a0ff;
			color: #FFFFFF;
		}
	}
	.cascad-width{
		display: inline-block;
		width: 15px;
	}
</style>