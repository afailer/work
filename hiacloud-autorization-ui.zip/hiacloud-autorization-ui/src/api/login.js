import request from '@/utils/request'
export function loginByUsername(loginName, password) {
    const data = {
        loginName,
        password
    }
    return request({
        url: '/uaa/sys/goLogin',
        method: 'post',
        data
    })
}