import request from '@/utils/request.js'
export function loadOrgs(zoneCode) {
    return request({
        method: 'get',
        url: 'http://192.168.66.161:8089/uaa/organization/getTree?zoneCode=' + zoneCode,
        responseType: 'stream'
    })
}

export function addOrg(data) {
    return request({
        url: '/uaa/organization/addOrg',
        method: 'post',
        data
    })
}
export function deleteOrg(data) {
    return request({
        url: '/uaa/organization/delOrgByCode?orgCode=' + data,
        method: 'delete'
    })
}
export function editeOrg(data) {
    return request({
        url: '/uaa/organization/editOrg',
        method: 'put',
        data: data
    })
}
export function getOrgUsers(code) {
    return request({
        url: '/uaa/organization/getOrgUsers?code=' + code, //?code=' + code,
        method: 'get',
        data: {}
    })
}
export function getUsersAll(pageNum, pageSize, zoneCode) {
    return request({
        url: '/uaa/user/userList?pageNum=' + pageNum + '&pageSize=' + pageSize + '&zoneCode=' + zoneCode,
        method: 'get'
    })
}
export function addUsers2Org(orgCode, userCodelist) {
    console.log(orgCode + "----------addUsers2Org")
    console.log(userCodelist)
    return request({
        url: '/uaa/organization/addUsers2Org?code=' + orgCode,
        method: 'post',
        data: userCodelist
    })
}
export function removeUsersFromOrg(orgCode, userCodelist) {
    console.log(orgCode + "----------removeUsersFromOrg")
    console.log(userCodelist)
    return request({
        url: '/uaa/organization/removeUsersFromOrg?orgCode=' + orgCode,
        method: 'post',
        data: userCodelist
    })
}