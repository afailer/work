import request from '@/utils/request'
// export function getRoleList(zoneCode, type,state) {

//     return request({
//         url: '/uaa/role/getRoleList?zoneCode=' + zoneCode + '&type='+ type+ '&state='+ state,
//         method: 'get',
//     })
// }

export function getRoleList(zoneCode, ) {
    return new Promise(function(resolve, reject) {
        request.get('/uaa/role/getRoleList?zoneCode=' + zoneCode).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        });
    })
}

export function addRole(data) {
    return new Promise(function(resolve, redirect) {
        request.post('/uaa/role/addRole', data).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}


export function detailRole(code) {
    return new Promise(function(resolve, redirect) {
        request.get('/uaa/role/getRole?code=' + code).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}


export function editRole(data) {
    return new Promise(function(resolve, redirect) {
        request.put('/uaa/role/editRole', data).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}

export function delRole(data) {

    return new Promise(function(resolve, redirect) {
        request.delete('/uaa/role/delRole?code=' + data).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}

//获取所有权限
export function getPermissionsInTree(zoneCode) {
    console.log("---------" + zoneCode)
    return request({
        url: '/uaa/permission/gePermissionsInTree?zoneCode=' + zoneCode,
        method: 'get'
    })
}
//拿到当前角色的权限
export function getRolePermissions(roleCode) {
    return request({
        url: '/uaa/role/getRolePermissions?roleCode=' + roleCode,
        method: 'get'
    })

}
// 保存权限
export function saveRolePermissions(roleCode, permissionCodeList) {
    return request({
        url: '/uaa/role/addRolePermissions?roleCode=' + roleCode,
        method: 'post',
        data: permissionCodeList
    })
}
//移除角色权限
export function removeRolePermissions(roleCode, permissionCodeList) {
    return request({
        url: '/uaa/role/removeRolePermissions?roleCode=' + roleCode,
        method: 'post',
        data: permissionCodeList
    })
}