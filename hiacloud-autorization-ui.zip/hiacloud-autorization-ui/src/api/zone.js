import request from '@/utils/request'

export function getZoneList(zoneCode, pageNum) {
    return new Promise(function(resolve, reject) {
        request.get('uaa/zone/list?pageNo=' + pageNum + '&pageSize=10' + '&zoneCode=' + zoneCode).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        });
    })
}
export function addNewZone(data) {
    return new Promise(function(resolve, reject) {
        request.post('/uaa/zone/addZone', data).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}
export function editNewZone(data) {
    return new Promise(function(resolve, reject) {
        request.post('uaa/zone/editZone', data).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}

export function setZoneManager(zoneCode, data) {
    return new Promise(function(resolve, reject) {
        request.post('uaa/zone/setZoneBuildInManager?zoneCode=' + zoneCode, data).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}
export function setZonePermissions(zoneCode, data) {
    return new Promise(function(resolve, reject) {
        request.post('uaa/zone/setZoneBuildInPermissionsStates?zoneCode=' + zoneCode, data).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}

export function getZoneManager(zoneCode) {
    return new Promise(function(resolve, reject) {
        request.get('uaa/zone/getZoneBuildInManager?zoneCode=' + zoneCode).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}

export function getZonePermissions(zoneCode) {
    return new Promise(function(resolve, reject) {
        request.get('uaa/zone/getZoneBuildInPermissions?zoneCode=' + zoneCode).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}

// 修改域管理员
export function modifyZoneManager(data) {
    return new Promise(function(resolve, reject) {
        request.post('uaa/user/editUser', data).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}

// 删除域
export function delZone(zoneCode) {
    return new Promise(function(resolve, reject) {
        request.delete('uaa/zone/delZoneByCode?code=' + zoneCode).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}

// 获取所有权限
export function getPermissionsInTree(zoneCode) {
    console.log("---------" + zoneCode)
    return request({
        url: '/uaa/permission/gePermissionsInTree?zoneCode=' + zoneCode,
        method: 'get'
    })
}

export function getZone(zoneCode) {
    return new Promise(function(resolve, reject) {
        request.get('uaa/zone/getZoneByCode?code=' + zoneCode).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}
export function getZoneLevel(userCode, zoneCode) {
    return new Promise(function(resolve, reject) {
        request.get('uaa/zone/getZoneLevel?userCode=' + userCode + "&zoneCode=" + zoneCode).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}