import request from '@/utils/request'

export function getUserList(zoneCode, pageNum) {
    return new Promise(function(resolve, reject) {
        request.get('/uaa/user/userList?pageNum=' + pageNum + '&pageSize=10' + '&zoneCode=' + zoneCode).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        });
    })
}
export function addUser(data) {
    return new Promise(function(resolve, reject) {
        request.post('/uaa/user/addUser', data).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}
export function editUser(data) {
    return new Promise(function(resolve, reject) {
        request.post('/uaa/user/editUser', data).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}
export function delUser(code) {
    return new Promise(function(resolve, reject) {
        request.delete('/uaa/user/delUser?code=' + code).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}
export function getUserRoles(code) {
    return new Promise(function(resolve, reject) {
        request.get('/uaa/user/role/getUserRoles?userCode=' + code).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}
export function getAllRoles(zoneCode) {
    return new Promise(function(resolve, reject) {
        request.get('/uaa/role/getRoleList?zoneCode=' + zoneCode + "&state=1").then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}
export function saveUserRoles(userCode, roleCodeList) {
    return new Promise(function(resolve, reject) {
        request.post('/uaa/user/role/saveUserRoles?userCode=' + userCode, roleCodeList).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}

export function getUserPermissions(code) {
    return new Promise(function(resolve, reject) {
        request.get('/uaa/user/permission/getUserPermissions?userCode=' + code).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}
export function getUserRolePermissions(code) {
    return new Promise(function(resolve, reject) {
        request.get('/uaa/role/getUserRolePermissions?userCode=' + code).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}
export function getAllPermissions(zoneCode) {
    return new Promise(function(resolve, reject) {
        request.get('/uaa/permission/gePermissionsInTree?zoneCode=' + zoneCode).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        });
    })
}
export function saveUserPermissions(userCode, roleCodeList) {
    return new Promise(function(resolve, reject) {
        request.post('/uaa/user/permission/saveUserPermissions?userCode=' + userCode, roleCodeList).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}