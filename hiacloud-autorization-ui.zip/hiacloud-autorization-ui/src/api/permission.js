import request from '@/utils/request'

export function getPermissionTree(zoneCode) {
    return new Promise(function(resolve, reject) {
        request.get('/uaa/permission/gePermissionsInTree?zoneCode=' + zoneCode).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        });
    })
}
export function addPermission(data) {
    return new Promise(function(resolve, redirect) {
        request.post('/uaa/permission/addPermission', data).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}
export function editPermission(data) {
    return new Promise(function(resolve, redirect) {
        request.post('/uaa/permission/editPermission', data).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}
export function delPermission(code) {
    return new Promise(function(resolve, redirect) {
        request.delete('/uaa/permission/delPermission?code=' + code).then((res) => {
            resolve(res)
        }).catch(function(error) {
            reject(error)
        })
    })
}