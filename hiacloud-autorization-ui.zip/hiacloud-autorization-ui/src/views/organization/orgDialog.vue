<template>
<div>
	<el-dialog
		:title=title
		width="40%"
		:visible.sync="orgDialog"
		>
		<el-form :model="form">
			<el-form-item label="名称" :label-width="formLabelWidth">
				<el-input v-model="form.name" auto-complete="off"></el-input>
			</el-form-item>
		</el-form>
		<el-form :model="form">
			<el-form-item label="描述" :label-width="formLabelWidth">
				<el-input v-model="form.description" auto-complete="off"></el-input>
			</el-form-item>
		</el-form>
		<div slot="footer" class="dialog-footer" style="overflow:hidden">
			<el-button @click="orgDialog=false" style="float:right !important">取 消</el-button>
			<el-button type="primary" @click="handleSubmit" style="margin:0px 10px;float:right !important">确 定</el-button>
		</div>
	</el-dialog>
</div>
</template>
<script>
import { editeOrg } from "@/api/org.js";
export default {
  name: "org-dialog",
  props: ["submit", "loadOrgs"],
  data() {
    return {
      title: "创建组织",
      formLabelWidth: "80px",
      orgDialog: false,
      isEdit: false,
      form: {}
    };
  },
  methods: {
    handleSubmit() {
      if (this.form.name == undefined || this.form.name.trim() == "") {
        this.$Toast("名称为必填", false);
        return;
      }
      // if (this.form.type != undefined) {
      //   if (this.form.type.trim().length > 2) {
      //     this.$Toast("类型需要1位或2位的整数", false);
      //     return;
      //   }
      //   if (this.form.type.trim() != "") {
      //     let reg = /\D/;
      //     let typeRes = reg.test(this.form.type.trim());
      //     if (typeRes) {
      //       this.$Toast("类型需要1位或2位的整数", false);
      //       return;
      //     }
      //   }
      // }
      this.submit(this.form);
      this.orgDialog = false;
    }
  },
  created() {
    this.$bus.$on("orgcreate", () => {
      this.title = "创建组织";
      this.isEdit = false;
      this.form = {};
      this.orgDialog = true;
    });
  },
  beforeDestroy() {
    this.$bus.$off("orgcreate");
  }
};
</script>