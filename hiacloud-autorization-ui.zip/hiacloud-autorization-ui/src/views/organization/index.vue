<template>
	<div class="container">
		<!-- <p class="title">组织管理</p> -->
		<div class="createbtn">
			<el-button size="small" icon="el-icon-plus" type="primary" @click="createRootOrg">创建组织</el-button>
		</div>
		<div class="table">
			<el-row :gutter="24" >
  		<el-col :span="9">
  			<cascader :options="options" :currentOption="item" :handler="handler" style=" border: 1px solid #dfe0e2;paddingTop:10px; min-height: 700px;"></cascader>
  		</el-col>
  		<el-col :span="15">
  			<el-tabs type="border-card">
				  <el-tab-pane label="用户" v-loading="loading">
						<div v-if="!this.item==''">
							<el-checkbox-group v-model="checkedOrgUsers" style="height:360px">
								<el-checkbox style="width:150px;margin:0px" :label="user.code" v-for="user in zoneUsers" :key="user.id">{{user.name}}</el-checkbox>
							</el-checkbox-group>
						<el-button type="primary" @click="saveOrgUsers" >保存</el-button>
						</div>
				  </el-tab-pane>
				  <el-tab-pane label="组织信息">
						<div div v-if="!this.item==''">
						<el-form :model="form">
							<el-form-item label="名称" :label-width="formLabelWidth">
								<el-input v-model="form.name" auto-complete="off"></el-input>
							</el-form-item>
						</el-form>
						<el-form :model="form">
							<el-form-item label="描述" :label-width="formLabelWidth">
								<el-input v-model="form.description" auto-complete="off"></el-input>
							</el-form-item>
						</el-form>

				  	<el-button type="primary" @click="editOrgInfo" >保存</el-button>
						</div>
				  </el-tab-pane>
				</el-tabs>
  		</el-col>
 		</el-row>
		</div>
		
    <div class="pop" ref="popMenu">
    	<p class="menuItem" @click="createOrg">创建下级组织</p>
    	<p class="menuItem" @click="deleteOrg">删除组织</p>
    </div>
		<org-dialog :submit=submit :loadOrgs=loadOrgs></org-dialog>
	</div>
	
</template>

<script>
import cascader from "@/components/Cascader";
import orgDialog from "./orgDialog";
import { mapGetters } from "vuex";
import beforeEach from "@/utils/beforeEach.js";
import {
  deleteOrg,
  editeOrg,
  getOrgUsers,
  getUsersAll,
  addUsers2Org,
  removeUsersFromOrg
} from "@/api/org.js";
export default {
  name: "organization",
  mixins: [beforeEach],
  data() {
    return {
      formLabelWidth: "50px",
      loading: "",
      tempTime: 0,
      centerDialogVisible: false,
      activeName: "",
      org: false,
      item: "",
      form: {},
      options: [],
      zoneUsers: [],
      checkedOrgUsers: [],
      currentOrgUsers: [],
      handler: {
        handleItemClick: this.handleOrgItemClick,
        handleRightClick: this.handleRightClick
      }
    };
  },
  computed: {
    ...mapGetters(["currentZoneCode"])
  },
  watch: {
    currentZoneCode: function() {
      this.loadOrgs();
      this.getAllUserByZoneCode();
    }
  },
  methods: {
    processData(array) {
      //给树形菜单添加参数
      for (let l = 0; l < array.length; l++) {
        array[l].isOpen = false;
        if (array[l].children.length > 0) {
          this.processData(array[l].children);
        }
      }
    },
    editOrgInfo() {
      //右面编辑
      if (this.form.name == undefined || this.form.name.trim() == "") {
        this.$Toast("名称为必填", false);
        return;
      }
      editeOrg(this.form).then(res => {
        this.$Toast(res);
        this.loadOrgs();
      });
    },
    handleOrgItemClick(item) {
      //点击每一项，获取用户信息
      this.item = item;
      this.form = {};
      Object.assign(this.form, item);
      this.loadCurrentOrgUsers();
    },
    loadCurrentOrgUsers() {
      this.loading = "loading";
      getOrgUsers(this.item.code).then(res => {
        this.checkedOrgUsers.splice(0, this.checkedOrgUsers.length);
        for (let l = 0; l < res.data.userList.length; l++) {
          if (
            res.data.userList[l] !== null &&
            res.data.userList[l] !== undefined
          ) {
            this.checkedOrgUsers.push(res.data.userList[l].code);
          }
        }
        this.currentOrgUsers = this.deepClone(this.checkedOrgUsers);
        this.loading = "";
      });
    },
    saveOrgUsers() {
      this.loading = "loading";
      let addUsers = [];
      let reduceUsers = [];
      for (let l = 0; l < this.checkedOrgUsers.length; l++) {
        if (this.currentOrgUsers.getIndex(this.checkedOrgUsers[l]) == -1) {
          addUsers.push(this.checkedOrgUsers[l]);
        }
      }
      for (let l = 0; l < this.currentOrgUsers.length; l++) {
        if (this.checkedOrgUsers.getIndex(this.currentOrgUsers[l]) == -1) {
          reduceUsers.push(this.currentOrgUsers[l]);
        }
      }
      if (addUsers.length > 0) {
        this.tempTime++;
        addUsers2Org(this.item.code, addUsers).then(res => {
          this.tempTime--;
          if (this.tempTime == 0) {
            this.loadCurrentOrgUsers();
          }
          this.$Toast(res);
        });
      }
      if (reduceUsers.length > 0) {
        this.tempTime++;
        removeUsersFromOrg(this.item.code, reduceUsers).then(res => {
          this.tempTime--;
          if (this.tempTime == 0) {
            this.loadCurrentOrgUsers();
          }
          this.$Toast(res);
        });
      }
    },
    getAllUserByZoneCode() {
      getUsersAll(0, 10000, this.currentZoneCode).then(res => {
        this.zoneUsers = res.data.obj.result;
      });
    },
    loadOrgs() {
      this.$http
        .get("/uaa/organization/getTree?zoneCode=" + this.currentZoneCode)
        .then(res => {
          this.processData(res.data.orgList);
          this.options = res.data.orgList;
          this.item = "";
        });
    },
    createOrg() {
      //打开创建组织的dialog
      this.$bus.$emit("orgcreate", "");
    },
    createRootOrg() {
      this.item = "";
      this.createOrg();
    },
    deleteOrg() {
      //右键删除组织事件
      this.$confirm("确定删除“ " + this.item.name + " ”组织?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          deleteOrg(this.item.code).then(res => {
            this.$Toast(res);
            this.loadOrgs();
          });
        })
        .catch(() => {
          this.$Toast("已取消删除", false);
        });
    },
    addOrgs(orgData) {
      //添加组织，请求网络
      this.$http.post("/uaa/organization/addOrg", orgData).then(res => {
        this.$Toast(res);
        this.loadOrgs();
      });
    },

    submit(orgData) {
      //添加组织
      debugger;
      if (this.item == "") {
        orgData.zoneCode = this.currentZoneCode;
      } else {
        //在组织下添加新的组织
        orgData.parentCode = this.item.code;
        orgData.zoneCode = this.item.zoneCode;
      }
      this.addOrgs(orgData);
    },
    handleRightClick(event, item) {
      //树形菜单右键事件，显示操作菜单
      this.item = item;
      this.form = {};
      Object.assign(this.form, item);
      this.centerDialogVisible = true;
      event.preventDefault();
      this.$refs.popMenu.style.left = event.clientX + "px";
      this.$refs.popMenu.style.top = event.clientY + "px";
      this.$refs.popMenu.style.visibility = "visible";
    }
  },
  components: {
    cascader,
    orgDialog
  },
  mounted: function() {
    window.addEventListener(
      "click",
      () => {
        this.$refs.popMenu.style.visibility = "hidden";
      },
      true
    );

    this.loadOrgs();
    this.getAllUserByZoneCode();
    Array.prototype.getIndex = function(obj) {
      if (obj == undefined) {
        return -1;
      }
      for (let l = 0; l < this.length; l++) {
        if (this[l] == obj) {
          return l;
        }
      }
      return -1;
    };
  }
};
</script>

<style rel="stylesheet/scss" lang="scss">
@import "src/styles/mixin.scss";

.pop {
  position: absolute;
  width: 100px;
  border: 1px solid #ccc;
  left: 279px;
  background: #ffffff;
  border-bottom: 0px;
  visibility: hidden;
  .menuItem {
    text-align: center;
    height: 30px;
    line-height: 30px;
    font-size: x-small;
    cursor: pointer;
    border-bottom: 1px solid #ccc;
  }
}
.msg {
  padding: 10px 0;
}
.content {
  margin-top: 20px;
}
</style>
