<template>
  <div>
    <el-dialog
      :title=title
      width="40%"
      :visible.sync="dialogFormVisible">
     <icon-selector :getIcon="getIcon"></icon-selector>
    <el-alert
      v-show="disable"
      :closable="false"
      title="该菜单是内置菜单，不能编辑"
      type="warning">
    </el-alert>
		<el-form :model="form" :rules="rules" :label-width="formLabelWidth">
			<el-form-item label="类型" >
				<el-radio v-model="form.type" label="3">目录</el-radio>
				<el-radio v-model="form.type" label="0">菜单</el-radio>
        <el-radio v-model="form.type" label="1">按钮</el-radio>
        <el-radio v-model="form.type" label="2">接口</el-radio>
			</el-form-item>
			<el-form-item label="上级节点">
				<el-input v-model="parent.name" auto-complete="off" :disabled="true"></el-input>
			</el-form-item>
			<el-form-item label="名称" prop="name">
				<el-input v-model="form.name" auto-complete="off"></el-input>
			</el-form-item>
			<el-form-item label="英文名称" prop="ename">
				<el-input v-model="form.ename" auto-complete="off"></el-input>
			</el-form-item>
      <el-form-item label="图标">
				<el-input v-model="form.icon" auto-complete="off" :disabled="true">
          <i  slot="prepend" ref="icon" class="fa fa-image" style="width:50px;text-align:center"></i>
          <el-button slot="append" @click="openSelectIcon">...</el-button>
        </el-input>
			</el-form-item>
			<el-form-item label="序号" prop="orderNo">
				<el-input type="number" v-model.number="form.orderNo" auto-complete="off"></el-input>
			</el-form-item>
			<el-form-item label="值">
				<el-input v-model="form.value" auto-complete="off"></el-input>
			</el-form-item>
			<el-form-item label="值2">
				<el-input v-model="form.value2" auto-complete="off"></el-input>
			</el-form-item>
			<el-form-item label="描述">
				<el-input v-model="form.description" auto-complete="off"></el-input>
			</el-form-item>
		</el-form>
		<div slot="footer" class="dialog-footer" style="overflow:hidden">
			<el-button @click="dialogFormVisible=false" style="float:right !important">取 消</el-button>
			<el-button type="primary" @click="submit(form)" :disabled="disable"
        style="margin:0px 10px;float:right !important">确 定</el-button>
		</div>
	</el-dialog>
</div>
</template>

<script>
import iconSelector from "./iconSelector";
export default {
  name: "permission-dialog",
  data() {
    return {
      disable: false,
      form: {
        type: "0"
      },
      parent: {},
      title: "创建许可",
      formLabelWidth: "100px",
      dialogFormVisible: false,
      innerVisible: false,
      rules: {
        name: [{ required: true, message: "请输入许可名称", trigger: "blur" }],
        ename: [
          { required: true, message: "请输入许可英文名称", trigger: "blur" }
        ],
        orderNo: [{ type: "number", required: true, min: 0 }]
      }
    };
  },
  components: {
    iconSelector
  },
  props: ["savePermission"],
  methods: {
    submit(data) {
      this.savePermission(data);
      this.dialogFormVisible = false;
    },
    openSelectIcon() {
      this.$bus.$emit("iconSelector", "");
    },
    getIcon(icon) {
      this.$set(this.form, "icon", icon);
      this.$refs.icon.setAttribute("class", icon);
    }
  },
  created() {
    this.$bus.$on("editPermission", item => {
      this.title = "编辑许可";
      this.disable = false;
      if (item.buildin) {
        this.disable = true;
      }
      this.form = {
        type: "1"
      };
      this.parent = {};
      this.form = Object.assign({}, item);
      this.parent.name = this.form.parentName;
      this.$nextTick(function() {
        if (this.$refs.icon != undefined) {
          this.$refs.icon.setAttribute("class", this.form.icon);
        }
      });

      this.dialogFormVisible = true;
    });
    this.$bus.$on("createPermission", item => {
      this.title = "创建子节点";
      this.disable = false;
      this.form = {
        type: "1"
      };
      this.parent = {};
      this.form.orderNo = 0;
      this.form.type = "0";
      if (item.code) {
        this.form.parentCode = item.code;
      }
      this.parent = Object.assign({}, item);
      this.$nextTick(function() {
        if (this.$refs.icon != undefined) {
          this.$refs.icon.setAttribute("class", "fa fa-image");
        }
      });
      this.dialogFormVisible = true;
    });
  }
};
</script>

<style rel="stylesheet/scss" lang="scss" module>
@import "src/styles/mixin.scss";
.dialog {
  height: 900px;
}
</style>
