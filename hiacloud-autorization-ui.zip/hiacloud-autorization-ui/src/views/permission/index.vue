<template>
  <div>
	  <permission-dialog :savePermission="savePermission"></permission-dialog>
    <div class="createbtn">
      <el-button type="primary" icon="el-icon-plus" size="small" @click="openCreateDialog">创建许可</el-button>
    </div>
    <div class="table" v-loading = 'loading'>
      <tree-grid 
        :items='data' 
        :columns='columns'
        @on-row-click='rowClick'
        @on-selection-change='selectionClick'
        @on-sort-change='sortClick'
      ></tree-grid>
    </div>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import permissionDialog from "./permissionDialog";
import {
  getPermissionTree,
  addPermission,
  editPermission,
  delPermission
} from "@/api/permission.js";
import { formatDate } from "@/filters";
import TreeGrid from "./treeGrid";
import beforeEach from "@/utils/beforeEach.js";
export default {
  mixins: [beforeEach],
  data() {
    return {
      loading: false,
      checkRows: [],
      columns: [
        /*    {
          type: "selection",
          width: "12"
        }, */
        /*         {
          title: "编号",
          key: "code"
        }, */
        {
          title: "名称",
          key: "name"
        },
        {
          title: "英文名",
          key: "ename"
        },
        {
          title: "图标",
          key: "icon",
          width: "50",
          formator: item => {
            if (item.icon) {
              return '<i class="' + item.icon + '"></i>';
            }
          }
        },
        {
          title: "类型",
          key: "type",
          align: "center",
          width: "50",
          formator: item => {
            if (item.type === "0") {
              return '<i class="label label-success">菜单</i>';
            } else if (item.type === "1") {
              return '<i class="label label-info">按钮</i>';
            } else if (item.type === "2") {
              return '<i class="label label-primary">接口</i>';
            } else if (item.type === "3") {
              return '<i class="label label-primary">目录</i>';
            } else {
              return '<i class="label label-defalut">其他</i>';
            }
          }
        },
        {
          title: "创建时间",
          key: "createTime",
          width: "150",
          formator: item => {
            if (item.createTime) {
              return formatDate(item.createTime, "yyyy/MM/dd hh:mm");
            }
          }
        },
        {
          title: "操作",
          type: "action",
          width: "300",
          actions: [
            {
              type: "primary",
              text: "编辑"
            },
            {
              type: "primary",
              text: "创建子节点"
            },
            {
              type: "danger",
              text: "删除"
            }
          ]
        }
      ],
      data: []
    };
  },
  components: {
    TreeGrid,
    permissionDialog
  },
  computed: {
    ...mapGetters(["currentZoneCode"])
  },
  watch: {
    currentZoneCode: function() {
      this.loadData();
    }
  },
  methods: {
    // 创建许可
    openCreateDialog() {
      this.$bus.$emit("createPermission", {});
    },
    rowClick(data, event, index, action) {
      // 编辑许可
      if (action === "编辑") {
        this.$bus.$emit("editPermission", data);
      } else if (action === "创建子节点") {
        this.$bus.$emit("createPermission", data);
      } else if (action === "删除") {
        this.$confirm("你正要删除该许可, 是否继续?", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(() => {
          delPermission(data.code)
            .then(res => {
              const data = res.data;
              if (data.success) {
                this.$message({ message: "删除许可成功！", type: "success" });
                this.loadData(1);
              } else {
                this.$message({
                  message: "删除许可失败:" + data.msg,
                  type: "error"
                });
              }
            })
            .catch(error => {
              this.$message({
                message: "删除许可失败:" + error,
                type: "error"
              });
            });
        });
      }
    },
    selectionClick(arr) {
      this.checkRows.length = 0;
      this.checkRows = arr;
      // console.log("选中数据id数组:" + arr);
    },
    sortClick(key, type) {
      console.log("排序字段:" + key);
      console.log("排序规则:" + type);
    },
    // 保存数据
    savePermission(data) {
      // 如果域编号为空，添加编号
      if (!data.zoneCode) {
        data.zoneCode = this.currentZoneCode;
      }
      // 编辑操作
      if (data.code) {
        editPermission(data)
          .then(res => {
            const data = res.data;
            if (data.success) {
              this.$message({ message: "编辑许可成功！", type: "success" });
              this.loadData();
            } else {
              this.$message({
                message: "编辑许可失败:" + data.msg,
                type: "error"
              });
            }
          })
          .catch(error => {
            this.$message({ message: "编辑许可失败:" + error, type: "error" });
          });
      } else {
        // 增加操作
        addPermission(data)
          .then(res => {
            const data = res.data;
            if (data.success) {
              this.$message({ message: "创建许可成功！", type: "success" });
              this.loadData();
            } else {
              this.$message({
                message: "创建许可失败:" + data.msg,
                type: "error"
              });
            }
          })
          .catch(error => {
            this.$message({ message: "创建许可失败:" + error, type: "error" });
          });
      }
    },
    // 加载数据列表
    loadData() {
      this.loading = true;
      getPermissionTree(this.currentZoneCode)
        .then(res => {
          const data = res.data;
          if (data.success) {
            this.data = data.obj;
          } else {
            console.log(error);
          }
          this.loading = false;
        })
        .catch(error => {
          console.log(error);
          this.loading = false;
        });
    }
  },
  mounted() {
    this.loadData();
  }
};
</script>

<style rel="stylesheet/scss" lang="scss">
td {
  .label {
    display: inline;
    padding: 0.2em 0.6em 0.3em;
    font-size: 75%;
    font-weight: 700;
    line-height: 1;
    color: #fff;
    text-align: center;
    white-space: nowrap;
    vertical-align: baseline;
    border-radius: 0.25em;
  }

  .label-default {
    background-color: #777;
  }

  .label-default[href]:focus,
  .label-default[href]:hover {
    background-color: #5e5e5e;
  }

  .label-primary {
    background-color: #337ab7;
  }

  .label-primary[href]:focus,
  .label-primary[href]:hover {
    background-color: #286090;
  }

  .label-success {
    background-color: #5cb85c;
  }

  .label-success[href]:focus,
  .label-success[href]:hover {
    background-color: #449d44;
  }

  .label-info {
    background-color: #5bc0de;
  }

  .label-info[href]:focus,
  .label-info[href]:hover {
    background-color: #31b0d5;
  }

  .label-warning {
    background-color: #f0ad4e;
  }

  .label-warning[href]:focus,
  .label-warning[href]:hover {
    background-color: #ec971f;
  }

  .label-danger {
    background-color: #d9534f;
  }

  .label-danger[href]:focus,
  .label-danger[href]:hover {
    background-color: #c9302c;
  }
}
</style>