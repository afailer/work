<template>
  <div>
    <el-dialog
     :title=title
     width="40%"
     :visible.sync="dialogFormVisible">
		<el-form :model="form" v-if="this.title == '编辑用户'">
			<el-form-item label="名称" :label-width="formLabelWidth">
				<el-input v-model="form.name" auto-complete="off"></el-input>
			</el-form-item>
			<el-form-item label="登录名称" :label-width="formLabelWidth">
				<el-input v-model="form.loginName" auto-complete="off"></el-input>
			</el-form-item>
       <el-form-item label="修改密码" :label-width="formLabelWidth">
        <el-checkbox v-model="checked"></el-checkbox>
      </el-form-item>
      <el-form-item label="新密码" :label-width="formLabelWidth" v-if="this.checked">
				<el-input v-model="password" auto-complete="off" type="password" placeholder="如需修改密码，请输入新密码"></el-input>
			</el-form-item>
      <el-form-item label="确认密码" :label-width="formLabelWidth" v-if="this.checked">
				<el-input v-model="newpassword" auto-complete="off" type="password"></el-input>
			</el-form-item>
		</el-form>

    <el-form :model="form" v-else>
			<el-form-item label="名称" :label-width="formLabelWidth">
				<el-input v-model="form.name" auto-complete="off"></el-input>
			</el-form-item>
			<el-form-item label="登录名称" :label-width="formLabelWidth">
				<el-input v-model="form.loginName" auto-complete="off"></el-input>
			</el-form-item>
       <el-form-item label="密码" :label-width="formLabelWidth">
				<el-input v-model="password" auto-complete="off" type="password"></el-input>
			</el-form-item>
      <el-form-item label="确认密码" :label-width="formLabelWidth">
				<el-input v-model="newpassword" auto-complete="off" type="password"></el-input>
			</el-form-item>
		</el-form>
 
		<div slot="footer" class="dialog-footer" style="overflow:hidden">
			<el-button @click="dialogFormVisible=false" style="float:right !important">取 消</el-button>
			<el-button type="primary" @click="submit(form)" style="margin:0px 10px;float:right !important">确 定</el-button>
		</div>
	</el-dialog>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import { addUser, editUser } from "@/api/user.js";
import { validatePassWord } from "@/utils/validate.js";
export default {
  name: "editeuser-dialog",
  data() {
    return {
      password: "",
      newpassword: "",
      form: {},
      title: "编辑用户",
      checked: false,
      formLabelWidth: "100px",
      dialogFormVisible: false
    };
  },
  props: ["reload"],
  computed: {
    ...mapGetters(["currentZoneCode"])
  },
  methods: {
    submit(data) {
      if (this.password != this.newpassword) {
        this.$message({ message: "两次密码不一致！", type: "warning" });
        return;
      }
      if (this.title == "创建用户" || this.checked) {
        //创建用户；修改用户信息
        if (!validatePassWord(this.password)) {
          this.$message({
            message: "密码需要6-12位的字母或数字",
            type: "warning"
          });
          return;
        }
      }
      data.password = this.password;
      this.saveUser(data);
    },
    // 保存数据
    saveUser(data) {
      // 如果域编号为空，添加编号
      if (!data.zoneCode) {
        data.zoneCode = this.currentZoneCode;
      }
      // 编辑操作
      if (data.code) {
        editUser(data)
          .then(res => {
            const data = res.data;
            if (data.success) {
              this.$message({ message: "编辑用户成功！", type: "success" });
              this.dialogFormVisible = false;
              this.reload(1);
            } else {
              this.$message({
                message: "编辑用户失败:" + data.msg,
                type: "error"
              });
            }
          })
          .catch(error => {
            this.$message({ message: "编辑用户失败:" + error, type: "error" });
          });
      } else {
        // 增加操作
        addUser(data)
          .then(res => {
            const data = res.data;
            if (data.success) {
              this.$message({ message: "创建用户成功！", type: "success" });
              this.dialogFormVisible = false;
              this.reload(1);
            } else {
              this.$message({
                message: "创建用户失败:" + data.msg,
                type: "error"
              });
            }
          })
          .catch(error => {
            this.$message({ message: "创建用户失败:" + error, type: "error" });
          });
      }
    }
  },
  created() {
    this.$bus.$on("editUser", item => {
      this.title = "编辑用户";
      this.password = "";
      this.newpassword = "";
      this.checked = false;
      this.form = Object.assign({}, item);
      this.dialogFormVisible = true;
    });

    this.$bus.$on("createUser", () => {
      this.title = "创建用户";
      this.password = "";
      this.newpassword = "";
      this.checked = false;
      this.form = {};
      this.dialogFormVisible = true;
    });
  }
};
</script>
