<template>
  <div>
    <el-dialog
        title="权限设置"
        :visible.sync="dialogVisible">
            <el-tabs type="border-card"  v-model="activeTable" >
                <el-tab-pane label="角色" name="user-role">
                    <div v-loading="roleLoading">
                        <el-checkbox-group v-model="userRoles">
                            <el-checkbox v-for="(role,index) in roles" :label="role.code" :key="role.code">{{role.name}}</el-checkbox>
                        </el-checkbox-group>
                        <div style="overflow:hidden">
                            <el-button @click="dialogVisible = false" style="float:right">取 消</el-button>
                            <el-button type="primary" @click="saveUserRoles()" style="float:right; margin:0px 10px">确 定</el-button>
                        </div>
                    </div>
                </el-tab-pane>
                <el-tab-pane label="权限" name="user-permission">
                    <div v-loading="permissionLoading">
                        <el-tree
                            :data="permissions"
                            show-checkbox
                            node-key="code"
                            ref="tree"
                            :props="defaultProps"
                            :default-checked-keys="userPermissions"
                            :render-content="renderContent">
                        </el-tree>
                        <div>
                            <el-button @click="dialogVisible = false" style="float:right">取 消</el-button>
                            <el-button type="primary" @click="saveUserPermissions()" style="float:right;margin:0 10px">确 定</el-button>
                        </div>
                    </div>
                </el-tab-pane>
            </el-tabs>
    </el-dialog>
  </div>
</template>
<script>
import { getAllRoles, getUserRoles, saveUserRoles, 
    getAllPermissions, getUserPermissions,getUserRolePermissions, saveUserPermissions} from "@/api/user.js";
export default{
    name:"userpermission-dialog",
    data(){
        return{
            permissionLoading:false,
            roleLoading:false,
            activeTable:"user-role",
            user:{},
            roles:[],
            userRoles:[],
            permissions:[],
            userPermissions:[],
            dublePermissions:[],
            userRolePermissions:[],
            defaultProps: {
                children: 'children',
                label: 'name'
            },

            dialogVisible:false
        }
    },
    // props:['userCode'],
    methods: {
        saveUserRoles(){
            saveUserRoles(this.user.code,this.userRoles).then(res => {
                const data = res.data;
                if (data.success) {
                    this.$message({ message: "保存用户角色成功！", type: "success" });
                    this.dialogVisible = false;
                } else {
                    this.$message({ message: "保存用户角色失败:" + data.msg, type: "error" });
                }
            }).catch(error => {
                 this.$message({ message: "保存用户角色失败:" + error, type: "error" });
            });
        },
        saveUserPermissions(){
            var targetData = [];
            this.$refs.tree.getCheckedKeys().forEach(element =>{
                if(this.userRolePermissions.indexOf(element) < 0){
                    targetData.push(element);
                }
            });

            targetData = targetData.concat(this.dublePermissions);

            saveUserPermissions(this.user.code,targetData).then(res => {
                const data = res.data;
                if (data.success) {
                    this.$message({ message: "保存用户权限成功！", type: "success" });
                    this.dialogVisible = false;
                } else {
                    this.$message({ message: "保存用户权限失败:" + data.msg, type: "error" });
                }
            }).catch(error => {
                 this.$message({ message: "保存用户权限失败:" + error, type: "error" });
            });
        },
        transType(type){
            if (type === "0") {
              return '<i class="label label-success">菜单</i>';
            }else if(type === "1"){
              return '<i class="label label-info">按钮</i>';
            }else if(type === "2"){
              return '<i class="label label-primary">接口</i>';
            }else if(type === "3"){
              return '<i class="label label-primary">目录</i>';
            }else{
              return '<i class="label label-defalut">其他</i>';
            }
        },
        renderContent(h, { node, data, store }) {
            return (
            <span class="custom-tree-node">
                <span>
                    <i class={node.icon}></i>
                    {node.label}
                </span>
            </span>);
        }
    },
    created () {
        this.$bus.$on("editUserPermission",(item)=>{
            this.user= Object.assign({}, item);
            this.activeTable = 'user-role';
            this.roleLoading = true;
            this.permissionLoading = true;

            // 用户角色
            this.roles=[];
            this.userRoles=[];
            getAllRoles(this.user.zoneCode).then(res => {
                const data = res.data;
                if (data.success) {
                    this.roles = data.obj;
                } else {
                    console.log(error);
                }
            })
            .then(getUserRoles(this.user.code).then(res => {
                const data = res.data;
                if (data.success) {
                    data.obj.forEach(element => {
                        this.userRoles.push(element.roleCode);
                    });
                } else {
                    console.log(error);
                }
                this.roleLoading = false;
            })).catch(error => {
                console.log(error);
            });
            
            // 用户权限
            this.permissions=[];
            this.userPermissions=[];
            this.userRolePermissions=[];

            getUserRolePermissions(this.user.code).then(res => {
                const data = res.data;
                if (data.success) {
                    data.obj.forEach(element => {
                        this.userRolePermissions.push(element.code);
                    });
                    
                } else {
                    console.log(error);
                }
                return  getUserPermissions(this.user.code);
            }).then(res => {
                const data = res.data;
                if (data.success) {
                    var arr = [];
                    data.obj.forEach(element => {
                        if(this.userRolePermissions.indexOf(element.permissionCode)>-1){
                            this.dublePermissions.push(element.permissionCode);
                        }else{
                            arr.push(element.permissionCode);
                        }
                    });
                    this.userPermissions = arr.concat(this.userRolePermissions);
                } else {
                    console.log(error);
                }
                return  getAllPermissions(this.user.zoneCode);
            }).then(res => {
                const data = res.data;
                if (data.success) {
                    this.permissions = data.obj;

                    this.permissions.forEach(el =>{
                        if(this.userRolePermissions.indexOf(el.code)>-1){
                            el.disabled = true;
                        }else{
                            el.disabled = false;
                        }
                    });
                } else {
                    console.log(error);
                }
                // permissionLoading.close();
                this.permissionLoading = false;
            }).catch(error => {
                console.log(error);
            });
                this.dialogVisible=true;
        
        })
    },
    beforeDestroy () {
        this.$bus.$off('editUserPermission');
    }
}
</script>
<style>
.label {
    display: inline;
    padding: 0.2em 0.6em 0.3em;
    font-size: 75%;
    font-weight: 700;
    line-height: 1;
    color: #fff;
    text-align: center;
    white-space: nowrap;
    vertical-align: baseline;
    border-radius: 0.25em;
  }

  .label-default {
    background-color: #777;
  }

  .label-default[href]:focus,
  .label-default[href]:hover {
    background-color: #5e5e5e;
  }

  .label-primary {
    background-color: #337ab7;
  }

  .label-primary[href]:focus,
  .label-primary[href]:hover {
    background-color: #286090;
  }

  .label-success {
    background-color: #5cb85c;
  }

  .label-success[href]:focus,
  .label-success[href]:hover {
    background-color: #449d44;
  }

  .label-info {
    background-color: #5bc0de;
  }

  .label-info[href]:focus,
  .label-info[href]:hover {
    background-color: #31b0d5;
  }

  .label-warning {
    background-color: #f0ad4e;
  }

  .label-warning[href]:focus,
  .label-warning[href]:hover {
    background-color: #ec971f;
  }

  .label-danger {
    background-color: #d9534f;
  }

  .label-danger[href]:focus,
  .label-danger[href]:hover {
    background-color: #c9302c;
  }
</style>
