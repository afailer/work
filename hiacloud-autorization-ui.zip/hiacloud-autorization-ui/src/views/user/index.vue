<template>
  <div>
		<!-- <p class="title">用户管理</p> -->
		<userpermission-dialog></userpermission-dialog>
		<editeuserDialog :reload=loadData></editeuserDialog>
		<div class="createbtn">
			<el-button type="primary" icon="el-icon-plus" size="small" @click="openCreateUserDialog">创建用户</el-button>
		</div>
		
	  <el-table
	    :data="users"
	    border
	    class="table"
	    >
	    <el-table-column
	      prop="code"
	      label="编号"
	      width="200">
	    </el-table-column>
	    <el-table-column
	      prop="name"
	      label="名称"
        width="200">
	    </el-table-column>
	    <el-table-column
	      prop="loginName"
	      label="登录名"
	      width="150">
	    </el-table-column>

	    <el-table-column
	      prop="roles"
	      label="角色"
	      width="150">
	    </el-table-column>

			<el-table-column
	      prop="createTime"
	      label="创建时间"
				:formatter="dateFormat" 
	      width="150">
	    </el-table-column>
	    
	    <el-table-column label="操作">
					<template slot-scope="scope">
						<el-button size="small" @click="openEditUserDialog(scope.row)" type="primary">编辑</el-button>
            <el-button size="small" :disabled=scope.row.buildin @click="editPermission(scope.row)" type="primary">权限</el-button>
						<el-button size="small" :disabled=scope.row.buildin @click="delUser(scope.row)" type="danger">删除</el-button>
					</template>
	    </el-table-column>
	  </el-table>
		<div style="float:right;margin-right:10%;">
			<el-pagination background
				@current-change="handleCurrentChange"
				layout="total, prev, pager, next"
				:current-page="pagination.currentPage"
				:total="pagination.total"
				:class="$style.pagination"
				>
			</el-pagination>
		</div>
	</div>
</template>

<script>
import userpermissionDialog from "./UserPermissionDialog";
import editeuserDialog from "./editeUserDialog";
import { getUserList, delUser } from "@/api/user.js";
import { getSideBar } from "@/api/setting.js";
import { formatDate } from "@/filters";
import { mapGetters } from "vuex";
import beforeEach from "@/utils/beforeEach.js";
export default {
  name: "user",
  mixins: [beforeEach],
  data() {
    return {
      users: [],
      pagination: {
        total: 0,
        currentPage: 1
      },
      permissiondialogVisible: false
    };
  },
  computed: {
    ...mapGetters(["sidebar", "currentZoneCode"])
  },
  watch: {
    currentZoneCode: function() {
      this.loadData(1);
    }
  },
  components: {
    userpermissionDialog,
    editeuserDialog
  },
  methods: {
    dateFormat: function(row, column) {
      var date = row[column.property];
      if (date == undefined) {
        return "";
      }
      return formatDate(date, "yyyy/MM/dd hh:mm");
    },
    editPermission(item) {
      this.$bus.$emit("editUserPermission", item);
    },
    // 创建用户
    openCreateUserDialog() {
      this.$bus.$emit("createUser", "");
    },
    // 编辑用户
    openEditUserDialog(item) {
      this.$bus.$emit("editUser", item);
    },
    // 删除用户
    delUser(data) {
      this.$confirm("你正要删除该用户, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(() => {
        delUser(data.code)
          .then(res => {
            const data = res.data;
            if (data.success) {
              this.$message({ message: "删除用户成功！", type: "success" });
              this.loadData(1);
            } else {
              this.$message({
                message: "删除用户失败: " + data.msg,
                type: "error"
              });
            }
          })
          .catch(error => {
            this.$message({ message: "删除用户失败:" + error, type: "error" });
          });
      });
    },
    // 页面发生变化
    handleCurrentChange(currentPage) {
      this.loadData(currentPage);
    },
    // 加载数据列表
    loadData(pageNum) {
      getUserList(this.currentZoneCode, pageNum)
        .then(res => {
          const data = res.data;
          if (data.success) {
            this.users = data.obj.result;
            this.pagination.currentPage = data.obj.pageNum;
            this.pagination.total = data.obj.totalCount;
          } else {
            console.log(error);
          }
        })
        .catch(error => {
          console.log(error);
        });
    }
  },
  mounted() {
    // getSideBar().then(res => {
    //   console.log(res);
    // });
    this.loadData(1);
  }
};
</script>

<style rel="stylesheet/scss" lang="scss" module>
.pagination {
  margin: 0 auto;
  margin-top: 30px;
  width: 30%;
}
</style>