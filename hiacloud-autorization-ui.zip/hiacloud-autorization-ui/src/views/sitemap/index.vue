<template>
  <div>
    <div class="title">功能导航</div>
    <div class="menu_content">
      <el-alert
        v-show="display"
        :closable="false"
        title="哎呀，你没有能看到的功能，请联系上级管理员。"
        type="warning">
      </el-alert>
      <template v-for="item in myMenus">
        <div class="menu_item" @click="goItem(item)">
            <i v-if="item.icon" :class="item.icon"></i>
            <span>{{item.name}}</span>
        </div>
      </template>
    </div>
	</div>
</template>

<script>
import { mapGetters } from "vuex";
import { loadMenus } from "@/api/setting.js";
export default {
  name: "sitemap",
  data() {
    return {
      display: false,
      myMenus: []
    };
  },
  computed: {
    ...mapGetters(["currentZoneCode"])
  },
  watch: {
    currentZoneCode: function() {
      this.loadNavs();
    }
  },
  mounted() {
    this.loadNavs();
  },
  methods: {
    goItem(item) {
      this.$router.replace(item.path);
    },
    loadNavs() {
      this.display = false;
      this.myMenus.length = 0;
      loadMenus(this.currentZoneCode).then(res => {
        this.myMenus = this.myMenus.concat(this.processData(res.data.obj));
        if (this.myMenus.length == 0) {
          this.display = true;
        }
      });
    },
    processData(arr) {
      for (let l = 0; l < arr.length; l++) {
        arr[l].path = this.getPath(arr[l]);
      }
      return arr;
    },
    getPath(item) {
      switch (item.ename) {
        case "sitemap":
          return "/sitemap";
        case "zone_manager":
          return "/domain";
        case "user_manager":
          return "/user";
        case "role_manager":
          return "/role";
        case "permission_manager":
          return "/permission";
        case "org_manager":
          return "/organization";
        default:
          return "/unknown";
      }
    }
  }
};
</script>

<style>
.menu_content {
  width: 90%;
  margin-left: 5%;
}
.menu_item {
  display: inline-block;
  width: 20%;
  border: 1px solid #9e9e9e59;
  height: 36px;
  cursor: pointer;
  border-radius: 5px;
  padding: 10px;
  margin: 10px 20px 10px;
  color: #5b9eff;
  background: aliceblue;
}
.menu_item:hover {
  background: #2196f3;
  color: white;
}
</style>