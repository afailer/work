<template>
	<div>
		<!-- <p class="title">角色管理</p> -->
		<div class="createbtn">
			<el-button type="primary" icon="el-icon-plus" @click="handleAdd()">创建角色</el-button>
		</div>
	  <el-table :data="roleData" border class="table">
	    <el-table-column label="名称" width="260">
			    <template slot-scope="scope">
        		<span style="margin-left: 10px">{{ scope.row.name }}</span>
      		</template>
	    </el-table-column>
	    <el-table-column label="英文名" width="260">
			<template slot-scope="scope">
        		<span style="margin-left: 10px">{{ scope.row.ename }}</span>
      		</template>
	    </el-table-column>
      <el-table-column label="描述" width="260">
			<template slot-scope="scope">
        		<span style="margin-left: 10px">{{ scope.row.description }}</span>
      		</template>
	    </el-table-column>
	    <el-table-column label="操作">
	    	<template slot-scope="scope">
	    		<el-button  type="primary" size="mini" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
	    		<el-button :disabled=scope.row.buildin type="primary"  size="mini"  @click="queryPermissions(scope.$index, scope.row)">权限</el-button>
	    		<el-button :disabled=scope.row.buildin type="danger"  size="mini"  @click="handDelRole( scope.row)">删除</el-button>
	    	</template>
	    </el-table-column>
	  </el-table>

		<!-- 对话框 -->
		<el-dialog :title="textMap[dialogStatus]" width="40%" :visible.sync="dialogEditOrAdd">
      <el-form :model="editRow" ref="dataForm">
        <el-form-item label="名称" :label-width="formLabelWidth">
          <el-input v-model="editRow.name" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="英文名称" :label-width="formLabelWidth">
          <el-input v-model="editRow.ename" auto-complete="off" ></el-input>
        </el-form-item>
        <!-- <el-form-item label="类型" :label-width="formLabelWidth">
          <el-input v-model="editRow.type" auto-complete="off" ></el-input>
        </el-form-item> -->
        <el-form-item label="描述" :label-width="formLabelWidth">
          <el-input type="textarea"  v-model="editRow.description" auto-complete="off" ></el-input>
        </el-form-item>
        
      </el-form>
      <div slot="footer" class="dialog-footer" style="overflow:hidden">
        <el-button @click="dialogEditOrAdd = false" style="float:right !important">取消</el-button>
        <el-button type="primary" v-if="dialogStatus=='create'" @click="sureAdd(editRow)" style="margin:0px 10px;float:right !important">确定</el-button>
        <el-button type="primary" v-else @click="sureEdit(editRow)" style="margin:0px 10px;float:right !important">确定</el-button>
      </div>
		</el-dialog>
    
    <rolepermission-dialog></rolepermission-dialog>
	</div>
</template>

<script>
import {
  getRoleList,
  addRole,
  detailRole,
  editRole,
  delRole,
  getPermissionsInTree,
  saveRolePermissions
} from "@/api/role.js";
import { mapGetters } from "vuex";
import rolepermissionDialog from "./rolePermission-dialog";
import beforeEach from "@/utils/beforeEach.js";
export default {
  name: "role",
  mixins: [beforeEach],
  data() {
    return {
      dataTree: [],
      roleData: [],
      editRow: {},
      permissionCodeList: [],
      formLabelWidth: "100px",
      dialogEditOrAdd: false,
      textMap: {
        update: "编辑角色",
        create: "创建角色"
      },
      dialogStatus: "",
      type: "",
      dialogPermision: false
    };
  },
  components: { rolepermissionDialog },
  created() {
    this.initRoleList();
  },
  computed: {
    ...mapGetters(["currentZoneCode"])
  },
  watch: {
    currentZoneCode: function() {
      this.initRoleList();
    }
  },
  methods: {
    getCheckedNodes(row) {
      // 权限确定
      this.permissionCodeList = [];

      console.log(this.$refs.tree.getCheckedNodes()); // 选中的节点
      var selectCode = [];
      for (var i = 0; i < this.$refs.tree.getCheckedNodes().length; i++) {
        selectCode.push(this.$refs.tree.getCheckedNodes()[i].code);
      }

      this.permissionCodeList = selectCode;
      console.log(this.permissionCodeList);
      saveRolePermissions(row.code, this.permissionCodeList).then(res => {
        if (res.data.success) {
          this.$message({
            message: res.data.msg,
            type: "success"
          });
        } else {
          this.$message({
            message: res.data.msg,
            type: "error"
          });
        }
        console.log(res);
      });
    },
    cleanAll() {
      this.editRow = {};
    },

    initRoleList() {
      getRoleList(this.currentZoneCode).then(res => {
        this.roleData = res.data.obj;
      });
    },

    queryPermissions(index, row) {
      console.log(row);
      this.$bus.$emit("rolePermission", row);
    },
    handleAdd(index, row) {
      this.cleanAll();
      this.dialogEditOrAdd = true; // 弹出对话框
      this.editRow = Object.assign({}, row); // 编辑的数据
      this.dialogStatus = "create";
      this.type = "添加";
    },
    handleEdit(index, row) {
      this.cleanAll();
      this.type = "编辑";
      this.dialogEditOrAdd = true; // 弹出对话框
      this.dialogStatus = "update";
      detailRole(row.code).then(res => {
        if (res.data.success) {
          this.editRow = Object.assign({}, res.data.obj);
        } else {
          this.$message({
            message: res.data.msg,
            type: "error"
          });
        }
      });

      // 加个校验
    },

    sureAdd(row) {
      this.editRow.zoneCode = this.currentZoneCode;
      addRole(this.editRow).then(res => {
        if (res.data.success) {
          this.$message({
            message: res.data.msg,
            type: "success"
          });
          this.dialogEditOrAdd = false;
          this.initRoleList();
        } else {
          this.$message({
            message: res.data.msg,
            type: "error"
          });
        }
      });
    },
    sureEdit(index, row) {
      editRole(this.editRow).then(res => {
        if (res.data.success) {
          this.$message({
            message: res.data.msg,
            type: "success"
          });
          this.dialogEditOrAdd = false;
          this.initRoleList();
        } else {
          this.$message({
            message: res.data.msg,
            type: "error"
          });
        }
      });
    },
    handDelRole(row) {
      this.$confirm("此操作将永久删除该角色, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          delRole(row.code).then(res => {
            if (res.data.success) {
              this.$message({
                message: res.data.msg,
                type: "success"
              });
              this.initRoleList();
            } else {
              this.$message({
                message: res.data.msg,
                type: "error"
              });
            }
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    }
  }
};
</script>

<style rel="stylesheet/scss" lang="scss" module>

</style>
