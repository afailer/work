<template>
  <div>
    <el-dialog
        title="编辑角色权限"
        :visible.sync="dialogVisible">
        <div  v-loading="loading">
        <el-tree
               
                :data="permissions"
                show-checkbox
                node-key="code"
                ref="tree"
                :props="defaultProps"
                :default-checked-keys="currentRolePermissionsKeys">
                <!-- :render-content="renderContent" -->
            </el-tree>
            <div style="overflow:hidden">
                <el-button @click="dialogVisible = false" style="float:right">取 消</el-button>
                <el-button type="primary" @click="saveRolePermissions()" style="float:right;margin:0 10px">确 定</el-button>
            </div>
        </div>
    </el-dialog>
  </div>
</template>
<script>
import { getPermissionsInTree,getRolePermissions,saveRolePermissions,removeRolePermissions } from "@/api/role.js";
export default{
    name:"rolepermission-dialog",
    data(){
        return{
            zoneCode:"",
            roleCode:"",
            loading:false,
            permissions:[],
            currentRolePermissions:[],
            currentRolePermissionsKeys:[],
            defaultProps: {
                children: 'children',
                label: 'name'
            },
            loading:'loading',
            dialogVisible:false,
            waitLoadTimes : 0
        }
    },
    methods: {
      saveRolePermissions(){
        this.dialogVisible=false;
        let addRolePermissions = [];
        let reduceRolePermissions = [];
        let checkedRolePermissions = this.$refs.tree.getCheckedNodes();
        for(let l=0;l<checkedRolePermissions.length;l++){
          if(this.currentRolePermissions.getTreeIndex(checkedRolePermissions[l]) == -1){
            addRolePermissions.push((checkedRolePermissions[l].code));
          }
        }
        for(let l=0;l<this.currentRolePermissions.length;l++){
          if(checkedRolePermissions.getTreeIndex(this.currentRolePermissions[l]) == -1){
            reduceRolePermissions.push((this.currentRolePermissions[l].code))
          }
        }
        if(addRolePermissions.length>0){
          this.waitLoadTimes++
          saveRolePermissions(this.roleCode,addRolePermissions).then((res)=>{
            this.$Toast(res)
          })
        }
        if(reduceRolePermissions.length>0){
          this.waitLoadTimes++
          removeRolePermissions(this.roleCode,reduceRolePermissions).then((res)=>{
            this.$Toast(res)
          })
        }
      },
      loadPermissionsAll(){
        this.waitLoadTimes++
        getPermissionsInTree(this.zoneCode).then((res)=>{
          this.freshLoadingState();
          this.permissions = res.data.obj
          
        })
      },
      loadCurrentRolePermission(){
        this.waitLoadTimes++
        getRolePermissions(this.roleCode).then((res)=>{
          this.freshLoadingState();
          this.currentRolePermissions = res.data.obj
          for(let l=0;l<this.currentRolePermissions.length;l++){
            this.currentRolePermissionsKeys.push(this.currentRolePermissions[l].code)
          }
        })
      },

      freshLoadingState(){
        this.waitLoadTimes--
        if(this.waitLoadTimes == 0){
          this.loading=""
        }
      }

    },
    created () {
        Array.prototype.getTreeIndex = function(obj){
          if(obj == undefined || obj == null){
            return -1
          }
          for(let l=0;l<this.length;l++){
            if(this[l].code == obj.code){
              return l
            }
          }
          return -1
        }
        this.$bus.$on("rolePermission",(roleItem)=>{
            console.log(roleItem)
            this.zoneCode = roleItem.zoneCode
            this.roleCode = roleItem.code
            this.dialogVisible = true
            this.waitLoadTimes=0
            this.loading='loading'
            this.currentRolePermissionsKeys.splice(0,this.currentRolePermissionsKeys.length)
            this.permissions.splice(0,this.permissions.length)
            this.currentRolePermissions.splice(0,this.currentRolePermissions.length),
            this.loadPermissionsAll()
            this.loadCurrentRolePermission()
        })
    },

    beforeDestroy () {
        this.$bus.$off('rolePermission');
    }
}
</script>