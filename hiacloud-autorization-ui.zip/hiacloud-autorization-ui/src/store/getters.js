const getters = {
    sidebar: state => state.app.sidebar,
    language: state => state.app.language,

    token: state => state.user.token,
    user: state => state.user.user,
    roles: state => state.user.roles,
    menus: state => state.user.menus,

    permission_routers: state => state.permission.routers,
    addRouters: state => state.permission.addRouters,

    currentZoneCode: state => state.zone.currentZoneCode,
    childZones: state => state.zone.childZones,
    menus: state => state.zone.menus
};
export default getters;