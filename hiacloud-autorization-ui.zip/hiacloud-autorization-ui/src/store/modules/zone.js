const zone = {
    state: {
        currentZoneCode: "",
        childZones: [],
        menus: []
    },

    mutations: {
        SET_CURRENTZONE_CODE: (state, currentZoneCode) => {
            state.currentZoneCode = currentZoneCode;
        },
        SET_CHILD_ZONES: (state, childZones) => {
            state.childZones = childZones;
        },
        SET_MENUS: (state, menus) => {
            state.menus = menus;
        }
    },

    actions: {
        currentZoneCode({ dispatch, commit }, currentZoneCode) {
            commit("SET_CURRENTZONE_CODE", currentZoneCode);
        },
        childZones({ commit }, childZones) {
            commit("SET_CHILD_ZONES", childZones);
        },
        menus({ commit }, menus) {
            commit("SET_MENUS", menus);
        }
    }
};

export default zone;