import { loginByUsername } from '@/api/login'
import { getToken, setToken, removeToken } from '@/utils/auth'
import menus from '@/utils/menus'

const user = {
    state: {
        user: {},
        token: '',
        roles: [],
        menus: menus.manage,
    },

    mutations: {
        SET_USER: (state, user) => {
            state.user = user;
        },
        SET_TOKEN: (state, token) => {
            state.token = token
        },
        SET_ROLES: (state, roles) => {
            state.roles = roles
        },
        SET_MENU: (state, menus) => {
            state.menus = menus
        }
    },

    actions: {
        initUser({ commit }, info) {
            commit('SET_TOKEN', info.token)
            commit('SET_USER', info.user)
        },
        // 用户名登录
        LoginByUsername({ commit }, userInfo) {
            const loginName = userInfo.username.trim()
            return new Promise((resolve, reject) => {
                loginByUsername(loginName, userInfo.password).then(response => {
                    const data = response.data
                    if (data.success) {
                        commit('SET_TOKEN', data.obj.access_token)
                        commit('SET_USER', data.obj.currentUser)
                        setToken(data.obj.access_token, data.obj.currentUser)
                        resolve()
                    } else {
                        reject(data.msg);
                    }

                }).catch(error => {
                    reject(error)
                })
            })
        },
        // 获取菜单
        menu({ commit }, memuInfo) {
            commit('SET_MENU', memuInfo)
        }
    }
}

export default user