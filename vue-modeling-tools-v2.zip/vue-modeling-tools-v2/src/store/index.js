import Vue from 'vue';
import Vuex from 'vuex';
import mutations from './mutations';
import actions from './actions';

Vue.use(Vuex);


const state = {
    isGraph: false,
    settings: {
        currentNamespace: "1",
        namespaceDefault: "http://opcfundation.org/UA/",
        namespaceBase: "http://model.hollysys.com/"
    },
    objectTreeState: {}, // 实例树缓存数据函数
    typeTreeState: {}, // 详情树缓存数据函数
    propertiesState: [], // 右侧詳情

    objectTreeNodeDetail: null, //存储objectTreeNode的节点详情信息
    currentNode: {}, // 当前节点
    childrenForTable: [{
        "node": {
            "nodeValues": {
                "DisplayName": "",
            }
        },
        "typeDefinition": {
            "nodeValues": {
                "DisplayName": "",
            }
        },
        "dataType": {
            "nodeValues": {
                "DisplayName": "",
            }
        },
        "modellingRule": {
            "nodeValues": {
                "DisplayName": "",
            }
        }
    }], //当前节点的子节点
    referenceTable: [{
        rel: { nodeValues: {} },
        targetNode: { nodeValues: {} }
    }],




    parentNode: {},

    parentNodeForSave: {},

    //当前节点的reference
    currentUri: "",
    newNode: {}, // 新建节点
    selectNode: {}, //弹出模态层选中的节点

    // 存放历史数据
    oldData: {
        parentNode: {},
        currentNode: {},
        typeDefinitionNode: {},
        modellingRuleNode: {},
        relationNode: {},
        children: [],
        references: []
    },
}
export default new Vuex.Store({
    state,
    mutations,
    // getters,
    actions
})