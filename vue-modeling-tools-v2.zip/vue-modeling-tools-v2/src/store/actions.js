import axios from 'axios';
import { getToken, setToken, removeToken } from '@/utils/auth'
import { login } from '@/api/mdt'


export default {

    fetchDefaultNamespace({ commit, state }) {
        axios.get("/mdt2/namespace/list")
            .then(res => {
                console.log(res);
                var result = res.data.result;
                var namespace = "1";
                for (var i = 0; i < result.length; i++) {
                    if (result[i].using && result[i].using == "1") {
                        namespace = result[i].uri.split('/')[2];
                    }
                }
                commit('UPDATE_NAMESPACE', namespace)
            });
    },
    // typeTree 增加節點
    addtypeNode({ commit, state }) {
        commit('ADDTYPE_NODE')
    },

    // editMain 
    showNode({ commit, state }, { treeNode: treeNode, parentNode: parentNode }) {
        commit('SHOW_NODE', { treeNode: treeNode, parentNode: parentNode });
    },
    // 右侧几点详情
    showProperties({ commit, state }, treeNode) {
        commit('SHOW_PROPERTIES', treeNode);
    },

    //获取当前节点子节点

    showchildrenTable({ commit, state }, childerenTable) {
        commit('SHOW_CHILDRENTABLE', childerenTable);
    },

    //获取当前节点的References

    showReferencesTable({ commit, state }, referencesTable) {
        commit('SHOW_REFERENCES', referencesTable);
    },

    showObjNode({ commit, state }, treeNode) {
        commit('SHOW_OBJ_NODE', treeNode)
    },
    showObjChildrenTable({ commit, state }, childrenTable) {
        commit('SHOW_OBJ_CHILDRENTABLE', childrenTable);
    },


    //模态层传递id
    getUri({ commit, state }, uri) {
        commit('GET_URI', uri);
    },

    //模态层选中节点
    selectNode({ commit, state }, treeNode) {
        commit('SELECT_NODE', treeNode);
    },

    updateChildRelation({ commit, state }, data) {
        commit("UPDATA_CHILDRELATION", data);
    },
    updateReferenceRelation({ commit, state }, data) {
        commit("UPDATA_REFERENCERELATION", data);
    },

    // 
    cacheTypeTree({ commit, state }, info) {
        commit('CACHE_TYPETREE', info)
    },
    cacheObjTree({ commit, state }, info) {
        commit('CACHE_OBJTREE', info)
    },
    addChildRow({ commit, state }, info) {
        commit('ADD_CHILD_ROW', info)
    },
    addReferenceRow({ commit, state }, info) {
        commit('ADD_REFERENCE_ROW', info)
    },
    deleteChildRow({ commit, state }, info) {
        commit('DELETE_CHILD_ROW', info)
    },
    deleteReferenceRow({ commit, state }, info) {
        commit('DELETE_REFERENCE_ROW', info)
    },
    updateNamespace({ commit, state }, namespace) {
        commit('UPDATE_NAMESPACE', namespace)
    },
    changeGraph({ commit, state }, isgraph) {
        commit('CHANGE_GRAPH', isgraph)
    },
    // 用户名登录
    Login({ commit }, formInfo) {
        const serverUrl = formInfo.serverUrl.trim();
        const token = formInfo.token.trim();
        return new Promise((resolve, reject) => {
            login(serverUrl, token).then(response => {
                const data = response.data
                if (data.success) {
                    setToken(data.obj)
                    resolve()
                } else {
                    reject(data.msg);
                }
            }).catch(error => {
                reject(error)
            })
        })
    },
}