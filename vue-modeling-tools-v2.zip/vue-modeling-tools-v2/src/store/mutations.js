import router from '../router'
import { getToken, setToken, removeToken } from '@/utils/auth'

const SHOW_PROPERTIES = 'SHOW_PROPERTIES'
const SHOW_NODE = 'SHOW_NODE'
const ADD_NODE = 'ADD_NODE'
const SHOW_CHILDRENTABLE = 'SHOW_CHILDRENTABLE'
const SHOW_REFERENCES = 'SHOW_REFERENCES'
const GET_URI = 'GET_URI'
const SELECT_NODE = 'SELECT_NODE'

const CACHE_TYPETREE = 'CACHE_TYPETREE'
const CACHE_OBJTREE = 'CACHE_OBJTREE'
const SHOW_OBJ_NODE = 'SHOW_OBJ_NODE'
const SHOW_OBJ_CHILDRENTABLE = "SHOW_OBJ_CHILDRENTABLE"

const UPDATA_CHILDRELATION = 'UPDATA_CHILDRELATION'
const UPDATA_REFERENCERELATION = 'UPDATA_REFERENCERELATION'
const ADD_CHILD_ROW = 'ADD_CHILD_ROW'
const ADD_REFERENCE_ROW = 'ADD_REFERENCE_ROW'
const DELETE_CHILD_ROW = 'DELETE_CHILD_ROW'
const DELETE_REFERENCE_ROW = 'DELETE_REFERENCE_ROW'

const UPDATE_NAMESPACE = 'UPDATE_NAMESPACE'

const CHANGE_GRAPH = 'change_graph'
const LOGIN_OUT = 'login_out'

export default {
    CHANGE_GRAPH: (state, isgraph) => {
        console.log(isgraph)
        state.isGraph = isgraph
    },
    //展示节点
    [SHOW_NODE](state, nodeDeail) {
        // debugger;

        state.parentNodeForSave = {}
        state.parentNode = {}
            //state.currentNode = {},
        state.oldData.currentNode = {};
        state.oldData.modellingRuleNode = {}
        state.oldData.typeDefinitionNode = {}
        state.oldData.relationNode = {}
        state.oldData.parentNod = {};

        state.currentNode = nodeDeail.treeNode;
        state.parentNodeForSave = nodeDeail.parentNode;
        if (nodeDeail.parentNode) {
            state.parentNode = JSON.parse(nodeDeail.parentNode.src);
        }



        if (nodeDeail.treeNode.src) {
            state.oldData.currentNode = JSON.parse(nodeDeail.treeNode.src);
        }
        if (nodeDeail.treeNode.modellingSrc) {
            state.oldData.modellingRuleNode = JSON.parse(nodeDeail.treeNode.modellingSrc);
        }

        if (nodeDeail.treeNode.typeDefinitionSrc) {
            state.oldData.typeDefinitionNode = JSON.parse(nodeDeail.treeNode.typeDefinitionSrc);
        }
        if (nodeDeail.treeNode.relationSrc) {
            state.oldData.relationNode = JSON.parse(nodeDeail.treeNode.relationSrc);
        }
        if (nodeDeail.parentNode) {
            state.oldData.parentNode = JSON.parse(nodeDeail.parentNode.src);
        }


    },

    //获取子节点


    [SHOW_CHILDRENTABLE](state, childrenTable) {

        // debugger;
        state.oldData.children = [];
        state.childrenForTable = [];
        if (childrenTable.length > 0) {
            var tempArray = [];
            childrenTable.forEach(element => {
                tempArray.push(Object.assign({}, element))
            });
            state.oldData.children = tempArray;
            state.childrenForTable = childrenTable;
        } else {
            state.childrenForTable = [{
                "node": {
                    "nodeValues": {
                        "DisplayName": "",
                    }
                },
                "typeDefinition": {
                    "nodeValues": {
                        "DisplayName": "",
                    }
                },
                "dataType": {
                    "nodeValues": {
                        "DisplayName": "",
                    }
                },
                "modellingRule": {
                    "nodeValues": {
                        "DisplayName": "",
                    }
                }
            }]
        }
    },


    //SHOW_REFERENCES


    [SHOW_REFERENCES](state, referenceTable) {
        state.oldData.references = [];
        state.referenceTable = [];
        if (referenceTable.length > 0) {
            var tempArray = [];
            referenceTable.forEach(element => {
                tempArray.push(Object.assign({}, element))
            });
            state.oldData.references = tempArray;
            state.referenceTable = referenceTable;
        } else {
            state.referenceTable = [{
                rel: { nodeValues: {} },
                targetNode: { nodeValues: {} }
            }]
        }

        console.log(state.referenceTable)

    },

    //右侧节点详情
    [SHOW_PROPERTIES](state, treeNode) {
        state.propertiesState.splice(0, state.propertiesState.length)

        if (treeNode.src) {
            let src = JSON.parse(treeNode.src)
            let data = {}
            if (src.nodeValues != undefined) {
                data = src.nodeValues;
            } else {
                data = src;
            }
            state.propertiesState.push({ key: "id", value: data.uri });
            state.propertiesState.push({ key: "NodeClass", value: data.NodeClass });
            state.propertiesState.push({ key: "BrowseName", value: data.BrowseName });
            state.propertiesState.push({ key: "DisplayName", value: data.DisplayName });
            state.propertiesState.push({ key: "Description", value: data.Description });

            for (var p in data) {
                if (p != "uri" &&
                    p != "id" &&
                    p != "NodeClass" &&
                    p != "BrowseName" &&
                    p != "DisplayName" &&
                    p != "Description"
                ) {
                    state.propertiesState.push({ key: p, value: data[p] });
                }
            }
        }
    },
    //传递uri
    // 存储 objectTreeView 点击节点的信息
    [SHOW_OBJ_NODE](state, nodeDeail) {
        state.objectTreeNodeDetail = nodeDeail;
    },

    [GET_URI](state, uri) {
        state.currentUri = uri;
    },

    //模态层选中节点

    [SELECT_NODE](state, treeNode) {
        state.selectNode = treeNode;
    },


    [CACHE_TYPETREE](state, tree) {
        state.typeTreeState = tree
    },
    [CACHE_OBJTREE](state, tree) {
        state.objectTreeState = tree
    },
    [UPDATA_CHILDRELATION](state, data) {
        state.childrenForTable[data.index][data.prop] = data.data;
    },
    [UPDATA_REFERENCERELATION](state, data) {
        state.referenceTable[data.index][data.prop] = data.data;
    },
    [ADD_CHILD_ROW](state, data) {
        state.childrenForTable.push(data);
    },
    [ADD_REFERENCE_ROW](state, data) {
        state.referenceTable.push(data);
    },
    [DELETE_CHILD_ROW](state, index) {
        // debugger;
        if (state.childrenForTable.length > 1) {
            state.childrenForTable.splice(index, 1);
        } else {
            state.childrenForTable.splice(index, 1);
            var emptyData = {
                "node": {
                    "nodeValues": {
                        "DisplayName": "",
                    }
                },
                "typeDefinition": {
                    "nodeValues": {
                        "DisplayName": "",
                    }
                },
                "dataType": {
                    "nodeValues": {
                        "DisplayName": "",
                    }
                },
                "modellingRule": {
                    "nodeValues": {
                        "DisplayName": "",
                    }
                }
            };
            state.childrenForTable.push(emptyData);
        }

    },
    [DELETE_REFERENCE_ROW](state, index) {
        if (state.referenceTable.length > 1) {
            state.referenceTable.splice(index, 1);
        } else {
            state.referenceTable.splice(index, 1);
            state.referenceTable.push({
                rel: { nodeValues: {} },
                targetNode: { nodeValues: {} }
            });
        }

    },
    [UPDATE_NAMESPACE](state, namespace) {
        state.settings.currentNamespace = namespace;
    },
    [LOGIN_OUT](state, namespace) {
        removeToken();
        router.go({ name: "login" })
    }
}