import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store'
import ElementUI from 'element-ui'
import { getToken, setToken, removeToken } from '@/utils/auth'
import 'element-ui/lib/theme-chalk/index.css'
import "./assets/css/iconfont/iconfont.css";
Vue.use(ElementUI)
Vue.config.productionTip = false

// 引入一些外部组件
import $ from 'jquery'
import './assets/ztree/jquery.ztree.core.js'
import './assets/ztree/jquery.ztree.excheck.js'
import './assets/ztree/jquery.ztree.exedit.js'
const eventBus = {
    install(Vue, options) {
        Vue.prototype.$bus = new Vue();
    }
};

Vue.use(eventBus);

// 配置 axios 
import Axios from 'axios'

// respone interceptor
Axios.interceptors.response.use(
    response => response,
    error => {
        console.log('err' + error) // for debug
        if (error.response.status === 401) {
            removeToken();
            router.go({ name: "login" })
        } else {}
        return Promise.reject(error)
    })
Vue.config.productionTip = false


Vue.prototype.$http = Axios;
Vue.prototype.deepClone = function(initalObj) {
    var obj = {};
    obj = JSON.parse(JSON.stringify(initalObj));
    return obj;
};
Vue.prototype.isEmpty = function(obj) {
    if (obj === null) return true;
    if (typeof obj === 'undefined') {
        return true;
    }
    if (typeof obj === 'string') {
        if (obj === "") {
            return true;
        }
        var reg = new RegExp("^([ ]+)|([　]+)$");
        return reg.test(obj);
    }
    return false;
}

router.beforeEach((to, from, next) => {
    var token = getToken();
    if (to.name == "login") {
        if (token) {
            next({ name: "layout" });
        } else {
            next();
        }
    } else {
        if (token) {
            next();
        } else {
            next({ name: "login" });
        }
    }
});
new Vue({
    el: '#app',
    router,
    store,
    template: '<App/>',
    components: { App },
    ready: function() {


    }
});