import request from '@/utils/axios'
export function getTree() {
  return request({
    url:'../../static/tree.json',
    method:'get',
   
  })
}
export function delUser (id) {
  return request({
    url:'/cloud/user/deleteUser',
    method:'get',
    params:{
      id: id
    }
  })
}
//
export function freezeUser (param) {
  return request({
    url:'/cloud/user/frozenUser',
    method:'get',
    params:param
  })
}
export function updUser (data) {
  return request({
    url:'/cloud/user/updateUser',
    method:'post',
    data
  })
}
export function insertUser (data) {
  return request({
    url:'/cloud/user/addUserInfo',
    method:'post',
    data
  })
}
