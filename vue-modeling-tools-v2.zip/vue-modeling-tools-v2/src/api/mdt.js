import request from "@/utils/request";
export function login(serverUrl, token) {
    const data = {
        serverUrl: serverUrl,
        token: token
    }
    return request({
        url: '/mdt2/login',
        method: 'post',
        data
    })
}

export function getNodesAndRel(uri) {
    console.log("getNodesAndRel")
    return request({
        url: "/mdt2/gremlin/query",
        method: "post",
        data: "return g.V().has('uri','" +
            uri +
            "').bothE().otherV().path().by(__.valueMap(true))"
    });
}