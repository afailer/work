<template>
  <div class="login-container">
    <el-form class="login-form" autoComplete="off" :model="loginForm" :rules="loginRules" ref="loginForm" label-position="left">
      <div class="title-container">
        <h3 class="title">建 模 工 具</h3>
        <div class="err_msg">{{err_msg}}</div>
      </div>
      <el-form-item prop="serverUrl">
        <el-input name="serverUrl" 
          type="text" 
          v-model="loginForm.serverUrl" 
          autoComplete="off" 
          placeholder="server url" />
      </el-form-item>
      <el-form-item prop="token">
        <el-input name="token" 
          type="textarea"
          :rows="6" 
          @keyup.enter.native="handleLogin" 
          v-model="loginForm.token" 
          autoComplete="off" 
          placeholder="bearer token " />
      </el-form-item>
      <el-button type="primary"
        class="loginBtn"
        :loading="loading" 
        @click.native.prevent="handleLogin">连 接</el-button>
      <div class="tips">
          server url：模型服务的访问地址，如：http://127.0.0.1:8065/module<br>
          bearer token：带bearer的token，此值可在控制台查询
      </div>
    </el-form>
  </div>
</template>
<script>
import { isValidateURL } from '@/utils/validate'
export default {
  name: 'login',
  data() {
    const validateURL = (rule, value, callback) => {
      if (!isValidateURL(value)) {
        callback(new Error('Please enter the server url'))
      } else {
        callback()
      }
    }
    const validateToken = (rule, value, callback) => {
      if (!value.startsWith("bearer")) {
        callback(new Error('Please enter the bearer token'))
      } else {
        callback()
      }
    }
    return {
      err_msg:"",
      loginForm: {
          serverUrl: '',
          token: ''
      },
      loginRules: {
        serverUrl: [{ required: true, trigger: 'blur', validator: validateURL }],
        token: [{ required: true, trigger: 'blur', validator: validateToken }]
      },
      loading: false
    }
  },
  methods: {
    handleLogin() {
      this.$refs.loginForm.validate(valid => {
        if (valid) {
          this.loading = true
          this.$store.dispatch('Login', this.loginForm).then(() => {
            this.loading = false
            this.$router.push({ path: '/' })
          }).catch((msg) => {
            this.loading = false
            this.err_msg = "连接发生错误.";
          })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
  }
}
</script>
<style>
.login-container {
    position: fixed;
    height: 100%;
    width: 100%;
    background-color: #2d3a4b ;
    top: 0;
}

.login-container .el-input {
    display: inline-block;
}

.login-container .el-input input, .login-container textarea {
    border: 0;
    -webkit-appearance: none;
    border-radius: 0;
    padding: 12px 12px 12px 12px;
    background: rgba(0,0,0,.1);
    color: #eee;
}
.login-container .el-input input:-webkit-autofill, .login-container textarea:-webkit-autofill {
    -webkit-box-shadow: 0 0 0 1000px #2d3a4b inset!important;
    -webkit-text-fill-color: #fff!important
}

.login-container .el-form-item {
    border: 1px solid hsla(0,0%,100%,.1);
    background: rgba(0,0,0,.1) !important;
    border-radius: 5px;
    color: #454545
}

.login-container .login-form {
    position: absolute;
    left: 0;
    right: 0;
    width: 520px;
    padding: 35px 35px 15px;
    margin: 120px auto
}

.login-container .title-container{
    position: relative;
    height: 100px;
}

.login-container .title-container .title{
    font-size: 32px;
    font-weight: 700;
    color: #1ebec3;
    margin-bottom: 40px;
    letter-spacing: 2px;
    text-align: center;
    width: 100%;
    margin: 0 auto 30px;
    height: 1rem;
    overflow:inherit;
}

.login-container .title-container .err_msg{
    color: red;
    text-align: center;
    margin: 0 auto 10px
}
.login-container .loginBtn{
    width:100%;
    margin-bottom:20px;
}
.login-container .tips{
    font-size: 14px;
    color: #fff;
    margin-bottom: 10px;
}
</style>
