<template>
  <div class="obj">
    
      <div >
        <!-- <h1> 监控页面，建设中。。。</h1> -->
        <div>

        <codemirror v-if="flag" :value="code"  :options="cmOptions" style="border:1px solid;"></codemirror>
        </div>
        <button @click="click">切换</button>
        
         <!-- <mavon-editor v-model="value" :ishljs ="true"></mavon-editor> -->
         <!-- <editor v-model="content" lang="script" height="500" ></editor> -->
      </div>
  </div>
</template>
<script>
//import Multiselect from "vue-multiselect"; // elementUI select 组件不能满足需求，
//import Vue from 'vue'
import { codemirror } from 'vue-codemirror'
import 'codemirror/mode/javascript/javascript.js'
import 'codemirror/theme/base16-dark.css'
import 'codemirror/lib/codemirror.css'
// require('codemirror/addon/hint/show-hint.js')
// require('codemirror/addon/hint/show-hint.css')
// require('codemirror/addon/hint/javascript-hint.js')
// import { mavonEditor } from 'mavon-editor'
// import 'mavon-editor/dist/css/index.css'
// import editor from 'vue2-ace-code-editor'
// import 'brace/mode/javascript'
// import 'brace/theme/chrome'

export default {
  components: {
    codemirror
  },

  data() {
    return {
      mode: "javascript",
      flag : true,
      code: 'var ss = "helloworld"',
      cmOptions: {
        tabSize: 4,
        mode: 'text/javascript',
        theme: 'default',
        lineNumbers: false,
        line: true
      }
    };
  },
  methods: {
    loadDemo() {},
    click:function(){
       this.flag = !this.flag;
    }
  },

  cumputed: {},
  created() {
    this.loadDemo();
  }
};
</script>
<style>
.obj {
  width: 100%;
  height: 60px;
}
.obj .formClass {
  width: 400px;
}

.CodeMirror {
  height: 600px;
}
</style>

