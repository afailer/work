<template>  
   <div class="tab-container">
    <!-- <el-tag>mounted times ：{{createdTimes}}</el-tag> -->
    <el-tabs style='margin-top:15px; height: 100%;' v-model="activeName" type="border-card" @tab-click="handleClick">
      <!-- <el-tab-pane v-for="item in tabMapOptions" :label="item.label" :key='item.key' :name="item.key">
        <keep-alive>
          <tab-pane v-if='activeName==item.key' :type='item.key'></tab-pane>
        </keep-alive>
      </el-tab-pane> -->
      <el-tab-pane label="命名空间" name="NameSpace">
        <name-space-setting></name-space-setting>  
      </el-tab-pane>
      <el-tab-pane label="其他设置" name="setting">
        <h1> 其他设置页面，建设中。。。</h1>
      </el-tab-pane>
     
    </el-tabs>
  </div> 
</template>
<script>
  import nameSpaceSetting from '@/components/settingsComponent/nameSpaceSetting'
  export default {
    name:'settings',
    components:{nameSpaceSetting},
    data(){
      return{
        tabMapOptions: [
          { label: '命名空间', key: 'NameSpace' },
          { label: '其他设置', key: 'setting' },
         
        ],
        activeName: 'NameSpace',
        createdTimes: 0
      }
    },
    methods: {
       handleClick(tab, event) {
         console.log( '-------------------------')
        console.log(tab, event);
      }
    },
  }
</script>
<style scoped>
.tab-container{
    margin: 10px;
  }
</style>

