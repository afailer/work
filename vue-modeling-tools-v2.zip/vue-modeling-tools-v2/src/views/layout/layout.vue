<template>
  <div id="lauout">
    <!-- <zTree></zTree> -->
    <!-- <span class="el-icon-tickets tips" v-if="showOrNo" @mouseover="overChangeWidth"></span> -->
  <!-- 
  <span class="el-icon-tickets tips2" v-if="showOrNo" @mouseover="overChangeWidth" ></span>
  <span class="el-icon-tickets tips3" v-if="showOrNo" @mouseover="overChangeWidth"></span> -->

  <el-container>
  <el-header style="height: 50px;">
    <div class="titleImage">
      <span class="hiacloud">HiaCloud</span>
      <span>建模工具</span>
    </div>
    <div class = "login-user"> 
      <span class="user-logout" @click="logout">退出</span>
    </div>
  </el-header>
  <el-container>
    <el-aside width="30px" >
        
            
            <el-menu default-active="1" class="el-menu-vertical-demo" background-color="#2b3643" :collapse="true">
                           
                <el-menu-item index="1" style="padding: 0px !important;" @click.native="toModel">
                  <i class="el-icon-location"></i>
                  <span slot="title">建模</span>
                </el-menu-item>
                <el-menu-item index="2" @click.native="toMonitor">
                  <i class="el-icon-menu"></i>
                  <span slot="title">监控</span>
                </el-menu-item>
                <el-menu-item index="3" @click.native="toSettings">
                  <i class="el-icon-setting"></i>
                  <span slot="title">设置</span>
                </el-menu-item>
              
              </el-menu>    



      </el-aside>
          <el-main>
            <transition :duration="200" name="fade" mode="out-in">
              <router-view></router-view>  
            </transition>
          </el-main>
      </el-container>
    </el-container>
  </div>
</template>


<script>
import { removeToken } from "@/utils/auth";
export default {
  data(){
    return{
      showOrNo:true,
    }
  },
  methods:{
     
    toModel(){
      this.$router.push({path: '/layout/model'})
    },
    toMonitor(){
      this.$router.push({ path: '/layout/monitor'})
    },
    toSettings(){
      this.$router.push({ path: '/layout/settings'})
    },
    logout() {
      removeToken();
      window.location.href = './index.html#/login';
    }
    // toDemo(){
    //   this.$router.push({ path: '/layout/demo'})
    // },
    // toIcon(){
    //   this.$router.push({ path: '/layout/icon'})
    // },
    // overChangeWidth(){
    //   this.width="64px";
    //   this.showOrNo= false;
    // },
    // outChangeWidth(){
    //   this.width="8px"
    //   this.showOrNo= true;
    // }
    // toggleCollapse(){
    //   this.isCollapse = !this.isCollapse
    // }
  }
} 
</script>

<style scoped>

body{
  margin: 0!important;
}
 .el-menu-vertical-demo{
    width: 50px;
    margin-left: -18px
    /* min-height: 400px; */
  }

  .tips{
    position: absolute;
    left: -4px;
    top: 380px;
    font-size: 24px;
    z-index:999;
    color: #409eff;
    /* font-weight: 800; */

  }
  .tips2{
    position: absolute;
    left: -4px;
    top: 360px;
    font-size: 24px;
    z-index:999;
    color: #409eff;
  }
  .tips3{
    position: absolute;
    left: -4px;
    top: 340px;
    font-size: 24px;
    z-index:999;
    color: #409eff;
  }

.navIconClass{
  font-size:0px;
}
.navIconClass .el-icon-location{
    font-size:16px;
     margin-top: -30px;
 }
 .navIconClass .el-icon-menu{
    font-size:16px;
     margin-top: -30px;
 }
 .navIconClass .el-icon-setting{
    font-size:16px;
     margin-top: -30px;
 }
 .navIconClass .navFontClass{
    font-size: 16px;
    display: inline-block;
    margin-top: -90px;
 }

  /*@import '';*/
  .titleImage {
  float: left;
  margin-left: -20px;
  height: 48px;
  line-height: 48px;
}


.titleImage .hiacloud {
  color: #ffffff;
  font-size: 28px;
  font-weight: 800;
  margin-left: 12px;
}
.titleImage span {
  color: #ffffff;
  font-weight: 800;
  margin-left: 2px;
}
/* 引入 布局容器样式 */
.el-header,
.el-footer {
  background-color:#2b3643;  
  color: #333;
  /* text-align: center; */
  line-height: 60px;
}

.el-aside {
  background-color:#2b3643;
  color: #333;
  text-align: center;
  line-height: 200px;
  /* height: 100vmin; */
  height: calc( 100vh - 50px );
  overflow: hidden;
}

.el-main {
  background-color: #ffffff;
  color: #333;
  /* text-align: center; */
  /* line-height: 160px; */
  padding:2px 0 0 2px;
  /* margin-left: 15px */
  height: calc( 100vh - 50px );
}

body > .el-container {
  margin-bottom: 40px;
}

.el-container:nth-child(5) .el-aside,
.el-container:nth-child(6) .el-aside {
  line-height: 260px;
}

.el-container:nth-child(7) .el-aside {
  line-height: 320px;
}    

.login-user {
  float: right;
}
.login-user   .user-title {
    color: #fff;
    margin-right: 20px;
  }
.login-user .user-logout {
    color: rgb(255, 255, 255);
    cursor: pointer;
    border: 1px solid white;
    padding: 5px 10px 5px 10px;
    border-radius: 7px;
}
</style>