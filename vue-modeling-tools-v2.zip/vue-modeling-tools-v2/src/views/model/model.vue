<template>
  <div class="zTree">
    <split-pane  split="vertical" :default-percent="18">
            
      <template slot="paneL">
          <split-pane split="horizontal" :default-percent="50">
            <template slot="paneL">
                <div class="top-container">
                    <object-tree-view></object-tree-view>
                </div>
            </template>
            <template slot="paneR">
                <div class="bottom-container">
                  <type-tree-view></type-tree-view>
                </div>
            </template>
          </split-pane>
      </template>
      <template slot="paneR">
          <split-pane split="vertical" :default-percent="76">
              <template slot="paneL">
                  <div class="left-container"> 
                      <main-view></main-view>
                  </div>
              </template>
              <template slot="paneR">
                  <div class="l-container">
                    <properties-view></properties-view>
                  </div>
              </template>
          </split-pane>          
      </template>
      
    </split-pane>
    <!-- ztree
  
  
  
  <detail-info></detail-info> -->
  </div>
</template>

<script>
// 引进局部组件
import ObjectTreeView from "@/components/objectTreeView";
import TypeTreeView from "@/components/typeTreeView";
import MainView from "@/components/mainView";
import PropertiesView from "@/components/propertiesView";
import GraphDetail from "@/components/mainComponents/graphCanvas/graphDetail";
// 引进 vue-splitpane 组件
import splitPane from "vue-splitpane";
import { mapState } from "vuex";
export default {
  name: "ztree",
  // 注册局部组件
  components: {
    ObjectTreeView,
    TypeTreeView,
    MainView,
    PropertiesView,
    GraphDetail,
    splitPane
  },
  data() {
    return {
      //isGraph: false
    };
  },
  mounted() {
    //  TODO
    console.log(this.isGraph + "===============");
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style >
@import "../../assets/zTreeStyle";
.zTree {
  position: relative;
  height: 100%;
}
.left-container {
  /* background-color: #F38181; */
  height: 100%;
}
.l-container {
  /* background-color: #33eb86; */
  height: 100%;
}
.right-container {
  /* background-color: #FCE38A; */
  height: 200px;
}
.top-container {
  /* background-color: #FCE38A; */
  width: 100%;
  height: 100%;
}
.bottom-container {
  width: 100%;
  /* background-color: #95E1D3; */
  height: 100%;
}
</style>
