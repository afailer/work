<template>
  <div style="padding:10px;text-align:center;">
      未选择任何模型
  </div>
</template>
