<template>
  <div>
    <!-- 这是Variable节点  name:{{ruleForm.name}} -->
       <div class="cardClass">
            <el-card class="box-card">
            <div class="itemCollapse">
                <el-collapse v-model="activeNames" >  
                    <el-collapse-item title="Parent" name="0">                                    
                        <div class="formClass">
                        <!-- from 表单 开始 -->
                        <el-form size="mini" :model="ParentForm" ref="ruleForm" label-width="80px" label-position="left">
                            
                            <el-form-item label="Name" prop="nodeClass" >
                                <el-input v-model="ParentForm.name" placeholder="Object" :disabled="true">
                                </el-input>
                            </el-form-item>
                            <el-form-item label="Reference" prop="Namespace">
                                <el-select v-model="ParentForm.references" :disabled="true" style="width: 100%">
                                </el-select>
                            </el-form-item>
                        </el-form>
                        </div>
                    </el-collapse-item>


                     <el-collapse-item title="Instance" name="1" >                                    
                        <div class="formClass">
                        <!-- from 表单 开始 -->
                        <el-form size="mini" :model="ruleForm" ref="ruleForm" label-width="80px" label-position="left">
                            
                            <el-form-item label="NodeClass" prop="nodeClass" >
                                <el-input v-model="ruleForm.NodeClass" placeholder="Object" :disabled="true">
                                <!-- <el-option label="Object" value="Object"></el-option>
                                <el-option label="Object1" value="Object1"></el-option> -->
                                </el-input>
                            </el-form-item>
                            <el-form-item label="Namespace" prop="Namespace">
                                <el-input v-model="ruleForm.Namespace" :disabled="true" placeholder="NodeClass" ></el-input>
                            </el-form-item>
                            <el-form-item label="Name" prop="name">
                                <el-input  v-model="ruleForm.name"  :disabled="true" > 
                                </el-input>
                            </el-form-item>
                            <el-form-item label="Type Definition" prop="name">
                                <el-input  v-model="ruleForm.typeDefinition"  :disabled="true" > 
                                </el-input>
                            </el-form-item>
                            <el-form-item label="Modelling Rule" prop="name">
                                <el-input  v-model="ruleForm.modellingRule"  :disabled="true" > 
                                </el-input>
                            </el-form-item>
                            <el-form-item label="Data Type" prop="name">
                                <el-input  v-model="ruleForm.dataType"  :disabled="true" > 
                                </el-input>
                            </el-form-item>
                    
                        </el-form>
                        </div>
                    </el-collapse-item>


                    <el-collapse-item title="Additional Attributes" name="2">                                    
                                <div class="formClass">
                                <!-- from 表单 开始 -->
                                <el-form size="mini" :model="attributesForm" ref="" label-width="80px" label-position="left">                                    
                                    <el-form-item label="NodeId" prop="nodeClass" >
                                        <el-input v-model="attributesForm.NodeId" placeholder="Object" :disabled="true">
                                        </el-input>
                                    </el-form-item>
                                    <el-form-item label="DisplayName" prop="Namespace">
                                        <el-select v-model="attributesForm.DisplayName" :disabled="true" style="width: 100%">
                                        </el-select>
                                    </el-form-item>
                                    <el-form-item label="BrowseName" prop="Namespace">
                                        <el-select v-model="attributesForm.BrowseName" :disabled="true" style="width: 100%">
                                        </el-select>
                                    </el-form-item>
                                    <el-form-item label="Description" prop="Namespace">
                                        <el-select v-model="attributesForm.Description" :disabled="true" style="width: 100%">
                                        </el-select>
                                    </el-form-item>
                                     <!-- <el-form-item label="Value" prop="Namespace">
                                        <el-select :disabled="true" style="width: 100%">
                                        </el-select>
                                    </el-form-item> -->
                                     <el-form-item label="ValueRank" prop="Namespace">
                                        <el-select v-model="attributesForm.ValueRank" :disabled="true" style="width: 100%">
                                        </el-select>
                                    </el-form-item>
                                     <el-form-item label="ArryDimesions" prop="Namespace">
                                        <el-select v-model="attributesForm.ArryDimesions" :disabled="true" style="width: 100%">
                                        </el-select>
                                    </el-form-item>
                                     <el-form-item label="AccessLevel" prop="Namespace">
                                        <el-select v-model="attributesForm.AccessLevel" :disabled="true" style="width: 100%">
                                        </el-select>
                                    </el-form-item>
                                     <el-form-item label="UserAccessLevel" prop="Namespace">
                                        <el-select v-model="attributesForm.UserAccessLevel" :disabled="true" style="width: 100%">
                                        </el-select>
                                    </el-form-item>
                                     <el-form-item label="Historizing" prop="Namespace">
                                        <el-checkbox v-model="attributesForm.Historizing" disabled></el-checkbox>
                                    </el-form-item>
                                     <el-form-item label="MinimumSamplingInterval" prop="Namespace">
                                        <el-select v-model="attributesForm.MinimumSamplingInterval" :disabled="true" style="width: 100%">
                                        </el-select>
                                    </el-form-item>
                                </el-form>
                                </div>
                    </el-collapse-item>

                    <el-collapse-item title="Children" name="3">
                    <!-- table 列表 开始 -->
                        <div class="childrenTable">
                            <el-table
                                    :data="childrenTable"
                                    border
                                    size="mini"
                                    style="width: 100%;">
                                    <el-table-column type="expand" >
                                        <template slot-scope="props" style="padding: 10px 10px 10px 10px;">
                                        <el-form label-position="left" inline class="demo-table-expand">
                                            <el-form-item label="ReferenceType">
                                            <span>{{ props.row.ReferenceType }}</span>
                                            </el-form-item>
                                            <el-form-item label="DisplayName">
                                            <span>{{ props.row.DisplayName }}</span>
                                            </el-form-item>   
                                            <el-form-item label="BowersName">
                                            <span>{{ props.row.BowersName }}</span>
                                            </el-form-item>
                    
                                            <el-form-item label="Description">
                                            <span>{{ props.row.Description }}</span>
                                            </el-form-item>
                                        
                                            <el-form-item label="ID">
                                            <span>{{ props.row.id }}</span>
                                            </el-form-item>
                                
                                        </el-form>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                        prop="NodeClass"
                                        label="NodeClass"
                                        width="120">
                                        <template  slot-scope="scope">
                                            <el-select v-model="childrenTable[scope.$index].nodeClass" placeholder="selection" size="mini" >
                                                <el-option
                                                v-for="item in NodeClassoptions"
                                                :key="item.value"
                                                :label="item.label"
                                                :value="item.value">
                                                </el-option>
                                            </el-select>
                                        </template>
                                    </el-table-column>
                        
                                    <el-table-column
                                        prop="name"
                                        label="Name"
                                        width="120">
                                        <template  slot-scope="scope">
                                            <el-input v-model="childrenTable[scope.$index].name" size="mini"></el-input>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                        prop="TypeDefinition"
                                        label="TypeDefinition">
                                        <template  slot-scope="scope">
                                        <el-input v-model="childrenTable[scope.$index].typeDefinition"  @focus="addTypeDefinition(scope.$index)" size="mini"></el-input>
                                        
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                        prop="ModellingRule"
                                        label="ModellingRule">
                                        <template  slot-scope="scope">
                                            <el-select v-model="childrenTable[scope.$index].modellingRule" placeholder="" size="mini">
                                                <el-option
                                                v-for="item in ModellingRuleOptions"
                                                :key="item.value"
                                                :label="item.label"
                                                :value="item.value">
                                                </el-option>
                                            
                                            </el-select>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                        prop="DateType"
                                        label="DateType">
                                        <template  slot-scope="scope">
                                            <el-input v-model="childrenTable[scope.$index].dataType"  @focus="addTypeDefinition(scope.$index)" size="mini"></el-input>
                                        </template>
                                    </el-table-column>
                                    

                                    <el-table-column                              
                                        label="Edit"
                                                                
                                        width="80"
                                        style="border-collapse:inherit;">                         
                                            <template slot-scope="scope">
                                                <span class="edit" >
                                                    <el-button  type="text" size="small" @click.native="FnAddRow(scope.$index,scope.row, childrenTable)">新增</el-button>           
                                                </span>
                                                <span class="delete">
                                                    <el-button  type="text" size="small" @click.native="FnDeleteRow(scope.$index, childrenTable)">删除</el-button>           
                                                </span>
                                            </template>
                                    </el-table-column>
                                    </el-table>
                        </div>
                        
                    </el-collapse-item>
                    <el-collapse-item title="References" name="4">
                            <div class="referenc">
                            <el-table
                                :data="referenceTable"
                                border
                                size="mini"
                                style="width: 100%;">
                                <el-table-column
                                    prop="date"
                                    label="ReferenceType"
                                    width="180">
                                    <template  slot-scope="scope">
                                        <el-input v-model="referenceTable[scope.$index].ReferenceType" @focus="addTypeDefinition(scope.$index)" size="mini"></el-input>
                                    </template>
                                </el-table-column>
                                <el-table-column
                                    prop="name"
                                    label="Target"
                                    width="180">
                                    <template  slot-scope="scope">
                                       <el-input v-model="referenceTable[scope.$index].Target" @focus="addTypeDefinition(scope.$index)" size="mini"></el-input>
                                    </template>
                                </el-table-column>
                                <el-table-column>
                                </el-table-column>

                                <el-table-column                              
                                    label="Edit"   
                                    width="120"
                                    style="border-collapse:inherit;">                         
                                        <template slot-scope="scope">
                                        <span class="edit">
                                            <el-button  type="text" size="small" @click.native="FnAddRow(scope.$index,scope.row, referenceTable)">新增</el-button>            
                                        </span>
                                        </template>
                                </el-table-column>
                                </el-table>
                            </div>
                    </el-collapse-item>
                <!-- button 按钮 -->
                    <div class="btnClass">                    
                        <el-button size="mini" type="primary" plain >提交</el-button>
                        <el-button size="mini" plain>取消</el-button>
                    </div> 
                </el-collapse>
                <!-- button 按钮 -->
                <!-- {{ objectTreeNodeDetail }} -->
            </div>
            </el-card>
        </div>
        
     
  </div>
</template>
<script>
import { mapState, mapActions } from "vuex";
export default {
  data() {
    return {
      ModellingRuleOptions: [
           {
          value: 'Mandatory',
          label: 'Mandatory'
        },
         {
          value: 'Optional',
          label: 'Optional'
        },
        //  {
        //   value: 'MandatoryPlaceholder',
        //   label: 'MandatoryPlaceholder'
        // },
        // {
        //   value: 'OptionalPlaceholder',
        //   label: 'OptionalPlaceholder'
        // },
         {
          value: 'None',
          label: 'None'
        },


      ],
      NodeClassoptions: [
          {
          value: 'Variable',
          label: 'Variable'
        },
         {
          value: 'Object',
          label: 'Object'
        },
         {
          value: 'Method',
          label: 'Method'
        },
        {
          value: 'NoSelection',
          label: 'NoSelection'
        },

      ],
   
      // 表单数据 初始化开始
     

      activeNames: ["0","1","2"],
      Typetitle: "Instance",
      ruleForm: {
        id: null,
        name: null,
        NodeClass: null,
        Namespace: null,
        TypeDefinition: null,
        dataType:null,
        modellingRule:null,
        
      },
      ParentForm: {
        name: null,
        references: null
      },
      attributesForm: {
        NodeId: null,
        DisplayName: null,
        BrowseName: null,
        Description: null,
        // Value: null,
        ValueRank: null,
        ArryDimesions: null,
        AccessLevel: null,
        UserAccessLevel: null,
        Historizing: null,
        MinimumSamplingInterval: null
      },
      children: [],
      references: [],
      flagDisplayName: true,
      flagBrowseName: true,
    };
  },
  computed: {
    ...mapState([
      "settings",
      "typeTreeState", // typeTreeState 数据
      "currentNode", // 数据详情
       "childrenTable",
      "referenceTable",
      "objectTreeNodeDetail"
      
    ])
  },

  created() {
    console.log("excute method： created");
    this.init();
  },
  methods: {
    init() {
        // if(!this.parentNodeForSave.id){
        //     this.$router.push({ name: "defaultModel" });
        // }
        console.log("excute method：init");
        this.preForm();
        this.preChildren();
        this.prePreference();
    },
    preForm() {
        console.log("excute method： preForm");

        //   debugger;

        //ParentForm
        this.ParentForm.name = this.$route.query.parentName; 
        if (this.currentNode.relationSrc) {
        this.ParentForm.references = JSON.parse(
          this.objectTreeNodeDetail.relationSrc
        );
      }
        if( this.objectTreeNodeDetail.name){
            // this.ruleForm.id = this.objectTreeNodeDetail.id;
            this.ruleForm.name = this.objectTreeNodeDetail.name;
            this.ruleForm.NodeClass = this.objectTreeNodeDetail.nodeClass;       
            this.ruleForm.Namespace = this.objectTreeNodeDetail.Namespace;
            this.ruleForm.TypeDefinition = this.objectTreeNodeDetail.typeDefinition;
            this.ruleForm.dataType =JSON.parse(
            this.objectTreeNodeDetail.dataTypeSrc
            );
            this.ruleForm.modellingRule = JSON.parse(
            this.objectTreeNodeDetail.modellingSrc
            );
        }
        //ruleForm
        
       
      
        if (this.objectTreeNodeDetail.typeDefinitionSrc) {
            var otherProperties = JSON.parse(this.objectTreeNodeDetail.typeDefinitionSrc);
            this.ruleForm.Historizing = otherProperties.nodeValues.isAbstract;

            // attributesForm

            this.attributesForm.NodeId = otherProperties.nodeUri;
            this.attributesForm.DisplayName = otherProperties.nodeValues.DisplayName;
            this.attributesForm.BrowseName = otherProperties.nodeValues.BrowseName;
            this.attributesForm.Description = otherProperties.nodeValues.Description;
            // this.attributesForm.Value = otherProperties.nodeValues.Value;
            // this.attributesForm.ValueRank = otherProperties.nodeValues.ValueRank;
            // this.attributesForm.ArryDimesions = otherProperties.nodeValues.ArryDimesions;
            // this.attributesForm.AccessLevel = otherProperties.nodeValues.AccessLevel;
            // this.attributesForm.UserAccessLevel = otherProperties.nodeValues.UserAccessLevel;
            // // this.attributesForm.Historizing = otherProperties.nodeValues.Historizing;
            // this.attributesForm.MinimumSamplingInterval = otherProperties.nodeValues.MinimumSamplingInterval;
      
        } else {
            this.attributesForm.NodeId = this.$route.query.id;
        }
        
        var namespace = this.attributesForm.NodeId.split("/")[1]
        if(namespace == '0'){
            this.ruleForm.Namespace = namespace + ":" + this.settings.namespaceDefault;
        }else{
            this.ruleForm.Namespace = namespace + ":" + this.settings.namespaceBase+namespace+"/";
        }

    },
    preChildren() {
      console.log("excute method： preChildren");
      if( this.objectTreeNodeDetail.children){
          this.children =  this.objectTreeNodeDetail.children
      }
    },
    prePreference() {
      console.log("excute method： prePreference");
    }
  },
  watch: {
    $route(currentState, oldState) {
      // debugger
      console.log("路由发生了变化：" + currentState.query.id);
      this.init();
    },
    'ruleForm.name':function(newValue,oldValue){
     
      if( this.attributesForm.DisplayName === newValue ){
        this.flagDisplayName = false
      }
      if( this.attributesForm.BrowseName === newValue ){
        this.flagBrowseName = false
      }
      if( this.currentNode.id === undefined &&  newValue === undefined ){
        this.attributesForm.DisplayName = newValue;
        this.attributesForm.BrowseName = newValue;
      }else
      if( this.currentNode.id === undefined && this.attributesForm.DisplayName === oldValue && this.attributesForm.BrowseName === oldValue ){
        this.attributesForm.DisplayName = newValue;
        this.attributesForm.BrowseName = newValue;
      }else if( this.currentNode.id === undefined && this.attributesForm.DisplayName === oldValue && this.flagDisplayName === true  ){
        this.attributesForm.DisplayName = newValue;         //
      }else if( this.currentNode.id === undefined && this.attributesForm.BrowseName === oldValue && this.flagBrowseName === true ){        
        this.attributesForm.BrowseName = newValue;  // 
      }
    },
  }
};
</script>

