import { ElementStore } from "./ElementStore";
import Setting from "./setting"
export function Util() {}
Util.prototype = {
    changeTragetElement: function(ele) {
        for (let l = 0; l < ElementStore.prototype.elements.length; l++) {
            if (
                ElementStore.prototype.elements[l].data.id != ele.data.id &&
                ElementStore.prototype.elements[l].data.x
            ) {
                let distanceX = Math.abs(
                    ele.data.x - ElementStore.prototype.elements[l].data.x
                );
                let distanceY = Math.abs(
                    ele.data.y - ElementStore.prototype.elements[l].data.y
                );
                let distance = Math.hypot(distanceX, distanceY);
                let SinT =
                    (ele.data.x - ElementStore.prototype.elements[l].data.x) / distance;
                let CosT =
                    (ele.data.y - ElementStore.prototype.elements[l].data.y) / distance;
                if (distance < Setting.prototype.CircleRadius * 2) {
                    ElementStore.prototype.elements[l].data.x =
                        ElementStore.prototype.elements[l].data.x -
                        (Setting.prototype.CircleRadius * 2 - distance) * SinT * 0.1;
                    ElementStore.prototype.elements[l].data.y =
                        ElementStore.prototype.elements[l].data.y -
                        (Setting.prototype.CircleRadius * 2 - distance) * CosT * 0.1;
                }
            }
        }
    },
    livingCycle: function() {
        let activeEle = "";
        for (let l = 0; l < ElementStore.prototype.elements.length; l++) {
            if (ElementStore.prototype.elements[l].data.isActive) {
                activeEle = ElementStore.prototype.elements[l];
            }
        }
        if (activeEle != "") {
            for (let l = 0; l < ElementStore.prototype.elements.length; l++) {
                if (
                    ElementStore.prototype.elements[l].data.linkNum ==
                    activeEle.data.linkNum &&
                    ElementStore.prototype.elements[l].data.id != activeEle.data.id
                ) {
                    ElementStore.prototype.elements[l].data;
                }
            }
        }

        let distanceX = Math.abs(this.data.beginPoint.x - this.data.endPoint.x);
        let distanceY = Math.abs(this.data.beginPoint.y - this.data.endPoint.y);
        let distance = Math.hypot(distanceX, distanceY);
        let SinT = (this.data.beginPoint.x - this.data.endPoint.x) / distance;
        let CosT = this.data.beginPoint.y - this.data.endPoint.y;
        if (distance > 300) {
            this.data.endPoint.x =
                this.data.endPoint.x + (distance - 300) * SinT * 0.01;
            this.data.endPoint.y =
                this.data.endPoint.y + (distance - 300) * CosT * 0.01;
        }
    }
};