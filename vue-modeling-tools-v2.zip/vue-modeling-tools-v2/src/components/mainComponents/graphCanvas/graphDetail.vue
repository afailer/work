<template>
	<div>
		
		<div slot="header" class="clearfix header">
				<span>属性</span>
		</div>
		<el-card class="box-card">
		<el-form ref="form" class="elform" :model="form" label-width="100px">
			<el-form-item label="BrowseName">
				<el-input v-model="form.BrowseName"></el-input>
			</el-form-item>
			<el-form-item label="Description">
				<el-input v-model="form.Description"></el-input>
			</el-form-item>
			<el-form-item label="DisplayName">
				<el-input v-model="form.Description"></el-input>
			</el-form-item>
			<el-form-item label="NodeClass">
				<el-input v-model="form.NodeClass"></el-input>
			</el-form-item>
		</el-form>
		</el-card>
  </div>
</template>
<script>
export default {
  name: "GraphDetail",
  data() {
    return {
      form: {}
    };
  },
  created() {
    this.$bus.$on("form", form => {
      this.form = form;
    });
  }
};
</script>
<style>
.header {
  padding: 4px 6px;
  border-bottom: 1px solid #ebeef5;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  background-color: #e4e7ef;
}
</style>
