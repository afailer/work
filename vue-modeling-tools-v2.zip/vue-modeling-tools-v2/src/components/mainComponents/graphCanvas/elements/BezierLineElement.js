import Setting from "../utils/setting";
import { RoleController } from "../RoleController";
export function BezierLineElement(data) {
    this.data = data;
}
BezierLineElement.prototype = {
    draw: function(pen) {
        let midX = (this.data.beginPoint.x + this.data.endPoint.x) / 2;
        let midY = (this.data.beginPoint.y + this.data.endPoint.y) / 2;
        let hypotSide = Math.hypot(
            Math.abs(this.data.endPoint.x - this.data.beginPoint.x),
            Math.abs(this.data.endPoint.y - this.data.beginPoint.y)
        );
        let sinT = (this.data.endPoint.x - this.data.beginPoint.x) / hypotSide;
        let cosT = (this.data.endPoint.y - this.data.beginPoint.y) / hypotSide;
        let lineHeight = 60;
        let middlePoint = { x: midX, y: midY };
        // 绘制线条
        pen.beginPath(); //单起一个路径，不会被外部影响
        pen.lineWidth = Setting.prototype.lineWidth; //线条的宽度
        pen.strokeStyle = Setting.prototype.LineColor; //默认线条的颜色
        if (this.data.id == Setting.prototype.hoverElementId) {
            // 悬停时线条的颜色
            pen.lineWidth = Setting.prototype.lineSelectWidth;
            pen.strokeStyle = Setting.prototype.lineHoverColor;
        }
        if (this.data.id == Setting.prototype.SelectElementId) {
            // 点击时线条的颜色
            pen.lineWidth = Setting.prototype.lineSelectWidth;
            pen.strokeStyle = Setting.prototype.lineSelectColor;
        }
        pen.moveTo(this.data.beginPoint.x, this.data.beginPoint.y);
        let finalY = parseInt(middlePoint.y + lineHeight * sinT); // 控制点
        let finalX = parseInt(middlePoint.x - lineHeight * cosT);
        pen.quadraticCurveTo(
            finalX,
            finalY,
            this.data.endPoint.x,
            this.data.endPoint.y
        );
        pen.stroke();

        // 箭头
        let x1 = this.data.endPoint.x;
        let y1 = this.data.endPoint.y;
        let x2 = finalX;
        let y2 = finalY;
        let x3 = this.data.beginPoint.x;
        let y3 = this.data.beginPoint.y;
        let radius = Setting.prototype.CircleRadius; // 圆形节点的半径
        let vertexX = x1 + radius * (x2 - x1) / Math.hypot(y2 - y1, x2 - x1); // 箭头在圆上顶点(控制点和x1点)
        let vertexY = y1 + radius * (y2 - y1) / Math.hypot(y2 - y1, x2 - x1);
        var rotate, xa, xb, ya, yb, rotateText;
        let bevel = Setting.prototype.bevel; // 箭头长度
        let bevelAngle = Setting.prototype.bevelAngle; // 箭头两边夹角
        let CurveVertexX =
            0.25 * (this.data.endPoint.x + this.data.beginPoint.x) + 0.5 * finalX; // 曲线上顶点坐标
        let CurveVertexY =
            0.25 * (this.data.endPoint.y + this.data.beginPoint.y) + 0.5 * finalY;
        if (x2 >= x1) {
            // rotate：计算箭头两边点的角度. 用控制点来计算。在-20 到 0度时 有 跳变情况。使用Math.PI/10来修正
            rotate =
                Math.asin((finalY - y1) / Math.hypot(finalY - y1, finalX - x1)) +
                Math.PI / 10; // 弧度
        } else {
            rotate =
                Math.PI -
                Math.asin((finalY - y1) / Math.hypot(finalY - y1, finalX - x1)) +
                Math.PI / 10; // 弧度
        }
        if (x2 < x1) {
            xa = bevel * Math.cos(Math.PI - rotate + bevelAngle / 2);
            ya = bevel * Math.sin(Math.PI - rotate + bevelAngle / 2);
            xb = bevel * Math.cos(Math.PI - rotate - bevelAngle / 2);
            yb = bevel * Math.sin(Math.PI - rotate - bevelAngle / 2);
        }
        if (x2 >= x1) {
            // xa ya,xb yb 箭头两个结束点位置相对于顶点的距离
            xa = bevel * Math.cos(rotate - bevelAngle / 2);
            ya = bevel * Math.sin(rotate - bevelAngle / 2);
            xb = bevel * Math.cos(rotate + bevelAngle / 2);
            yb = bevel * Math.sin(rotate + bevelAngle / 2);
        }
        pen.lineWidth = Setting.prototype.lineWidth; //箭头线条的宽度
        pen.fillStyle = Setting.prototype.LineColor; //默认箭头线条的颜色
        pen.save();
        pen.beginPath();
        if (x2 >= x1) {
            pen.moveTo(vertexX + xa, vertexY + ya); // 左箭头顶点
            pen.lineTo(vertexX, vertexY); // 圆上节点
            pen.lineTo(vertexX + xb, vertexY + yb); // 右箭头顶点
            pen.closePath();
        }
        if (x2 < x1) {
            pen.moveTo(vertexX - xa, vertexY + ya);
            pen.lineTo(vertexX, vertexY); // 圆上节点
            pen.lineTo(vertexX - xb, vertexY + yb);
            pen.closePath();
        }
        pen.fill(); // 实心箭头
        // console.log('角度:'+rotate*180/Math.PI,'endPoint:'+ x1,'控制点x：'+finalX,'差值：'+ (x1-finalX))
        console.log("角度:" + rotate * 180 / Math.PI, "差值：" + (x1 - finalX));
        pen.restore();

        // 文字矩形
        if (x3 >= x1) {
            // rotateText 文字矩形旋转角度
            rotateText = Math.asin((y3 - y1) / Math.hypot(y3 - y1, x3 - x1));
        } else {
            rotateText =
                Math.PI - Math.asin((y3 - y1) / Math.hypot(y3 - y1, x3 - x1));
        }
        let rectWidth = Setting.prototype.lineLabelWidth;
        let rectHeight = Setting.prototype.lineLabelHeight;
        let rectbevel = Math.hypot(rectWidth, rectHeight) / 2; // 矩形内斜对角一半
        let rectOriginX, rectOriginY; // 文字矩形左上角坐标
        // let CurveVertexX =
        //     0.25 * (this.data.endPoint.x + this.data.beginPoint.x) + 0.5 * finalX; // 曲线上顶点坐标
        // let CurveVertexY =
        //     0.25 * (this.data.endPoint.y + this.data.beginPoint.y) + 0.5 * finalY;
        let rectInnerAngle = Math.asin(rectHeight / 2 / rectbevel); // 矩形内斜对角线和矩形宽的夹角
        pen.save();
        pen.beginPath();
        if (x3 > x1) {
            rectOriginX =
                CurveVertexX - rectbevel * Math.cos(rotateText + rectInnerAngle);
            rectOriginY =
                CurveVertexY - rectbevel * Math.sin(rotateText + rectInnerAngle);
            pen.translate(rectOriginX, rectOriginY);
            pen.rotate(rotateText);
        } else {
            rectOriginX =
                CurveVertexX + rectbevel * Math.cos(rotateText + rectInnerAngle);
            rectOriginY =
                CurveVertexY + rectbevel * Math.sin(rotateText + rectInnerAngle);
            pen.translate(rectOriginX, rectOriginY);
            pen.rotate(rotateText - Math.PI);
        }
        pen.rect(0, 0, rectWidth, rectHeight);
        pen.fillStyle = Setting.prototype.lineLabelBg; // 矩形背景颜色
        pen.fill();

        pen.fillStyle = Setting.prototype.lineLabelText; // 字体颜色
        pen.font = `${Setting.prototype.lineLabelTextFont}px Arial`;
        if (this.data.id == Setting.prototype.hoverElementId) {
            // 悬停时字体的颜色
            pen.fillStyle = Setting.prototype.lineHoverColor;
            pen.font = `${Setting.prototype.lineLabelTextSelectFont}px Arial`;
        }
        if (this.data.id == Setting.prototype.SelectElementId) {
            // 点击时字体的颜色
            pen.fillStyle = Setting.prototype.lineSelectColor;
            pen.font = `${Setting.prototype.lineLabelTextSelectFont}px Arial`;
        }
        let maxLength = Setting.prototype.lineTextMaxLength;
        pen.textAlign = "center";
        pen.textBaseline = "middle";
        if (this.data.rel.length >= maxLength) {
            this.data.rel = this.data.rel.replace(
                this.data.rel.substring(maxLength),
                "..."
            );
        }
        pen.fillText(this.data.rel, rectWidth / 2, rectHeight / 2);

        pen.closePath();
        pen.restore();
    },
    caculate: function(event) {
        let x1 = this.data.endPoint.x;
        let y1 = this.data.endPoint.y;
        let x2 = this.data.beginPoint.x;
        let y2 = this.data.beginPoint.y;
        let x0 = event.offsetX - RoleController.prototype.translateX; // 点击页面的坐标
        let y0 = event.offsetY - RoleController.prototype.translateY;
        let x1x2 = Math.hypot(y2 - y1, x2 - x1); // 线的长度 圆心两点间距
        let x0x1 = Math.hypot(y0 - y1, x0 - x1); // 3条边距离
        let x0x2 = Math.hypot(y2 - y0, x2 - x0); // 3条边距离
        let perimeterHalf = (x1x2 + x0x1 + x0x2) / 2; // 三角形周长一半
        let midX = (x2 + x1) / 2;
        let midY = (y2 + y1) / 2;
        let middlePoint = { x: midX, y: midY };
        let lineHeight = 60;
        let hypotSide = Math.hypot(Math.abs(x1 - x2), Math.abs(y1 - y2));
        let sinT = (x1 - x2) / hypotSide;
        let cosT = (y1 - y2) / hypotSide;
        let finalY = parseInt(middlePoint.y + lineHeight * sinT); // 控制点
        let finalX = parseInt(middlePoint.x - lineHeight * cosT);
        let mixDistance = 10; // 设置最小距离
        let lineDistance; // 点击到两点直线的距离
        let bezierDistance; // 点击到贝塞尔曲线的距离
        let parameterT; // 贝塞尔曲线参数T,与起始点相比
        let CurveVertexX, CurveVertexY; // 贝塞尔曲线上的点

        if (x1 == x2) {
            // y1>y2 箭头向上
            // 竖线
            lineDistance = Math.abs(x0 - x1);
            parameterT = Math.abs(y0 - y2) / Math.abs(y2 - y1);
            CurveVertexX =
                Math.pow(1 - parameterT, 2) * x2 +
                2 * parameterT * (1 - parameterT) * finalX +
                Math.pow(parameterT, 2) * x1;
            CurveVertexY =
                Math.pow(1 - parameterT, 2) * y2 +
                2 * parameterT * (1 - parameterT) * finalY +
                Math.pow(parameterT, 2) * y1;
            bezierDistance = Math.abs(x0 - CurveVertexX);
            if (bezierDistance <= mixDistance) {
                return true;
            }
        } else if (y1 == y2) {
            // 横线
            lineDistance = Math.abs(y0 - y1);
            parameterT = Math.abs(x0 - x2) / Math.abs(x2 - x1);
            CurveVertexX =
                Math.pow(1 - parameterT, 2) * x2 +
                2 * parameterT * (1 - parameterT) * finalX +
                Math.pow(parameterT, 2) * x1;
            CurveVertexY =
                Math.pow(1 - parameterT, 2) * y2 +
                2 * parameterT * (1 - parameterT) * finalY +
                Math.pow(parameterT, 2) * y1;
            bezierDistance = Math.abs(y0 - CurveVertexY);
            if (bezierDistance <= mixDistance) {
                return true;
            }
        } else if (
            (x0 < x2 && x0 > x1) ||
            (x0 < x1 && x0 > x2) ||
            (y0 < y2 && y0 > y1) ||
            (y0 < y1 && y0 > y2)
        ) {
            // x0 y0点在两个圆点之间时计算bezierDistance
            lineDistance =
                2 *
                Math.sqrt(
                    perimeterHalf *
                    (perimeterHalf - x1x2) *
                    (perimeterHalf - x0x1) *
                    (perimeterHalf - x0x2)
                ) /
                x1x2;
            parameterT =
                Math.sqrt(Math.pow(x0x2, 2) - Math.pow(lineDistance, 2)) / x1x2;
            CurveVertexX =
                Math.pow(1 - parameterT, 2) * x2 +
                2 * parameterT * (1 - parameterT) * finalX +
                Math.pow(parameterT, 2) * x1;
            CurveVertexY =
                Math.pow(1 - parameterT, 2) * y2 +
                2 * parameterT * (1 - parameterT) * finalY +
                Math.pow(parameterT, 2) * y1;
            bezierDistance = Math.hypot(x0 - CurveVertexX, y0 - CurveVertexY);
            if (bezierDistance <= mixDistance) {
                return true;
            } else {
                return false;
            }
        }
    },
    onClick: function(event) {
        Setting.prototype.SelectElementId = this.data.id;
    },
    update: function(beginPoint, endPoint) {
        this.beginPoint = beginPoint;
        this.endPoint = endPoint;
    },
    living: function() {
        let distanceX = Math.abs(this.data.beginPoint.x - this.data.endPoint.x);
        let distanceY = Math.abs(this.data.beginPoint.y - this.data.endPoint.y);
        let distance = Math.hypot(distanceX, distanceY);
        let SinT = (this.data.beginPoint.x - this.data.endPoint.x) / distance;
        let CosT = (this.data.beginPoint.y - this.data.endPoint.y) / distance;
        let offsetX = 0;
        let offsetY = 0;
        if (distance > 230) {
            offsetX = (distance - 230) * SinT * 0.2;
            offsetY = (distance - 230) * CosT * 0.2;
            if (offsetX > 0 && offsetX > 30) {
                offsetX = 30;
            }
            if (offsetX < 0 && offsetX < -30) {
                offsetX = -30;
            }
            if (offsetY > 0 && offsetY > 30) {
                offsetY = 30;
            }
            if (offsetY < 0 && offsetY < -30) {
                offsetY = -30;
            }
        }
        if (distance < 130) {
            offsetX = (distance - 130) * SinT * 0.2;
            offsetY = (distance - 130) * CosT * 0.2;
        }
        if (!this.data.beginPoint.isActive) {
            this.data.beginPoint.x -= offsetX;
            this.data.beginPoint.y -= offsetY;
        }
        if (!this.data.endPoint.isActive) {
            this.data.endPoint.x += offsetX;
            this.data.endPoint.y += offsetY;
        }
    }
};