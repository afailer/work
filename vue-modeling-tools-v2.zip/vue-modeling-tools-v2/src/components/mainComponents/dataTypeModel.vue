<template>
  <div>
      <!-- 这是DataTypeModel节点  id:{{ruleForm.name}} -->
       <div class="cardClass">
            <el-card class="box-card">
            <div class="itemCollapse">
                <el-collapse v-model="activeNames" >  
                    <el-collapse-item title="Parent" name="0">                                    
                        <div class="formClass">
                        <!-- from 表单 开始 -->
                        <el-form size="mini" :model="ParentForm" ref="ruleForm" label-width="80px" label-position="left">
                            
                            <el-form-item label="Name" prop="nodeClass" >
                                <el-input v-model="ParentForm.name" placeholder="Object" :disabled="true">
                                </el-input>
                            </el-form-item>
                             <el-form-item label="Reference" prop="Namespace">
                                <el-select v-model="ParentForm.relationNode" placeholder="selection" size="mini" >
                                    <el-option
                                    v-for="item in relationNodes"
                                    :key="item.nodeUri"
                                    :label="item.nodeValues.DisplayName"
                                    :value="item">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-form>
                        </div>
                    </el-collapse-item>

                    <el-collapse-item title="Type" name="1" >                                    
                        <div class="formClass">
                        <!-- from 表单 开始 -->
                        <el-form size="mini" :model="ruleForm" ref="ruleForm" label-width="80px" label-position="left">
                            
                            <el-form-item label="NodeClass" prop="nodeClass" >
                                <el-input v-model="ruleForm.NodeClass" placeholder="Object" :disabled="true">
                                <!-- <el-option label="Object" value="Object"></el-option>
                                <el-option label="Object1" value="Object1"></el-option> -->
                                </el-input>
                            </el-form-item>
                            <el-form-item label="Namespace" prop="Namespace">
                                <el-input v-model="ruleForm.Namespace" :disabled="true" placeholder="NodeClass" ></el-input>
                            </el-form-item>
                            <el-form-item label="Name" prop="name">
                                <el-input  v-model="ruleForm.name"> 
                                </el-input>
                            </el-form-item>
                              <el-form-item label="IsAbstract" prop="IsAbstract">
                                <!-- `checked` 为 true 或 false -->
                                <el-checkbox v-model="ruleForm.IsAbstract" disabled></el-checkbox>
                            </el-form-item>
                            
                            
                    
                        </el-form>
                        </div>
                    </el-collapse-item>

                    <el-collapse-item title="Additional Attributes" name="2">                                    
                        <div class="formClass">
                        <!-- from 表单 开始 -->
                        <el-form size="mini" :model="attributesForm" ref="" label-width="80px" label-position="left">
                            
                            <el-form-item label="NodeId" prop="nodeClass" >
                                <el-input v-model="attributesForm.NodeId" placeholder="Object" :disabled="true">
                                </el-input>
                            </el-form-item>
                            <el-form-item label="DisplayName" prop="Namespace">
                                <el-input v-model="attributesForm.DisplayName">
                                </el-input>
                            </el-form-item>
                            <el-form-item label="BrowseName" prop="Namespace">
                                <el-input v-model="attributesForm.BrowseName">
                                </el-input>
                            </el-form-item>
                            <el-form-item label="Description" prop="Namespace">
                                 <el-input v-model="attributesForm.Description">
                                </el-input>
                            </el-form-item>
                        </el-form>
                        </div>
                    </el-collapse-item>

                    <el-collapse-item title="Children" name="3">
                        <!-- table 列表 开始 -->
                        <div class="childrenTable noactive">
                            
                        </div>                        
                    </el-collapse-item>
                    <el-collapse-item title="References" name="4">
                        <div class="referenc noactive">
                        
                        </div>
                    </el-collapse-item>
                    <!-- button 按钮 -->
                    <div class="btnClass">                    
                        <el-button size="mini" type="primary" plain  @click="saveInfo()" >提交</el-button>
                        <el-button size="mini" plain>取消</el-button>
                    </div> 
                </el-collapse>
                <!-- button 按钮 -->
                
            </div>
            </el-card>
        </div>
        
     
  </div>
</template>
<script>
import { mapState, mapActions } from "vuex";
import { compare } from "@/utils/utils";
export default {
  data() {
    return {
      relationNodes: [{
          nodeUri: "/0/45",
          nodeValues:{
            DisplayName: "HasSubType"
          }
      }],
      activeNames: ["0", "1", "2"],
      ruleForm: {
        id: null,
        name: null,
        NodeClass: null,
        Namespace: null,
        TypeDefinition: null,
        IsAbstract: null,
       
      
      },
      ParentForm: {
        name: null,
        references: null,
        relationNode :{
          nodeUri: "/0/45",
          nodeValues:{
            DisplayName: "HasSubType"
          }
        }
      },
      attributesForm: {
        NodeId: null,
        DisplayName: null,
        BrowseName: null,
        Description: null
      },
      flagDisplayName: true,
      flagBrowseName: true,
    };
  },
  computed: {
    ...mapState([
      "settings",
      "typeTreeState", // typeTreeState 数据
      "currentNode", // 数据详情
      "selectNode",
      "oldData",
      "parentNodeForSave"
    ])
  },

  created() {
    console.log("excute method： created");
    this.init();
  },
  methods: {
    init() {
      if(!this.parentNodeForSave.id){
        this.$router.push({ name: "defaultModel" });
      }
      console.log("excute method：init");
      this.preForm();
    },
    preForm() {
      //ParentForm
      this.ParentForm.name = this.$route.query.parentName;
      if (this.currentNode.relationSrc) {
        this.ParentForm.references = JSON.parse(
          this.currentNode.relationSrc
        ).BrowseName;
      }

     
      //ruleForm
      this.ruleForm.name = this.currentNode.name;
      if(this.currentNode.src){

        this.ruleForm.NodeClass = JSON.parse(this.currentNode.src).nodeValues.NodeClass;
      }else{
        this.ruleForm.NodeClass = this.currentNode.NodeClass;
      }
      this.ruleForm.TypeDefinition = this.currentNode.TypeDefinition;
      this.ruleForm.Namespace = this.currentNode.Namespace;

    if (this.currentNode.src) {
        var otherProperties = JSON.parse(this.currentNode.src);
        this.ruleForm.IsAbstract = otherProperties.nodeValues.isAbstract;
        

        //attributesForm

        this.attributesForm.NodeId = otherProperties.nodeUri;
        this.attributesForm.DisplayName = otherProperties.nodeValues.DisplayName;
        this.attributesForm.BrowseName = otherProperties.nodeValues.BrowseName;
        this.attributesForm.Description =  otherProperties.nodeValues.Description;
      } else {
        this.attributesForm.NodeId = this.$route.query.id;
         this.attributesForm.DisplayName ="";
        this.attributesForm.BrowseName = "";
        this.attributesForm.Description ="";
      }
      
      var namespace = this.attributesForm.NodeId.split("/")[1]
      if(namespace == '0'){
         this.ruleForm.Namespace = namespace + ":" + this.settings.namespaceDefault;
      }else{
         this.ruleForm.Namespace = namespace + ":" + this.settings.namespaceBase+namespace+"/";
      }

    },
    preChildren() {
      console.log("excute method： preChildren");
    },
    prePreference() {
      console.log("excute method： prePreference");
    },
    saveInfo() {
      // debugger;
      var currentNode = {};
      currentNode.nodeUri = this.attributesForm.NodeId;
      currentNode.relation = this.ParentForm.relationNode.nodeUri;
      currentNode.nodeValues = {};
      currentNode.nodeValues.name = this.ruleForm.name;
      currentNode.nodeValues.BrowseName = this.attributesForm.BrowseName;
      currentNode.nodeValues.DisplayName = this.attributesForm.DisplayName;
      currentNode.nodeValues.Description = this.attributesForm.Description;
      currentNode.nodeValues.NodeClass = this.ruleForm.NodeClass;
      currentNode.nodeValues.uri = this.attributesForm.NodeId;
      currentNode.nodeValues.isAbstract = this.ruleForm.IsAbstract;
     

      var saveData = {};
      saveData.currentNode = currentNode;
      saveData.parentNode = this.oldData.parentNode;
      saveData.relationNode = this.ParentForm.relationNode;
      saveData.children = [];
      saveData.references = [];

      var compareData = compare(this.oldData, saveData);

      this.$http.post("/mdt2/nodes/save", compareData).then(res => {
        if(res.status=='200'){
          this.$message({message: "操作成功",type: 'success'});
        }else{
          this.$message({message: "操作失败",type: 'success'});
          return;
        }
        var saveNewNodeId = res.data.currentNode[this.attributesForm.NodeId];
        var namespace = this.parentNodeForSave.id.match(/\/(\S*)\//)[1];
        var parentNodeForUpdate = this.typeTreeState.getNodeByParam('id',this.parentNodeForSave.id);
        // 强制刷新父节点
        var tree = this.typeTreeState;
        this.typeTreeState.reAsyncChildNodes(parentNodeForUpdate, "refresh",false, function(){
          var node = tree.getNodeByParam('id',saveNewNodeId);
          tree.selectNode(node);
          // 触发click事件
          tree.setting.callback.onClick(null,tree.treeId,node)
        });
      });
    },
  },
  watch: {
    $route(currentState, oldState) {
      // debugger
      console.log("路由发生了变化：" + currentState.query.id);
      this.init();
    },
    'ruleForm.name':function(newValue,oldValue){
     
      if( this.attributesForm.DisplayName === newValue ){
        this.flagDisplayName = false
      }
      if( this.attributesForm.BrowseName === newValue ){
        this.flagBrowseName = false
      }
      if( this.currentNode.id === undefined &&  newValue === undefined ){
        this.attributesForm.DisplayName = newValue;
        this.attributesForm.BrowseName = newValue;
      }else
      if( this.currentNode.id === undefined && this.attributesForm.DisplayName === oldValue && this.attributesForm.BrowseName === oldValue ){
        this.attributesForm.DisplayName = newValue;
        this.attributesForm.BrowseName = newValue;
      }else if( this.currentNode.id === undefined && this.attributesForm.DisplayName === oldValue && this.flagDisplayName === true  ){
        this.attributesForm.DisplayName = newValue;         //
      }else if( this.currentNode.id === undefined && this.attributesForm.BrowseName === oldValue && this.flagBrowseName === true ){        
        this.attributesForm.BrowseName = newValue;  // 
      }
    },
  }
};
</script>

<style>
.referenc.noactive ,.childrenTable.noactive {
    min-height: 100px;
    border: 1px solid;
    background: lightgray;
}
</style>
