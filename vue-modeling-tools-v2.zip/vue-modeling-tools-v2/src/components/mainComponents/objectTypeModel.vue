<template>
  <div>

       <el-dialog
            v-loading="loading2"    
            :title=modelName
            :visible.sync="dialogVisible"    
            width="30%"
            ref="dialog"
            :before-close="beforeCloseDialogVisible">    
            <!-- <ul id="treeDemo3" class="ztree" style="height:300px;"></ul> -->
            <public-tree> </public-tree>
            <span slot="footer" class="dialog-footer">
              <el-button @click="dialogVisible = false">取 消</el-button>
              <el-button type="primary"    @click.native="setSelectNode()">确 定</el-button>
            </span>
        </el-dialog>

       <div class="cardClass">
            <el-card class="box-card">
            <div class="itemCollapse">
                <el-collapse v-model="activeNames" >  
                    <el-collapse-item title="Parent" name="0">                                    
                        <div class="formClass">
                        <!-- from 表单 开始 -->
                        <el-form size="mini" :model="ParentForm" ref="ruleForm" label-width="80px" label-position="left">
                            
                            <el-form-item label="Name" prop="nodeClass" >
                                <el-input v-model="ParentForm.name" placeholder="Object" :disabled="true">
                                </el-input>
                            </el-form-item>
                            <el-form-item label="Reference" prop="Namespace">
                                <el-select v-model="ParentForm.relationNode" placeholder="selection" size="mini" >
                                    <el-option
                                    v-for="item in relationNodes"
                                    :key="item.nodeUri"
                                    :label="item.nodeValues.DisplayName"
                                    :value="item">
                                    </el-option>
                                </el-select>

                            </el-form-item>
                        </el-form>
                        </div>
                    </el-collapse-item>

                    <el-collapse-item title="Type" name="1" >                                    
                        <div class="formClass">
                        <!-- from 表单 开始 -->
                        <el-form size="mini" :model="ruleForm" ref="ruleForm" label-width="80px" label-position="left">
                            
                            <el-form-item label="NodeClass" prop="nodeClass" >
                                <el-input v-model="ruleForm.NodeClass" placeholder="Object" :disabled="true">
                                <!-- <el-option label="Object" value="Object"></el-option>
                                <el-option label="Object1" value="Object1"></el-option> -->
                                </el-input>
                            </el-form-item>
                            <el-form-item label="Namespace" prop="Namespace">
                                <el-input v-model="ruleForm.Namespace" :disabled="true" placeholder="NodeClass" ></el-input>
                            </el-form-item>
                            <el-form-item label="Name" prop="name">
                                <el-input  v-model.lazy="ruleForm.name"> 
                                </el-input>
                            </el-form-item>
                             <el-form-item label="IsAbstract" prop="name">
                                <!-- `checked` 为 true 或 false -->
                                <el-checkbox v-model="ruleForm.IsAbstract"></el-checkbox>
                            </el-form-item>
                        </el-form>
                        </div>
                    </el-collapse-item>

                    <el-collapse-item title="Additional Attributes" name="2">                                    
                        <div class="formClass">
                        <!-- from 表单 开始 -->
                        <el-form size="mini" :model="attributesForm" ref="" label-width="80px" label-position="left">
                            
                            <el-form-item label="NodeId" prop="nodeClass" >
                                <el-input v-model="attributesForm.NodeId" placeholder="Object" :disabled="true"></el-input>
                            </el-form-item>
                            <el-form-item label="DisplayName" prop="Namespace">
                                <el-input v-model="attributesForm.DisplayName"></el-input>
                            </el-form-item>
                            <el-form-item label="BrowseName" prop="Namespace">
                                <el-input v-model="attributesForm.BrowseName"></el-input>
                            </el-form-item>
                            <el-form-item label="Description" prop="Namespace">
                                <el-input v-model="attributesForm.Description"></el-input>
                            </el-form-item>
                            <template v-if="attributesForm.NodeId.indexOf('/0/')!=0">
                              <div class="over-hr">
                                <span class="btn-circle" @click.prevent="addProperty()">
                                    <i class="el-icon-circle-plus-outline"></i>  Extends Attributes
                                </span>
                            </div>
                            </template>
                            
                            <template v-for="(property,index) in attributesForm.properties" >
                            <el-form-item>
                              <el-input style="width:125px" placeholder="属性名称"  v-model="property.name"></el-input>
                              <el-select style="width:100px" placeholder="属性类型" allow-create="" filterable="" v-model="property.type">
                                <el-option label="string" value="string"></el-option>
                                <el-option label="boolean" value="boolean"></el-option>      
                                <el-option label="number" value="number"></el-option>
                                <el-option label="object" value="object"></el-option>
                                <el-option label="array" value="array"></el-option>
                              </el-select>
                              <el-input style="width:200px" placeholder="描述"  v-model="property.description"></el-input>
                              <el-button style="float:right;" @click.prevent="delProperty(property)">删除</el-button>
                            </el-form-item>
                            </template>
                        </el-form>
                        </div>
                    </el-collapse-item>

                    <el-collapse-item title="Children" name="3">
                    <!-- table 列表 开始 -->
                        <div class="childrenTable">
                            <el-table
                                    :data="childrenForTable"
                                    border
                                    size="mini"
                                    style="width: 100%;">    
                                    <el-table-column
                                        prop="nodeClass"
                                        label="NodeClass"
                                        width="120">
                                        <template  slot-scope="scope">
                                            <el-select v-model="scope.row.nodeClass" placeholder="请选择" size="mini" >
                                                <el-option
                                                v-for="item in NodeClassoptions"
                                                :key="item.value"
                                                :label="item.label"
                                                :value="item.value">
                                                </el-option>
                                            </el-select>
                                        </template>
                                    </el-table-column>
                        
                                    <el-table-column
                                        prop="name"
                                        label="Name"
                                        width="120">
                                        <template  slot-scope="scope">
                                            <el-input v-model="scope.row.node.nodeValues.DisplayName" size="mini"></el-input>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                        prop="TypeDefinition"
                                        label="TypeDefinition">
                                        <template  slot-scope="scope">
                                        <el-input v-model="scope.row.typeDefinition.nodeValues.DisplayName"  @focus="openTypeModels(scope.$index)" size="mini"></el-input>
                                        
                                        </template>
                                    </el-table-column>
                                   <el-table-column
                                        prop="ModellingRule"
                                        label="ModellingRule">
                                        <template  slot-scope="scope">
                                            <el-select v-model="scope.row.modellingRule" value-key="nodeUri" placeholder="请选择" size="mini">
                                                <el-option
                                                v-for="item in ModellingRuleOptions"
                                                :key="item.nodeUri"
                                                :label="item.nodeValues.DisplayName"
                                                :value="item">
                                                </el-option>                                            
                                            </el-select>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                        prop="DataType"
                                        label="DataType">
                                        <template  slot-scope="scope">
                                        <el-input v-model="scope.row.dataType.nodeValues.DisplayName"  @focus="openDataModels(scope.$index)" size="mini"></el-input>
                                        
                                        </template>
                                    </el-table-column>
                                    <el-table-column                              
                                        label="Edit"
                                                                
                                        width="80"
                                        style="border-collapse:inherit;">                         
                                            <template slot-scope="scope">
                                                <span class="edit" >
                                                    <el-button  type="text" size="small" @click.native="FnAddChildRow(scope.$index,scope.row, childrenForTable)">新增</el-button>           
                                                </span>
                                                <span class="delete">
                                                    <el-button  type="text" size="small" @click.native="FnDeleteChildRow(scope.$index, childrenForTable)">删除</el-button>           
                                                </span>
                                            </template>
                                    </el-table-column>
                                    </el-table>
                        </div>
                        
                    </el-collapse-item>
                    <el-collapse-item title="References" name="4">
                            <div class="referenc">
                            <el-table
                                :data="referenceTable"
                                border
                                size="mini"
                                style="width: 100%;">
                                <el-table-column
                                    prop="date"
                                    label="Reference Type"
                                    width="180">
                                    <template  slot-scope="scope">
                                        <el-input v-model="scope.row.rel.nodeValues.DisplayName"  @focus="openReferModels(scope.$index)" size="mini"></el-input>
                                    </template>
                                </el-table-column>
                                <el-table-column
                                    prop="name"
                                    label="Target"
                                    width="180">
                                    <template  slot-scope="scope">
                                       <el-input v-model="scope.row.targetNode.nodeValues.DisplayName"  @focus="openTargetModels(scope.$index)" size="mini"></el-input>
                                    </template>
                                </el-table-column>
                                <el-table-column>
                                </el-table-column>

                                <el-table-column                              
                                    label="Edit"   
                                    width="120"
                                    style="border-collapse:inherit;">                         
                                        <template slot-scope="scope">
                                        <span class="edit">
                                            <el-button  type="text" size="small" @click.native="FnAddReferenceRow(scope.$index,scope.row, referenceTable)">新增</el-button>            
                                        </span>
                                         <span class="delete">
                                                    <el-button  type="text" size="small" @click.native="FnDeleteReferenceRow(scope.$index, referenceTable)">删除</el-button>           
                                                </span>
                                        </template>
                                </el-table-column>
                                </el-table>
                            </div>
                    </el-collapse-item>
                        <!-- button 按钮 -->
                    <div class="btnClass">                    
                        <el-button size="mini" type="primary" plain @click="saveInfo()" >提交</el-button>
                        <el-button size="mini" plain>取消</el-button>
                    </div> 
                </el-collapse>
                <!-- button 按钮 -->
                
            </div>
            </el-card>
        </div>
        
     
  </div>
</template>
<script>
import { mapState, mapActions } from "vuex";
import publicTree from "@/components/publicTree";
import { compare, isEqual } from "@/utils/utils";
export default {
  components: { publicTree },
  data() {
    return {
      dialogVisible: false, // 数据初始化dialog弹出框控制
      loading2: false,

      ModellingRuleOptions: [
        {
          nodeUri: "/0/78",
          nodeValues: {
            DisplayName: "Mandatory"
          }
        },
        {
          nodeUri: "/0/80",
          nodeValues: {
            DisplayName: "Optional"
          }
        }
      ],
      relationNodes: [
        {
          nodeUri: "/0/45",
          nodeValues: {
            DisplayName: "HasSubType"
          }
        }
      ],

      NodeClassoptions: [
        {
          value: "Variable",
          label: "Variable"
        },
        {
          value: "Object",
          label: "Object"
        }
      ],

      // 表单数据 初始化开始

      activeNames: ["0", "1", "2"],
      Typetitle: "Instance",
      ruleForm: {
        id: null,
        name: null,
        NodeClass: null,
        Namespace: null,
        TypeDefinition: null,
        IsAbstract: null
      },
      ParentForm: {
        name: null,
        references: null,
        relationNode: {
          nodeUri: "/0/45",
          nodeValues: {
            DisplayName: "HasSubType"
          }
        }
      },

      attributesForm: {
        NodeId: null,
        DisplayName: null,
        BrowseName: null,
        Description: null,
        properties: [],
        newProperty: {
          name: "",
          type: ""
        }
      },
      cacheIndex: null,
      children: [],
      references: [],
      modelName: null,
      flagDisplayName: true,
      flagBrowseName: true
    };
  },
  computed: {
    ...mapState([
      "settings",
      "typeTreeState", // typeTreeState 数据
      "currentNode", // 数据详情
      "childrenForTable",
      "referenceTable",
      "selectNode",
      "oldData",
      "parentNodeForSave"
    ])
  },

  created() {
    console.log("excute method： created");
    this.init();
  },
  methods: {
    ...mapActions([
      "getUri",
      "updateChildRelation",
      "updateReferenceRelation",
      "addChildRow",
      "deleteChildRow",
      "addReferenceRow",
      "deleteReferenceRow"
    ]),

    init() {
      if (!this.parentNodeForSave.id) {
        this.$router.push({ name: "defaultModel" });
      }
      console.log("excute method：init");
      this.preForm();
      this.preChildren();
      this.prePreference();
    },

    prompt() {
      this.$message({
        message: "请选择NodeClass!!!",
        type: "warning",
        duration: 1000
      });
    },
    preForm() {
      //ParentForm
      this.ParentForm.name = this.$route.query.parentName;
      this.attributesForm.properties = [];
      if (this.currentNode.relationSrc) {
        this.ParentForm.references = JSON.parse(
          this.currentNode.relationSrc
        ).BrowseName;
      }

      //ruleForm
      this.ruleForm.name = this.currentNode.name;
      if (this.currentNode.src) {
        this.ruleForm.NodeClass = JSON.parse(
          this.currentNode.src
        ).nodeValues.NodeClass;
      } else {
        this.ruleForm.NodeClass = this.currentNode.NodeClass;
      }

      this.ruleForm.TypeDefinition = this.currentNode.TypeDefinition;
      this.ruleForm.Namespace = this.currentNode.Namespace;
      if (this.currentNode.src) {
        var otherProperties = JSON.parse(this.currentNode.src);
        this.ruleForm.IsAbstract = otherProperties.nodeValues.isAbstract;
        if (otherProperties.nodeValues.schema) {
          this.attributesForm.properties = this.attributesForm.properties.concat(
            otherProperties.nodeValues.schema
          );
        } else {
          this.attributesForm.properties = [];
        }

        //attributesForm
        this.attributesForm.NodeId = otherProperties.nodeUri;
        this.attributesForm.DisplayName =
          otherProperties.nodeValues.DisplayName;
        this.attributesForm.BrowseName = otherProperties.nodeValues.BrowseName;
        this.attributesForm.Description =
          otherProperties.nodeValues.Description;
      } else {
        this.attributesForm.NodeId = this.$route.query.id;
        this.attributesForm.DisplayName = "";
        this.attributesForm.BrowseName = "";
        this.attributesForm.Description = "";
      }

      var namespace = this.attributesForm.NodeId.split("/")[1];
      if (namespace == "0") {
        this.ruleForm.Namespace =
          namespace + ":" + this.settings.namespaceDefault;
      } else {
        this.ruleForm.Namespace =
          namespace + ":" + this.settings.namespaceBase + namespace + "/";
      }
    },

    preChildren() {
      console.log("excute method： preChildren");
    },
    prePreference() {
      console.log("excute method： prePreference");
    },

    // 鼠标聚焦弹出 dialog
    openTypeModels(index) {
      // debugger;

      this.cacheIndex = index;
      if (!this.childrenForTable[this.cacheIndex].nodeClass) {
        this.prompt();
      } else {
        this.modelName = "Add TypeDefinition";

        if (this.childrenForTable[this.cacheIndex].nodeClass == "Variable") {
          this.getUri("/0/89");
        } else if (
          this.childrenForTable[this.cacheIndex].nodeClass == "Object"
        ) {
          this.getUri("/0/88");
        }

        this.dialogVisible = true;
      }
    },

    openDataModels(index) {
      this.modelName = "Add DadaType";
      this.cacheIndex = index;
      this.getUri("/0/90");

      this.dialogVisible = true;
    },

    openReferModels(index) {
      this.modelName = "Add References";
      this.cacheIndex = index;
      this.getUri("/0/91");
      this.dialogVisible = true;
    },

    openTargetModels(index) {
      this.modelName = "Add Target";
      this.cacheIndex = index;
      this.getUri("");
      this.dialogVisible = true;
    },

    //关闭之前
    beforeCloseDialogVisible() {
      this.dialogVisible = false;
      console.log("模态层关闭之前的操作");
    },

    //模态层点击确定
    setSelectNode() {
      var selectIfo = JSON.parse(this.selectNode.src);
      if (this.modelName == "Add TypeDefinition") {
        // 如果Typedefinition发生变化，node节点需要重建
        if (
          this.childrenForTable[this.cacheIndex].typeDefinition.nodeUri !=
          selectIfo.nodeUri
        ) {
          var newData = {
            nodeValues: {
              DisplayName: this.childrenForTable[this.cacheIndex].node
                .nodeValues.DisplayName
            }
          };
          this.updateChildRelation({
            index: this.cacheIndex,
            prop: "node",
            data: newData
          });

          this.updateChildRelation({
            index: this.cacheIndex,
            prop: "typeDefinition",
            data: selectIfo
          });
        }
      } else if (this.modelName == "Add DadaType") {
        this.updateChildRelation({
          index: this.cacheIndex,
          prop: "dataType",
          data: selectIfo
        });
        var newData = Object.assign(
          {},
          this.childrenForTable[this.cacheIndex].node
        );
        newData.nodeValues.DataType = selectIfo.nodeUri;
        this.updateChildRelation({
          index: this.cacheIndex,
          prop: "node",
          data: newData
        });
      } else if (this.modelName == "Add References") {
        this.updateReferenceRelation({
          index: this.cacheIndex,
          prop: "rel",
          data: selectIfo
        });
      } else if (this.modelName == "Add Target") {
        this.updateReferenceRelation({
          index: this.cacheIndex,
          prop: "targetNode",
          data: selectIfo
        });
      }

      this.dialogVisible = false;
    },

    // 添加更多方法
    FnAddChildRow(index, row, rows) {
      var data = {
        node: {
          nodeValues: {
            DisplayName: ""
          }
        },
        typeDefinition: {
          nodeValues: {
            DisplayName: ""
          }
        },
        dataType: {
          nodeValues: {
            DisplayName: ""
          }
        },
        modellingRule: {
          nodeValues: {
            DisplayName: ""
          }
        }
      };
      this.addChildRow(data);
    },
    FnDeleteChildRow(index, rows) {
      this.deleteChildRow(index);
    },
    // 添加更多方法
    FnAddReferenceRow(index, row, rows) {
      var data = {
        rel: { nodeValues: {} },
        targetNode: { nodeValues: {} }
      };
      this.addReferenceRow(data);
    },
    FnDeleteReferenceRow(index, rows) {
      this.deleteReferenceRow(index);
    },

    addProperty() {
      var property = {
        name: "",
        type: "",
        description: ""
      };

      this.attributesForm.properties.unshift(property);
    },
    delProperty(property) {
      var index = this.attributesForm.properties.indexOf(property);
      if (index !== -1) {
        this.attributesForm.properties.splice(index, 1);
      }
    },

    saveInfo() {
      // debugger;
      var currentNode = {};
      currentNode.nodeUri = this.attributesForm.NodeId;
      currentNode.relation = this.ParentForm.references;
      currentNode.nodeValues = {};
      currentNode.nodeValues.name = this.ruleForm.name;
      currentNode.nodeValues.BrowseName = this.attributesForm.BrowseName;
      currentNode.nodeValues.DisplayName = this.attributesForm.DisplayName;
      currentNode.nodeValues.DataType = this.attributesForm.DataType;
      currentNode.nodeValues.Description = this.attributesForm.Description;
      currentNode.nodeValues.NodeClass = this.ruleForm.NodeClass;
      currentNode.nodeValues.uri = this.attributesForm.NodeId;
      currentNode.nodeValues.isAbstract = this.ruleForm.IsAbstract;
      currentNode.nodeValues.schema = JSON.stringify(
        this.attributesForm.properties
      );

      var saveData = {};

      saveData.currentNode = currentNode;
      saveData.parentNode = this.oldData.parentNode;
      //   saveData.typeDefinitionNode = {};
      //   saveData.modellingRuleNode = {};
      saveData.relationNode = this.ParentForm.relationNode;
      saveData.children = this.childrenForTable;
      saveData.references = this.referenceTable;

      var compareData = compare(this.oldData, saveData);

      this.$http.post("/mdt2/nodes/save", compareData).then(res => {
        //  res.currentNode[nodeUri]
        //1.刷新节点
        //2.获取子节点 更新from
        //
        if (res.status == "200") {
          this.$message({ message: "操作成功", type: "success" });
        } else {
          this.$message({ message: "操作失败", type: "success" });
          return;
        }
        var saveNewNodeId = res.data.currentNode[this.attributesForm.NodeId];
        var namespace = this.parentNodeForSave.id.match(/\/(\S*)\//)[1];
        var parentNodeForUpdate = this.typeTreeState.getNodeByParam(
          "id",
          this.parentNodeForSave.id
        );
        // 强制刷新父节点
        var tree = this.typeTreeState;
        this.typeTreeState.reAsyncChildNodes(
          parentNodeForUpdate,
          "refresh",
          false,
          function() {
            var node = tree.getNodeByParam("id", saveNewNodeId);
            tree.selectNode(node);
            // 触发click事件
            tree.setting.callback.onClick(null, tree.treeId, node);
          }
        );
      });
    }
  },

  watch: {
    $route(currentState, oldState) {
      console.log("路由发生了变化：" + currentState.query.id);
      this.init();
    },
    "ruleForm.name": function(newValue, oldValue) {
      if (this.attributesForm.DisplayName === newValue) {
        this.flagDisplayName = false;
      }
      if (this.attributesForm.BrowseName === newValue) {
        this.flagBrowseName = false;
      }
      if (this.currentNode.id === undefined && newValue === undefined) {
        this.attributesForm.DisplayName = newValue;
        this.attributesForm.BrowseName = newValue;
      } else if (
        this.currentNode.id === undefined &&
        this.attributesForm.DisplayName === oldValue &&
        this.attributesForm.BrowseName === oldValue
      ) {
        this.attributesForm.DisplayName = newValue;
        this.attributesForm.BrowseName = newValue;
      } else if (
        this.currentNode.id === undefined &&
        this.attributesForm.DisplayName === oldValue &&
        this.flagDisplayName === true
      ) {
        this.attributesForm.DisplayName = newValue; //
      } else if (
        this.currentNode.id === undefined &&
        this.attributesForm.BrowseName === oldValue &&
        this.flagBrowseName === true
      ) {
        this.attributesForm.BrowseName = newValue; //
      }
    }
  }
};
</script>
<style>
.collapseClass {
  width: 96%;
  margin: 0 30px 0 6px;
}
.collapseClass .el-collapse-item__header {
  height: 32px;
  line-height: 32px;
}

.collapseClass .el-collapse-item__arrow {
  margin-right: 18px;

  line-height: 32px;
}
.formClass {
  width: 600px;
  margin-left: 6px;
}
.formClass .el-form-item__label {
  font-size: 12px;
}
.formClass .opt-properties {
  cursor: pointer;
  color: #409eff;
  font-size: 12px;
  font-weight: bold;
}
/* 提交 button 按钮样式 */
.btnClass {
  float: right;
  margin: 10px 40px 10px 10px;
  /* margin-bottom: 80px; */
}
.property-margin-top {
  margin-top: -1.25rem;
}

.over-hr {
  overflow: hidden;
  text-align: center;
  margin: 5px 0 5px 0;
}

.over-hr > span {
  position: relative;
  display: inline-block;
  font-size: 13px;
}

.over-hr > span:after,
.over-hr > span:before {
  content: "";
  position: absolute;
  top: 50%;
  height: 1px;
  width: 9999px;
  background: #ccd1d3;
}

.over-hr > span:before {
  right: 100%;
  margin-right: 15px;
}

.over-hr > span:after {
  left: 100%;
  margin-left: 15px;
}
.over-hr > .btn-circle {
  cursor: pointer;
}

.btn-circle,
.btn-circle-text {
  line-height: 1.42857;
  touch-action: manipulation;
  background-color: transparent;
  background-repeat: no-repeat;
  padding: 0;
  border: 0;
  text-decoration: none;
}

.btn-circle I,
.btn-circle-text I {
  vertical-align: middle;
  font-size: 1.5em;
}

.btn-circle[disabled],
[disabled].btn-circle-text {
  opacity: 0.5;
}
</style>

