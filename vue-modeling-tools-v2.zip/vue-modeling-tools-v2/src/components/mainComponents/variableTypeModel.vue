<template>
  <div>
      <!-- 这是VariableTypeModel节点v-loading="loading2"   name:{{ruleForm.name}} -->
      <el-dialog
               
            :title=modelName
            :visible.sync="dialogVisible"    
            width="30%"
            ref="dialog"
            :before-close="beforeCloseDialogVisible">    
            <!-- <ul id="treeDemo3" class="ztree" style="height:300px;"></ul> -->
            <public-tree> </public-tree>
            <span slot="footer" class="dialog-footer">
              <el-button @click="dialogVisible = false">取 消</el-button>
              <el-button type="primary" @click.native="setSelectNode()">确 定</el-button>
            </span>
        </el-dialog>

       <div class="cardClass">
            <el-card class="box-card">
              <div class="itemCollapse">
                  <el-collapse v-model="activeNames" >  
                         <el-collapse-item title="Parent" name="0">                                    
                          <div class="formClass">
                          <!-- from 表单 开始 -->
                          <el-form size="mini" :model="ParentForm" ref="ruleForm" label-width="80px" label-position="left">
                              
                              <el-form-item label="Name">
                                  <el-input v-model="ParentForm.name" placeholder="Object" >
                                  </el-input>
                              </el-form-item>
                              <el-form-item label="Reference">
                                  <el-select v-model="ParentForm.relationNode"  style="width: 100%">
                                        <el-option
                                            v-for="item in relationNodes"
                                            :key="item.nodeUri"
                                            :label="item.nodeValues.DisplayName"
                                            :value="item">
                                        </el-option>
                                  </el-select>
                              </el-form-item>
                          </el-form>
                          </div>
                        </el-collapse-item>

                        <el-collapse-item title="Type" name="1" >                                    
                            <div class="formClass">
                            <!-- from 表单 开始 -->
                            <el-form size="mini" :model="ruleForm" ref="ruleForm" label-width="80px" label-position="left">
                                <el-form-item label="NodeClass" prop="nodeClass" >
                                    <el-input v-model="ruleForm.NodeClass" placeholder="NodeClass" ></el-input>
                                </el-form-item>
                                <el-form-item label="Namespace" prop="Namespace">
                                    <el-input v-model="ruleForm.Namespace" :disabled="true" placeholder="NodeClass" ></el-input>
                                </el-form-item>
                                <el-form-item label="Name" prop="name">
                                    <el-input  v-model="ruleForm.name"> 

                                    </el-input>
                                </el-form-item>
                                 <el-form-item label="Data type" prop="dataTypeName">
                                   <el-input  v-model="ruleForm.dataType.nodeValues.DisplayName" @focus="openNodesDataModels"> </el-input>
                                    <!-- <el-select v-model="ruleForm.dataType"  style="width: 100%">
                                       
                                        <el-option
                                            v-for="item in dataTypeNodes"
                                            :key="item.value"
                                            :label="item.label"
                                            :value="item.value">
                                        </el-option>
                                    </el-select> -->
                                   
                                    
                                </el-form-item>
                                <el-form-item label="IsAbstract" prop="name">
                                <!-- `checked` 为 true 或 false -->
                                    <el-checkbox v-model="ruleForm.IsAbstract" disabled></el-checkbox>
                                </el-form-item>
                                
                        
                            </el-form>
                            </div>
                        </el-collapse-item>

                         <el-collapse-item title="Additional Attributes" name="2">                                    
                                <div class="formClass">
                                <!-- from 表单 开始 -->
                                <el-form size="mini" :model="attributesForm" ref="" label-width="80px" label-position="left">
                                    
                                    <el-form-item label="NodeId" prop="nodeClass" >
                                        <el-input v-model="attributesForm.NodeId" placeholder="Object" :disabled="true">
                                        </el-input>
                                    </el-form-item>
                                    <el-form-item label="DisplayName" prop="Namespace">
                                        <el-input v-model="attributesForm.DisplayName"  style="width: 100%">
                                        </el-input>
                                    </el-form-item>
                                    <el-form-item label="BrowseName" prop="Namespace">
                                        <el-input v-model="attributesForm.BrowseName"  style="width: 100%">
                                        </el-input>
                                    </el-form-item>
                                    <el-form-item label="Description" prop="Namespace">
                                        <el-input v-model="attributesForm.Description"  style="width: 100%">
                                        </el-input>
                                    </el-form-item>
                                     <!-- <el-form-item label="Value" prop="Namespace">
                                        <el-input v-model="attributesForm.Value"  style="width: 100%">
                                        </el-input>
                                    </el-form-item>
                                     <el-form-item label="ValueRank" prop="Namespace">
                                        <el-input v-model="attributesForm.ValueRank"  style="width: 100%">
                                        </el-input>
                                    </el-form-item>
                                     <el-form-item label="ArryDimesions" prop="Namespace">
                                        <el-input v-model="attributesForm.ArryDimesions"  style="width: 100%">
                                        </el-input>
                                    </el-form-item> -->
                                </el-form>
                                </div>
                         </el-collapse-item>


                        <el-collapse-item title="Children" name="3">
                        <!-- table 列表 开始 -->
                            <div class="childrenTable">
                                <el-table
                                    :data="childrenForTable"
                                    border
                                    size="mini"
                                    style="width: 100%;">
                                    <el-table-column type="expand" >
                                        <template slot-scope="props" style="padding: 10px 10px 10px 10px;">
                                        <el-form label-position="left" inline class="demo-table-expand">
                                            <el-form-item label="ReferenceType">
                                            <span>{{ props.row.ReferenceType }}</span>
                                            </el-form-item>
                                            <el-form-item label="DisplayName">
                                            <span>{{ props.row.DisplayName }}</span>
                                            </el-form-item>   
                                            <el-form-item label="BowersName">
                                            <span>{{ props.row.BowersName }}</span>
                                            </el-form-item>                        
                                            <el-form-item label="Description">
                                            <span>{{ props.row.Description }}</span>
                                            </el-form-item>                                            
                                            <el-form-item label="ID">
                                            <span>{{ props.row.id }}</span>
                                            </el-form-item>                                    
                                        </el-form>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                        prop="NodeClass"
                                        label="NodeClass"
                                        width="120">
                                        <template  slot-scope="scope">
                                            <el-select v-model="scope.row.nodeClass" placeholder="请选择" size="mini" >
                                                <el-option
                                                    v-for="nodeClass in NodeClassoptions"
                                                    :key="nodeClass.value"
                                                    :label="nodeClass.label"
                                                    :value="nodeClass.value">
                                                </el-option>
                                            </el-select>
                                        </template>
                                    </el-table-column>
                        
                                    <el-table-column
                                        prop="name"
                                        label="Name"
                                        width="120">
                                        <template  slot-scope="scope">
                                            <el-input v-model="scope.row.node.nodeValues.DisplayName" size="mini"></el-input>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                        prop="TypeDefinition"
                                        label="TypeDefinition">
                                        <template  slot-scope="scope">
                                            <el-input v-model="scope.row.typeDefinition.nodeValues.DisplayName" @focus="openTypeModels(scope.$index)" size="mini"></el-input>                                          
                                            
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                        prop="ModellingRule"
                                        label="ModellingRule">
                                        <template slot-scope="scope">
                                            <el-select v-model="scope.row.modellingRule" value-key="nodeUri" placeholder="请选择" size="mini">
                                                <el-option
                                                v-for="item3 in ModellingRuleOptions"
                                                :key="item3.nodeUri"
                                                :label="item3.nodeValues.DisplayName"
                                                :value="item3">
                                                </el-option>                                                
                                            </el-select>
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                        prop="DateType"
                                        label="DateType">
                                        <template  slot-scope="scope">
                                            <el-input v-model="scope.row.dataType.nodeValues.DisplayName"  @focus="openDataModels(scope.$index)" size="mini"></el-input>
                                            <!-- <el-select v-model="scope.row.item3" placeholder="" size="mini">
                                                <el-option
                                                v-for="item3 in DateTypeoption"   
                                                :key="item3.value"
                                                :label="item3.label"
                                                :value="item3.value">
                                                </el-option>
                                                
                                            </el-select> -->
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                        label="Edit"                                                                    
                                        width="80"
                                        style="border-collapse:inherit;">                         
                                            <template slot-scope="scope">
                                                <span class="edit" >
                                                    <el-button type="text" size="small" @click.native="FnAddChildRow(scope.$index,scope.row, childrenForTable)">新增</el-button>           
                                                </span>
                                                <span class="delete">
                                                    <el-button type="text" size="small" @click.native="FnDeleteChildRow(scope.$index, childrenForTable)">删除</el-button>           
                                                </span>
                                            </template>
                                    </el-table-column>
                                </el-table>
                            </div>
                                
                        </el-collapse-item>

                        <el-collapse-item title="References" name="4">
                                <div class="referenc">
                                <el-table
                                    :data="referenceTable"
                                    border
                                    size="mini"
                                    style="width: 100%;">
                                    <el-table-column
                                        prop="date"
                                        label="ReferenceType"
                                        width="180">
                                        <template  slot-scope="scope">
                                            <el-input v-model="scope.row.rel.nodeValues.DisplayName" @focus="openReferModels(scope.$index)" size="mini"></el-input>                                           
                                        </template>
                                    </el-table-column>
                                    <el-table-column
                                        prop="name"
                                        label="Target"
                                        width="180">
                                        <template  slot-scope="scope">
                                            <el-input v-model="scope.row.targetNode.nodeValues.DisplayName" @focus="openTargetModels(scope.$index)" size="mini"></el-input>
                                            <!-- <el-select v-model="scope.row.item" placeholder="请选择" size="mini">
                                                <el-option
                                                v-for="item in TargetOption"   
                                                :key="item.value"
                                                :label="item.label"
                                                :value="item.value">
                                                </el-option>
                                                
                                            </el-select> -->
                                        </template>
                                    </el-table-column>
                                    <el-table-column>
                                    </el-table-column>

                                    <el-table-column                              
                                        label="Edit"   
                                        width="120"
                                        style="border-collapse:inherit;">                         
                                            <template slot-scope="scope">
                                                <span class="edit">
                                                    <el-button  type="text" size="small" @click.native="FnAddReferenceRow(scope.$index,scope.row, referenceTable)">新增</el-button>            
                                                </span>
                                                <span class="delete">
                                                    <el-button  type="text" size="small" @click.native="FnDeleteReferenceRow(scope.$index, referenceTable)">删除</el-button>           
                                                </span>
                                        
                                            </template>
                                    </el-table-column>
                                    </el-table>
                                </div>
                        </el-collapse-item>
                        <!-- button 按钮 -->
                        <div class="btnClass">                    
                            <el-button size="mini" type="primary" plain @click.native="saveInfo" >提交</el-button>
                            <el-button size="mini" plain>取消</el-button>
                        </div> 
                  </el-collapse>
                  <!-- button 按钮 -->
                  <!-- {{ childrenForTable }} -->
                  
              </div>
            </el-card>
        </div>
        
     
  </div>
</template>
<script>
import { mapState, mapActions } from "vuex";
import publicTree from "@/components/publicTree";
import { compare,isEqual } from "@/utils/utils";
export default {
    components: { publicTree },
  data() {
    return {
        dialogVisible: false, // 数据初始化dialog弹出框控制
      DateTypeoption: [],
       ModellingRuleOptions: [
        
        {
          nodeUri: "/0/80",
          nodeValues:{
            DisplayName: "Optional"
          }
        },{
           nodeUri: "/0/78",
           nodeValues:{
            DisplayName: "Mandatory"
          }
        },],
      
      TargetOption:[],
      ReferencesOption:[],
  
      // 表单数据 初始化开始

      activeNames: ["0","1","2"],
      Typetitle: "Instance",
      ruleForm: {
        id: null,
        name: null,
        NodeClass: null,
        Namespace: null,
        TypeDefinition: null,
        dataType: null,
        IsAbstract: null
      },
    //   BaseDateType  Double  ByteString   string   BuildInfo   Boolean   
       dataTypeNodes: [{
          value: 'BaseDateType',
          label: 'BaseDateType'
        }, {
          value: 'Double',
          label: 'Double'
        }, {
          value: 'ByteString',
          label: 'ByteString'
        }, {
          value: 'string',
          label: 'string'
        }, {
          value: 'BuildInfo',
          label: 'BuildInfo'
        },{
          value: 'Boolean',
          label: 'Boolean'
        }],
      ParentForm: {
        name: null,
        references: null,
        relationNode :{
          nodeUri: "/0/45",
          nodeValues:{
            DisplayName: "HasSubType"
          }
        }
      },
       relationNodes: [{
          nodeUri: "/0/45",
          nodeValues:{
            DisplayName: "HasSubType"
          }
      }],
      attributesForm: {
        NodeId: null,
        DisplayName: null,
        BrowseName: null,
        Description: null,
        Value: null,
        ValueRank: null,
        ArryDimesions: null
      },
        NodeClassoptions: [
        {
            value: "Variable",
            label: "Variable"
        },
        // {
        //     value: "NoSelection",
        //     label: "NoSelection"
        // },     
        ],
      children: [],
      references: [],
      cacheIndex: null,
      modelName: null,  // dialog彈出框名稱
      flagDisplayName: true,
      flagBrowseName: true,
    };
  },
  computed: {
    ...mapState([
      "settings",
      "typeTreeState", // typeTreeState 数据
      "currentNode", // 数据详情
      "childrenForTable",//children子節點信息
      "referenceTable",// referenceTable 關係節點信息
      "selectNode",
      "oldData",
      "parentNodeForSave"
    ])
  },

  created() {
    console.log("excute method： created");
    this.init();
  },
  methods: {
    ...mapActions([
        
        "getUri",
        "updateChildRelation",
        "updateReferenceRelation",
        "addChildRow",
        "deleteChildRow",
        "addReferenceRow",
        "deleteReferenceRow",
        "updataDataType"
    ]), 
    beforeCloseDialogVisible() {
      this.dialogVisible = false;
      console.log("模态层关闭之前的操作");
    },
     

    init() {
      if(!this.parentNodeForSave.id){
        this.$router.push({ name: "defaultModel" });
      }
      console.log("excute method：init");
      this.preForm();
      this.preChildren();
      this.prePreference();
    },
    preForm() {
       this.ParentForm.name = this.$route.query.parentName;
       if (this.currentNode.relationSrc) {
        this.ParentForm.references = JSON.parse(
          this.currentNode.relationSrc
        ).DisplayName;
      }
      
      //ruleForm
      this.ruleForm.name = this.currentNode.name;
      if (this.currentNode.dataTypeSrc) {  // 如果currentNode 裡面有 dataTypeSrc，那麼就把displayName 賦值給 ruleForm.dataType
        this.ruleForm.dataType = JSON.parse(
            this.currentNode.dataTypeSrc)
      }else{
        this.ruleForm.dataType = { nodeValues:{DisplayName: ""}}
      }

      if(this.currentNode.src){
        this.ruleForm.NodeClass = JSON.parse(this.currentNode.src).nodeValues.NodeClass;
      }else{
        this.ruleForm.NodeClass = this.currentNode.NodeClass; 
      }
           
      // this.ruleForm.NodeClass = this.currentNode.NodeClass;
      this.ruleForm.TypeDefinition = this.currentNode.TypeDefinition;
      this.ruleForm.Namespace = this.currentNode.Namespace;
      
      //attributesForm
      if (this.currentNode.src) {
        var otherProperties = JSON.parse(this.currentNode.src);
       
        this.ruleForm.IsAbstract = otherProperties.nodeValues.isAbstract;
        // this.ruleForm.dataType = otherProperties.nodeValues.DataType;
        this.attributesForm.NodeId = otherProperties.nodeUri;
        this.attributesForm.DisplayName = otherProperties.nodeValues.DisplayName;
        this.attributesForm.BrowseName = otherProperties.nodeValues.BrowseName;
        this.attributesForm.Description = otherProperties.nodeValues.Description;
        // this.attributesForm.Value = otherProperties.nodeValues.Value;


      } else {
        this.attributesForm.NodeId = this.$route.query.id;
        this.attributesForm.DisplayName = '';
        this.attributesForm.BrowseName = '';
        this.attributesForm.Description = '';
        // this.attributesForm.Value = '';
      
      }
      var namespace = this.attributesForm.NodeId.split("/")[1]
      if(namespace == '0'){
         this.ruleForm.Namespace = namespace + ":" + this.settings.namespaceDefault;
      }else{
         this.ruleForm.Namespace = namespace + ":" + this.settings.namespaceBase+namespace+"/";
      }     
    },
    preChildren() {
      console.log("excute method： preChildren");
    },
    prePreference() {
      console.log("excute method： prePreference");
    },
    saveInfo() {
      
      var currentNode = {};
      
      currentNode.nodeUri = this.attributesForm.NodeId;
      currentNode.relation = this.ParentForm.references;

      //attributesForm
      currentNode.nodeValues = {};
      currentNode.nodeValues.name = this.ruleForm.name;
      currentNode.nodeValues.NodeClass = this.ruleForm.NodeClass;
      currentNode.nodeValues.Description = this.attributesForm.Description;
      currentNode.nodeValues.BrowseName = this.attributesForm.BrowseName;
      currentNode.nodeValues.DisplayName = this.attributesForm.DisplayName;
      currentNode.nodeValues.uri = this.attributesForm.NodeId;
      currentNode.nodeValues.DataType = this.ruleForm.dataType.nodeUri;
      
            
    //   currentNode.nodeValues.Value = this.attributesForm.Value;
      var saveData = {};
      
      saveData.currentNode = currentNode;
      saveData.parentNode = this.oldData.parentNode;
      //   saveData.typeDefinitionNode = {};
      //   saveData.modellingRuleNode = {};
      saveData.relationNode = this.ParentForm.relationNode;
      saveData.children = this.childrenForTable;
      saveData.references = this.referenceTable;
      

      var compareData = compare(this.oldData, saveData);
      console.log(  )
      console.log( JSON.stringify( compareData ))
     

      this.$http.post("/mdt2/nodes/save", compareData).then(res => {
        if(res.status=='200'){
          this.$message({message: "操作成功",type: 'success'});
        }else{
          this.$message({message: "操作失败",type: 'success'});
          return;
        }
        var saveNewNodeId = res.data.currentNode[this.attributesForm.NodeId];
        if(saveNewNodeId == undefined){
          saveNewNodeId =  this.attributesForm.NodeId;
        }
        
        var parentNodeForUpdate = this.typeTreeState.getNodeByParam('id',this.parentNodeForSave.id);
        var cacheTypeTree = this.typeTreeState
        this.typeTreeState.reAsyncChildNodes(parentNodeForUpdate, "refresh",false,()=>{
          
          var node =this.typeTreeState.getNodeByParam("id",saveNewNodeId);
        //   console.log(node)
          cacheTypeTree.selectNode(node);
          cacheTypeTree.setting.callback.onClick( null, cacheTypeTree.treeId, node )
        });
       
      });
    },
    openNodesDataModels(){
      this.modelName = "Add Nodes DadaType";
      this.getUri("/0/90");
      this.dialogVisible = true;
    },
   openTypeModels(index) {
      // debugger;
      this.modelName = "Add TypeDefinition";
      this.cacheIndex = index;
      if (this.childrenForTable[this.cacheIndex].nodeClass == "Variable") {
        this.getUri("/0/89");
        this.dialogVisible = true;
      } else {
        // alert("");
         this.$message.error('请先选择NodeClass');
      }

      
    },
    openDataModels(index) {
        // debugger;
      this.modelName = "Add DadaType";
      this.cacheIndex = index;
      this.getUri("/0/90");
      this.dialogVisible = true;
    },

    openReferModels(index) {
      this.modelName = "Add References";
      this.cacheIndex = index;
      this.getUri("/0/91");
      this.dialogVisible = true;
    },

    openTargetModels(index) {
      this.modelName = "Add Target";
      this.cacheIndex = index;
      this.getUri("");
      this.dialogVisible = true;
    },

    
    setSelectNode() {
      // debugger;
      var selectIfo = JSON.parse(this.selectNode.src);
      if (this.modelName == "Add TypeDefinition") {
        // 如果Typedefinition发生变化，node节点需要重建
        if(this.childrenForTable[this.cacheIndex].typeDefinition.nodeUri != selectIfo.nodeUri){
          var newData = {
            nodeValues:{
              DisplayName:this.childrenForTable[this.cacheIndex].node.nodeValues.DisplayName
              }
            };
          this.updateChildRelation({
            index: this.cacheIndex,
            prop: "node",
            data: newData
          });
          
          this.updateChildRelation({
            index: this.cacheIndex,
            prop: "typeDefinition",
            data: selectIfo
          });
        }
      } else if (this.modelName == "Add DadaType") {
        this.updateChildRelation({
          index: this.cacheIndex,
          prop: "dataType",
          data: selectIfo
        });
        var newData = Object.assign({},this.childrenForTable[this.cacheIndex].node);
        newData.nodeValues.DataType = selectIfo.nodeUri;
        this.updateChildRelation({
            index: this.cacheIndex,
            prop: "node",
            data: newData
        });
      } else if (this.modelName == "Add References") {
        this.updateReferenceRelation({
          index: this.cacheIndex,
          prop: "rel",
          data: selectIfo
        });
      } else if (this.modelName == "Add Target") {
        this.updateReferenceRelation({
          index: this.cacheIndex,
          prop: "targetNode",
          data: selectIfo
        });
      }else{
         this.ruleForm.dataType = selectIfo
      }

      this.dialogVisible = false;
    },
    // 添加更多方法
    FnAddChildRow(index, row, rows) {
      // debugger;
      // var copy = Object.assign({}, row);
      // copy.node = {
      // nodeValues:{
      //   DisplayName:this.childrenForTable[index].node.nodeValues.DisplayName
      //   }
      // };
      var data = {
            "node": {
                "nodeValues": {
                    "DisplayName": "",
                }
            },
            "typeDefinition": {
                "nodeValues": {
                    "DisplayName": "",
                }
            },
            "dataType": {
                "nodeValues": {
                    "DisplayName": "",
                }
            },
            "modellingRule": {
                "nodeValues": {
                    "DisplayName": "",
                }
            }
        }
      this.addChildRow(data);
    },
    FnDeleteChildRow(index, rows) {
      this.deleteChildRow(index);
    },
    // 添加更多方法
    FnAddReferenceRow(index, row, rows) {
      var data = {
        rel:{nodeValues:{}},
        targetNode:{nodeValues:{}}
      }
      this.addReferenceRow(data);
    },
    FnDeleteReferenceRow(index, rows) {
      this.deleteReferenceRow(index);
    },
    
   
  },
  watch: {
    $route(currentState, oldState) {
      
      console.log("路由发生了变化：" + currentState.query.id);
      this.init();
    },
    'ruleForm.name':function(newValue,oldValue){
     
      if( this.attributesForm.DisplayName === newValue ){
        this.flagDisplayName = false
      }
      if( this.attributesForm.BrowseName === newValue ){
        this.flagBrowseName = false
      }
      if( this.currentNode.id === undefined &&  newValue === undefined ){
        this.attributesForm.DisplayName = newValue;
        this.attributesForm.BrowseName = newValue;
      }else
      if( this.currentNode.id === undefined && this.attributesForm.DisplayName === oldValue && this.attributesForm.BrowseName === oldValue ){
        this.attributesForm.DisplayName = newValue;
        this.attributesForm.BrowseName = newValue;
      }else if( this.currentNode.id === undefined && this.attributesForm.DisplayName === oldValue && this.flagDisplayName === true  ){
        this.attributesForm.DisplayName = newValue;         //
      }else if( this.currentNode.id === undefined && this.attributesForm.BrowseName === oldValue && this.flagBrowseName === true ){        
        this.attributesForm.BrowseName = newValue;  // 
      }
    },
  }
};
</script>
