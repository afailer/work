<template>
  <div>

         <el-dialog
            :title=modelName
            :visible.sync="dialogVisible"    
            width="30%"
            ref="dialog"
            :before-close="beforeCloseDialogVisible">    
            <!-- <ul id="treeDemo3" class="ztree" style="height:300px;"></ul> -->
            <public-tree> </public-tree>
            <span slot="footer" class="dialog-footer">
            <el-button @click="dialogVisible = false">取 消</el-button>
            <el-button type="primary"    @click.native="setSelectNode()">确 定</el-button>
            </span>
        </el-dialog>



      <!-- 这是系统自带的节点都是不可编辑的  id:{{ruleForm.name}} -->
       <div class="cardClass">
            <el-card class="box-card">
            <div class="itemCollapse">
                <el-collapse v-model="activeNames" >  
                    <el-collapse-item title="Parent" name="0">                                    
                        <div class="formClass">
                        <!-- from 表单 开始 -->
                          <el-form size="mini" :model="ParentForm" ref="ruleForm" label-width="80px" label-position="left">
                              
                              <el-form-item label="Name" prop="nodeClass" >
                                  <el-input v-model="ParentForm.name" placeholder="Object" :disabled="editOrNo">
                                  </el-input>
                              </el-form-item>
                              <el-form-item label="Reference" prop="Namespace">
                                  <el-select v-model="ParentForm.references" :disabled="editOrNo" style="width: 100%">
                                  </el-select>
                              </el-form-item>
                          </el-form>
                        </div>
                    </el-collapse-item>
                    <el-collapse-item title="Instance" name="1" >                                    
                        <div class="formClass">
                        <!-- from 表单 开始 -->
                          <el-form size="mini" :model="ruleForm" ref="ruleForm" label-width="80px" label-position="left">
                              
                              <el-form-item label="NodeClass" prop="nodeClass" >
                                   <el-select v-model="ruleForm.NodeClass" :change="changeNodeClass()"  :disabled="isCreate" style="width: 100%">
                                        <el-option label="Object" value="Object"></el-option>
                                        <el-option label="Variable" value="Variable"></el-option>
                                  
                                  </el-select>
                                  
                              </el-form-item>
                              <el-form-item label="Namespace" prop="Namespace">
                                <el-input v-model="ruleForm.Namespace" :disabled="true" placeholder="NodeClass" ></el-input>
                              </el-form-item>
                              <el-form-item label="Name" prop="name">
                                  <el-input  v-model="ruleForm.name" :disabled="editOrNo"> 

                                  </el-input>
                              </el-form-item>

                              <el-form-item label="TypeDefinition"  prop="type">      
                                  <el-input v-model="ruleForm.TypeDefinition.nodeValues.DisplayName"  @focus="openDefinitionModel()" :disabled="editOrNo"></el-input>                            
                              </el-form-item>

                            <el-form-item label="ModellingRule" v-if="isVariable && ruleForm.ModellingRule.nodeUri.length>0">      
                              <el-select v-model="ruleForm.ModellingRule"  value-key="nodeUri"  placeholder="" style="width: 100%">
                                  <el-option
                                      v-for="item in ModellingRuleOptions"
                                      :key="item.nodeUri"
                                      :label="item.nodeValues.DisplayName"
                                      :value="item">
                                      </el-option>   
                              </el-select>
                            </el-form-item>
                            <el-form-item label="Data Type" v-if="isVariable">      
                              <el-input v-model="ruleForm.DataType.nodeValues.DisplayName" @focus="openNodesDataModels"></el-input>                            
                            </el-form-item>
                          </el-form>
                        </div>
                    </el-collapse-item>
                    <el-collapse-item title="Additional Attributes" name="2">                                    
                        <div class="formClass">
                        <!-- from 表单 开始 -->
                        <el-form size="mini" :model="attributesForm" ref="" label-width="80px" label-position="left">
                          <el-form-item label="NodeId" prop="nodeClass" >
                            <el-input v-model="attributesForm.NodeId" placeholder="Object" :disabled="true"></el-input>
                          </el-form-item>
                          <el-form-item label="DisplayName" prop="Namespace">
                            <el-input v-model="attributesForm.DisplayName" :disabled="editOrNo"></el-input>
                          </el-form-item>
                          <el-form-item label="BrowseName" prop="Namespace">
                            <el-input v-model="attributesForm.BrowseName" :disabled="editOrNo"></el-input>
                          </el-form-item>
                          <el-form-item label="Description" prop="Namespace">
                            <el-input v-model="attributesForm.Description" :disabled="editOrNo"></el-input>
                          </el-form-item>
                          <el-form-item label="EventNotifier" prop="Namespace" v-if="!isVariable">
                            <el-input v-model="attributesForm.EventNotifier" :disabled="editOrNo"></el-input>
                          </el-form-item>
                          <el-form-item label="Value" prop="Namespace" v-if="isVariable">
                            <template v-if="ruleForm.DataType.nodeValues && ruleForm.DataType.nodeValues.DisplayName=='ScriptString'">
                             <codemirror 
                                :options="cmOptions" 
                                v-model="attributesForm.Value"></codemirror>
                            </template>
                            <template v-else>
                              <el-input 
                                v-model="attributesForm.Value" 
                                :disabled="editOrNo" 
                                style="width: 100%"></el-input>
                            </template>
                          </el-form-item>
                          <el-form-item label="ValueRank" prop="Namespace" v-if="isVariable">
                            <el-select v-model="attributesForm.ValueRank" :disabled="editOrNo" style="width: 100%"></el-select>
                          </el-form-item>
                          <el-form-item label="ArryDimesions" prop="Namespace" v-if="isVariable">
                            <el-input v-model="attributesForm.ArryDimesions" :disabled="editOrNo"></el-input>
                          </el-form-item>
                          <el-form-item label="AccessLevel" prop="Namespace" v-if="isVariable">
                            <el-input v-model="attributesForm.AccessLevel" :disabled="editOrNo"></el-input>
                          </el-form-item>
                          <el-form-item label="UserAccessLevel" prop="Namespace" v-if="isVariable">
                            <el-input v-model="attributesForm.UserAccessLevel" :disabled="editOrNo"></el-input>
                          </el-form-item>
                          <el-form-item label="Historizing" prop="Namespace" v-if="isVariable">
                            <el-checkbox v-model="attributesForm.Historizing" disabled></el-checkbox>
                          </el-form-item>
                          <el-form-item label="MinimumSamplingInterval" prop="Namespace" v-if="isVariable">
                            <el-input v-model="attributesForm.MinimumSamplingInterval" :disabled="editOrNo"></el-input>
                          </el-form-item>

                          <template v-if="attributesForm.NodeId&&attributesForm.NodeId.indexOf('/0/')!=0">
                              <div class="over-hr">
                                <span class="btn-circle" @click.prevent="addProperty()">
                                    <i class="el-icon-circle-plus-outline"></i>  Extends Attributes
                                </span>
                            </div>
                            </template>                            
                            <template v-for="(property,index) in attributesForm.properties" >
                            <el-form-item>
                              <el-input style="width:125px" v-bind:style="{ opacity: property.isSchema? '0.5':'1'}" placeholder="属性名称"  v-bind:readonly="property.isSchema" v-model="property.name"></el-input>
                              <el-input style="width:125px;opacity:0.5;" placeholder="属性类型"  readonly v-bind:value="property.type?property.type:'string'"></el-input>
                              <el-input style="width:150px;" placeholder="值"  v-model="property.value"></el-input>
                              <el-input style="width:100px" placeholder="描述"  v-if="property.isSchema" readonly v-model="property.description"></el-input>
                              <el-button v-if="!property.isSchema" @click.prevent="delProperty(property)">删除</el-button>
                            </el-form-item>
                            </template>
                         </el-form>
                        </div>
                    </el-collapse-item>
                <el-collapse-item title="Children" name="3">
                <!-- table 列表 开始 -->
                <div class="childrenTable">
                    <el-table
                            :data="childrenForTable"
                            border
                            size="mini"
                            style="width: 100%;">
                            <el-table-column type="expand" >
                                <template slot-scope="props" style="padding: 10px 10px 10px 10px;">
                                <el-form label-position="left" inline class="demo-table-expand">
                                    <el-form-item label="ReferenceType">
                                    <span>{{ props.row.ReferenceType }}</span>
                                    </el-form-item>
                                    <el-form-item label="DisplayName">
                                    <span>{{ props.row.DisplayName }}</span>
                                    </el-form-item>   
                                    <el-form-item label="BowersName">
                                    <span>{{ props.row.BowersName }}</span>
                                    </el-form-item>
            
                                    <el-form-item label="Description">
                                    <span>{{ props.row.Description }}</span>
                                    </el-form-item>
                                
                                    <el-form-item label="ID">
                                    <span>{{ props.row.id }}</span>
                                    </el-form-item>
                        
                                </el-form>
                                </template>
                            </el-table-column>
                            <el-table-column
                                prop="NodeClass"
                                label="NodeClass"
                                width="120">
                                <template  slot-scope="scope">
                                    <el-select v-model="scope.row.nodeClass" placeholder="selection" size="mini" >
                                        <el-option
                                        v-for="item in NodeClassoptions"
                                        :key="item.value"
                                        :label="item.label"
                                        :value="item.value">
                                        </el-option>
                                    </el-select>
                                </template>
                            </el-table-column>
                
                            <el-table-column
                                prop="name"
                                label="Name"
                                width="120">
                                <template  slot-scope="scope">
                                    <el-input v-model="scope.row.node.nodeValues.DisplayName" :disabled="editOrNo" size="mini"></el-input>
                                </template>
                            </el-table-column>
                            <el-table-column
                                prop="TypeDefinition"
                                label="TypeDefinition">
                                <template  slot-scope="scope">
                                <el-input v-model="scope.row.typeDefinition.nodeValues.DisplayName"  @focus="openTypeModels(scope.$index)" size="mini"></el-input>
                                
                                </template>
                            </el-table-column>
                            <el-table-column
                                prop="ModellingRule"
                                label="ModellingRule">
                                <template  slot-scope="scope">
                                    <el-select v-model="scope.row.modellingRule"  value-key="nodeUri"  placeholder="" size="mini">
                                        <el-option
                                            v-for="item in ModellingRuleOptions"
                                            :key="item.nodeUri"
                                            :label="item.nodeValues.DisplayName"
                                            :value="item">
                                            </el-option>   
                                    </el-select>
                                </template>
                            </el-table-column>
                           <el-table-column
                                prop="DataType"
                                label="DataType">
                                <template  slot-scope="scope">
                                    <el-input v-model="scope.row.dataType.nodeValues.DisplayName"  @focus="openDataModels(scope.$index)" size="mini"></el-input>                                
                                </template>
                             </el-table-column>
                            

                            <el-table-column                              
                                label="Edit"                            
                                width="80"
                                style="border-collapse:inherit;">                         
                                    <template slot-scope="scope">
                                        <span class="edit" >
                                            <el-button  type="text" size="small" @click.native="FnAddChildRow(scope.$index,scope.row, childrenForTable)">新增</el-button>           
                                        </span>
                                        <span class="delete">
                                            <el-button  type="text" size="small" @click.native="FnDeleteChildRow(scope.$index, childrenForTable)">删除</el-button>           
                                        </span>
                                    </template>
                            </el-table-column>
                    </el-table>
                </div>
                    
                </el-collapse-item>
                 <el-collapse-item title="References" name="4">
                            <div class="referenc">
                            <el-table
                                :data="referenceTable"
                                border
                                size="mini"
                                style="width: 100%;">
                                <el-table-column
                                    prop="date"
                                    label="Reference Type"
                                    width="180">
                                    <template  slot-scope="scope">
                                        <el-input v-model="scope.row.rel.nodeValues.DisplayName"  @focus="openReferModels(scope.$index)" size="mini"></el-input>
                                    </template>
                                </el-table-column>
                                <el-table-column
                                    prop="name"
                                    label="Target"
                                    width="180">
                                    <template  slot-scope="scope">
                                       <el-input v-model="scope.row.targetNode.nodeValues.DisplayName"  @focus="openTargetModels(scope.$index)" size="mini"></el-input>
                                    </template>
                                </el-table-column>
                                <el-table-column>
                                </el-table-column>

                                <el-table-column                              
                                    label="Edit"   
                                    width="120"
                                    style="border-collapse:inherit;">                         
                                        <template slot-scope="scope">
                                        <span class="edit">
                                            <el-button  type="text" size="small" @click.native="FnAddReferenceRow(scope.$index,scope.row, referenceTable)">新增</el-button>            
                                        </span>
                                         <span class="delete">
                                                    <el-button  type="text" size="small" @click.native="FnDeleteReferenceRow(scope.$index, referenceTable)">删除</el-button>           
                                                </span>
                                        </template>
                                </el-table-column>
                                </el-table>
                            </div>
                    </el-collapse-item>
                <!-- button 按钮 -->
                <div class="btnClass">                    
                    <el-button size="mini" type="primary" plain  @click="saveInfo()">提交</el-button>
                    <el-button size="mini" plain>取消</el-button>
                </div> 
                </el-collapse>
              
            </div>
            </el-card>
        </div>
        
     
  </div>
</template>
<script>
import { codemirror } from "vue-codemirror";
import "codemirror/mode/javascript/javascript.js";
import "codemirror/theme/base16-dark.css";
import "codemirror/lib/codemirror.css";
import { mapState, mapActions } from "vuex";
import publicTree from "@/components/publicTree";
import { compare, isEqual } from "@/utils/utils";
import typeTreeViewVue from "@/components/typeTreeView";
export default {
  components: { publicTree, codemirror },
  data() {
    return {
      cmOptions: {
        tabSize: 4,
        mode: "text/javascript",
        theme: "default",
        lineNumbers: false,
        line: true
      },
      isCreate: false,
      editOrNo: false,
      dialogVisible: false, // 数据初始化dialog弹出框控制
      DateTypeoption: [],
      NodeClassoptions: [
        {
          value: "Variable",
          label: "Variable"
        },
        {
          value: "Object",
          label: "Object"
        },
        {
          value: "Method",
          label: "Method"
        },
        {
          value: "NoSelection",
          label: "NoSelection"
        }
      ],

      ModellingRuleOptions: [
        {
          nodeUri: "/0/78",
          nodeValues: {
            DisplayName: "Mandatory"
          }
        },
        {
          nodeUri: "/0/80",
          nodeValues: {
            DisplayName: "Optional"
          }
        }
      ],

      // 表单数据 初始化开始

      activeNames: ["0", "1", "2"],
      //   Typetitle: "Instance",
      ParentForm: {
        name: null,
        references: null
      },
      ruleForm: {
        id: null,
        name: null,
        NodeClass: null,
        Namespace: null,
        TypeDefinition: null,
        ModellingRule: {},
        DataType: {}
      },
      attributesForm: {
        NodeId: null,
        DisplayName: null,
        BrowseName: null,
        Description: null,
        EventNotifier: null,
        Value: "",
        ValueRank: "",
        ArryDimesions: "",
        AccessLevel: "",
        UserAccessLevel: "",
        Historizing: "",
        MinimumSamplingInterval: "",
        properties: []
      },
      modelName: null,
      isVariable: false,

      children: [],
      references: [],
      flagDisplayName: true,
      flagBrowseName: true
    };
  },
  computed: {
    ...mapState([
      "settings",
      "objectTreeState", //  数据
      "currentNode", // 数据详情
      "childrenForTable",
      "referenceTable",
      "selectNode",
      "oldData",
      "parentNodeForSave"
    ])
  },

  created() {
    this.init();
  },
  methods: {
    ...mapActions([
      "getUri",
      "updateChildRelation",
      "updateReferenceRelation",
      "addChildRow",
      "deleteChildRow",
      "addReferenceRow",
      "deleteReferenceRow",
      "showchildrenTable",
      "showReferencesTable"
    ]),

    changeNodeClass() {
      if (this.ruleForm.NodeClass == "Variable") {
        this.isVariable = true;
      } else {
        this.isVariable = false;
      }
    },
    init() {
      if (!this.parentNodeForSave.id) {
        this.$router.push({ name: "defaultModel" });
      }
      console.log("excute method：init");
      this.preForm();
      this.preChildren();
      this.prePreference();
    },

    prompt() {
      this.$message({
        message: "请选择NodeClass!!!",
        type: "warning",
        duration: 1000
      });
    },
    preForm() {
      this.isCreate = false;
      // 清空数组
      this.attributesForm.properties.length = 0;
      //ParentForm
      this.ParentForm.name = this.$route.query.parentName;
      if (this.currentNode.relationSrc) {
        this.ParentForm.references = JSON.parse(
          this.currentNode.relationSrc
        ).BrowseName;
      }

      //ruleForm
      this.ruleForm.name = this.currentNode.name;
      if (this.currentNode.src) {
        this.isCreate = true;
        this.ruleForm.NodeClass = JSON.parse(
          this.currentNode.src
        ).nodeValues.NodeClass;
      } else {
        this.ruleForm.NodeClass = this.currentNode.NodeClass;
      }
      if (this.ruleForm.NodeClass == "Variable") {
        this.isVariable = true;
      } else if (this.ruleForm.NodeClass == "Object") {
        this.isVariable = false;
      }

      if (this.currentNode.typeDefinitionSrc) {
        this.ruleForm.TypeDefinition = JSON.parse(
          this.currentNode.typeDefinitionSrc
        );
      } else {
        this.ruleForm.TypeDefinition = {
          nodeValues: {
            DisplayName: ""
          }
        };
      }

      this.ruleForm.Namespace = this.currentNode.Namespace;

      // 填充
      if (this.currentNode.typeDefinitionSrc) {
        var schema = JSON.parse(this.currentNode.typeDefinitionSrc).nodeValues
          .schema;
        if (schema) {
          this.attributesForm.properties = this.attributesForm.properties.concat(
            schema
          );
        }
      }
      this.attributesForm.properties.forEach(function(e, index) {
        e.isSchema = true;
      });

      if (this.currentNode.dataTypeSrc) {
        this.ruleForm.DataType = JSON.parse(this.currentNode.dataTypeSrc);
      } else {
        this.ruleForm.DataType = {
          nodeValues: {
            DisplayName: ""
          }
        };
      }
      if (this.currentNode.modellingSrc) {
        var ModellingRuleObj = JSON.parse(this.currentNode.modellingSrc);
        this.ruleForm.ModellingRule = {
          nodeUri: ModellingRuleObj.nodeUri,
          nodeValues: {
            DisplayName: ModellingRuleObj.nodeValues.BrowseName
          }
        };
      } else {
        this.ruleForm.ModellingRule = {
          nodeUri: "",
          nodeValues: {
            DisplayName: ""
          }
        };
      }

      if (this.currentNode.src) {
        var otherProperties = JSON.parse(this.currentNode.src);
        //attributesForm
        this.attributesForm.NodeId = otherProperties.nodeUri;
        this.attributesForm.DisplayName =
          otherProperties.nodeValues.DisplayName;
        this.attributesForm.BrowseName = otherProperties.nodeValues.BrowseName;
        this.attributesForm.Description =
          otherProperties.nodeValues.Description;
        this.attributesForm.Value = otherProperties.nodeValues.Value;
        this.attributesForm.ValueRank = otherProperties.nodeValues.ValueRank;
        this.attributesForm.ArryDimesions =
          otherProperties.nodeValues.ArryDimesions;
        this.attributesForm.AccessLevel =
          otherProperties.nodeValues.AccessLevel;
        this.attributesForm.UserAccessLevel =
          otherProperties.nodeValues.UserAccessLevel;
        this.attributesForm.Historizing =
          otherProperties.nodeValues.Historizing;
        this.attributesForm.MinimumSamplingInterval =
          otherProperties.nodeValues.MinimumSamplingInterval;
        //this.attributesForm.UserAccessLevel = otherProperties.nodeValues.UserAccessLevel;
        // 尝试填充props
        this.attributesForm.properties.forEach(prop => {
          if (otherProperties.nodeValues[prop.name]) {
            prop.value = otherProperties.nodeValues[prop.name];
          }
        });

        // 自己添加的扩展属性
        for (var key in otherProperties.nodeValues) {
          if (!this.attributesForm.hasOwnProperty(key)) {
            var isExist = false;
            for (var j = 0; j < this.attributesForm.properties.length; j++) {
              if (this.attributesForm.properties[j].name == key) {
                isExist = true;
                break;
              }
            }
            if (
              [
                "name",
                "NodeClass",
                "uri",
                "DataType",
                "isAbstract",
                "schema",
                "EventNotifier"
              ].indexOf(key) >= 0
            ) {
              isExist = true;
            }
            if (!isExist) {
              this.attributesForm.properties.unshift({
                name: key,
                type: "string",
                value: otherProperties.nodeValues[key]
              });
            }
          }
        }
      } else {
        this.attributesForm.NodeId = this.$route.query.id;
        this.attributesForm.DisplayName = "";
        this.attributesForm.BrowseName = "";
        this.attributesForm.Description = "";
        this.attributesForm.Value = "";
        this.attributesForm.ValueRank = "";
        this.attributesForm.ArryDimesions = "";
        this.attributesForm.AccessLevel = "";
        this.attributesForm.UserAccessLevel = "";
        this.attributesForm.Historizing = "";
        this.attributesForm.MinimumSamplingInterval = "";
      }
      var namespace = this.attributesForm.NodeId.split("/")[1];
      if (namespace == "0") {
        this.ruleForm.Namespace =
          namespace + ":" + this.settings.namespaceDefault;
      } else {
        this.ruleForm.Namespace =
          namespace + ":" + this.settings.namespaceBase + namespace + "/";
      }
    },
    preChildren() {
      console.log("excute method： preChildren");
    },

    // 鼠标聚焦弹出 dialog
    openTypeModels(index) {
      this.modelName = "Add TypeDefinition";

      this.cacheIndex = index;
      // if (this.childrenForTable[this.cacheIndex].nodeClass == "Variable") {
      //   this.getUri("/0/89");
      // } else if (this.childrenForTable[this.cacheIndex].nodeClass == "Object") {
      //   this.getUri("/0/88");
      // } else if (this.childrenForTable[this.cacheIndex].nodeClass == null) {
      //   // alert("请先选择NodeClass");
      //   this.$message.error('请先选择NodeClass');
      // }
      if (!this.childrenForTable[this.cacheIndex].nodeClass) {
        this.prompt();
      } else {
        this.modelName = "Add TypeDefinition";

        if (this.childrenForTable[this.cacheIndex].nodeClass == "Variable") {
          this.getUri("/0/89");
        } else if (
          this.childrenForTable[this.cacheIndex].nodeClass == "Object"
        ) {
          this.getUri("/0/88");
        }

        this.dialogVisible = true;
      }
    },

    openDataModels(index) {
      this.modelName = "Add DadaType";
      this.cacheIndex = index;
      this.getUri("/0/90");

      this.dialogVisible = true;
    },
    openNodesDataModels() {
      this.modelName = "Add Nodes DadaType";
      this.getUri("/0/90");
      this.dialogVisible = true;
    },

    openReferModels(index) {
      this.modelName = "Add References";
      this.cacheIndex = index;
      this.getUri("/0/91");
      this.dialogVisible = true;
    },

    openTargetModels(index) {
      this.modelName = "Add Target";
      this.cacheIndex = index;
      this.getUri("");
      this.dialogVisible = true;
    },

    openDefinitionModel() {
      this.modelName = "Browse Node";
      if (this.isVariable) {
        this.getUri("/0/89");
      } else {
        this.getUri("/0/88");
      }
      this.dialogVisible = true;
    },

    //关闭之前
    beforeCloseDialogVisible() {
      console.log("模态层关闭之前的操作");
    },

    //模态层点击确定
    setSelectNode() {
      var selectIfo = JSON.parse(this.selectNode.src);

      if (this.modelName == "Add TypeDefinition") {
        // 如果Typedefinition发生变化，node节点需要重建
        if (
          this.childrenForTable[this.cacheIndex].typeDefinition.nodeUri !=
          selectIfo.nodeUri
        ) {
          var newData = {
            nodeValues: {
              DisplayName: this.childrenForTable[this.cacheIndex].node
                .nodeValues.DisplayName
            }
          };
          this.updateChildRelation({
            index: this.cacheIndex,
            prop: "node",
            data: newData
          });

          this.updateChildRelation({
            index: this.cacheIndex,
            prop: "typeDefinition",
            data: selectIfo
          });
        }
      } else if (this.modelName == "Add DadaType") {
        this.updateChildRelation({
          index: this.cacheIndex,
          prop: "dataType",
          data: selectIfo
        });
        var newData = Object.assign(
          {},
          this.childrenForTable[this.cacheIndex].node
        );
        newData.nodeValues.DataType = selectIfo.nodeUri;
        this.updateChildRelation({
          index: this.cacheIndex,
          prop: "node",
          data: newData
        });
      } else if (this.modelName == "Add References") {
        this.updateReferenceRelation({
          index: this.cacheIndex,
          prop: "rel",
          data: selectIfo
        });
      } else if (this.modelName == "Add Nodes DadaType") {
        this.ruleForm.DataType = selectIfo;
      } else if (this.modelName == "Add Target") {
        this.updateReferenceRelation({
          index: this.cacheIndex,
          prop: "targetNode",
          data: selectIfo
        });
      } else if (this.modelName == "Browse Node") {
        this.ruleForm.TypeDefinition = selectIfo;

        var nodeId = selectIfo.nodeUri;
        var namespace = nodeId.match(/\/(\S*)\//)[1];
        this.$http
          .get(
            "/mdt2/nodes/findChildren?namespace=" +
              namespace +
              "&nodeId=" +
              nodeId,
            {}
          )
          .then(res => {
            var getChildren = res.data.children;
            getChildren.forEach(element => {
              if (!element.dataType) {
                element.dataType = { nodeValues: { DisplayName: "" } };
              }
            });
            this.showchildrenTable(getChildren);
          });
        this.$http
          .get("/mdt2/nodes/findReferences", {
            params: { namespace: namespace, nodeId: nodeId }
          })
          .then(res => {
            var getReferences = res.data.references;
            this.showReferencesTable(getReferences);
          });

        // 处理Props
        this.attributesForm.properties.length = 0;
        var schema = selectIfo.nodeValues.schema;
        if (schema) {
          this.attributesForm.properties = this.attributesForm.properties.concat(
            schema
          );
        }
      }

      this.dialogVisible = false;
    },

    // 添加更多方法
    FnAddChildRow(index, row, rows) {
      var copy = Object.assign({}, row);
      copy.node = {
        nodeValues: {
          DisplayName: this.childrenForTable[index].node.nodeValues.DisplayName
        }
      };
      this.addChildRow(copy);
    },
    FnDeleteChildRow(index, rows) {
      this.deleteChildRow(index);
    },
    // 添加更多方法
    FnAddReferenceRow(index, row, rows) {
      var data = {
        rel: { nodeValues: {} },
        targetNode: { nodeValues: {} }
      };
      this.addReferenceRow(data);
    },
    FnDeleteReferenceRow(index, rows) {
      this.deleteReferenceRow(index);
    },
    addProperty() {
      var property = {
        name: "",
        type: "string",
        value: ""
      };

      this.attributesForm.properties.unshift(property);
    },
    delProperty(property) {
      var index = this.attributesForm.properties.indexOf(property);
      if (index !== -1) {
        this.attributesForm.properties.splice(index, 1);
      }
    },
    saveInfo() {
      var currentNode = {};
      currentNode.nodeUri = this.attributesForm.NodeId;
      currentNode.relation = this.ParentForm.references;
      currentNode.nodeValues = {};
      currentNode.nodeValues.name = this.ruleForm.name;
      currentNode.nodeValues.BrowseName = this.attributesForm.BrowseName;
      currentNode.nodeValues.DisplayName = this.attributesForm.DisplayName;
      currentNode.nodeValues.Description = this.attributesForm.Description;
      currentNode.nodeValues.NodeClass = this.ruleForm.NodeClass;
      currentNode.nodeValues.uri = this.attributesForm.NodeId;
      currentNode.nodeValues.isAbstract = this.ruleForm.IsAbstract;

      if (this.isVariable) {
        currentNode.nodeValues.ValueRank = this.ruleForm.ValueRank;
        currentNode.nodeValues.ArryDimesions = this.attributesForm.ArryDimesions;
        currentNode.nodeValues.AccessLevel = this.attributesForm.AccessLevel;
        currentNode.nodeValues.UserAccessLevel = this.attributesForm.UserAccessLevel;
        currentNode.nodeValues.Historizing = this.attributesForm.Historizing;
        currentNode.nodeValues.MinimumSamplingInterval = this.ruleForm.MinimumSamplingInterval;
        currentNode.nodeValues.Value = this.attributesForm.Value;
      }

      // 对props进行处理
      this.attributesForm.properties.forEach(prop => {
        currentNode.nodeValues[prop.name] = prop.value;
      });

      if (this.ruleForm.DataType.nodeUri) {
        currentNode.nodeValues.DataType = this.ruleForm.DataType.nodeUri;
      } else {
        currentNode.nodeValues.DataType = {
          nodeValues: {
            DisplayName: ""
          }
        };
      }

      var saveData = {};

      saveData.currentNode = currentNode;
      saveData.parentNode = this.oldData.parentNode;
      //   saveData.typeDefinitionNode = {};
      //   saveData.modellingRuleNode = {};
      saveData.relationNode = this.ParentForm.relationNode;
      saveData.children = this.childrenForTable;
      saveData.references = this.referenceTable;
      saveData.typeDefinitionNode = this.ruleForm.TypeDefinition;

      var compareData = compare(this.oldData, saveData);

      this.$http.post("/mdt2/nodes/save", compareData).then(res => {
        //  res.currentNode[nodeUri]
        //1.刷新节点
        //2.获取子节点 更新from
        //
        if (res.status == "200") {
          this.$message({ message: "操作成功", type: "success" });
        } else {
          this.$message({ message: "操作失败", type: "success" });
          return;
        }
        var saveNewNodeId = res.data.currentNode[this.attributesForm.NodeId];
        if (saveNewNodeId == undefined) {
          saveNewNodeId = this.attributesForm.NodeId;
        }

        var namespace = this.parentNodeForSave.id.match(/\/(\S*)\//)[1];
        var parentNodeForUpdate = this.objectTreeState.getNodeByParam(
          "id",
          this.parentNodeForSave.id
        );
        // 强制刷新父节点
        var tree = this.objectTreeState;
        this.objectTreeState.reAsyncChildNodes(
          parentNodeForUpdate,
          "refresh",
          false,
          function() {
            var node = tree.getNodeByParam("id", saveNewNodeId);
            tree.selectNode(node);
            // 触发click事件
            tree.setting.callback.onClick(null, tree.treeId, node);
          }
        );
      });
    },

    prePreference() {
      console.log("excute method： prePreference");
    }
  },
  watch: {
    $route(currentState, oldState) {
      // debugger
      console.log("路由发生了变化：" + currentState.query.id);
      this.init();
    },
    "ruleForm.name": function(newValue, oldValue) {
      if (this.attributesForm.DisplayName === newValue) {
        this.flagDisplayName = false;
      }
      if (this.attributesForm.BrowseName === newValue) {
        this.flagBrowseName = false;
      }
      if (this.currentNode.id === undefined && newValue === undefined) {
        this.attributesForm.DisplayName = newValue;
        this.attributesForm.BrowseName = newValue;
      } else if (
        this.currentNode.id === undefined &&
        this.attributesForm.DisplayName === oldValue &&
        this.attributesForm.BrowseName === oldValue
      ) {
        this.attributesForm.DisplayName = newValue;
        this.attributesForm.BrowseName = newValue;
      } else if (
        this.currentNode.id === undefined &&
        this.attributesForm.DisplayName === oldValue &&
        this.flagDisplayName === true
      ) {
        this.attributesForm.DisplayName = newValue; //
      } else if (
        this.currentNode.id === undefined &&
        this.attributesForm.BrowseName === oldValue &&
        this.flagBrowseName === true
      ) {
        this.attributesForm.BrowseName = newValue; //
      }
    }
  }
};
</script>
<style>
.formClass .CodeMirror {
  border: 1px solid #e8eaef;
  border-radius: 3px;
  height: 200px;
}
.over-hr {
  overflow: hidden;
  text-align: center;
  margin: 5px 0 5px 0;
}

.over-hr > span {
  position: relative;
  display: inline-block;
  font-size: 13px;
}

.over-hr > span:after,
.over-hr > span:before {
  content: "";
  position: absolute;
  top: 50%;
  height: 1px;
  width: 9999px;
  background: #ccd1d3;
}

.over-hr > span:before {
  right: 100%;
  margin-right: 15px;
}

.over-hr > span:after {
  left: 100%;
  margin-left: 15px;
}
.over-hr > .btn-circle {
  cursor: pointer;
}

.btn-circle,
.btn-circle-text {
  line-height: 1.42857;
  touch-action: manipulation;
  background-color: transparent;
  background-repeat: no-repeat;
  padding: 0;
  border: 0;
  text-decoration: none;
}

.btn-circle I,
.btn-circle-text I {
  vertical-align: middle;
  font-size: 1.5em;
}

.btn-circle[disabled],
[disabled].btn-circle-text {
  opacity: 0.5;
}
</style>
