<template>
    <div class="objZtree">
        <div class="cardClass">
            <el-card class="box-card" :body-style="{ padding: '0px' }" >
                <div slot="header" class="clearfix">
                    <span>对象</span>
                </div>
                <div class="item">
                    <div style="height:100%">
                        <ul id="objTree" class="ztree" >            
                        </ul>
                    </div>
                </div>
            </el-card>
        </div>
        <div id="areaTree">
            <div id="rObjMenu">                
                <ul>
                    <li id="ObjTree_addObject" @click="addObj">
                        <el-button size="mini" type="text" style="color: #000" icon="el-icon-plus"> Add Instance</el-button>
                    </li>
                    <li id="ObjTree_delType" @click="removeTreeNode">
                        <el-button size="mini" type="text" style="color: #000" icon="el-icon-remove-outline">delete Node</el-button>
                    </li>
                
                </ul>
            </div>
        </div>   
    </div>
</template>
<script>
import { mapState, mapActions } from "vuex";
import { randomNum } from "@/utils/utils";
export default {
  data() {
    return {
      objTree: {},
      objCacheId: "",
      objCacheNode: {},
      newObjCount: 1,
      ObjSetting: {
        async: {
          enable: true,
          url: "/mdt2/nodes/findSubNodes",
          autoParam: ["id=nodeId"],
          otherParam: ["namespace", "0"],
          type: "GET",
          dataFilter: this.filter
        },
        callback: {
          beforeAsync: this.beforeAsync,
          onAsyncError: this.onAsyncError,
          onAsyncSuccess: this.onAsyncSuccess,
          onClick: this.onClick,
          onRightClick: this.OnRightClick
        }
      }
    };
  },
  // 引入 state
  computed: mapState(["settings", "ObjTypeDefinition", "isGraph"]),
  methods: {
    ...mapActions([
      "showNode",
      "showProperties",
      "showObjNode",
      "cacheObjTree",
      "showchildrenTable",
      "showReferencesTable",
      "showObjChildrenTable"
    ]),

    // 获取typeTree 的数据
    loadObjTree() {
      $.fn.zTree.init($("#objTree"), this.ObjSetting, null);
    },

    beforeAsync() {
      return true;
    },

    onAsyncSuccess(event, treeId, treeNode, msg) {
      // debugger;
      this.objTree = $.fn.zTree.getZTreeObj(treeId);
      var data = JSON.parse(msg).nodes;
      data.forEach(function(value) {
        value.isParent = true;
      });
      if (treeNode == undefined) {
        for (var i = 0; i < data.length; i++) {
          if (data[i].id == "/0/85") {
            this.objTree.addNodes(null, data[i], true); // 如果是根节点，那么就在null后面加载数据
            this.cacheObjTree(this.objTree);
          }
        }
      } else {
        this.objTree.addNodes(treeNode, data, true);
        this.cacheObjTree(this.objTree); //如果是加载子节点，那么就是父节点下面加载
      }
      console.log(
        "[ onAsyncSuccess ]&nbsp;&nbsp;&nbsp;&nbsp;" +
          (!!treeNode && !!treeNode.name ? treeNode.name : "root")
      );
    },

    filter(treeId, parentNode, childNodes) {},

    onClick(e, treeId, treeNode) {
      // debugger;
      //this.showObjNode(treeNode);
      // this.showNode(treeNode);

      this.showProperties(treeNode);
      var nodeNamespace = treeNode.id.match(/\/(\S*)\//)[1];

      this.$http
        .get("/mdt2/nodes/findChildren", {
          params: { namespace: nodeNamespace, nodeId: treeNode.id }
        })
        .then(res => {
          var getChildren = res.data.children;

          getChildren.forEach(element => {
            if (!element.dataType) {
              element.dataType = { nodeValues: { DisplayName: "" } };
            }
          });
          this.showchildrenTable(getChildren);
        });

      this.$http
        .get("/mdt2/nodes/findReferences", {
          params: { namespace: nodeNamespace, nodeId: treeNode.id }
        })
        .then(res => {
          var getReferences = res.data.references;
          //debugger;
          this.showReferencesTable(getReferences);
        });

      //获取父节点名称
      if (treeNode.id != "/0/85") {
        var parentNode = this.objTree
          .getNodeByParam("id", treeNode.id)
          .getParentNode();
        this.showNode({ treeNode: treeNode, parentNode: parentNode });
      } else {
        var parentNode = {};
        parentNode.name = "Root";
        this.showNode({ treeNode: treeNode, parentNode: null });
      }
      if (!this.isGraph) {
        if (treeNode.nodeClass == "Object") {
          this.$router.push({
            name: "rootObject",
            query: { id: treeNode.id, parentName: parentNode.name }
          });
        } else if (treeNode.nodeClass == "Variable") {
          this.$router.push({
            name: "rootObject",
            query: { id: treeNode.id, parentName: parentNode.name }
          });
        }
      }
    },
    // 右击事件
    OnRightClick(event, treeId, treeNode) {
      this.objCacheId = treeId;
      this.objCacheNode = treeNode;
      this.objTree.selectNode(treeNode);

      if (treeNode.id.startsWith("/0/")) {
        if (treeNode.nodeClass == "Object") {
          this.showRObjMenu(
            "objinstance",
            "Notdel",
            event.pageX - 30,
            event.pageY - 42
          );
        } else if (treeNode.nodeClass == "Variable") {
          this.showRObjMenu(
            "variableinstance",
            "Notdel",
            event.pageX - 30,
            event.pageY - 42
          );
        }
      } else {
        if (treeNode.nodeClass == "Object") {
          this.showRObjMenu(
            "objinstance",
            "Isdel",
            event.pageX - 30,
            event.pageY - 42
          );
        } else if (treeNode.nodeClass == "Variable") {
          this.showRObjMenu(
            "variableinstance",
            "Isdel",
            event.pageX - 30,
            event.pageY - 42
          );
        }
      }
    },

    // 显示菜单
    showRObjMenu(type, del, x, y) {
      $("#rObjMenu ul").show();
      if (type == "instence" && del == "Notdel") {
        $("#ObjTree_addType").hide();
        $("#ObjTree_addObject").hide();
        $("#ObjTree_addAddReferenceType").show();

        $("#ObjTree_delType").hide();
      } else if (type == "instence" && del == "Isdel") {
        $("#ObjTree_addType").hide();
        $("#ObjTree_addObject").hide();
        $("#ObjTree_addAddReferenceType").show();
        $("#ObjTree_delType").show();
      } else if (type == "noMenu") {
        $("#ObjTree_addObject").hide();
        $("#ObjTree_addType").hide();
        $("#ObjTree_delType").hide();
        $("#ObjTree_addAddReferenceType").hide();
      } else if (type == "newType" && del == "Notdel") {
        $("#ObjTree_addType").show();
        $("#ObjTree_addObject").hide();
        $("#ObjTree_addAddReferenceType").hide();
        $("#ObjTree_delType").hide();
      } else if (type == "newType" && del == "Isdel") {
        $("#ObjTree_addType").show();
        $("#ObjTree_addObject").hide();
        $("#ObjTree_addAddReferenceType").hide();
        $("#ObjTree_delType").show();
      } else if (type == "objinstance" && del == "Notdel") {
        $("#ObjTree_addType").hide();
        $("#ObjTree_addObject").show();
        $("#ObjTree_addAddReferenceType").hide();
        $("#ObjTree_delType").hide();
      } else if (type == "objinstance" && del == "Isdel") {
        $("#ObjTree_addType").hide();
        $("#ObjTree_addObject").show();
        $("#ObjTree_addAddReferenceType").hide();
        $("#ObjTree_delType").show();
      } else if (type == "variableinstance" && del == "Notdel") {
        $("#ObjTree_addType").hide();
        $("#ObjTree_addObject").show();
        $("#ObjTree_addAddReferenceType").hide();
        $("#ObjTree_delType").hide();
      } else if (type == "variableinstance" && del == "Isdel") {
        $("#ObjTree_addType").hide();
        $("#ObjTree_addObject").show();
        $("#ObjTree_addAddReferenceType").hide();
        $("#ObjTree_delType").show();
      } else {
        $("#ObjTree_addObject").hide();
        $("#ObjTree_addType").hide();
        $("#ObjTree_delType").hide();
        $("#ObjTree_addAddReferenceType").hide();
      }

      y += document.body.scrollTop;
      x += document.body.scrollLeft;

      $("#rObjMenu").css({
        top: y + "px",
        left: x + "px",
        visibility: "visible",
        "z-index": 999
      });

      $("body").bind("mousedown", this.onBodyMouseDown);
    },
    // 隐藏 Menu
    hideRMenu() {
      if ($("#rObjMenu")) {
        $("#rObjMenu").css({ visibility: "hidden" });
      }
      $("body").unbind("mousedown", this.onBodyMouseDown);
    },
    // 鼠标事件S
    onBodyMouseDown(event) {
      if (
        !(
          event.target.id == "rObjMenu" ||
          $(event.target).parents("#rObjMenu").length > 0
        )
      ) {
        $("#rObjMenu").css({ visibility: "hidden" });
      }
    },

    // 删除节点
    removeTreeNode(e, a, b) {
      this.hideRMenu();
      //debugger;
      this.nodes = this.objTree.getSelectedNodes();
      var msg = "此节点有子节点，你确定删除吗？";
      if (confirm(msg) == true) {
        var nodeId = this.nodes[0].id;
        var namespace = nodeId.match(/\/(\S*)\//)[1];
        this.$http
          .delete(
            "/mdt2/nodes/delNode" +
              "?namespace=" +
              namespace +
              "&nodeId=" +
              nodeId,
            {}
          )
          .then(res => {
            this.objTree.removeNode(this.nodes[0]);
          });
      }
    },

    //增加对象
    addObj(event) {
      // debugger;
      this.hideRMenu();
      this.showProperties({});
      this.showchildrenTable([]);
      this.showReferencesTable([]);

      //获取父节点名称
      if (this.objCacheNode != "/0/85") {
        var parentNode = this.objCacheNode;
        this.showNode({
          treeNode: { NodeClass: this.objCacheNode.nodeClass },
          parentNode: this.objCacheNode
        });
      } else {
        var parentNode = {};
        parentNode.name = "Root";
        this.showNode({
          treeNode: { NodeClass: "Object" },
          parentNode: this.objCacheNode
        });
      }

      if (this.objCacheNode.nodeClass == "Object") {
        this.$router.push({
          name: "rootObject",
          query: {
            id: randomNum(this.settings.currentNamespace),
            parentName: parentNode.name
          }
        });
      } else if (this.objCacheNode.nodeClass == "Variable") {
        this.$router.push({
          name: "variable",
          query: {
            id: randomNum(this.settings.currentNamespace),
            parentName: parentNode.name
          }
        });
      }

      // this.cacheObjTreethis.cacheObjTree(this.objTree); // 将typeTree存入store中
      return false;
    }
  },
  created() {
    this.loadObjTree();
  },
  mounted() {
    //this.loadObjTree();
    $.fn.zTree.init($("#objTree"), this.ObjSetting);
  }
};
</script>
<style>
@import "../assets/zTreeStyle";
@import "../assets/demo";
.ztree li span.button.iconObject_ico_open,
.ztree li span.button.iconObject_ico_close {
  margin-right: 2px;
  background: url(../assets/img/cut_add_object.png) no-repeat scroll 0 0
    transparent;
  vertical-align: top;
  *vertical-align: middle;
}
.cardClass {
  padding: 0px;
}
.cardClass .el-card {
  border: none;
}

.cardClass .el-card__body {
  padding: 0px;
  font-size: 500;
  border-bottom: none;
  height: 100%;
}
.cardClass .el-card__header {
  padding: 4px 6px;
  border-bottom: 1px solid #ebeef5;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  background-color: #e4e7ef;
}
.clearfix:before,
.clearfix:after {
  display: table;
  content: "";
}
.clearfix:after {
  clear: both;
}
.box-card {
  /* width: 480px; */
  padding: 0;
  height: 100%;
  box-shadow: none;
}

.objZtree,
.cardClass,
.right {
  height: 100% !important;
}
.item {
  height: 85% !important;
}

ul.ztree {
  height: 95%;
  width: 103%;
  overflow: auto;
  overflow-x: hidden;
}

#areaTree {
  /* border: 1px solid #e5e5e5;
    margin-bottom: 2px;
    border-radius: 14px; */
  /* position: relative; */
  /* overflow: hidden; */
  z-index: 9999;
}
#areaTree .content_wrap .zTreeDemoBackground {
  height: 300px;
}
#areaTree .content_wrap .right {
  height: 300px;
}
div #rObjMenu {
  position: absolute;
  visibility: hidden;
  top: 0;
  background-color: #fff;
  text-align: left;

  padding: 6px 8px;
  min-width: 120px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4), 0 0 1px rgba(0, 0, 0, 0.2);
  border-radius: 4px;
}

#rObjMenu ul li {
  list-style: none;
}
#rObjMenu el-button {
  color: #ffffff;
}
#ObjTree_addObject:hover {
  background-color: #409eff;
}
#ObjTree_addType:hover {
  background-color: #409eff;
}
#ObjTree_addAddReferenceType:hover {
  background-color: #409eff;
}
#ObjTree_delType:hover {
  background-color: #409eff;
}
</style>
