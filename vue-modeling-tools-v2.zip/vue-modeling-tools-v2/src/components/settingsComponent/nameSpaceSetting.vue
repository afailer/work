<template>
  <div class="nameSpace-Setting-Class">
      <el-tag type="danger">提示：namespace 为0时禁止修改和删除</el-tag>
     
      <div class="add-NameSpace">
        <el-input style="width: 200px;" placeholder="name" size="mini" v-model="listQuery.name"></el-input>
        <el-input  style="width: 200px;" placeholder="description" size="mini" v-model="listQuery.description"></el-input>
        <el-button class="filter-item" size="mini" style="margin-left: 10px;" @click="handleCreate" type="primary" icon="el-icon-plus">添加</el-button>
      </div>
      <div class=""></div>
      <el-table :data="list" 
        :default-sort="{prop: 'uri', order: 'ascending'}"
        v-loading="listLoading" 
        element-loading-text="给我一点时间"
        height="600"
        border fit highlight-current-row style="width: 100%">
        <el-table-column width="350px" align="left" label="名称" sortable prop="uri" >
          <template slot-scope="scope">
            <span>{{ scope.row.uri.split("/")[2] }}</span>
            <el-tag type="success" v-if="scope.row.using=='1'" size="mini">current</el-tag>
          </template>
        </el-table-column>
        <el-table-column  align="left" label="描述" prop="description"></el-table-column>
        <el-table-column align="left" label="操作" width="380" class-name="small-padding fixed-width">
          <template slot-scope="scope">
            <el-button size="mini" type="primary" :disabled="scope.row.uri.split('/')[2]==0 || scope.row.uri.split('/')[2]==3" @click="handleEdit(scope.row)" icon="el-icon-edit">编辑</el-button>
            <el-button size="mini" type="success" :disabled="scope.row.uri.split('/')[2]==0 || scope.row.uri.split('/')[2]==3" @click="handleDefault(scope.row)" icon="el-icon-delete">设为当前命名空间</el-button>
            <el-button size="mini" type="danger"  :disabled="scope.row.uri.split('/')[2]==0 || scope.row.uri.split('/')[2]==3" @click="handleDelete(scope.row)" icon="el-icon-delete">删除</el-button>
          </template>
        </el-table-column>
    </el-table>

    <el-dialog title="编辑" width="40%" :visible.sync="dialogFormVisible">
      
        <el-form :model="form" label-width="70px">
          <el-form-item label="name" :label-width="formLabelWidth">
            <el-input v-model="form.name" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="description" :label-width="formLabelWidth">
            <el-input v-model="form.description" auto-complete="off"></el-input>
          </el-form-item>
          
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button type="primary" @click="handleEditForm">确 定</el-button>
        </div>
    </el-dialog>
  </div>
</template>

<script>
import { mapState, mapActions } from "vuex";
export default {
  data() {
    return {
      listLoading: false,
      listQuery: {
        name: "",
        description: ""
      },
      list: [],
      dialogFormVisible: false,
      form: {
        name: "",
        description: ""
      },
      formLabelWidth: "80px"
    };
  },
  methods: {
     ...mapActions([
      "updateNamespace",
    ]),
    getList() {
      this.listLoading = true;
      var data = {maxSize:10000};
      this.$http
        .get("/mdt2/namespace/list")

        .then(res => {
          console.log(res);
          var result = [], num = 1;

          res.data.result.forEach(function(element) {
            if (!element.name) {
              element.name = "";
            }
            if (!element.description) {
              element.description = "";
            }
            result.push(element);
          });

          this.list.length = 0;
          for (var i = 0; i < result.length; i++) {
            this.list.push(result[i]);
          }
          this.listLoading = false;
        });
    },
    handleCreate() {
      var data = {
        name: this.listQuery.name,
        description: this.listQuery.description,
        indexList: {
          NodeClass: "String",
          BrowseName: "String",
          DisplayName: "String",
          Description: "String",
          isAbstract: "Boolean",
          DataType: "String"
        }
      };
      this.$http.post("/mdt2/namespace", data).then(res => {
        this.$message({
          message: res.data.msg,
          type: "success"
        });
        setTimeout(() => {
          this.getList();
          this.listQuery.name = "";
          this.listQuery.description = "";
        }, 3000);
      });
    },
    handleDefault(row) {
      row.using = "1";
      var data = [row];
      for(var i=0;i<this.list.length;i++){
        if(this.list[i].using == "1" && this.list[i].uri != row.uri){
          this.list[i].using = 0;
          data.push(this.list[i]);
        }
      }
      this.$http
        .put("/mdt2/namespace", data)
        .then(res => {
          this.$message({
            message: res.data.msg,
            type: "success"
          });
        });
      setTimeout(() => {
        this.getList();
        this.updateNamespace(row.uri.split("/")[2]);
      }, 3000);
    },
    handleEdit(row) {
      this.dialogFormVisible = true;
      this.form = Object.assign({}, row);
    },
    handleEditForm() {
      var data = [this.form];
      this.$http
        .put("/mdt2/namespace", data)
        .then(res => {
          this.$message({
            message: res.data.msg,
            type: "success"
          });
        });
      setTimeout(() => {
        this.dialogFormVisible = false;
        this.getList();
      }, 3000);
    },
    handleDelete(row) {
      this.$http.delete("/mdt2/namespace/" + row.uri.split("/")[2]).then(res => {
        this.$message({
          message: res.data.msg,
          type: "success"
        });
      });
      setTimeout(() => {
        this.getList();
      }, 3000);
    },
  },
  created() {
    this.getList();
  }
};
</script>
<style>
.add-NameSpace {
  margin-top: 10px;
  margin-bottom: 10px;
}
</style>
