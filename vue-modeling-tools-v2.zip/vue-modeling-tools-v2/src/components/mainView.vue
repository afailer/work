<template>
  <div class="editMain">
    <div class="cardClass">
        <el-card class="box-card">
        <div slot="header" class="clearfix">
            <span>详情</span>
            <div id="switcher">
              <span @click="isgraph = !isgraph"
              class="switcher lb" v-bind:class="{active: !isgraph}">文本</span> 
              <span @click="isgraph = !isgraph" class="switcher rb" v-bind:class="{active: isgraph}">图形</span>  
            </div>
        </div>
        <div class="title">
          <div class="main_scroll">
            <router-view></router-view>
          </div>
            
        </div>
        </el-card>
    </div>
  </div>
</template>
<script>
import { mapState, mapActions } from "vuex";
export default {
  data() {
    return {
      isgraph: false
    };
  },
  computed: mapState(["currentNode", "parentNodeForSave", "isGraph"]),
  watch: {
    isgraph: function() {
      this.changeGraph(this.isgraph);
      if (this.isgraph) {
        this.$router.push("/layout/model/graph");
      } else {
        console.log(this.currentNode);
        console.log(this.parentNodeForSave);
        this.loadDefaultView(this.currentNode, this.parentNodeForSave);
      }
    }
  },
  methods: {
    ...mapActions(["fetchDefaultNamespace", "changeGraph"]),
    loadDefaultView(treeNode, parentNode) {
      //根据nodeClass 判断
      if (treeNode.nodeClass == "Object") {
        this.$router.push({
          name: "rootObject4Type",
          query: { id: treeNode.id, parentName: parentNode.name }
        });
      } else if (treeNode.nodeClass == "Data Type") {
        this.$router.push({
          name: "dataType",
          query: { id: treeNode.id, parentName: parentNode.name }
        });
      } else if (treeNode.nodeClass == "Object Type") {
        this.$router.push({
          name: "objecttype",
          query: { id: treeNode.id, parentName: parentNode.name }
        });
      } else if (treeNode.nodeClass == "Reference Type") {
        this.$router.push({
          name: "referenceType",
          query: { id: treeNode.id, parentName: parentNode.name }
        });
      } else if (treeNode.nodeClass == "Variable Type") {
        this.$router.push({
          name: "variableType",
          query: { id: treeNode.id, parentName: parentNode.name }
        });
      } else if (treeNode.nodeClass == "Variable") {
        this.$router.push({
          name: "variable4Type",
          query: { id: treeNode.id, parentName: parentNode.name }
        });
      }
    }
  },
  mounted() {
    this.fetchDefaultNamespace();
  }
};
</script>
<style>
.switcher {
  border: 1px solid #5d8fc182;
  padding: 2px 5px;
  background: #5d8fc182;
  color: white;
  cursor: pointer;
}
.switcher.active {
  border: 1px solid #409eff;
  background: #409eff;
}
.switcher.lb {
  border-radius: 5px 0 0 5px;
}
.switcher.rb {
  margin-left: -5px;
  border-radius: 0px 5px 5px 0px;
}

#switcher {
  float: right;
  margin-right: 2rem;
}

.title {
  width: 100%;
  height: calc(100vh - 84px);
  overflow: hidden;
  margin: 0 2px 0 2px;
  border-radius: 4px;
}
.main_scroll {
  width: 102%;
  height: 100%;
  overflow-x: hidden;
  overflow-y: auto;
  padding-right: 20px;
}
.itemCollapse {
  width: 96%;
  margin: 0 10px 0 6px;
}
.itemCollapse .el-collapse-item__header {
  height: 32px;
  line-height: 32px;
}
.itemCollapse .el-collapse-item__content {
  padding-bottom: 0px;
}

.itemCollapse .el-collapse-item__arrow {
  margin-right: 18px;
  line-height: 32px;
}
.formClass {
  max-width: 800px;
  margin-left: 6px;
  margin-top: 16px;
}
.formClass .el-form-item__label {
  font-size: 12px;
}
/* 提交 button 按钮样式 */
.btnClass {
  float: right;
  margin: 10px 40px 100px 10px;
}

.el-collapse-item__header {
  background: rgb(224, 215, 215) !important;
  font-weight: bold;
  padding-left: 5px;
}
.main_scroll .demo-table-expand {
  font-size: 0;
}
.main_scroll .demo-table-expand label {
  width: 90px;
  color: #99a9bf;
}
.main_scroll .demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 100%;
}

.main_scroll .el-form-item--mini.el-form-item,
.main_scroll .el-form-item--small.el-form-item {
  margin-bottom: 10px !important;
}
.switchPower {
  float: right;
  margin-right: 100px;
}
</style>

