<template>
  <div class="cardClass">
      <el-card class="box-card">
        <div slot="header" class="clearfix">
            <span>属性</span>
        </div>
        <div class="detailBody">
            
            <div class="detial">
              <div v-if=" this.propertiesState.length > 0">
                <table class="tableValue">
                  <tr>
                    <th width="30%">Attribute</th>
                    <th width="70%">Value</th>
                  </tr>
                  <tr v-for="item in propertiesState">
                    <td>{{ item.key}}</td>
                    <td>{{ item.value }} </td>
                  </tr>                 
                </table>
              </div>
              <div v-else style="with:90%;;text-align:center;margin-top: 10px">
                 <span >没有数据</span>
              </div>
          </div>
        </div>
      </el-card>
  </div>
</template>
<script>
import { mapState, mapActions,mapMutations } from 'vuex'
  export default{
    // store,
    data(){
      return{
        
      }
    },
    computed: mapState([
      'propertiesState', // 詳情數據,
    ]),
    // computed:{
    //   getPropertiesState: function(){
    //     return JSON.parse(propertiesState[0].src);//删除属性 this.getPropertiesState
    //   }
    // },
    methods: {
     
         
      
        
    },
    mounted () {
   
     
    }
  }
</script>
<style>

.detailBody{
  width: 100%;
  /* height: 250px; */
  height: calc( 100vh - 86px);
  /* background-color: rgb(224, 20, 20); */
  overflow: hidden;
}

.detial{
  width: 102%;
  height: 100%;
  overflow-x: hidden;
  overflow-y: auto;
  padding-right: 20px;
}

.tableValue{
  font-size: 14px;
  width: 100%;
  table-layout: fixed;
}
.tableValue th{
  padding: 5px 0 5px 10px;
  text-align: left;
  font-weight: bold;
}
.tableValue td{
  padding: 5px 0 5px 10px;
  height:20px;
  border-width: 1px 0 0 0px;
  border-style: dashed;
  border-color: #80808042;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
}
</style>