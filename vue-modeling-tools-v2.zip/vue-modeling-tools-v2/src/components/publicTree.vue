<template>
  <div class="publictree">
    <ul id="publicTree" class="ztree" >            
    </ul>
  </div>
</template>
<script>
import { mapState, mapActions } from "vuex";
export default {
  data() {
    return {
      publicTree: {},
      Setting: {
        async: {
          enable: true,
          url: this.getUrl,
          type: "GET",
          dataFilter: this.filter
        },
        callback: {
          beforeAsync: this.beforeAsync,
          onAsyncError: this.onAsyncError,
          onAsyncSuccess: this.onAsyncSuccess,
          onClick: this.onClick
        }
      }
    };
  },
  methods: {
     ...mapActions(["selectNode"]),
    beforeAsync() {
      return true;
    },

    getUrl(treeId, treeNode) {
      
     
      var namespace;
      var param;
      var uri = this.currentUri;
      if (treeNode) {
        namespace = treeNode.id.match(/\/(\S*)\//)[1];
        param = "nodeId=" + treeNode.id + "&namespace=" + namespace;
      } else {
        namespace = "0";
        param = "nodeId=" + uri + "&namespace=" + namespace;
      }
      return "/mdt2/nodes/findSubNodes?" + param;
    },

    onAsyncSuccess(event, treeId, treeNode, msg) {
      this.publicTree = $.fn.zTree.getZTreeObj(treeId);
      
      var data = JSON.parse(msg).nodes;
      // if (data.length == 0) {
      //   treeNode.isParent = false;
      //   return;
      // }

      data.forEach(function(value) {
        value.isParent = true;
      });
      if (treeNode == undefined) {
        this.publicTree.addNodes(null, data, true); // 如果是根节点，那么就在null后面加载数据
      } else {
        this.publicTree.addNodes(treeNode, data, true); //如果是加载子节点，那么就是父节点下面加载
      }
      console.log(
        "[ onAsyncSuccess ]&nbsp;&nbsp;&nbsp;&nbsp;" +
          (!!treeNode && !!treeNode.name ? treeNode.name : "root")
      );
    },

    filter(treeId, parentNode, childNodes) {},

    onClick(e, treeId, treeNode) {
      // debugger;
      //选中节点存到store
       this.selectNode(treeNode)
    }


  },

  computed: {
    ...mapState([
      "currentUri" // 当前节点的URI
    ])
  },
  created() {},
  watch: {
    currentUri(current, old) {
      console.log("uri发生了变化：" + current);
      $.fn.zTree.init($("#publicTree"), this.Setting);
    }
  },
  mounted() {
    $.fn.zTree.init($("#publicTree"), this.Setting);
  }
};
</script>
<style>
.publictree ul.ztree {
  width: 100% !important;
}
</style>

