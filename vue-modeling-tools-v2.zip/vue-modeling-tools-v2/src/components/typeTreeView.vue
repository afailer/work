<template>
    <div class="typeTree">
        <div class="cardClass">
            <el-card class="box-card">
            <div slot="header" class="clearfix">
                <span>模型</span>
            </div>
            <div class="item" >
                <div class="right">
                    <ul id="typeTree" class="ztree"></ul>
                </div>
            </div>
            </el-card>
        </div>
        <!-- 鼠标右键弹出框开始 -->
        <div id="areaTree">
            <div id="rMenu">                
                <ul>
                    <li id="m_addObject" @click="addObj">
                        <el-button size="mini" type="text" style="color: #000" icon="el-icon-plus"> Add Instance</el-button>
                        </li>
                    <li id="m_addType" @click="addType">
                        <el-button size="mini" type="text" style="color: #000" icon="el-icon-plus">Add New Type</el-button>
                    </li>
                    <li id="m_addAddReferenceType" @click="addType">
                        <el-button size="mini" type="text" style="color: #000" icon="el-icon-plus">Add New ReferenceType</el-button>
                    </li>
                    <li id="m_delType" @click="removeTreeNode">
                        <el-button size="mini" type="text" style="color: #000" icon="el-icon-remove-outline">delete Node</el-button>
                    </li>
                
                </ul>
            </div>
        </div>   
    </div>
  
   
  
</template>
<script>
import { mapState, mapActions } from "vuex";
import { randomNum } from "@/utils/utils";
export default {
  data() {
    return {
      typeTree: {},
      typeCacheId: "",
      typeCacheNode: {},
      newTypeCount: 1,
      typeSetting: {
        async: {
          enable: true,
          url: "/mdt2/nodes/findSubNodes",
          autoParam: ["id=nodeId"],
          otherParam: ["namespace", "0"],
          type: "GET",
          dataFilter: this.filter
        },
        callback: {
          beforeAsync: this.beforeAsync,
          onAsyncError: this.onAsyncError,
          onAsyncSuccess: this.onAsyncSuccess,
          onClick: this.onClick,
          onRightClick: this.OnRightClick
        }
      }
      // typeNodes: [
      //   {
      //     id: 1,
      //     name: null,
      //     open: true,
      //     drag: false,
      //     drop: false,
      //     children: []
      //   }
      // ]
    };
  },
  // 引入 state 中的 定
  computed: mapState(["settings", "objectTreeState", "isGraph"]),
  methods: {
    ...mapActions([
      "showNode",
      "showProperties",
      "cacheTypeTree",
      "showchildrenTable",
      "showReferencesTable"
    ]),
    // 获取typeTree 的数据
    loadTypeTree() {
      $.fn.zTree.init($("#typeTree"), this.typeSetting, null);
    },

    beforeAsync() {
      return true;
    },

    onAsyncSuccess(event, treeId, treeNode, msg) {
      this.typeTree = $.fn.zTree.getZTreeObj(treeId);
      var data = JSON.parse(msg).nodes;
      // if (data.length == 0) {
      //   treeNode.isParent = false;
      //   return;
      // }
      data.forEach(function(value) {
        value.isParent = true;
      });
      if (treeNode == undefined) {
        for (var i = 0; i < data.length; i++) {
          if (data[i].id == "/0/86") {
            this.typeTree.addNodes(null, data[i], true); // 如果是根节点，那么就在null后面加载数据

            this.cacheTypeTree(this.typeTree);
          }
        }
      } else {
        this.typeTree.addNodes(treeNode, data, true);
        this.cacheTypeTree(this.typeTree); //如果是加载子节点，那么就是父节点下面加载
      }
      console.log(
        "[ onAsyncSuccess ]&nbsp;&nbsp;&nbsp;&nbsp;" +
          (!!treeNode && !!treeNode.name ? treeNode.name : "root")
      );
    },

    filter(treeId, parentNode, childNodes) {},

    // 节点点击事件
    onClick(e, treeId, treeNode) {
      var nodeNamespace = treeNode.id.match(/\/(\S*)\//)[1];

      this.$http
        .get("/mdt2/nodes/findChildren", {
          params: { namespace: nodeNamespace, nodeId: treeNode.id }
        })
        .then(res => {
          var getChildren = res.data.children;
          getChildren.forEach(element => {
            if (!element.dataType) {
              element.dataType = { nodeValues: { DisplayName: "" } };
            }
          });
          this.showchildrenTable(getChildren);
        });

      this.$http
        .get("/mdt2/nodes/findReferences", {
          params: { namespace: nodeNamespace, nodeId: treeNode.id }
        })
        .then(res => {
          var getReferences = res.data.references;
          this.showReferencesTable(getReferences);
        });
      this.showProperties(treeNode);

      //获取父节点名称
      if (treeNode.id != "/0/86") {
        var parentNode = this.typeTree
          .getNodeByParam("id", treeNode.id)
          .getParentNode();
        this.showNode({ treeNode: treeNode, parentNode: parentNode });
      } else {
        var parentNode = {};
        parentNode.name = "Root";
        this.showNode({ treeNode: treeNode, parentNode: null });
      }
      if (!this.isGraph) {
        //根据nodeClass 判断
        if (treeNode.nodeClass == "Object") {
          this.$router.push({
            name: "rootObject4Type",
            query: { id: treeNode.id, parentName: parentNode.name }
          });
        } else if (treeNode.nodeClass == "Data Type") {
          this.$router.push({
            name: "dataType",
            query: { id: treeNode.id, parentName: parentNode.name }
          });
        } else if (treeNode.nodeClass == "Object Type") {
          this.$router.push({
            name: "objecttype",
            query: { id: treeNode.id, parentName: parentNode.name }
          });
        } else if (treeNode.nodeClass == "Reference Type") {
          this.$router.push({
            name: "referenceType",
            query: { id: treeNode.id, parentName: parentNode.name }
          });
        } else if (treeNode.nodeClass == "Variable Type") {
          this.$router.push({
            name: "variableType",
            query: { id: treeNode.id, parentName: parentNode.name }
          });
        } else if (treeNode.nodeClass == "Variable") {
          this.$router.push({
            name: "variable4Type",
            query: { id: treeNode.id, parentName: parentNode.name }
          });
        }
      }
    },
    // 右击事件
    OnRightClick(event, treeId, treeNode) {
      this.typeCacheId = treeId;
      this.typeCacheNode = treeNode;
      this.typeTree.selectNode(treeNode);
      if (treeNode.id.startsWith("/0/")) {
        if (treeNode.nodeClass == "Reference Type") {
          // clientY  screenY offsetY event.screenY - 500  event.screenY - event.offsetY  ( $(window).height() - event.screenY- event.offsetY )
          // - $("body").height()/5
          this.showRMenu(
            "instence",
            "Notdel",
            event.pageX - 30,
            event.clientY - 20 - $("body").height() / 2
          );
        } else if (treeNode.NodeClass == "Object") {
          this.showRMenu(
            "noMenu",
            "Notdel",
            event.pageX - 30,
            event.clientY - 20 - $("body").height() / 2
          );
        } else if (
          treeNode.nodeClass == "Data Type" ||
          treeNode.nodeClass == "Object Type" ||
          treeNode.nodeClass == "Variable Type"
        ) {
          this.showRMenu(
            "newType",
            "Notdel",
            event.pageX - 30,
            event.clientY - 20 - $("body").height() / 2
          );
        }
      } else {
        if (treeNode.nodeClass == "Reference Type") {
          this.showRMenu(
            "instence",
            "Isdel",
            event.pageX - 30,
            event.clientY - 20 - $("body").height() / 2
          );
        } else if (treeNode.NodeClass == "Object") {
          this.showRMenu(
            "noMenu",
            "Isdel",
            event.pageX - 30,
            event.clientY - 20 - $("body").height() / 2
          );
        } else if (
          treeNode.nodeClass == "Data Type" ||
          treeNode.nodeClass == "Object Type" ||
          treeNode.nodeClass == "Variable Type"
        ) {
          this.showRMenu(
            "newType",
            "Isdel",
            event.pageX - 30,
            event.clientY - 20 - $("body").height() / 2
          );
        }
      }
    },
    // 显示菜单
    showRMenu(type, del, x, y) {
      $("#rMenu ul").show();
      if (type == "instence" && del == "Notdel") {
        $("#m_addType").hide();
        $("#m_addObject").hide();
        $("#m_addAddReferenceType").show();

        $("#m_delType").hide();
      } else if (type == "instence" && del == "Isdel") {
        $("#m_addType").hide();
        $("#m_addObject").hide();
        $("#m_addAddReferenceType").show();
        $("#m_delType").show();
      } else if (type == "noMenu") {
        $("#m_addObject").hide();
        $("#m_addType").hide();
        $("#m_delType").hide();
        $("#m_addAddReferenceType").hide();
      } else if (type == "newType" && del == "Notdel") {
        $("#m_addType").show();
        $("#m_addObject").hide();
        $("#m_addAddReferenceType").hide();
        $("#m_delType").hide();
      } else if (type == "newType" && del == "Isdel") {
        $("#m_addType").show();
        $("#m_addObject").hide();
        $("#m_addAddReferenceType").hide();
        $("#m_delType").show();
      } else if (type == "objinstance" && del == "Notdel") {
        $("#m_addType").hide();
        $("#m_addObject").show();
        $("#m_addAddReferenceType").hide();
        $("#m_delType").hide();
      } else if (type == "objinstance" && del == "Isdel") {
        $("#m_addType").hide();
        $("#m_addObject").show();
        $("#m_addAddReferenceType").hide();
        $("#m_delType").show();
      } else if (type == "variableinstance" && del == "Notdel") {
        $("#m_addType").hide();
        $("#m_addObject").show();
        $("#m_addAddReferenceType").hide();
        $("#m_delType").hide();
      } else if (type == "variableinstance" && del == "Isdel") {
        $("#m_addType").hide();
        $("#m_addObject").show();
        $("#m_addAddReferenceType").hide();
        $("#m_delType").show();
      } else {
        $("#m_addObject").hide();
        $("#m_addType").hide();
        $("#m_delType").hide();
        $("#m_addAddReferenceType").hide();
      }
      //

      $("#rMenu").css({
        top: y + "px",
        left: x + "px",
        visibility: "visible",
        "z-index": 999
      });

      $("body").bind("mousedown", this.onBodyMouseDown);
    },
    // 隐藏 Menu
    hideRMenu() {
      if ($("#rMenu")) {
        $("#rMenu").css({ visibility: "hidden" });
      }
      $("body").unbind("mousedown", this.onBodyMouseDown);
    },
    // 鼠标事件S
    onBodyMouseDown(event) {
      if (
        !(
          event.target.id == "rMenu" ||
          $(event.target).parents("#rMenu").length > 0
        )
      ) {
        $("#rMenu").css({ visibility: "hidden" });
      }
    },
    // 删除节点
    removeTreeNode(e, a, b) {
      this.hideRMenu();
      this.nodes = this.typeTree.getSelectedNodes();
      var msg = "此节点有子节点，你确定删除吗？";
      if (confirm(msg) == true) {
        var nodeId = this.nodes[0].id;
        var namespace = nodeId.match(/\/(\S*)\//)[1];
        this.$http
          .delete(
            "/mdt2/nodes/delNode" +
              "?namespace=" +
              namespace +
              "&nodeId=" +
              nodeId,
            {}
          )
          .then(res => {
            this.typeTree.removeNode(this.nodes[0]);
          });
      }
    },
    //增加Type
    addType(event) {
      // debugger;
      this.hideRMenu();

      this.showProperties({});

      this.showchildrenTable([]);
      this.showReferencesTable([]);

      //获取父节点名称
      if (this.typeCacheNode != "/0/86") {
        // debugger;
        // var parentNode = this.typeTree
        //   .getNodeByParam("id", this.typeCacheNode.id)
        //   .getParentNode();

        var parentNode = this.typeCacheNode;
        this.showNode({
          treeNode: { NodeClass: this.typeCacheNode.nodeClass },
          parentNode: this.typeCacheNode
        });
      } else {
        var parentNode = {};
        parentNode.name = "Root";
        this.showNode({ treeNode: {}, parentNode: this.typeCacheNode });
      }

      //根据nodeClass 判断
      if (this.typeCacheNode.nodeClass == "Object") {
        this.$router.push({
          name: "rootObject",
          query: {
            id: randomNum(this.settings.currentNamespace),
            parentName: parentNode.name
          }
        });
      } else if (this.typeCacheNode.nodeClass == "Data Type") {
        this.$router.push({
          name: "dataType",
          query: {
            id: randomNum(this.settings.currentNamespace),
            parentName: parentNode.name
          }
        });
      } else if (this.typeCacheNode.nodeClass == "Object Type") {
        this.$router.push({
          name: "objecttype",
          query: {
            id: randomNum(this.settings.currentNamespace),
            parentName: parentNode.name
          }
        });
      } else if (this.typeCacheNode.nodeClass == "Reference Type") {
        this.$router.push({
          name: "referenceType",
          query: {
            id: randomNum(this.settings.currentNamespace),
            parentName: parentNode.name
          }
        });
      } else if (this.typeCacheNode.nodeClass == "Variable Type") {
        this.$router.push({
          name: "variableType",
          query: {
            id: randomNum(this.settings.currentNamespace),
            parentName: parentNode.name
          }
        });
      } else if (this.typeCacheNode.nodeClass == "Variable") {
        this.$router.push({
          name: "rootObject",
          query: {
            id: randomNum(this.settings.currentNamespace),
            parentName: parentNode.name
          }
        });
      }
    },

    //增加对象
    addObj(event) {},
    //增加 addAddReferenceType
    addAddReferenceType() {
      this.hideRMenu();
      this.showProperties({});

      this.cacheTypeTree(this.typeTree); // 将typeTree存入store中
      return false;
    }
  },

  created() {
    this.loadTypeTree();
  },
  mounted() {
    $.fn.zTree.init($("#typeTree"), this.typeSetting);
  }
};
</script>
<style>
@import "../assets/zTreeStyle";
@import "../assets/demo";

.ztree li span.button.iconFolder_ico_open {
  margin-right: 2px;
  background: url(../assets/img/file_open.png) no-repeat scroll 0 0 transparent;
  vertical-align: top;
  *vertical-align: middle;
}
.ztree li span.button.iconFolder_ico_close {
  margin-right: 2px;
  background: url(../assets/img/file_close.png) no-repeat scroll 0 0 transparent;
  vertical-align: top;
  *vertical-align: middle;
}
.ztree li span.button.iconDataType_ico_open,
.ztree li span.button.iconDataType_ico_close {
  margin-right: 2px;
  background: url(../assets/img/cut_add_structure.png) no-repeat scroll 0 0
    transparent;
  vertical-align: top;
  *vertical-align: middle;
}
.ztree li span.button.iconObjectType_ico_open,
.ztree li span.button.iconObjectType_ico_close {
  margin-right: 2px;
  background: url(../assets/img/cut_howto_se_add_objecttype.png) no-repeat
    scroll 0 0 transparent;
  vertical-align: top;
  *vertical-align: middle;
}
.ztree li span.button.iconReferenceType_ico_open,
.ztree li span.button.iconReferenceType_ico_close {
  margin-right: 2px;
  background: url(../assets/img/cut_add_reference.png) no-repeat scroll 0 0
    transparent;
  vertical-align: top;
  *vertical-align: middle;
}
.ztree li span.button.iconVariableType_ico_open,
.ztree li span.button.iconVariableType_ico_close {
  margin-right: 2px;
  background: url(../assets/img/cut_add_varizbleType.png) no-repeat scroll 0 0
    transparent;
  vertical-align: top;
  *vertical-align: middle;
}

.ztree li span.button.iconVariable_ico_open,
.ztree li span.button.iconVariable_ico_close {
  margin-right: 2px;
  background: url(../assets/img/cut_specify_nodeaccessinfo.png) no-repeat scroll
    0 0 transparent;
  vertical-align: top;
  *vertical-align: middle;
}

.ztree li span.button.icon011_ico_docu {
  margin-right: 2px;
  background: url(../assets/img/cut_add_structure.png) no-repeat scroll 0 0
    transparent;
  vertical-align: top;
  *vertical-align: middle;
}
/* .ztree li span.button.icon031_ico_docu {
  margin-right: 2px;
  background: url(../assets/img/cut_add_variable.png)
    no-repeat scroll 0 0 transparent;
  vertical-align: top;
  *vertical-align: middle;
} */

.ztree li span.button.icon021_ico_docu {
  margin-right: 2px;
  background: url(../assets/img/cut_howto_se_add_objecttype.png) no-repeat
    scroll 0 0 transparent;
  vertical-align: top;
  *vertical-align: middle;
}
.ztree li span.button.icon041_ico_docu {
  margin-right: 2px;
  background: url(../assets/img/cut_add_reference.png) no-repeat scroll 0 0
    transparent;
  vertical-align: top;
  *vertical-align: middle;
}
.ztree li span.button.icon051_ico_docu {
  margin-right: 2px;
  background: url(../assets/img/cut_add_varizbleType.png) no-repeat scroll 0 0
    transparent;
  vertical-align: top;
  *vertical-align: middle;
}

/* tree样式 */

.typeTree,
.cardClass,
.right {
  height: 100%;
}
.item {
  height: 85%;
}

ul.ztree {
  height: 95%;
  width: 103%;
  overflow: auto;
  overflow-x: hidden;
}

/* 鼠标右键菜单 */
#areaTree {
  /* border: 1px solid #e5e5e5;
    margin-bottom: 2px;
    border-radius: 14px; */
  /* position: relative; */
  /* overflow: hidden; */
  z-index: 9999;
}
#areaTree .content_wrap .zTreeDemoBackground {
  height: 300px;
}
#areaTree .content_wrap .right {
  height: 300px;
}
div #rMenu {
  position: absolute;
  visibility: hidden;
  top: 0;
  background-color: #fff;
  text-align: left;

  padding: 6px 8px;
  min-width: 120px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4), 0 0 1px rgba(0, 0, 0, 0.2);
  border-radius: 4px;
}

#rMenu ul li {
  list-style: none;
}
#rMenu el-button {
  color: #ffffff;
}
#m_addObject:hover {
  background-color: #409eff;
}
#m_addType:hover {
  background-color: #409eff;
}
#m_addAddReferenceType:hover {
  background-color: #409eff;
}
#m_delType:hover {
  background-color: #409eff;
}
</style>