import Vue from 'vue'
import Router from 'vue-router'
import Layout from '@/views/layout/layout'
import Model from '@/views/model/model'
import Monitor from '@/views/monitor/monitor'
import Settings from '@/views/settings/settings'
import ObjectTypeModel from '@/components/mainComponents/objectTypeModel'
import DefaultModel from '@/components/mainComponents/defaultModel'
import ObjectRootModel from '@/components/mainComponents/objectRootModel'
import ObjectRootModel4Type from '@/components/mainComponents/objectRootModel4Type'
import DataTypeModel from '@/components/mainComponents/dataTypeModel'
import ReferenceTypeModel from '@/components/mainComponents/referenceTypeModel'
import VariableTypeModel from '@/components/mainComponents/variableTypeModel'
import VariableModel from '@/components/mainComponents/variableModel'
import DataTypeEnumeration from '@/components/mainComponents/dataTypeEnumeration'
import Graph from '@/components/mainComponents/graphCanvas/graph.vue'

Vue.use(Router)

export default new Router({
    routes: [{
        path: "/login",
        name: "login",
        component: () =>
            import ("@/views/login/index")
    }, {
        path: '/',
        name: 'layout',
        component: Layout,
        redirect: '/layout/model',
        children: [{
                path: "/layout/model",
                name: 'model',
                component: Model,
                redirect: '/layout/model/default',
                children: [{
                        path: "/layout/model/default",
                        name: "defaultModel",
                        component: DefaultModel,
                    },
                    {
                        path: "/layout/model/objecttype",
                        name: "objecttype",
                        component: ObjectTypeModel,
                    },
                    {
                        path: "/layout/model/rootObject",
                        name: "rootObject",
                        component: ObjectRootModel,
                    },
                    {
                        path: "/layout/model/rootObject4Type",
                        name: "rootObject4Type",
                        component: ObjectRootModel4Type,
                    },
                    {
                        path: "/layout/model/dataType",
                        name: "dataType",
                        component: DataTypeModel,
                    },
                    // {
                    //     path: "/layout/model/dataType",
                    //     name: "dataType",
                    //     component: DataTypeEnumeration,
                    // },
                    {
                        path: "/layout/model/referenceType",
                        name: "referenceType",
                        component: ReferenceTypeModel,
                    },
                    {
                        path: "/layout/model/variableType",
                        name: "variableType",
                        component: VariableTypeModel,
                    },
                    {
                        path: "/layout/model/variable",
                        name: "variable",
                        component: ObjectRootModel,
                    },
                    {
                        path: "/layout/model/variable4Type",
                        name: "variable4Type",
                        component: ObjectRootModel4Type,
                    },
                    {
                        path: "/layout/model/graph",
                        name: "graph",
                        component: Graph
                    }


                ],
            },
            {
                path: "/layout/monitor",
                name: 'monitor',
                component: Monitor,
            },
            {
                path: "/layout/settings",
                name: 'settings',
                component: Settings,
            }
        ]
    }]
})