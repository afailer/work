export function randomNum(index) {
    if (index) {
        return "/" + index + "/" + "$" + Date.parse(new Date()) + "$";
    } else {
        return "/1/" + "$" + Date.parse(new Date()) + "$";
    }
}


export function compare(oldObj, newObj) {
    var result = {
        parentNode: {},
        currentNode: {},
        typeDefinitionNode: {},
        modellingRuleNode: {},
        relationNode: {},

        addChildNodes: [],
        delChildNodes: [],
        updateChildNodes: [],

        delReferences: [],
        addReferences: []
    }

    // --------------- 处理当前节点 start----------------------
    var parentNode1 = oldObj.parentNode;
    var currentNode1 = oldObj.currentNode;
    // var typeDefinitionNode1 = oldObj.typeDefinitionNode;
    // var modellingRuleNode1 = oldObj.modellingRuleNode;
    // var relationNode1 = oldObj.relationNode;

    var parentNode2 = newObj.parentNode;
    var currentNode2 = newObj.currentNode;
    var typeDefinitionNode2 = newObj.typeDefinitionNode;
    var modellingRuleNode2 = newObj.modellingRuleNode;
    var relationNode2 = newObj.relationNode;
    // 在版本V1中typedefinition、modellingRule、relation 暂不允许修改的，所以只需比对currentNode节点
    // current节点无则创建，有则更新，不需要进行比对！！
    result.parentNode = parentNode2;
    result.currentNode = currentNode2;
    result.typeDefinitionNode = typeDefinitionNode2;
    result.modellingRuleNode = modellingRuleNode2;
    result.relationNode = relationNode2;
    // --------------- 处理当前节点 end----------------------

    // --------------- 处理children start----------------------
    var children1 = oldObj.children;
    var children2 = newObj.children;
    // 遍历时，应考虑到name/dataType/typedefinition/ModellingRule!!!!!!!!!!!!!!!!

    children1.forEach(element => {
        var element2 = findChildRelationInList(children2, element.node.nodeUri);

        if (element2) { // 没有新建对象，可能变化的是：name/dataType/ModellingRule
            var compareResult = isChildRelationEqual(element, element2);
            if (compareResult) { // 比对一致
                // Donothing
            } else {
                // 引起不一致的原因很多：name、dataType;modellingrule
                if (element.node.name != element2.node.name ||
                    element.dataType.nodeUri != element2.dataType.nodeUri) {
                    result.updateChildNodes.push(element2)
                }
                if (element.modellingRule.nodeUri != element2.modellingRule.nodeUri) {
                    // 现在暂时值支持Mandatory和Optional
                    if (element.modellingRule.nodeUri == '/0/78') { //  Mandatory
                        result.delReferences.push({
                            rel: {
                                nodeUri: "/0/37"
                            },
                            targetNode: {
                                nodeUri: "/0/78"
                            }
                        });
                        result.addReferences.push({
                            rel: {
                                nodeUri: "/0/37"
                            },
                            targetNode: {
                                nodeUri: "/0/80"
                            }
                        });
                    } else {
                        result.addReferences.push({
                            rel: {
                                nodeUri: "/0/37"
                            },
                            targetNode: {
                                nodeUri: "/0/78"
                            }
                        });
                        result.delReferences.push({
                            rel: {
                                nodeUri: "/0/37"
                            },
                            targetNode: {
                                nodeUri: "/0/80"
                            }
                        });
                    }
                }

            }
        } else {
            result.delChildNodes.push(element);
        }
    });

    children2.forEach(element => {
        var element1 = findChildRelationInList(children1, element.node.nodeUri);
        if (element1) { // 在上一轮循环中已经比对过
            // Do nothing
        } else {
            if (element.node.nodeValues.DisplayName) {
                if (!element.node.nodeUri) {
                    element.node.nodeUri = randomNum();
                }
                if (!element.node.name) {
                    element.node.nodeValues.name = element.node.nodeValues.DisplayName

                }
                if (!element.node.BrowseName) {
                    element.node.nodeValues.BrowseName = element.node.nodeValues.DisplayName
                }
                element.node.nodeClass = element.nodeClass
                result.addChildNodes.push(element);
            }

        }
    });
    // --------------- 处理children end----------------------

    // --------------- 处理Reference start----------------------
    var references1 = oldObj.references;
    var references2 = newObj.references;
    // 遍历时，只会影响到关系变化
    references1.forEach(element => {
        if (isReferenceRelationExistInList(references2, element)) {
            // do nothing
        } else {
            result.delReferences.push(element)
        }
    });

    references2.forEach(element => {
        if (isReferenceRelationExistInList(references1, element)) {
            // do nothing
        } else {
            if (element.rel.nodeValues.DisplayName) {
                result.addReferences.push(element)
            }
        }
    });
    // --------------- 处理Reference end----------------------


    return result;

}

export function findChildRelationInList(list, uri) {
    for (var i = 0; i < list.length; i++) {
        if (list[i].node.nodeUri == uri) {
            return list[i];
        }
    }

    return null;
}
export function isReferenceRelationExistInList(list, referenceRelation) {
    for (var i = 0; i < list.length; i++) {
        if (list[i].rel.nodeUri == referenceRelation.rel.nodeUri && list[i].targetNode.nodeUri == referenceRelation.targetNode.nodeUri) {
            return true;
        }
    }

    return false;
}

export function isChildRelationEqual(oldObj, newObj) {
    if (oldObj.node.nodeUri != newObj.node.nodeUri) {
        return false;
    }
    if (oldObj.typeDefinition.nodeUri != newObj.typeDefinition.nodeUri) {
        return false;
    }
    if (oldObj.modellingRule.nodeUri != newObj.modellingRule.nodeUri) {
        return false;
    }
    if (oldObj.dataType.nodeUri != newObj.dataType.nodeUri) {
        return false;
    }
    if (oldObj.nodeClass != newObj.nodeClass) {
        return false;
    }

    return true;
}

export function isEqual(oldObj, newObj) {
    var oldStr, newStr;
    if (typeof(oldObj) == "string") {
        oldStr = oldObj;
        newObj = newObj;
    } else {
        oldStr = JSON.stringify(oldObj);
        newStr = JSON.stringify(newObj);
    }

    if (hashcode(oldStr) == hashcode(newStr)) {
        return true;
    }
    return false;
}

export function hashcode(str) {
    var hash = 0,
        i, chr, len;
    if (str.length === 0) return hash;
    for (i = 0, len = str.length; i < len; i++) {
        chr = str.charCodeAt(i);
        hash = ((hash << 5) - hash) + chr;
        hash |= 0; // Convert to 32bit integer
    }
    return hash;
}