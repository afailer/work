// 专门为axios封装实例
import axios from 'axios'
import {Message, MessageBox} from 'element-ui'

// create axios instance
const service = axios.create({

  timeout:15000
})

// 添加一个请求拦截器
service.interceptors.request.use(config => {
  //return config 一定要保留,调用axios都是采用config的方式
  return config
}, error => {
  // Do something with request error
  console.info('request-error', error)
  Promise.reject(error)
})

// 添加一个响应拦截器
service.interceptors.response.use(response => {
  // var response = {
  //   data:{
  //     success:true,
  //     code:401,
  //     msg:"",
  //     list:[],
  //     pageNum:1,
  //     totalCount:2,
  //     pageSize:10
  //   },
  //   status:401,
  //   statusText:'',
  //   headers:{},
  //   config:{}
  // }
  const res = response.data
  if (!res.success) {
    Message({
      message: res.msg,
      type: 'error',
      duration: 2 * 1000
    })
  } else {
    return response.data;
  }
  // 在此处还可以根据返回的code
}, error => {
  // Do something with response error

  console.info('response-error', error)
  // Message({
  //   message: '服务器挂啦，请稍后重试',
  //   type: 'error',
  //   duration: 2 * 1000
  // })
  Promise.reject(error)
})

export default service
