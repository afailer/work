import Mock from 'mockjs'
import getList from './getList'

Mock.mock('/layout/Object', 'get', getList.getArticle)
    // Mock.mock('/layout/Object', 'get', typeJsonApi)
    //引入mockjs

//使用mockjs模拟数据
// Mock.mock('/layout/Object', (req, res) => {
//     return {
//         data: ['a', 'b']
//     }
// })

const List = []
const count = 100;

for (let i = 0; i < count; i++) {
    List.push(Mock.mock({
        order_no: '@guid()',
        timestamp: +Mock.Random.date('T'),
        username: '@name()',
        price: '@float(1000, 15000, 0, 2)',
        'status|1': ['success', 'pending']
    }))
}

const typeJsonApi = () => {
    return {
        total: List.length,
        items: List
    }
}