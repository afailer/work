import Mock from 'mockjs'


export default {
    getArticle: () => ({ // 后去文章
        id: 120000000001,
        author: { key: 'mockPan' },
        source_name: '原创作者',
        category_item: [{ key: 'global', name: '全球' }],
        comment_disabled: true,
        content: '<p>我是测试数据我是测试数据</p><p><img class="wscnph" src="https://wpimg.wallstcn.com/4c69009c-0fd4-4153-b112-6cb53d1cf943" data-wscntype="image" data-wscnh="300" data-wscnw="400" data-mce-src="https://wpimg.wallstcn.com/4c69009c-0fd4-4153-b112-6cb53d1cf943"></p>"',
        content_short: '我是测试数据',
        display_time: +new Date(),
        image_uri: 'https://wpimg.wallstcn.com/e4558086-631c-425c-9430-56ffb46e70b3',
        platforms: ['a-platform'],
        source_uri: 'https://github.com/PanJiaChen/vue-element-admin',
        status: 'published',
        tags: [],
        title: 'vue-element-admin'
    }),
}


// const List = []
// const count = 100;

// for (let i = 0; i < count; i++) {
//     List.push(Mock.mock({
//         order_no: '@guid()',
//         timestamp: +Mock.Random.date('T'),
//         username: '@name()',
//         price: '@float(1000, 15000, 0, 2)',
//         'status|1': ['success', 'pending']
//     }))
// }

// const typeJsonApi = () => {
//     return {
//         total: List.length,
//         items: List
//     }
// }