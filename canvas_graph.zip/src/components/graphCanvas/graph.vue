<template>
  <div ref="canvas_container" class="canvas_container">
    
    <p ref="info" class="info">{{src}}</p>
    <div class="canvas_parent" ref="canvas_parent">
      <span class="iconfont icon-fanhui backStart" @click="backToStart"></span>
      <canvas ref="canvas" width="800" height="800" class="canvas"></canvas>
    </div>
    
  </div>
</template>

<script>
import { RoleController } from "./RoleController";
import { EventHandler } from "./utils/EventHandler";
import { ElementCreator } from "./utils/ElementCreator";
import ProcessData from "./utils/ProcessData";
import { ElementStore } from "./utils/ElementStore";
import Setting from "./utils/setting";
import axios from "axios";
export default {
  name: "Graph",
  data() {
    return {
      nodes: [
        {
          id: 5,
          name: "C语言",
          src: "c语言"
        },
        {
          id: 12,
          name: "ios",
          src: "ios系统"
        },
        {
          id: 6,
          name: "java",
          src: "java语言"
        },
        {
          id: 7,
          name: "Android",
          src: "Android操作系统"
        },
        {
          id: 8,
          name: "前端",
          src: "基于浏览器的前端"
        },
        {
          id: 9,
          name: "vue",
          src: "vue框架"
        },

        {
          id: 10,
          name: "react",
          src: "react框架"
        },
        {
          id: 11,
          name: "JQuery",
          src: "Jquery是一个js库"
        }
      ],
      relationships: [
        {
          id: 214,
          startNode: 5,
          endNode: 12,
          type: "用到"
        },
        {
          id: 202,
          startNode: 11,
          endNode: 8,
          type: "属于"
        },
        {
          id: 234,
          startNode: 10,
          endNode: 8,
          type: "属于"
        },
        {
          id: 236,
          startNode: 9,
          endNode: 8,
          type: "属于"
        },
        {
          id: 421,
          startNode: 6,
          endNode: 5,
          type: "JNI调用"
        },
        {
          id: 425,
          startNode: 6,
          endNode: 7,
          type: "语言"
        },
        {
          id: 416,
          startNode: 7,
          endNode: 6,
          type: "产品"
        }
      ],
      src: "",
      form: {},
      currentCircle: "",
      circleDatas: [],
      roleCtrl: "",
      canvas_container: {},
      info: {},
      canvas_parent: {},
      canvas: {},
      oldNodeId: ""
    };
  },
  methods: {
    getNewDatas(datas) {
      //请求到的数据与本地数据进行比对
      let newDatas = [];
      if (datas.length == 0) {
        return newDatas;
      }

      for (let d = 0; d < datas.length; d++) {
        let isNew = true;
        for (let l = 0; l < ElementStore.prototype.elements.length; l++) {
          if (datas[d].id == ElementStore.prototype.elements[l].data.id) {
            isNew = false;
            break;
          }
        }
        if (isNew) {
          newDatas.push(datas[d]);
        }
      }
      if (newDatas.length == 0) {
        //alert("没有请求到新数据");
      }
      return newDatas;
    },
    addCircleEles(nodes, relationships) {
      let circleDatas = null;
      if (this.currentCircle != "") {
        circleDatas = ProcessData.addCircleDatas(nodes, this.currentCircle);
      } else {
        circleDatas = ProcessData.getCircleDatas(nodes);
      }
      ElementStore.prototype.addCircles(circleDatas);
      this.circleDatas = this.circleDatas.concat(circleDatas);
      ElementCreator.prototype.addElements(circleDatas);
      this.addLines(relationships);
    },
    addLines(relationships) {
      let lines = ProcessData.getLineDatas(
        ElementStore.prototype.circleDatas,
        relationships
      );
      ElementCreator.prototype.addLines(lines);
    },
    backToStart() {
      this.roleCtrl.backToStart();
    },
    initHandlerListener() {
      EventHandler.prototype.listen("loadNewData", data => {
        this.currentCircle = data;
        //this.getNodesRels(data.id);
      });
      EventHandler.prototype.listen("showInfo", data => {
        if (data.eleType == "circle") {
          this.showProperties(data);
        }
      });
      EventHandler.prototype.listen("showDetails", data => {
        if (data == false) {
          ElementStore.prototype.info.style.display = "none";
        } else {
          if (
            data.src == undefined &&
            (data.eleType == "line" || data.eleType == "BezierLine")
          ) {
            this.src = data.type;
            ElementStore.prototype.info.style.position = "absolute";
            ElementStore.prototype.info.style.left =
              //this.canvas_parent.offsetLeft +
              parseInt((data.beginPoint.x + data.endPoint.x) / 2) +
              this.roleCtrl.translateX +
              "px";
            ElementStore.prototype.info.style.top =
              // this.canvas_parent.offsetTop +
              parseInt((data.beginPoint.y + data.endPoint.y) / 2) +
              this.roleCtrl.translateY +
              "px";
            ElementStore.prototype.info.innerText = data.type;
          } else {
            this.src = data.src;
            ElementStore.prototype.info.style.position = "absolute";
            ElementStore.prototype.info.style.left =
              //this.canvas_parent.offsetLeft +
              parseInt(data.x) + this.roleCtrl.translateX + "px";
            ElementStore.prototype.info.style.top =
              //this.canvas_parent.offsetTop +
              Setting.prototype.CircleRadius +
              parseInt(data.y) +
              this.roleCtrl.translateY +
              "px";
            ElementStore.prototype.info.innerText = data.src;
          }
          ElementStore.prototype.info.style.display = "block";
        }
      });
      EventHandler.prototype.listen("drag", (x, y, eventType) => {
        this.roleCtrl.onDrag(x, y, eventType);
      });
    },
    initCanvas() {
      this.$nextTick(() => {
        this.canvas.width = this.canvas_parent.offsetWidth;
        this.canvas.height = this.canvas_parent.offsetHeight;
      });

      document.oncontextmenu = new Function("event.returnValue=false;");
      document.onselectstart = new Function("event.returnValue=false;");
      this.roleCtrl = new RoleController(this.canvas);
      window.addEventListener(
        "resize",
        () => {
          this.canvas.width = this.canvas_parent.offsetWidth;
          this.canvas.height = this.canvas_parent.offsetHeight;
        },
        false
      );
      window.addEventListener(
        "mouseup",
        event => EventHandler.prototype.handleMouseUp(event),
        false
      );
      this.canvas.addEventListener(
        "mousedown",
        event => EventHandler.prototype.handleMouseDown(event),
        false
      );
      this.canvas.addEventListener(
        "mousemove",
        event => EventHandler.prototype.handleMouseMove(event),
        false
      );
    }
  },
  mounted() {
    this.canvas_container = document.querySelector(".canvas_container");
    ElementStore.prototype.info = this.$refs.info;
    this.canvas_parent = document.querySelector(".canvas_parent");
    this.canvas = document.querySelector(".canvas");
    this.initCanvas();
    this.initHandlerListener();
    this.addCircleEles(this.nodes, this.relationships);
  },
  created() {}
  //{"success":true,"msg":"查询成功.","nodes":[{"id":"/0/86","name":"Types","iconSkin":"iconFolder","nodeClass":"Object","typeDefinition":"/0/61","src":"{\"NodeClass\":\"Object\",\"Description\":\"The browse entry point when looking for types in the server address space.\",\"BrowseName\":\"Types\",\"DisplayName\":\"Types\",\"label\":\"0\",\"id\":4280,\"uri\":\"/0/86\"}","typeDefinitionSrc":"{\"nodeValues\":{\"NodeClass\":\"Object Type\",\"Description\":\"The type for objects that organize other nodes.\",\"BrowseName\":\"FolderType\",\"DisplayName\":\"FolderType\",\"isAbstract\":\"false\",\"uri\":\"/0/61\"},\"relationValue\":null,\"nodeUri\":\"/0/61\",\"relation\":\"/0/40\"}","modellingSrc":null,"dataTypeSrc":null,"relationSrc":null},{"id":"/0/61","name":"FolderType","iconSkin":"iconObjectType","nodeClass":"Object Type","typeDefinition":null,"src":"{\"NodeClass\":\"Object Type\",\"Description\":\"The type for objects that organize other nodes.\",\"BrowseName\":\"FolderType\",\"DisplayName\":\"FolderType\",\"label\":\"0\",\"id\":8424,\"isAbstract\":\"false\",\"uri\":\"/0/61\"}","typeDefinitionSrc":null,"modellingSrc":null,"dataTypeSrc":null,"relationSrc":null},{"id":"/0/90","name":"DataTypes","iconSkin":"iconFolder","nodeClass":"Object","typeDefinition":"/0/61","src":"{\"NodeClass\":\"Object\",\"Description\":\"The browse entry point when looking for data types in the server address space.\",\"BrowseName\":\"DataTypes\",\"DisplayName\":\"DataTypes\",\"label\":\"0\",\"id\":8248,\"uri\":\"/0/90\"}","typeDefinitionSrc":"{\"nodeValues\":{\"NodeClass\":\"Object Type\",\"Description\":\"The type for objects that organize other nodes.\",\"BrowseName\":\"FolderType\",\"DisplayName\":\"FolderType\",\"isAbstract\":\"false\",\"uri\":\"/0/61\"},\"relationValue\":null,\"nodeUri\":\"/0/61\",\"relation\":\"/0/40\"}","modellingSrc":null,"dataTypeSrc":null,"relationSrc":null},{"id":"/0/24","name":"BaseDataType","iconSkin":"iconDataType","nodeClass":"Data Type","typeDefinition":null,"src":"{\"NodeClass\":\"Data Type\",\"Description\":\"Describes a value that can have any valid DataType.\",\"BrowseName\":\"BaseDataType\",\"DisplayName\":\"BaseDataType\",\"label\":\"0\",\"id\":8328,\"isAbstract\":\"true\",\"uri\":\"/0/24\"}","typeDefinitionSrc":null,"modellingSrc":null,"dataTypeSrc":null,"relationSrc":null}],"relationships":[{"id":"32279","properties":{},"type":"R-/0/35","startNode":"/0/86","endNode":"/0/90"},{"id":"13319","properties":{},"type":"R-/0/40","startNode":"/0/90","endNode":"/0/61"},{"id":"13831","properties":{},"type":"R-/0/35","startNode":"/0/90","endNode":"/0/24"}]}
};
</script>

<style scoped>
.canvas_container {
  position: relative;
  border: 1px dashed #ccc;
  width: 100%;
  height: 100%;
}
.canvas_parent {
  width: 100%;
  height: 100%;
}
.info {
  width: 300px;
  padding: 10px;
  border-radius: 20px;
  border: 1px solid #333;
  position: absolute;
  word-break: break-all;
  left: 0px;
  display: none;
  z-index: 20;
  text-align: center;
  background: #ffffff;
  top: 0px;
}
.backStart {
  z-index: 30;
  position: absolute;
  top: 30px;
  left: 30px;
  font-size: 30px;
}
.backStart:hover {
  color: #ff0000;
}
</style>
