const Setting = {};
Setting.prototype = {
    defaultBorder: 0.1,
    defaultBorderColor: "#ccc",
    RectBgColor: "#f0f",
    RectWidth: 50,
    RectHeight: 30,
    CircleBgColor: "#48D1CC",
    CircleRadius: 26, //圆的半径
    CircleHoverBgColor: "#40E0D0",
    CircleSelectColor: "#5CACEE",
    CircleTextColor: "#333", // 圆正常时的字体颜色
    CircleTextHoverColor: "#4876FF", // 圆悬停时的字体颜色
    CircleTextSelectColor: "#8B008B", // 圆选中时的字体颜色
    CircleTextFont: "12", // 圆正常时的字体大小
    CircleTextSelectFont: "18", // 圆选中时的字体大小
    lineWidth: 1, //线的宽度
    LineColor: "#333", //线的正常颜色
    lineSelectWidth: 2, //线被选中时的宽度
    lineSelectColor: "#0fff00", //线被选中时的颜色
    lineHoverColor: "#9AFF9A", //鼠标经过线时的颜色
    lineLabelWidth: 50, //线label矩形的宽度
    lineLabelHeight: 10, //线label矩形的高度
    lineLabelBg: "#FFFFFF", //线label的背景
    lineTextMaxLength: 5, //线label文字最大长度length
    lineLabelText: "#333", //线label字体颜色 正常时
    lineLabelTextFont: "14", //线label字体大小 正常时
    lineLabelTextSelectFont: "18", //线label字体大小 选中时
    hoverElementId: 0, //当时鼠标经过的元素的id
    SelectElementId: 0, //当前被选中元素的id
    bevel: 10, // 箭头边长
    bevelAngle: Math.PI / 4 //箭头两边夹角
};
export default Setting;