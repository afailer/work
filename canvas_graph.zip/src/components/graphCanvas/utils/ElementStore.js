export function ElementStore() {}
ElementStore.prototype = {
    elements: [],
    circleDatas: [],
    info: {},
    oldNodeId: "",
    addCircles: function(datas) {
        ElementStore.prototype.circleDatas = ElementStore.prototype.circleDatas.concat(
            datas
        );
    },
    saveLines: function(lines) {
        ElementStore.prototype.elements.splice(0, 0, ...lines);
    },
    saveElement: ele => {
        ElementStore.prototype.elements.push(ele);
    },
    getElements: type => {
        let eles = [];
        for (let l = 0; l < ElementStore.prototype.elements.length; l++) {
            if (ElementStore.prototype.elements[l].data.type == type) {
                eles.push(ElementStore.prototype.elements[l]);
            }
        }
        return eles;
    },
    resetData: () => {
        for (let l = 0; l < ElementStore.prototype.elements.length; l++) {
            if (ElementStore.prototype.elements[l].data.eleType == "circle") {
                ElementStore.prototype.elements[l].data.x = parseInt(
                    50 + Math.random() * 700
                );
                ElementStore.prototype.elements[l].data.y = parseInt(
                    50 + Math.random() * 700
                );
                ElementStore.prototype.elements[l].old_x =
                    ElementStore.prototype.elements[l].data.x;
                ElementStore.prototype.elements[l].old_y =
                    ElementStore.prototype.elements[l].data.y;
            }
        }
    }
};