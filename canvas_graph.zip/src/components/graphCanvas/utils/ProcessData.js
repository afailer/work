const ProcessData = {};
ProcessData.getCircleDatas = function(nodes) {
    let circles = [];
    for (let l = 0; l < nodes.length; l++) {
        let c = {};
        c.eleType = "circle";
        c.x = Math.ceil(50 + Math.random() * 700);
        c.y = Math.ceil(50 + Math.random() * 700);
        c.width = 0;
        c.height = 0;
        if (nodes[l].name.length > 5) {
            nodes[l].name = nodes[l].name.substring(0, 4) + "...";
        }
        c.name = nodes[l].name;
        Object.assign(c, nodes[l]);
        circles.push(c);
    }
    return circles;
};
ProcessData.addCircleDatas = function(nodes, lastdata) {
    let circles = [];
    for (let l = 0; l < nodes.length; l++) {
        let c = {};
        c.eleType = "circle";
        c.x = lastdata.x + Math.ceil(Math.random() * 50);
        c.y = lastdata.y + Math.ceil(Math.random() * 50);
        c.width = 0;
        c.height = 0;
        if (nodes[l].name.length > 5) {
            nodes[l].name = nodes[l].name.substring(0, 4) + "...";
        }
        c.name = nodes[l].name;
        Object.assign(c, nodes[l]);
        circles.push(c);
    }
    return circles;
};
ProcessData.getRectDatas = function(nodes) {
    let rects = [];
    for (let l = 0; l < nodes.length; l++) {
        let rect = {};
        rect.eleType = "rect";
        rect.x = 50 + Math.random() * 700;
        rect.y = 50 + Math.random() * 700;
        rect.radius = 20;
        rect.width = 50;
        rect.height = 30;
        Object.assign(rect, nodes[l]);
        rects.push(rect);
    }
    return rects;
};
ProcessData.getLineDatas = (nodes, relations) => {
    let lines = [];
    for (let l = 0; l < relations.length; l++) {
        let line = {};
        line.eleType = ProcessData.getLineType(relations[l], relations);
        let beginPointIndex = ProcessData.getTargetPoint(
            nodes,
            relations[l].startNode
        );
        let endPointIndex = ProcessData.getTargetPoint(nodes, relations[l].endNode);
        if (beginPointIndex == -1 || endPointIndex == -1) {
            alert("-1");
        }
        line.beginPoint = nodes[beginPointIndex];
        line.endPoint = nodes[endPointIndex];
        line.rel = relations[l].type;
        Object.assign(line, relations[l]);
        lines.push(line);
    }
    return lines;
};
ProcessData.getTargetPoint = function(nodes, id) {
    for (let l = 0; l < nodes.length; l++) {
        if (nodes[l].id === id) {
            return l;
        }
    }
    return -1;
};
ProcessData.getLineType = function(rel, relations) {
    for (let l = 0; l < relations.length; l++) {
        if (
            relations[l].endNode == rel.startNode &&
            relations[l].startNode == rel.endNode
        ) {
            return "BezierLine";
        }
    }
    return "line";
};
ProcessData.test = function() {
    alert("datas");
};
export default ProcessData;