import { CircleElement } from "../elements/CircleElement";
import { RectElement } from "../elements/RectElement";
import { LineElement } from "../elements/LineElement";
import { ElementStore } from "./ElementStore";
import { BezierLineElement } from "../elements/BezierLineElement";
import { format } from "util";

export function ElementCreator() {}
ElementCreator.prototype = {
    eleTypes: {
        circle: function(data) {
            return new CircleElement(data);
        },
        rect: function(data) {
            return new RectElement(data);
        },
        line: function(data) {
            return new LineElement(data);
        },
        BezierLine: function(data) {
            return new BezierLineElement(data);
        }
    },
    addElement: function(data) {
        ElementStore.prototype.saveElement(
            ElementCreator.prototype.eleTypes[data.eleType](data)
        );
    },
    addLines: function(datas) {
        let lines = [];
        for (let l = 0; l < datas.length; l++) {
            lines.push(ElementCreator.prototype.eleTypes[datas[l].eleType](datas[l]));
        }
        ElementStore.prototype.saveLines(lines);
    },
    addElements: function(datas) {
        for (let l = 0; l < datas.length; l++) {
            ElementCreator.prototype.addElement(datas[l]);
        }
    }
};