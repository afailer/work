<template>
  <div class="canvas-container">
    
    <p ref="info" class="info">{{src}}</p>
    
    <el-form ref="form" class="elform" :model="form" label-width="100px">
      <el-form-item label="BrowseName">
        <el-input v-model="form.BrowseName"></el-input>
      </el-form-item>
      <el-form-item label="Description">
        <el-input v-model="form.Description"></el-input>
      </el-form-item>
      <el-form-item label="DisplayName">
        <el-input v-model="form.Description"></el-input>
      </el-form-item>
      <el-form-item label="NodeClass">
        <el-input v-model="form.NodeClass"></el-input>
      </el-form-item>
    </el-form>
    <div class="canvas" ref="canvas_con">
      <span class="iconfont icon-fanhui backStart" @click="backToStart"></span>
      <canvas ref="canvas" width="800" height="800" ></canvas>
    </div>
    
  </div>
</template>

<script>
import { RoleController } from "./roleHandler/RoleController";
import { EventHandler } from "./roleHandler/EventHandler";
import { ElementCreator } from "./roleHandler/ElementCreator";
import ProcessData from "./roleHandler/ProcessData";
import { ElementStore } from "./roleHandler/ElementStore";
import axios from "axios";
export default {
  name: "CanvasDemo",
  data() {
    return {
      src: "",
      form: {},
      currentCircle: "",
      nodes: [
        {
          id: 6,
          name: "6b"
        },
        {
          id: 7,
          name: "7b"
        }
      ],
      relationships: [
        {
          id: 425,
          startNode: 6,
          endNode: 7,
          rel: "5friends"
        },
        {
          id: 416,
          startNode: 7,
          endNode: 6,
          rel: "5friends"
        }
      ],
      elements: [
        {
          type: "rect",
          bg: "#ff0",
          border: "#f0f",
          name: "dsf"
        }
      ],
      circleDatas: [],
      roleCtrl: ""
    };
  },
  methods: {
    getInitData() {
      getStartNodes()
        .then(res => {
          this.getNodesRels(res.data.result[0].uri);
        })
        .catch(rej => {});
    },
    getNodesRels(uri) {
      getNodesAndRel(uri)
        .then(res => {
          let newNodes = this.getNewDatas(res.data.nodes);
          let newRels = this.getNewDatas(res.data.relationships);
          this.addCircleEles(newNodes, newRels);
        })
        .catch(rej => {});
    },
    getNewDatas(datas) {
      //请求到的数据与本地数据进行比对
      let newDatas = [];
      for (let d = 0; d < datas.length; d++) {
        let isNew = true;
        for (let l = 0; l < ElementStore.prototype.elements.length; l++) {
          if (datas[d].id == ElementStore.prototype.elements[l].data.id) {
            isNew = false;
            break;
          }
        }
        if (isNew) {
          newDatas.push(datas[d]);
        }
      }
      if (newDatas.length == 0) {
        //alert("没有请求到新数据");
      }
      return newDatas;
    },
    addCircleEles(nodes, relationships) {
      let circleDatas = null;
      if (this.currentCircle != "") {
        circleDatas = ProcessData.addCircleDatas(nodes, this.currentCircle);
      } else {
        circleDatas = ProcessData.getCircleDatas(nodes);
      }
      this.circleDatas.splice(0, 0, ...circleDatas);
      ElementCreator.prototype.addElements(circleDatas);
      this.addLines(relationships);
    },
    addLines(relationships) {
      let lines = ProcessData.getLineDatas(this.circleDatas, relationships);
      //this.lines.splice(0, 0, ...lines);
      ElementCreator.prototype.addLines(lines);
    },
    backToStart() {
      this.roleCtrl.backToStart();
    },
    initCanvas() {
      document.oncontextmenu = new Function("event.returnValue=false;");
      document.onselectstart = new Function("event.returnValue=false;");
      this.roleCtrl = new RoleController(this.$refs.canvas);
      EventHandler.prototype.listen("loadNewData", data => {
        this.currentCircle = data;
        this.getNodesRels(data.id);
      });
      EventHandler.prototype.listen("showInfo", data => {
        if (data.eleType == "circle") {
          this.form = data.properties;
        } else {
          this.form = {};
        }
      });
      EventHandler.prototype.listen("showDetails", data => {
        if (data == false) {
          this.$refs.info.style.display = "none";
        } else {
          if (
            data.src == undefined &&
            (data.eleType == "line" || data.eleType == "BezierLine")
          ) {
            this.src = data.type;
            this.$refs.info.style.left =
              this.$refs.canvas_con.offsetLeft +
              parseInt((data.beginPoint.x + data.endPoint.x) / 2) +
              this.roleCtrl.translateX +
              "px";
            this.$refs.info.style.top =
              this.$refs.canvas_con.offsetTop +
              parseInt((data.beginPoint.y + data.endPoint.y) / 2) +
              this.roleCtrl.translateY +
              "px";
          } else {
            this.src = data.src;
            this.$refs.info.style.left =
              this.$refs.canvas_con.offsetLeft +
              parseInt(data.x) +
              this.roleCtrl.translateX +
              "px";
            this.$refs.info.style.top =
              this.$refs.canvas_con.offsetTop +
              parseInt(data.y) +
              this.roleCtrl.translateY +
              "px";
          }
          this.$refs.info.style.display = "block";
        }
      });
      EventHandler.prototype.listen("drag", (x, y, eventType) => {
        this.roleCtrl.onDrag(x, y, eventType);
      });
      window.addEventListener(
        "mouseup",
        event => EventHandler.prototype.handleMouseUp(event),
        false
      );
      this.$refs.canvas.addEventListener(
        "mousedown",
        event => EventHandler.prototype.handleMouseDown(event),
        false
      );
      this.$refs.canvas.addEventListener(
        "mousemove",
        event => EventHandler.prototype.handleMouseMove(event),
        false
      );
    },
    resetData() {
      let rects = ProcessData.getRectDatas(this.elements);
      ElementCreator.prototype.addElements(rects);
    }
  },
  mounted() {
    //this.addCircleEles(this.nodes, this.relationships);
    this.initCanvas();
    this.getInitData();
  }
};
</script>

<style scoped>
.canvas-container {
  position: relative;
  width: 100%;
  height: 100%;
}
.info {
  width: 300px;
  border-radius: 20px;
  border: 1px solid #333;
  position: absolute;
  word-break: break-all;
  left: 0px;
  display: none;
  z-index: 2;
  background: #ffffff;
  top: 0px;
}
.canvas {
  border: 1px dashed #ccc;
  float: right;
  position: relative;
}
.backStart {
  position: absolute;
  top: 30px;
  left: 30px;
  font-size: 30px;
}
.backStart:hover {
  color: #ff0000;
}
.elform {
  width: 25%;
  float: right;
}
</style>
