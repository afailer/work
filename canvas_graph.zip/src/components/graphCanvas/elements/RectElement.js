import { ElementCreator } from "../utils/ElementCreator";
import { EventHandler } from "../utils/EventHandler";
import { Util } from "../utils/Util";
export function RectElement(data) {
    this.old_x = data.x;
    this.old_y = data.y;
    this.isActive = false;
    this.data = data;
}
RectElement.prototype = {
    caculate: function(event) {
        let x = event.offsetX - (this.data.x - this.data.width / 2);
        let y = event.offsetY - (this.data.y - this.data.height / 2);
        if (x > 0 && x < this.data.width && y > 0 && y < this.data.height) {
            return true;
        }
    },
    draw: function(pen) {
        pen.beginPath(); //单起一个路径，不会被外部影响
        pen.lineWidth = 0.1;
        pen.rect(
            this.data.x - this.data.width / 2,
            this.data.y - this.data.height / 2,
            this.data.width,
            this.data.height
        );
        pen.fillStyle = this.data.bg;
        //pen.strokeStyle = this.data.border;
        pen.fill();
        pen.stroke();
    },
    update: function(event) {
        this.data.x = event.offsetX;
        this.data.y = event.offsetY;
        if (this.data.x - this.data.width / 2 < 0) {
            this.data.x = this.data.width / 2;
        }
        if (this.data.y - this.data.height / 2 < 0) {
            this.data.y = this.data.height / 2;
        }
    },
    onClick: function() {
        EventHandler.prototype.trigger("eleClick", "aaa");
    },
    living: function() {
        let vx = (this.data.x - this.old_x) * 0.92,
            vy = (this.data.y - this.old_y) * 0.92;
        this.old_x = this.data.x;
        this.old_y = this.data.y;
        if (!this.data.isActive) {
            this.data.x += vx;
            this.data.y += vy;
        }
        if (this.data.x - this.data.radius < 0) {
            this.data.x = this.data.radius;
            this.old_x = this.data.x + vx * 0.2;
        }
        if (this.data.y - this.data.radius < 0) {
            this.data.y = this.data.radius;
            this.old_y = this.data.y + vy * 0.2;
        }
        Util.prototype.changeTragetElement(this);
    }
};