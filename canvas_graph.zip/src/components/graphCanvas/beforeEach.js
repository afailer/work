import { mapState } from "vuex";
export default {
    data() {
        return {};
    },
    computed: {
        ...mapState(["isGraph"])
    },
    beforeRouteEnter: (to, from, next) => {
        next(vm => {
            if (!vm.isGraph) {
                next({ path: "/layout/model/default" });
            }
        });
        // if (vm.menus.length == 0) {
        //     vm.$router.push({
        //         path: "/sitemap"
        //     });
        // } else {
        //     next({ path: vm.menus[0].path });
        // }
    }
};